﻿namespace Litmus.forms.transactional_forms
{
    partial class frm_meltings
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tabMeltings = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.txtBSugarPurity = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.txtBSugarPol = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.txtBSugarBrix = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.txtBSugarTransDate = new System.Windows.Forms.DateTimePicker();
            this.label9 = new System.Windows.Forms.Label();
            this.txtBSugarTransTime = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.txtCSinglePurity = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.txtCSinglePol = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.txtCSingleBrix = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.txtCSugarTransDate = new System.Windows.Forms.DateTimePicker();
            this.label14 = new System.Windows.Forms.Label();
            this.txtCSingleSugarTransTime = new System.Windows.Forms.TextBox();
            this.label15 = new System.Windows.Forms.Label();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.txtCDoublePurity = new System.Windows.Forms.TextBox();
            this.label16 = new System.Windows.Forms.Label();
            this.txtCDoublePol = new System.Windows.Forms.TextBox();
            this.label17 = new System.Windows.Forms.Label();
            this.txtCDoubleBrix = new System.Windows.Forms.TextBox();
            this.label18 = new System.Windows.Forms.Label();
            this.txtCDoubleTransDate = new System.Windows.Forms.DateTimePicker();
            this.label19 = new System.Windows.Forms.Label();
            this.txtCDoubleTransTime = new System.Windows.Forms.TextBox();
            this.label20 = new System.Windows.Forms.Label();
            this.tabPage4 = new System.Windows.Forms.TabPage();
            this.txtMeltPurity = new System.Windows.Forms.TextBox();
            this.label21 = new System.Windows.Forms.Label();
            this.txtMeltPol = new System.Windows.Forms.TextBox();
            this.label22 = new System.Windows.Forms.Label();
            this.txtMeltBrix = new System.Windows.Forms.TextBox();
            this.label23 = new System.Windows.Forms.Label();
            this.txtMeltTransDate = new System.Windows.Forms.DateTimePicker();
            this.label24 = new System.Windows.Forms.Label();
            this.txtMeltTransTime = new System.Windows.Forms.TextBox();
            this.label25 = new System.Windows.Forms.Label();
            this.tabPage5 = new System.Windows.Forms.TabPage();
            this.txtDrySeedPurity = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.txtDrySeedPol = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.txtDrySeedBrix = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.txtDrySeedTransDate = new System.Windows.Forms.DateTimePicker();
            this.label6 = new System.Windows.Forms.Label();
            this.txtDrySeedTransTime = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.tabPage6 = new System.Windows.Forms.TabPage();
            this.txtDustCollectorPurity = new System.Windows.Forms.TextBox();
            this.label26 = new System.Windows.Forms.Label();
            this.txtDustCollectorPol = new System.Windows.Forms.TextBox();
            this.label27 = new System.Windows.Forms.Label();
            this.txtDustCollectorBrix = new System.Windows.Forms.TextBox();
            this.label28 = new System.Windows.Forms.Label();
            this.txtDustCollectorTransDate = new System.Windows.Forms.DateTimePicker();
            this.label29 = new System.Windows.Forms.Label();
            this.txtDustCollectorTransTime = new System.Windows.Forms.TextBox();
            this.label30 = new System.Windows.Forms.Label();
            this.btnModify = new System.Windows.Forms.Button();
            this.btnNewRecord = new System.Windows.Forms.Button();
            this.btnSave = new System.Windows.Forms.Button();
            this.btnClear = new System.Windows.Forms.Button();
            this.tabMeltings.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.tabPage3.SuspendLayout();
            this.tabPage4.SuspendLayout();
            this.tabPage5.SuspendLayout();
            this.tabPage6.SuspendLayout();
            this.SuspendLayout();
            // 
            // tabMeltings
            // 
            this.tabMeltings.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tabMeltings.Controls.Add(this.tabPage1);
            this.tabMeltings.Controls.Add(this.tabPage2);
            this.tabMeltings.Controls.Add(this.tabPage3);
            this.tabMeltings.Controls.Add(this.tabPage4);
            this.tabMeltings.Controls.Add(this.tabPage5);
            this.tabMeltings.Controls.Add(this.tabPage6);
            this.tabMeltings.Location = new System.Drawing.Point(1, 2);
            this.tabMeltings.Name = "tabMeltings";
            this.tabMeltings.SelectedIndex = 0;
            this.tabMeltings.Size = new System.Drawing.Size(723, 169);
            this.tabMeltings.TabIndex = 0;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.txtBSugarPurity);
            this.tabPage1.Controls.Add(this.label5);
            this.tabPage1.Controls.Add(this.txtBSugarPol);
            this.tabPage1.Controls.Add(this.label7);
            this.tabPage1.Controls.Add(this.txtBSugarBrix);
            this.tabPage1.Controls.Add(this.label8);
            this.tabPage1.Controls.Add(this.txtBSugarTransDate);
            this.tabPage1.Controls.Add(this.label9);
            this.tabPage1.Controls.Add(this.txtBSugarTransTime);
            this.tabPage1.Controls.Add(this.label10);
            this.tabPage1.Location = new System.Drawing.Point(4, 25);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(715, 140);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "B-Sugar";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // txtBSugarPurity
            // 
            this.txtBSugarPurity.Location = new System.Drawing.Point(545, 78);
            this.txtBSugarPurity.Name = "txtBSugarPurity";
            this.txtBSugarPurity.ReadOnly = true;
            this.txtBSugarPurity.Size = new System.Drawing.Size(100, 22);
            this.txtBSugarPurity.TabIndex = 32;
            this.txtBSugarPurity.Text = "0";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(489, 81);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(44, 17);
            this.label5.TabIndex = 33;
            this.label5.Text = "Purity";
            // 
            // txtBSugarPol
            // 
            this.txtBSugarPol.Location = new System.Drawing.Point(338, 78);
            this.txtBSugarPol.Name = "txtBSugarPol";
            this.txtBSugarPol.Size = new System.Drawing.Size(100, 22);
            this.txtBSugarPol.TabIndex = 3;
            this.txtBSugarPol.Text = "0";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(282, 81);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(40, 17);
            this.label7.TabIndex = 31;
            this.label7.Text = "Pol%";
            // 
            // txtBSugarBrix
            // 
            this.txtBSugarBrix.Location = new System.Drawing.Point(128, 75);
            this.txtBSugarBrix.Name = "txtBSugarBrix";
            this.txtBSugarBrix.Size = new System.Drawing.Size(100, 22);
            this.txtBSugarBrix.TabIndex = 2;
            this.txtBSugarBrix.Text = "0";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(72, 78);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(43, 17);
            this.label8.TabIndex = 29;
            this.label8.Text = "Brix%";
            // 
            // txtBSugarTransDate
            // 
            this.txtBSugarTransDate.CustomFormat = "yyyy-MM-dd";
            this.txtBSugarTransDate.Enabled = false;
            this.txtBSugarTransDate.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.txtBSugarTransDate.Location = new System.Drawing.Point(128, 27);
            this.txtBSugarTransDate.Name = "txtBSugarTransDate";
            this.txtBSugarTransDate.Size = new System.Drawing.Size(100, 22);
            this.txtBSugarTransDate.TabIndex = 27;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(36, 29);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(75, 17);
            this.label9.TabIndex = 26;
            this.label9.Text = "Entry Date";
            // 
            // txtBSugarTransTime
            // 
            this.txtBSugarTransTime.Location = new System.Drawing.Point(338, 26);
            this.txtBSugarTransTime.Name = "txtBSugarTransTime";
            this.txtBSugarTransTime.Size = new System.Drawing.Size(100, 22);
            this.txtBSugarTransTime.TabIndex = 1;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(282, 29);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(39, 17);
            this.label10.TabIndex = 25;
            this.label10.Text = "Time";
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.txtCSinglePurity);
            this.tabPage2.Controls.Add(this.label11);
            this.tabPage2.Controls.Add(this.txtCSinglePol);
            this.tabPage2.Controls.Add(this.label12);
            this.tabPage2.Controls.Add(this.txtCSingleBrix);
            this.tabPage2.Controls.Add(this.label13);
            this.tabPage2.Controls.Add(this.txtCSugarTransDate);
            this.tabPage2.Controls.Add(this.label14);
            this.tabPage2.Controls.Add(this.txtCSingleSugarTransTime);
            this.tabPage2.Controls.Add(this.label15);
            this.tabPage2.Location = new System.Drawing.Point(4, 25);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(715, 140);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "C-Single Sugar";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // txtCSinglePurity
            // 
            this.txtCSinglePurity.Location = new System.Drawing.Point(545, 78);
            this.txtCSinglePurity.Name = "txtCSinglePurity";
            this.txtCSinglePurity.ReadOnly = true;
            this.txtCSinglePurity.Size = new System.Drawing.Size(100, 22);
            this.txtCSinglePurity.TabIndex = 42;
            this.txtCSinglePurity.Text = "0";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(489, 81);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(44, 17);
            this.label11.TabIndex = 43;
            this.label11.Text = "Purity";
            // 
            // txtCSinglePol
            // 
            this.txtCSinglePol.Location = new System.Drawing.Point(338, 78);
            this.txtCSinglePol.Name = "txtCSinglePol";
            this.txtCSinglePol.Size = new System.Drawing.Size(100, 22);
            this.txtCSinglePol.TabIndex = 3;
            this.txtCSinglePol.Text = "0";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(282, 81);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(40, 17);
            this.label12.TabIndex = 41;
            this.label12.Text = "Pol%";
            // 
            // txtCSingleBrix
            // 
            this.txtCSingleBrix.Location = new System.Drawing.Point(128, 75);
            this.txtCSingleBrix.Name = "txtCSingleBrix";
            this.txtCSingleBrix.Size = new System.Drawing.Size(100, 22);
            this.txtCSingleBrix.TabIndex = 2;
            this.txtCSingleBrix.Text = "0";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(72, 78);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(43, 17);
            this.label13.TabIndex = 39;
            this.label13.Text = "Brix%";
            // 
            // txtCSugarTransDate
            // 
            this.txtCSugarTransDate.CustomFormat = "yyyy-MM-dd";
            this.txtCSugarTransDate.Enabled = false;
            this.txtCSugarTransDate.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.txtCSugarTransDate.Location = new System.Drawing.Point(128, 27);
            this.txtCSugarTransDate.Name = "txtCSugarTransDate";
            this.txtCSugarTransDate.Size = new System.Drawing.Size(100, 22);
            this.txtCSugarTransDate.TabIndex = 37;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(36, 29);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(75, 17);
            this.label14.TabIndex = 36;
            this.label14.Text = "Entry Date";
            // 
            // txtCSingleSugarTransTime
            // 
            this.txtCSingleSugarTransTime.Location = new System.Drawing.Point(338, 26);
            this.txtCSingleSugarTransTime.Name = "txtCSingleSugarTransTime";
            this.txtCSingleSugarTransTime.Size = new System.Drawing.Size(100, 22);
            this.txtCSingleSugarTransTime.TabIndex = 1;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(282, 29);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(39, 17);
            this.label15.TabIndex = 35;
            this.label15.Text = "Time";
            // 
            // tabPage3
            // 
            this.tabPage3.Controls.Add(this.txtCDoublePurity);
            this.tabPage3.Controls.Add(this.label16);
            this.tabPage3.Controls.Add(this.txtCDoublePol);
            this.tabPage3.Controls.Add(this.label17);
            this.tabPage3.Controls.Add(this.txtCDoubleBrix);
            this.tabPage3.Controls.Add(this.label18);
            this.tabPage3.Controls.Add(this.txtCDoubleTransDate);
            this.tabPage3.Controls.Add(this.label19);
            this.tabPage3.Controls.Add(this.txtCDoubleTransTime);
            this.tabPage3.Controls.Add(this.label20);
            this.tabPage3.Location = new System.Drawing.Point(4, 25);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage3.Size = new System.Drawing.Size(715, 140);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "C-Double Sugar";
            this.tabPage3.UseVisualStyleBackColor = true;
            // 
            // txtCDoublePurity
            // 
            this.txtCDoublePurity.Location = new System.Drawing.Point(545, 78);
            this.txtCDoublePurity.Name = "txtCDoublePurity";
            this.txtCDoublePurity.ReadOnly = true;
            this.txtCDoublePurity.Size = new System.Drawing.Size(100, 22);
            this.txtCDoublePurity.TabIndex = 42;
            this.txtCDoublePurity.TabStop = false;
            this.txtCDoublePurity.Text = "0";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(489, 81);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(44, 17);
            this.label16.TabIndex = 43;
            this.label16.Text = "Purity";
            // 
            // txtCDoublePol
            // 
            this.txtCDoublePol.Location = new System.Drawing.Point(338, 78);
            this.txtCDoublePol.Name = "txtCDoublePol";
            this.txtCDoublePol.Size = new System.Drawing.Size(100, 22);
            this.txtCDoublePol.TabIndex = 3;
            this.txtCDoublePol.Text = "0";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(282, 81);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(40, 17);
            this.label17.TabIndex = 41;
            this.label17.Text = "Pol%";
            // 
            // txtCDoubleBrix
            // 
            this.txtCDoubleBrix.Location = new System.Drawing.Point(128, 75);
            this.txtCDoubleBrix.Name = "txtCDoubleBrix";
            this.txtCDoubleBrix.Size = new System.Drawing.Size(100, 22);
            this.txtCDoubleBrix.TabIndex = 2;
            this.txtCDoubleBrix.Text = "0";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(72, 78);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(43, 17);
            this.label18.TabIndex = 39;
            this.label18.Text = "Brix%";
            // 
            // txtCDoubleTransDate
            // 
            this.txtCDoubleTransDate.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtCDoubleTransDate.CustomFormat = "yyyy-MM-dd";
            this.txtCDoubleTransDate.Enabled = false;
            this.txtCDoubleTransDate.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.txtCDoubleTransDate.Location = new System.Drawing.Point(128, 27);
            this.txtCDoubleTransDate.Name = "txtCDoubleTransDate";
            this.txtCDoubleTransDate.Size = new System.Drawing.Size(100, 22);
            this.txtCDoubleTransDate.TabIndex = 37;
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(36, 29);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(75, 17);
            this.label19.TabIndex = 36;
            this.label19.Text = "Entry Date";
            // 
            // txtCDoubleTransTime
            // 
            this.txtCDoubleTransTime.Location = new System.Drawing.Point(338, 26);
            this.txtCDoubleTransTime.Name = "txtCDoubleTransTime";
            this.txtCDoubleTransTime.Size = new System.Drawing.Size(100, 22);
            this.txtCDoubleTransTime.TabIndex = 1;
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(282, 29);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(39, 17);
            this.label20.TabIndex = 35;
            this.label20.Text = "Time";
            // 
            // tabPage4
            // 
            this.tabPage4.Controls.Add(this.txtMeltPurity);
            this.tabPage4.Controls.Add(this.label21);
            this.tabPage4.Controls.Add(this.txtMeltPol);
            this.tabPage4.Controls.Add(this.label22);
            this.tabPage4.Controls.Add(this.txtMeltBrix);
            this.tabPage4.Controls.Add(this.label23);
            this.tabPage4.Controls.Add(this.txtMeltTransDate);
            this.tabPage4.Controls.Add(this.label24);
            this.tabPage4.Controls.Add(this.txtMeltTransTime);
            this.tabPage4.Controls.Add(this.label25);
            this.tabPage4.Location = new System.Drawing.Point(4, 25);
            this.tabPage4.Name = "tabPage4";
            this.tabPage4.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage4.Size = new System.Drawing.Size(715, 140);
            this.tabPage4.TabIndex = 3;
            this.tabPage4.Text = "Melt";
            this.tabPage4.UseVisualStyleBackColor = true;
            // 
            // txtMeltPurity
            // 
            this.txtMeltPurity.Location = new System.Drawing.Point(545, 78);
            this.txtMeltPurity.Name = "txtMeltPurity";
            this.txtMeltPurity.ReadOnly = true;
            this.txtMeltPurity.Size = new System.Drawing.Size(100, 22);
            this.txtMeltPurity.TabIndex = 42;
            this.txtMeltPurity.TabStop = false;
            this.txtMeltPurity.Text = "0";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(489, 81);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(44, 17);
            this.label21.TabIndex = 43;
            this.label21.Text = "Purity";
            // 
            // txtMeltPol
            // 
            this.txtMeltPol.Location = new System.Drawing.Point(338, 78);
            this.txtMeltPol.Name = "txtMeltPol";
            this.txtMeltPol.Size = new System.Drawing.Size(100, 22);
            this.txtMeltPol.TabIndex = 3;
            this.txtMeltPol.Text = "0";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Location = new System.Drawing.Point(282, 81);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(40, 17);
            this.label22.TabIndex = 41;
            this.label22.Text = "Pol%";
            // 
            // txtMeltBrix
            // 
            this.txtMeltBrix.Location = new System.Drawing.Point(128, 75);
            this.txtMeltBrix.Name = "txtMeltBrix";
            this.txtMeltBrix.Size = new System.Drawing.Size(100, 22);
            this.txtMeltBrix.TabIndex = 2;
            this.txtMeltBrix.Text = "0";
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Location = new System.Drawing.Point(72, 78);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(43, 17);
            this.label23.TabIndex = 39;
            this.label23.Text = "Brix%";
            // 
            // txtMeltTransDate
            // 
            this.txtMeltTransDate.CustomFormat = "yyyy-MM-dd";
            this.txtMeltTransDate.Enabled = false;
            this.txtMeltTransDate.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.txtMeltTransDate.Location = new System.Drawing.Point(128, 27);
            this.txtMeltTransDate.Name = "txtMeltTransDate";
            this.txtMeltTransDate.Size = new System.Drawing.Size(100, 22);
            this.txtMeltTransDate.TabIndex = 37;
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Location = new System.Drawing.Point(36, 29);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(75, 17);
            this.label24.TabIndex = 36;
            this.label24.Text = "Entry Date";
            // 
            // txtMeltTransTime
            // 
            this.txtMeltTransTime.Location = new System.Drawing.Point(338, 26);
            this.txtMeltTransTime.Name = "txtMeltTransTime";
            this.txtMeltTransTime.Size = new System.Drawing.Size(100, 22);
            this.txtMeltTransTime.TabIndex = 1;
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Location = new System.Drawing.Point(282, 29);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(39, 17);
            this.label25.TabIndex = 35;
            this.label25.Text = "Time";
            // 
            // tabPage5
            // 
            this.tabPage5.Controls.Add(this.txtDrySeedPurity);
            this.tabPage5.Controls.Add(this.label4);
            this.tabPage5.Controls.Add(this.txtDrySeedPol);
            this.tabPage5.Controls.Add(this.label2);
            this.tabPage5.Controls.Add(this.txtDrySeedBrix);
            this.tabPage5.Controls.Add(this.label1);
            this.tabPage5.Controls.Add(this.txtDrySeedTransDate);
            this.tabPage5.Controls.Add(this.label6);
            this.tabPage5.Controls.Add(this.txtDrySeedTransTime);
            this.tabPage5.Controls.Add(this.label3);
            this.tabPage5.Location = new System.Drawing.Point(4, 25);
            this.tabPage5.Name = "tabPage5";
            this.tabPage5.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage5.Size = new System.Drawing.Size(715, 140);
            this.tabPage5.TabIndex = 4;
            this.tabPage5.Text = "Dry Seed";
            this.tabPage5.UseVisualStyleBackColor = true;
            // 
            // txtDrySeedPurity
            // 
            this.txtDrySeedPurity.Location = new System.Drawing.Point(545, 78);
            this.txtDrySeedPurity.Name = "txtDrySeedPurity";
            this.txtDrySeedPurity.ReadOnly = true;
            this.txtDrySeedPurity.Size = new System.Drawing.Size(100, 22);
            this.txtDrySeedPurity.TabIndex = 22;
            this.txtDrySeedPurity.Text = "0";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(489, 81);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(44, 17);
            this.label4.TabIndex = 23;
            this.label4.Text = "Purity";
            // 
            // txtDrySeedPol
            // 
            this.txtDrySeedPol.Location = new System.Drawing.Point(338, 78);
            this.txtDrySeedPol.Name = "txtDrySeedPol";
            this.txtDrySeedPol.Size = new System.Drawing.Size(100, 22);
            this.txtDrySeedPol.TabIndex = 20;
            this.txtDrySeedPol.Text = "0";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(282, 81);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(40, 17);
            this.label2.TabIndex = 21;
            this.label2.Text = "Pol%";
            // 
            // txtDrySeedBrix
            // 
            this.txtDrySeedBrix.Location = new System.Drawing.Point(128, 75);
            this.txtDrySeedBrix.Name = "txtDrySeedBrix";
            this.txtDrySeedBrix.Size = new System.Drawing.Size(100, 22);
            this.txtDrySeedBrix.TabIndex = 18;
            this.txtDrySeedBrix.Text = "0";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(72, 78);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(43, 17);
            this.label1.TabIndex = 19;
            this.label1.Text = "Brix%";
            // 
            // txtDrySeedTransDate
            // 
            this.txtDrySeedTransDate.CustomFormat = "yyyy-MM-dd";
            this.txtDrySeedTransDate.Enabled = false;
            this.txtDrySeedTransDate.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.txtDrySeedTransDate.Location = new System.Drawing.Point(128, 27);
            this.txtDrySeedTransDate.Name = "txtDrySeedTransDate";
            this.txtDrySeedTransDate.Size = new System.Drawing.Size(100, 22);
            this.txtDrySeedTransDate.TabIndex = 17;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(36, 29);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(75, 17);
            this.label6.TabIndex = 16;
            this.label6.Text = "Entry Date";
            // 
            // txtDrySeedTransTime
            // 
            this.txtDrySeedTransTime.Location = new System.Drawing.Point(338, 26);
            this.txtDrySeedTransTime.Name = "txtDrySeedTransTime";
            this.txtDrySeedTransTime.Size = new System.Drawing.Size(100, 22);
            this.txtDrySeedTransTime.TabIndex = 1;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(282, 29);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(39, 17);
            this.label3.TabIndex = 15;
            this.label3.Text = "Time";
            // 
            // tabPage6
            // 
            this.tabPage6.Controls.Add(this.txtDustCollectorPurity);
            this.tabPage6.Controls.Add(this.label26);
            this.tabPage6.Controls.Add(this.txtDustCollectorPol);
            this.tabPage6.Controls.Add(this.label27);
            this.tabPage6.Controls.Add(this.txtDustCollectorBrix);
            this.tabPage6.Controls.Add(this.label28);
            this.tabPage6.Controls.Add(this.txtDustCollectorTransDate);
            this.tabPage6.Controls.Add(this.label29);
            this.tabPage6.Controls.Add(this.txtDustCollectorTransTime);
            this.tabPage6.Controls.Add(this.label30);
            this.tabPage6.Location = new System.Drawing.Point(4, 25);
            this.tabPage6.Name = "tabPage6";
            this.tabPage6.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage6.Size = new System.Drawing.Size(715, 140);
            this.tabPage6.TabIndex = 5;
            this.tabPage6.Text = "Dust Collector";
            this.tabPage6.UseVisualStyleBackColor = true;
            // 
            // txtDustCollectorPurity
            // 
            this.txtDustCollectorPurity.Location = new System.Drawing.Point(545, 78);
            this.txtDustCollectorPurity.Name = "txtDustCollectorPurity";
            this.txtDustCollectorPurity.ReadOnly = true;
            this.txtDustCollectorPurity.Size = new System.Drawing.Size(100, 22);
            this.txtDustCollectorPurity.TabIndex = 32;
            this.txtDustCollectorPurity.Text = "0";
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Location = new System.Drawing.Point(489, 81);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(44, 17);
            this.label26.TabIndex = 33;
            this.label26.Text = "Purity";
            // 
            // txtDustCollectorPol
            // 
            this.txtDustCollectorPol.Location = new System.Drawing.Point(338, 78);
            this.txtDustCollectorPol.Name = "txtDustCollectorPol";
            this.txtDustCollectorPol.Size = new System.Drawing.Size(100, 22);
            this.txtDustCollectorPol.TabIndex = 30;
            this.txtDustCollectorPol.Text = "0";
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Location = new System.Drawing.Point(282, 81);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(40, 17);
            this.label27.TabIndex = 31;
            this.label27.Text = "Pol%";
            // 
            // txtDustCollectorBrix
            // 
            this.txtDustCollectorBrix.Location = new System.Drawing.Point(128, 75);
            this.txtDustCollectorBrix.Name = "txtDustCollectorBrix";
            this.txtDustCollectorBrix.Size = new System.Drawing.Size(100, 22);
            this.txtDustCollectorBrix.TabIndex = 28;
            this.txtDustCollectorBrix.Text = "0";
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Location = new System.Drawing.Point(72, 78);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(43, 17);
            this.label28.TabIndex = 29;
            this.label28.Text = "Brix%";
            // 
            // txtDustCollectorTransDate
            // 
            this.txtDustCollectorTransDate.CustomFormat = "yyyy-MM-dd";
            this.txtDustCollectorTransDate.Enabled = false;
            this.txtDustCollectorTransDate.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.txtDustCollectorTransDate.Location = new System.Drawing.Point(128, 27);
            this.txtDustCollectorTransDate.Name = "txtDustCollectorTransDate";
            this.txtDustCollectorTransDate.Size = new System.Drawing.Size(100, 22);
            this.txtDustCollectorTransDate.TabIndex = 27;
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Location = new System.Drawing.Point(36, 29);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(75, 17);
            this.label29.TabIndex = 26;
            this.label29.Text = "Entry Date";
            // 
            // txtDustCollectorTransTime
            // 
            this.txtDustCollectorTransTime.Location = new System.Drawing.Point(338, 26);
            this.txtDustCollectorTransTime.Name = "txtDustCollectorTransTime";
            this.txtDustCollectorTransTime.Size = new System.Drawing.Size(100, 22);
            this.txtDustCollectorTransTime.TabIndex = 24;
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Location = new System.Drawing.Point(282, 29);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(39, 17);
            this.label30.TabIndex = 25;
            this.label30.Text = "Time";
            // 
            // btnModify
            // 
            this.btnModify.Enabled = false;
            this.btnModify.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnModify.Location = new System.Drawing.Point(503, 177);
            this.btnModify.Name = "btnModify";
            this.btnModify.Size = new System.Drawing.Size(105, 31);
            this.btnModify.TabIndex = 37;
            this.btnModify.Text = "MODIFY";
            this.btnModify.UseVisualStyleBackColor = true;
            // 
            // btnNewRecord
            // 
            this.btnNewRecord.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnNewRecord.Location = new System.Drawing.Point(281, 177);
            this.btnNewRecord.Name = "btnNewRecord";
            this.btnNewRecord.Size = new System.Drawing.Size(105, 31);
            this.btnNewRecord.TabIndex = 35;
            this.btnNewRecord.Text = "&New Record";
            this.btnNewRecord.UseVisualStyleBackColor = true;
            this.btnNewRecord.Click += new System.EventHandler(this.btnNewRecord_Click);
            // 
            // btnSave
            // 
            this.btnSave.Enabled = false;
            this.btnSave.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnSave.Location = new System.Drawing.Point(392, 177);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(105, 31);
            this.btnSave.TabIndex = 4;
            this.btnSave.Text = "&Save";
            this.btnSave.UseVisualStyleBackColor = true;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // btnClear
            // 
            this.btnClear.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnClear.Location = new System.Drawing.Point(614, 177);
            this.btnClear.Name = "btnClear";
            this.btnClear.Size = new System.Drawing.Size(105, 31);
            this.btnClear.TabIndex = 36;
            this.btnClear.Text = "&Clear";
            this.btnClear.UseVisualStyleBackColor = true;
            this.btnClear.Click += new System.EventHandler(this.btnClear_Click);
            // 
            // frm_meltings
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(733, 214);
            this.Controls.Add(this.btnModify);
            this.Controls.Add(this.btnNewRecord);
            this.Controls.Add(this.btnSave);
            this.Controls.Add(this.btnClear);
            this.Controls.Add(this.tabMeltings);
            this.Name = "frm_meltings";
            this.Text = "frm_meltings";
            this.tabMeltings.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            this.tabPage3.ResumeLayout(false);
            this.tabPage3.PerformLayout();
            this.tabPage4.ResumeLayout(false);
            this.tabPage4.PerformLayout();
            this.tabPage5.ResumeLayout(false);
            this.tabPage5.PerformLayout();
            this.tabPage6.ResumeLayout(false);
            this.tabPage6.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl tabMeltings;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.TabPage tabPage4;
        private System.Windows.Forms.TabPage tabPage5;
        private System.Windows.Forms.TextBox txtDrySeedPurity;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txtDrySeedPol;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtDrySeedBrix;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.DateTimePicker txtDrySeedTransDate;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox txtDrySeedTransTime;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button btnModify;
        private System.Windows.Forms.Button btnNewRecord;
        private System.Windows.Forms.Button btnSave;
        private System.Windows.Forms.Button btnClear;
        private System.Windows.Forms.TextBox txtBSugarPurity;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txtBSugarPol;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox txtBSugarBrix;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.DateTimePicker txtBSugarTransDate;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox txtBSugarTransTime;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox txtCSinglePurity;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox txtCSinglePol;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox txtCSingleBrix;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.DateTimePicker txtCSugarTransDate;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.TextBox txtCSingleSugarTransTime;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.TextBox txtCDoublePurity;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.TextBox txtCDoublePol;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.TextBox txtCDoubleBrix;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.DateTimePicker txtCDoubleTransDate;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.TextBox txtCDoubleTransTime;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.TextBox txtMeltPurity;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.TextBox txtMeltPol;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.TextBox txtMeltBrix;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.DateTimePicker txtMeltTransDate;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.TextBox txtMeltTransTime;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.TabPage tabPage6;
        private System.Windows.Forms.TextBox txtDustCollectorPurity;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.TextBox txtDustCollectorPol;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.TextBox txtDustCollectorBrix;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.DateTimePicker txtDustCollectorTransDate;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.TextBox txtDustCollectorTransTime;
        private System.Windows.Forms.Label label30;
    }
}