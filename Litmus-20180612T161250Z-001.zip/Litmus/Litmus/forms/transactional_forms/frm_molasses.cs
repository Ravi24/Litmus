﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
namespace Litmus.forms.transactional_forms
{
    public partial class frm_molasses : Form
    {
        #region variable declaration
        float mol_brix, mol_pol, mol_purity;
        string trans_date, trans_time;
        string current_user;
        int mol_code = 25;
        #endregion
        classes.generalFunctions genFunc = new classes.generalFunctions();
        classes.ExceptionHelper expHelper = new classes.ExceptionHelper();
        classes.master_parameter_logic masterParam = new classes.master_parameter_logic();
        classes.molasses_logic molasses_logic = new classes.molasses_logic();

        public frm_molasses()
        {
            InitializeComponent();
            genFunc.disableFieldsInControl(TabMolasses);

            txtMolAHeavy_TranDate.Text = masterParam.entryDate;
            txtMolA1Heavy_TransDate.Text = masterParam.entryDate;
            txtMolBHeavy_trans_dateTime.Text = masterParam.entryDate;
            txtMolC1Heavy_transDate.Text = masterParam.entryDate;
            txtMolALight_transDate.Text = masterParam.entryDate;
            txtMolCHeavy_transDate.Text = masterParam.entryDate;
            txtMolCLight_transDate.Text = masterParam.entryDate;

            TabMolasses.SelectedIndexChanged += new EventHandler(MolassessMasterTabChanged);
            txtMolAHeavy_transTime.LostFocus += new EventHandler(convertToTime);
            txtMolA1Heavy_transTime.LostFocus += new EventHandler(convertToTime);
            txtMolBHeavy_transTime.LostFocus += new EventHandler(convertToTime);
            txtMolC1Heavy_transTime.LostFocus += new EventHandler(convertToTime);
            txtMolALight_transTime.LostFocus += new EventHandler(convertToTime);
            txtMolCHeavy_transTime.LostFocus += new EventHandler(convertToTime);
            txtMolCLight_transTime.LostFocus += new EventHandler(convertToTime);
            btnSave.GotFocus += new EventHandler(setAllInputToVariables);
       }

        private void convertToTime(object sender, EventArgs e)
        {
            TextBox tempText = (TextBox)sender;
            tempText.Text = genFunc.parseHourMinuteFormat(tempText.Text);
            genFunc.validate_hours_minutes(tempText,btnSave);

        }
        private void setAllInputToVariables(object sender, EventArgs e)
        {
            switch (TabMolasses.SelectedIndex)
            {
                case 0:
                    a_heavy_molasses();
                    break;
                case 1:
                    a1_heavy_molasses();
                    break;
                case 2:
                    b_heavy_molasses();
                    break;
                case 3:
                    c1_heavy_molasses();
                    break;
                case 4:
                    a_light_molasses();
                    break;
                case 5:
                    c_heavy_molasses();
                    break;
                case 6:
                    c_light_molasses();
                    break;
                default:
                    MessageBox.Show("Could not get Molasses code, kindly check master parameter types for molasess", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    break;
            }
        }
        
        private void MolassessMasterTabChanged(object sender, EventArgs e)
        {
            switch (TabMolasses.SelectedIndex)
            {
                case 0:
                    
                    break;
                case 1:
                    
                    break;
                case 2:
                    
                    break;
                case 3:
                    
                    break;
                case 4:
                    
                    break;
                case 5:
                    
                    break;
                case 6:
                    
                    break;
                default:
                    MessageBox.Show("Could not get Molasses code, kindly check master parameter types for molasess","Error",MessageBoxButtons.OK,MessageBoxIcon.Error);
                    break;
            }

            genFunc.disableFieldsInControl(TabMolasses);
            setTexBoxDefaultValues();
        }
        private void a_heavy_molasses()
        {
            mol_code = 25;
            trans_date = txtMolAHeavy_TranDate.Text;
            trans_time = txtMolAHeavy_transTime.Text;
            mol_brix = float.Parse(txtMolAHeavy_brix.Text);
            mol_pol = float.Parse(txtMolAHeavy_pol.Text);
            mol_purity = genFunc.calculate_purity(mol_pol, mol_brix);
            txtMolAHeavyPurity.Text = mol_purity.ToString();

        }
        private void a1_heavy_molasses()
        {
            mol_code = 26;
            trans_date = txtMolA1Heavy_TransDate.Text;
            trans_time = txtMolA1Heavy_transTime.Text;
            mol_brix = float.Parse(txtMolA1Heavy_brix.Text);
            mol_pol = float.Parse(txtMolA1Heavy_pol.Text);
            mol_purity = genFunc.calculate_purity(mol_pol, mol_brix);
            txtMolA1Heavy_Purity.Text = mol_purity.ToString();
        }
        private void b_heavy_molasses()
        {
            mol_code = 27;
            trans_date = txtMolBHeavy_trans_dateTime.Text;
            trans_time = txtMolBHeavy_transTime.Text;
            mol_brix = float.Parse(txtMolBHeavy_brix.Text);
            mol_pol = float.Parse(txtMolBHeavy_pol.Text);
            mol_purity = genFunc.calculate_purity(mol_pol, mol_brix);
            txtMolBHeavy_purity.Text = mol_purity.ToString();
           
        }
        private void c1_heavy_molasses()
        {
            mol_code = 28;
            trans_date = txtMolC1Heavy_transDate.Text;
            trans_time = txtMolC1Heavy_transTime.Text;
            mol_brix = float.Parse(txtMolC1Heavy_brix.Text);
            mol_pol = float.Parse(txtMolC1Heavy_pol.Text);
            mol_purity = genFunc.calculate_purity(mol_pol, mol_brix);
            txtMolC1Heavy_purity.Text = mol_purity.ToString();
        }
        private void a_light_molasses()
        {
            mol_code = 29;
            trans_date = txtMolALight_transDate.Text;
            trans_time = txtMolALight_transTime.Text;
            mol_brix = float.Parse(txtMolALight_brix.Text);
            mol_pol = float.Parse(txtMolALight_pol.Text);
            mol_purity = genFunc.calculate_purity(mol_pol, mol_brix);
            txtMolALight_purity.Text = mol_purity.ToString();
        }
        private void c_heavy_molasses()
        {
            mol_code = 30;
            trans_date = txtMolCHeavy_transDate.Text;
            trans_time = txtMolCHeavy_transTime.Text;
            mol_brix = float.Parse(txtMolCHeavy_brix.Text);
            mol_pol = float.Parse(txtMolCHeavy_pol.Text);
            mol_purity = genFunc.calculate_purity(mol_pol, mol_brix);
            txtMolCHeavy_purity.Text = mol_purity.ToString();
        }
        private void c_light_molasses()
        {
            mol_code = 38;
            trans_date = txtMolCLight_transDate.Text;
            trans_time = txtMolCLight_transTime.Text;
            mol_brix = float.Parse(txtMolCLight_brix.Text);
            mol_pol = float.Parse(txtMolCLight_pol.Text);
            mol_purity = genFunc.calculate_purity(mol_pol, mol_brix);
            txtMolCLight_purity.Text = mol_purity.ToString();
        }
        
        private void btnNewRecord_Click(object sender, EventArgs e)
        {
            genFunc.enableFieldsInControl(TabMolasses);
            btnSave.Enabled = true;
            btnClear.Enabled = true;
        }
        private void setTexBoxDefaultValues()
        {
            txtMolAHeavy_brix.Text = "0";
            txtMolAHeavy_pol.Text = "0";
            txtMolAHeavyPurity.Text = "0";
            
            txtMolAHeavy_transTime.Text = string.Empty;

            txtMolA1Heavy_brix.Text = "0";
            txtMolA1Heavy_pol.Text = "0";
            txtMolA1Heavy_Purity.Text = "0";
            txtMolA1Heavy_transTime.Text = string.Empty;

            txtMolBHeavy_brix.Text = "0";
            txtMolBHeavy_pol.Text = "0";
            txtMolBHeavy_purity.Text = "0";
            txtMolBHeavy_transTime.Text = string.Empty;

            txtMolC1Heavy_brix.Text = "0";
            txtMolC1Heavy_pol.Text = "0";
            txtMolC1Heavy_purity.Text = "0";
            txtMolC1Heavy_transTime.Text = string.Empty;

            txtMolCLight_brix.Text = "0";
            txtMolCLight_pol.Text = "0";
            txtMolCLight_purity.Text = "0";
            txtMolCLight_transTime.Text = string.Empty;

            txtMolALight_brix.Text = "0";
            txtMolALight_pol.Text = "0";
            txtMolALight_purity.Text = "0";
            txtMolALight_transTime.Text = string.Empty;
            txtMolCHeavy_brix.Text = "0";
            txtMolCHeavy_pol.Text = "0";
            txtMolCHeavy_purity.Text = "0";
            txtMolCHeavy_transTime.Text = string.Empty;
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
                saveMolassesData();
                setTexBoxDefaultValues();
             
        }
        private void saveMolassesData()
        {
            current_user = genFunc.userCode;
            molasses_logic.insert_molasses_data(trans_date, trans_time, mol_code, mol_brix, mol_pol, mol_purity, current_user);
            genFunc.disableFieldsInControl(TabMolasses);
            btnSave.Enabled = false;
            btnClear.Enabled = false;
            setTexBoxDefaultValues();
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            setTexBoxDefaultValues();
        }
    }
}
