﻿namespace Litmus.forms.transactional_forms
{
    partial class frm_massecuite_transactions
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.comboBoxMassecuite = new System.Windows.Forms.ComboBox();
            this.label10 = new System.Windows.Forms.Label();
            this.txtMassA_Trans_Time = new System.Windows.Forms.TextBox();
            this.lblDate = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.txtMassA_dateTimeTranDate = new System.Windows.Forms.DateTimePicker();
            this.groupBoxMassecuteEntries = new System.Windows.Forms.GroupBox();
            this.txtMassA_Brix = new System.Windows.Forms.TextBox();
            this.txtMassA_Purity = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.txtMassA_CrystNo = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.txtMassA_DropTime = new System.Windows.Forms.TextBox();
            this.txtMassA_Pol = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.txtMassA_StartTime = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.txtMassA_PanNo = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.txtMassA_HL = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.button5 = new System.Windows.Forms.Button();
            this.btnNewRecord = new System.Windows.Forms.Button();
            this.btnSave = new System.Windows.Forms.Button();
            this.btnClear = new System.Windows.Forms.Button();
            this.groupBox1.SuspendLayout();
            this.groupBoxMassecuteEntries.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.comboBoxMassecuite);
            this.groupBox1.Controls.Add(this.label10);
            this.groupBox1.Controls.Add(this.txtMassA_Trans_Time);
            this.groupBox1.Controls.Add(this.lblDate);
            this.groupBox1.Controls.Add(this.label9);
            this.groupBox1.Controls.Add(this.txtMassA_dateTimeTranDate);
            this.groupBox1.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.groupBox1.Location = new System.Drawing.Point(12, 12);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(844, 46);
            this.groupBox1.TabIndex = 15;
            this.groupBox1.TabStop = false;
            // 
            // comboBoxMassecuite
            // 
            this.comboBoxMassecuite.FormattingEnabled = true;
            this.comboBoxMassecuite.Location = new System.Drawing.Point(623, 12);
            this.comboBoxMassecuite.Name = "comboBoxMassecuite";
            this.comboBoxMassecuite.Size = new System.Drawing.Size(183, 24);
            this.comboBoxMassecuite.TabIndex = 2;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(443, 17);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(140, 17);
            this.label10.TabIndex = 11;
            this.label10.Text = "Massecuite Category";
            // 
            // txtMassA_Trans_Time
            // 
            this.txtMassA_Trans_Time.Location = new System.Drawing.Point(311, 14);
            this.txtMassA_Trans_Time.Name = "txtMassA_Trans_Time";
            this.txtMassA_Trans_Time.Size = new System.Drawing.Size(100, 22);
            this.txtMassA_Trans_Time.TabIndex = 1;
            // 
            // lblDate
            // 
            this.lblDate.AutoSize = true;
            this.lblDate.Location = new System.Drawing.Point(23, 15);
            this.lblDate.Name = "lblDate";
            this.lblDate.Size = new System.Drawing.Size(96, 17);
            this.lblDate.TabIndex = 7;
            this.lblDate.Text = "ENTRY DATE";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(257, 17);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(40, 17);
            this.label9.TabIndex = 6;
            this.label9.Text = "TIME";
            // 
            // txtMassA_dateTimeTranDate
            // 
            this.txtMassA_dateTimeTranDate.CustomFormat = "yyyy-MM-dd";
            this.txtMassA_dateTimeTranDate.Enabled = false;
            this.txtMassA_dateTimeTranDate.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.txtMassA_dateTimeTranDate.Location = new System.Drawing.Point(135, 15);
            this.txtMassA_dateTimeTranDate.Name = "txtMassA_dateTimeTranDate";
            this.txtMassA_dateTimeTranDate.Size = new System.Drawing.Size(100, 22);
            this.txtMassA_dateTimeTranDate.TabIndex = 1;
            // 
            // groupBoxMassecuteEntries
            // 
            this.groupBoxMassecuteEntries.Controls.Add(this.txtMassA_Brix);
            this.groupBoxMassecuteEntries.Controls.Add(this.txtMassA_Purity);
            this.groupBoxMassecuteEntries.Controls.Add(this.label6);
            this.groupBoxMassecuteEntries.Controls.Add(this.txtMassA_CrystNo);
            this.groupBoxMassecuteEntries.Controls.Add(this.label8);
            this.groupBoxMassecuteEntries.Controls.Add(this.label5);
            this.groupBoxMassecuteEntries.Controls.Add(this.label7);
            this.groupBoxMassecuteEntries.Controls.Add(this.txtMassA_DropTime);
            this.groupBoxMassecuteEntries.Controls.Add(this.txtMassA_Pol);
            this.groupBoxMassecuteEntries.Controls.Add(this.label4);
            this.groupBoxMassecuteEntries.Controls.Add(this.txtMassA_StartTime);
            this.groupBoxMassecuteEntries.Controls.Add(this.label3);
            this.groupBoxMassecuteEntries.Controls.Add(this.txtMassA_PanNo);
            this.groupBoxMassecuteEntries.Controls.Add(this.label2);
            this.groupBoxMassecuteEntries.Controls.Add(this.txtMassA_HL);
            this.groupBoxMassecuteEntries.Controls.Add(this.label1);
            this.groupBoxMassecuteEntries.Location = new System.Drawing.Point(12, 64);
            this.groupBoxMassecuteEntries.Name = "groupBoxMassecuteEntries";
            this.groupBoxMassecuteEntries.Size = new System.Drawing.Size(844, 164);
            this.groupBoxMassecuteEntries.TabIndex = 16;
            this.groupBoxMassecuteEntries.TabStop = false;
            // 
            // txtMassA_Brix
            // 
            this.txtMassA_Brix.Location = new System.Drawing.Point(311, 107);
            this.txtMassA_Brix.Name = "txtMassA_Brix";
            this.txtMassA_Brix.Size = new System.Drawing.Size(100, 22);
            this.txtMassA_Brix.TabIndex = 8;
            this.txtMassA_Brix.Text = "0";
            // 
            // txtMassA_Purity
            // 
            this.txtMassA_Purity.Enabled = false;
            this.txtMassA_Purity.Location = new System.Drawing.Point(707, 107);
            this.txtMassA_Purity.Name = "txtMassA_Purity";
            this.txtMassA_Purity.Size = new System.Drawing.Size(100, 22);
            this.txtMassA_Purity.TabIndex = 10;
            this.txtMassA_Purity.Text = "0";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(254, 110);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(43, 17);
            this.label6.TabIndex = 10;
            this.label6.Text = "Brix%";
            // 
            // txtMassA_CrystNo
            // 
            this.txtMassA_CrystNo.Location = new System.Drawing.Point(134, 107);
            this.txtMassA_CrystNo.Name = "txtMassA_CrystNo";
            this.txtMassA_CrystNo.Size = new System.Drawing.Size(100, 22);
            this.txtMassA_CrystNo.TabIndex = 7;
            this.txtMassA_CrystNo.Text = "0";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(649, 110);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(44, 17);
            this.label8.TabIndex = 8;
            this.label8.Text = "Purity";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(54, 110);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(66, 17);
            this.label5.TabIndex = 8;
            this.label5.Text = "Cryst No.";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(454, 110);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(40, 17);
            this.label7.TabIndex = 6;
            this.label7.Text = "Pol%";
            // 
            // txtMassA_DropTime
            // 
            this.txtMassA_DropTime.Location = new System.Drawing.Point(707, 43);
            this.txtMassA_DropTime.Name = "txtMassA_DropTime";
            this.txtMassA_DropTime.Size = new System.Drawing.Size(100, 22);
            this.txtMassA_DropTime.TabIndex = 6;
            this.txtMassA_DropTime.Text = "0";
            // 
            // txtMassA_Pol
            // 
            this.txtMassA_Pol.Location = new System.Drawing.Point(508, 107);
            this.txtMassA_Pol.Name = "txtMassA_Pol";
            this.txtMassA_Pol.Size = new System.Drawing.Size(100, 22);
            this.txtMassA_Pol.TabIndex = 9;
            this.txtMassA_Pol.Text = "0";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(619, 46);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(74, 17);
            this.label4.TabIndex = 6;
            this.label4.Text = "Drop Time";
            // 
            // txtMassA_StartTime
            // 
            this.txtMassA_StartTime.Location = new System.Drawing.Point(508, 43);
            this.txtMassA_StartTime.Name = "txtMassA_StartTime";
            this.txtMassA_StartTime.Size = new System.Drawing.Size(100, 22);
            this.txtMassA_StartTime.TabIndex = 5;
            this.txtMassA_StartTime.Text = "0";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(421, 46);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(73, 17);
            this.label3.TabIndex = 4;
            this.label3.Text = "Start Time";
            // 
            // txtMassA_PanNo
            // 
            this.txtMassA_PanNo.Location = new System.Drawing.Point(311, 43);
            this.txtMassA_PanNo.Name = "txtMassA_PanNo";
            this.txtMassA_PanNo.Size = new System.Drawing.Size(100, 22);
            this.txtMassA_PanNo.TabIndex = 4;
            this.txtMassA_PanNo.Text = "0";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(242, 46);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(55, 17);
            this.label2.TabIndex = 2;
            this.label2.Text = "Pan No";
            // 
            // txtMassA_HL
            // 
            this.txtMassA_HL.Location = new System.Drawing.Point(134, 43);
            this.txtMassA_HL.Name = "txtMassA_HL";
            this.txtMassA_HL.Size = new System.Drawing.Size(100, 22);
            this.txtMassA_HL.TabIndex = 3;
            this.txtMassA_HL.Text = "0";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(86, 46);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(34, 17);
            this.label1.TabIndex = 0;
            this.label1.Text = "H.L.";
            // 
            // button5
            // 
            this.button5.Enabled = false;
            this.button5.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.button5.Location = new System.Drawing.Point(640, 234);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(105, 31);
            this.button5.TabIndex = 29;
            this.button5.Text = "MODIFY";
            this.button5.UseVisualStyleBackColor = true;
            // 
            // btnNewRecord
            // 
            this.btnNewRecord.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnNewRecord.Location = new System.Drawing.Point(418, 234);
            this.btnNewRecord.Name = "btnNewRecord";
            this.btnNewRecord.Size = new System.Drawing.Size(105, 31);
            this.btnNewRecord.TabIndex = 27;
            this.btnNewRecord.Text = "&New Record";
            this.btnNewRecord.UseVisualStyleBackColor = true;
            this.btnNewRecord.Click += new System.EventHandler(this.btnNewRecord_Click);
            // 
            // btnSave
            // 
            this.btnSave.Enabled = false;
            this.btnSave.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnSave.Location = new System.Drawing.Point(529, 234);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(105, 31);
            this.btnSave.TabIndex = 26;
            this.btnSave.Text = "&Save";
            this.btnSave.UseVisualStyleBackColor = true;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // btnClear
            // 
            this.btnClear.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnClear.Location = new System.Drawing.Point(751, 234);
            this.btnClear.Name = "btnClear";
            this.btnClear.Size = new System.Drawing.Size(105, 31);
            this.btnClear.TabIndex = 28;
            this.btnClear.Text = "&Clear";
            this.btnClear.UseVisualStyleBackColor = true;
            // 
            // frm_massecuite_transactions
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(876, 271);
            this.Controls.Add(this.button5);
            this.Controls.Add(this.btnNewRecord);
            this.Controls.Add(this.btnSave);
            this.Controls.Add(this.btnClear);
            this.Controls.Add(this.groupBoxMassecuteEntries);
            this.Controls.Add(this.groupBox1);
            this.Name = "frm_massecuite_transactions";
            this.Text = "frm_massecuite_transactions";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBoxMassecuteEntries.ResumeLayout(false);
            this.groupBoxMassecuteEntries.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TextBox txtMassA_Trans_Time;
        private System.Windows.Forms.Label lblDate;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.DateTimePicker txtMassA_dateTimeTranDate;
        private System.Windows.Forms.ComboBox comboBoxMassecuite;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.GroupBox groupBoxMassecuteEntries;
        private System.Windows.Forms.TextBox txtMassA_Brix;
        private System.Windows.Forms.TextBox txtMassA_Purity;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox txtMassA_CrystNo;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox txtMassA_DropTime;
        private System.Windows.Forms.TextBox txtMassA_Pol;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txtMassA_StartTime;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtMassA_PanNo;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtMassA_HL;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Button btnNewRecord;
        private System.Windows.Forms.Button btnSave;
        private System.Windows.Forms.Button btnClear;
    }
}