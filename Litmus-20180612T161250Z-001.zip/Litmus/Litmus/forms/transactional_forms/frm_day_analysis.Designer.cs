﻿namespace Litmus.forms.transactional_forms
{
    partial class frm_day_analysis
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.txtFarmCana = new System.Windows.Forms.Label();
            this.txtCaneFarm = new System.Windows.Forms.TextBox();
            this.label110 = new System.Windows.Forms.Label();
            this.txtCaneCrushed = new System.Windows.Forms.TextBox();
            this.label103 = new System.Windows.Forms.Label();
            this.txtCaneCentre = new System.Windows.Forms.TextBox();
            this.label102 = new System.Windows.Forms.Label();
            this.txtCaneGate = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.txtReject = new System.Windows.Forms.TextBox();
            this.txtEarly = new System.Windows.Forms.TextBox();
            this.txtGeneral = new System.Windows.Forms.TextBox();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.txtJuice = new System.Windows.Forms.TextBox();
            this.txtSpGrvity = new System.Windows.Forms.TextBox();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.label7 = new System.Windows.Forms.Label();
            this.txtWater = new System.Windows.Forms.TextBox();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.label4 = new System.Windows.Forms.Label();
            this.txtPressCake = new System.Windows.Forms.TextBox();
            this.groupBox6 = new System.Windows.Forms.GroupBox();
            this.label8 = new System.Windows.Forms.Label();
            this.txtMolassesSentOut = new System.Windows.Forms.TextBox();
            this.groupBox7 = new System.Windows.Forms.GroupBox();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.txtBissSugar = new System.Windows.Forms.TextBox();
            this.txtBissMolasses = new System.Windows.Forms.TextBox();
            this.groupBox8 = new System.Windows.Forms.GroupBox();
            this.label9 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.txtScrapSugar = new System.Windows.Forms.TextBox();
            this.txtScrapMolasses = new System.Windows.Forms.TextBox();
            this.groupBox9 = new System.Windows.Forms.GroupBox();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.txtMoistSugar = new System.Windows.Forms.TextBox();
            this.txtMoistMolasses = new System.Windows.Forms.TextBox();
            this.groupBox10 = new System.Windows.Forms.GroupBox();
            this.label15 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.txtRawSugar = new System.Windows.Forms.TextBox();
            this.txtRawMolasses = new System.Windows.Forms.TextBox();
            this.groupBox11 = new System.Windows.Forms.GroupBox();
            this.label17 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.txtOtherSugar = new System.Windows.Forms.TextBox();
            this.txtOtherMolasses = new System.Windows.Forms.TextBox();
            this.groupBox12 = new System.Windows.Forms.GroupBox();
            this.label19 = new System.Windows.Forms.Label();
            this.txtUnknownLosses = new System.Windows.Forms.TextBox();
            this.groupBox13 = new System.Windows.Forms.GroupBox();
            this.label20 = new System.Windows.Forms.Label();
            this.txtDirtCorrection = new System.Windows.Forms.TextBox();
            this.groupBox14 = new System.Windows.Forms.GroupBox();
            this.label30 = new System.Windows.Forms.Label();
            this.txtStorePhosphoric = new System.Windows.Forms.TextBox();
            this.label29 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.txtStoreBoilerChemical = new System.Windows.Forms.TextBox();
            this.txtStoreBioeide = new System.Windows.Forms.TextBox();
            this.label23 = new System.Windows.Forms.Label();
            this.txtStoreViscocty = new System.Windows.Forms.TextBox();
            this.label28 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.txtStoreLubGreece = new System.Windows.Forms.TextBox();
            this.label22 = new System.Windows.Forms.Label();
            this.txtStoreSulpher = new System.Windows.Forms.TextBox();
            this.label27 = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.txtStoreLime = new System.Windows.Forms.TextBox();
            this.txtStoreLubOil = new System.Windows.Forms.TextBox();
            this.txtStoreColorReducer = new System.Windows.Forms.TextBox();
            this.label26 = new System.Windows.Forms.Label();
            this.txtStoreMegnafloe = new System.Windows.Forms.TextBox();
            this.groupBox15 = new System.Windows.Forms.GroupBox();
            this.label34 = new System.Windows.Forms.Label();
            this.txtIcumsaS30 = new System.Windows.Forms.TextBox();
            this.label35 = new System.Windows.Forms.Label();
            this.label36 = new System.Windows.Forms.Label();
            this.txtIcumsaL30 = new System.Windows.Forms.TextBox();
            this.txtIcumsaM30 = new System.Windows.Forms.TextBox();
            this.label33 = new System.Windows.Forms.Label();
            this.txtIcumsaS31 = new System.Windows.Forms.TextBox();
            this.label31 = new System.Windows.Forms.Label();
            this.label32 = new System.Windows.Forms.Label();
            this.txtIcumsaL31 = new System.Windows.Forms.TextBox();
            this.txtIcumsaM31 = new System.Windows.Forms.TextBox();
            this.groupBox16 = new System.Windows.Forms.GroupBox();
            this.label37 = new System.Windows.Forms.Label();
            this.txtForeignS30 = new System.Windows.Forms.TextBox();
            this.label38 = new System.Windows.Forms.Label();
            this.label39 = new System.Windows.Forms.Label();
            this.txtForeignL30 = new System.Windows.Forms.TextBox();
            this.txtForeignM30 = new System.Windows.Forms.TextBox();
            this.label40 = new System.Windows.Forms.Label();
            this.txtForeignS31 = new System.Windows.Forms.TextBox();
            this.label41 = new System.Windows.Forms.Label();
            this.label42 = new System.Windows.Forms.Label();
            this.txtForeIgnL31 = new System.Windows.Forms.TextBox();
            this.txtForeignM31 = new System.Windows.Forms.TextBox();
            this.groupBox17 = new System.Windows.Forms.GroupBox();
            this.label43 = new System.Windows.Forms.Label();
            this.txtRetentionS30 = new System.Windows.Forms.TextBox();
            this.label44 = new System.Windows.Forms.Label();
            this.label45 = new System.Windows.Forms.Label();
            this.txtRetentionL30 = new System.Windows.Forms.TextBox();
            this.txtRetentionM30 = new System.Windows.Forms.TextBox();
            this.label46 = new System.Windows.Forms.Label();
            this.txtRetentionS31 = new System.Windows.Forms.TextBox();
            this.label47 = new System.Windows.Forms.Label();
            this.label48 = new System.Windows.Forms.Label();
            this.txtRetentionL31 = new System.Windows.Forms.TextBox();
            this.txtRetentionM31 = new System.Windows.Forms.TextBox();
            this.groupBox18 = new System.Windows.Forms.GroupBox();
            this.label69 = new System.Windows.Forms.Label();
            this.txtEtpPh = new System.Windows.Forms.TextBox();
            this.label50 = new System.Windows.Forms.Label();
            this.txtEtpBod = new System.Windows.Forms.TextBox();
            this.label49 = new System.Windows.Forms.Label();
            this.txtEtpCod = new System.Windows.Forms.TextBox();
            this.label52 = new System.Windows.Forms.Label();
            this.txtEtpWaterFlow = new System.Windows.Forms.TextBox();
            this.label56 = new System.Windows.Forms.Label();
            this.txtEtpTss = new System.Windows.Forms.TextBox();
            this.btnNewRecord = new System.Windows.Forms.Button();
            this.btnSave = new System.Windows.Forms.Button();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabParameter1 = new System.Windows.Forms.TabPage();
            this.groupBox24 = new System.Windows.Forms.GroupBox();
            this.txtTransTime = new System.Windows.Forms.TextBox();
            this.label98 = new System.Windows.Forms.Label();
            this.label99 = new System.Windows.Forms.Label();
            this.txtTransDate = new System.Windows.Forms.DateTimePicker();
            this.groupBox22 = new System.Windows.Forms.GroupBox();
            this.txt80tCMassecuitePan = new System.Windows.Forms.TextBox();
            this.label111 = new System.Windows.Forms.Label();
            this.txtExhaustCondensateRecovery = new System.Windows.Forms.TextBox();
            this.label54 = new System.Windows.Forms.Label();
            this.label53 = new System.Windows.Forms.Label();
            this.txtTotalOperatingTubeWell = new System.Windows.Forms.TextBox();
            this.groupBox21 = new System.Windows.Forms.GroupBox();
            this.label51 = new System.Windows.Forms.Label();
            this.label55 = new System.Windows.Forms.Label();
            this.txtPhosphateMixedJuice = new System.Windows.Forms.TextBox();
            this.txtPhosphateClearJuice = new System.Windows.Forms.TextBox();
            this.groupBox19 = new System.Windows.Forms.GroupBox();
            this.label57 = new System.Windows.Forms.Label();
            this.label58 = new System.Windows.Forms.Label();
            this.txtCalciumMixedJuice = new System.Windows.Forms.TextBox();
            this.txtCalciumClearJuice = new System.Windows.Forms.TextBox();
            this.groupBox25 = new System.Windows.Forms.GroupBox();
            this.tabParameter2 = new System.Windows.Forms.TabPage();
            this.groupBox23 = new System.Windows.Forms.GroupBox();
            this.txtPowerPerQtlOfSugar = new System.Windows.Forms.TextBox();
            this.label114 = new System.Windows.Forms.Label();
            this.txtPowerPerTonOfCane = new System.Windows.Forms.TextBox();
            this.label113 = new System.Windows.Forms.Label();
            this.txtPowerGen3OldTurbine = new System.Windows.Forms.TextBox();
            this.label112 = new System.Windows.Forms.Label();
            this.txTotalPower = new System.Windows.Forms.TextBox();
            this.label104 = new System.Windows.Forms.Label();
            this.txtPowerGenImportFromCogen = new System.Windows.Forms.TextBox();
            this.label105 = new System.Windows.Forms.Label();
            this.txtPowerGenDg = new System.Windows.Forms.TextBox();
            this.label106 = new System.Windows.Forms.Label();
            this.txtPowerGen1Turbine = new System.Windows.Forms.TextBox();
            this.label107 = new System.Windows.Forms.Label();
            this.txtPowerGen3NewTurbine = new System.Windows.Forms.TextBox();
            this.label108 = new System.Windows.Forms.Label();
            this.txtPowerGen25Turbine = new System.Windows.Forms.TextBox();
            this.label109 = new System.Windows.Forms.Label();
            this.groupBox20 = new System.Windows.Forms.GroupBox();
            this.txtSteamPercentCane = new System.Windows.Forms.TextBox();
            this.label117 = new System.Windows.Forms.Label();
            this.txtSteamPerTonOfCane = new System.Windows.Forms.TextBox();
            this.label116 = new System.Windows.Forms.Label();
            this.txtSteamPerQtlOfSugar = new System.Windows.Forms.TextBox();
            this.label115 = new System.Windows.Forms.Label();
            this.txtD_sulpher_heating = new System.Windows.Forms.TextBox();
            this.label100 = new System.Windows.Forms.Label();
            this.txtExhaustStamConsumption = new System.Windows.Forms.TextBox();
            this.label101 = new System.Windows.Forms.Label();
            this.txtExhaustSteamGeneration = new System.Windows.Forms.TextBox();
            this.label94 = new System.Windows.Forms.Label();
            this.txtDrainPipeLoss = new System.Windows.Forms.TextBox();
            this.label95 = new System.Windows.Forms.Label();
            this.txtAtaFromCogen = new System.Windows.Forms.TextBox();
            this.label96 = new System.Windows.Forms.Label();
            this.txtBleedingAcf = new System.Windows.Forms.TextBox();
            this.txtBleedingProcess = new System.Windows.Forms.TextBox();
            this.label97 = new System.Windows.Forms.Label();
            this.label87 = new System.Windows.Forms.Label();
            this.txtPowerTurbines = new System.Windows.Forms.TextBox();
            this.label91 = new System.Windows.Forms.Label();
            this.txtLiveSteamConsumption = new System.Windows.Forms.TextBox();
            this.label92 = new System.Windows.Forms.Label();
            this.txtLiveStamGeneration = new System.Windows.Forms.TextBox();
            this.label93 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.txtBoilerWater = new System.Windows.Forms.TextBox();
            this.label120 = new System.Windows.Forms.Label();
            this.txtOmPryExt = new System.Windows.Forms.TextBox();
            this.label118 = new System.Windows.Forms.Label();
            this.txtOmPIndex = new System.Windows.Forms.TextBox();
            this.label119 = new System.Windows.Forms.Label();
            this.txtPhMixedJuice = new System.Windows.Forms.TextBox();
            this.label88 = new System.Windows.Forms.Label();
            this.txtPhPrimaryJuice = new System.Windows.Forms.TextBox();
            this.label89 = new System.Windows.Forms.Label();
            this.txtIuClearJuice = new System.Windows.Forms.TextBox();
            this.label90 = new System.Windows.Forms.Label();
            this.txtIuMixedJuice = new System.Windows.Forms.TextBox();
            this.label83 = new System.Windows.Forms.Label();
            this.txtIuPrimaryJuice = new System.Windows.Forms.TextBox();
            this.label84 = new System.Windows.Forms.Label();
            this.txtRainFall = new System.Windows.Forms.TextBox();
            this.label85 = new System.Windows.Forms.Label();
            this.txtHumidity = new System.Windows.Forms.TextBox();
            this.label86 = new System.Windows.Forms.Label();
            this.txtTempMin = new System.Windows.Forms.TextBox();
            this.label79 = new System.Windows.Forms.Label();
            this.txtTempMax = new System.Windows.Forms.TextBox();
            this.label80 = new System.Windows.Forms.Label();
            this.TxtRsPercentage = new System.Windows.Forms.TextBox();
            this.label81 = new System.Windows.Forms.Label();
            this.txtTrsPercentage = new System.Windows.Forms.TextBox();
            this.label82 = new System.Windows.Forms.Label();
            this.txtNmPryExt = new System.Windows.Forms.TextBox();
            this.label75 = new System.Windows.Forms.Label();
            this.txtNmPIndex = new System.Windows.Forms.TextBox();
            this.label76 = new System.Windows.Forms.Label();
            this.txtBagasseStock = new System.Windows.Forms.TextBox();
            this.label77 = new System.Windows.Forms.Label();
            this.txtBagasseSold = new System.Windows.Forms.TextBox();
            this.label78 = new System.Windows.Forms.Label();
            this.txtCfWater = new System.Windows.Forms.TextBox();
            this.label71 = new System.Windows.Forms.Label();
            this.txtPanWater = new System.Windows.Forms.TextBox();
            this.label72 = new System.Windows.Forms.Label();
            this.txtFilterWater = new System.Windows.Forms.TextBox();
            this.label73 = new System.Windows.Forms.Label();
            this.txtPowerExportUppcb = new System.Windows.Forms.TextBox();
            this.label74 = new System.Windows.Forms.Label();
            this.txtPowerFromUppcb = new System.Windows.Forms.TextBox();
            this.label67 = new System.Windows.Forms.Label();
            this.txtBaggasseBaed = new System.Windows.Forms.TextBox();
            this.label68 = new System.Windows.Forms.Label();
            this.txtBoilerFeedWater = new System.Windows.Forms.TextBox();
            this.label70 = new System.Windows.Forms.Label();
            this.txtBoilerSteamPressHp = new System.Windows.Forms.TextBox();
            this.label66 = new System.Windows.Forms.Label();
            this.txtBoilerSteamPressLp = new System.Windows.Forms.TextBox();
            this.label65 = new System.Windows.Forms.Label();
            this.txtExhaustSteamPressHp = new System.Windows.Forms.TextBox();
            this.label64 = new System.Windows.Forms.Label();
            this.txtExhaustSteamPressLp = new System.Windows.Forms.TextBox();
            this.label63 = new System.Windows.Forms.Label();
            this.txtVaccumeOnEvap = new System.Windows.Forms.TextBox();
            this.label62 = new System.Windows.Forms.Label();
            this.txtVaccumeOnPan = new System.Windows.Forms.TextBox();
            this.label61 = new System.Windows.Forms.Label();
            this.txtInjectionOutlet = new System.Windows.Forms.TextBox();
            this.label60 = new System.Windows.Forms.Label();
            this.txtInjectionInlet = new System.Windows.Forms.TextBox();
            this.label59 = new System.Windows.Forms.Label();
            this.groupBox2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.groupBox5.SuspendLayout();
            this.groupBox6.SuspendLayout();
            this.groupBox7.SuspendLayout();
            this.groupBox8.SuspendLayout();
            this.groupBox9.SuspendLayout();
            this.groupBox10.SuspendLayout();
            this.groupBox11.SuspendLayout();
            this.groupBox12.SuspendLayout();
            this.groupBox13.SuspendLayout();
            this.groupBox14.SuspendLayout();
            this.groupBox15.SuspendLayout();
            this.groupBox16.SuspendLayout();
            this.groupBox17.SuspendLayout();
            this.groupBox18.SuspendLayout();
            this.tabControl1.SuspendLayout();
            this.tabParameter1.SuspendLayout();
            this.groupBox24.SuspendLayout();
            this.groupBox22.SuspendLayout();
            this.groupBox21.SuspendLayout();
            this.groupBox19.SuspendLayout();
            this.groupBox25.SuspendLayout();
            this.tabParameter2.SuspendLayout();
            this.groupBox23.SuspendLayout();
            this.groupBox20.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.txtFarmCana);
            this.groupBox2.Controls.Add(this.txtCaneFarm);
            this.groupBox2.Controls.Add(this.label110);
            this.groupBox2.Controls.Add(this.txtCaneCrushed);
            this.groupBox2.Controls.Add(this.label103);
            this.groupBox2.Controls.Add(this.txtCaneCentre);
            this.groupBox2.Controls.Add(this.label102);
            this.groupBox2.Controls.Add(this.txtCaneGate);
            this.groupBox2.Controls.Add(this.label3);
            this.groupBox2.Controls.Add(this.label2);
            this.groupBox2.Controls.Add(this.label1);
            this.groupBox2.Controls.Add(this.txtReject);
            this.groupBox2.Controls.Add(this.txtEarly);
            this.groupBox2.Controls.Add(this.txtGeneral);
            this.groupBox2.Location = new System.Drawing.Point(21, 74);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(677, 82);
            this.groupBox2.TabIndex = 0;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Cane Weight";
            // 
            // txtFarmCana
            // 
            this.txtFarmCana.AutoSize = true;
            this.txtFarmCana.Location = new System.Drawing.Point(480, 20);
            this.txtFarmCana.Name = "txtFarmCana";
            this.txtFarmCana.Size = new System.Drawing.Size(40, 17);
            this.txtFarmCana.TabIndex = 13;
            this.txtFarmCana.Text = "Farm";
            // 
            // txtCaneFarm
            // 
            this.txtCaneFarm.Location = new System.Drawing.Point(467, 43);
            this.txtCaneFarm.Name = "txtCaneFarm";
            this.txtCaneFarm.Size = new System.Drawing.Size(67, 22);
            this.txtCaneFarm.TabIndex = 6;
            this.txtCaneFarm.Text = "0";
            // 
            // label110
            // 
            this.label110.AutoSize = true;
            this.label110.Location = new System.Drawing.Point(561, 20);
            this.label110.Name = "label110";
            this.label110.Size = new System.Drawing.Size(98, 17);
            this.label110.TabIndex = 11;
            this.label110.Text = "Cane Crushed";
            // 
            // txtCaneCrushed
            // 
            this.txtCaneCrushed.Location = new System.Drawing.Point(577, 43);
            this.txtCaneCrushed.Name = "txtCaneCrushed";
            this.txtCaneCrushed.Size = new System.Drawing.Size(67, 22);
            this.txtCaneCrushed.TabIndex = 7;
            this.txtCaneCrushed.Text = "0";
            // 
            // label103
            // 
            this.label103.AutoSize = true;
            this.label103.Location = new System.Drawing.Point(386, 20);
            this.label103.Name = "label103";
            this.label103.Size = new System.Drawing.Size(50, 17);
            this.label103.TabIndex = 9;
            this.label103.Text = "Centre";
            // 
            // txtCaneCentre
            // 
            this.txtCaneCentre.Location = new System.Drawing.Point(378, 43);
            this.txtCaneCentre.Name = "txtCaneCentre";
            this.txtCaneCentre.Size = new System.Drawing.Size(67, 22);
            this.txtCaneCentre.TabIndex = 5;
            this.txtCaneCentre.Text = "0";
            // 
            // label102
            // 
            this.label102.AutoSize = true;
            this.label102.Location = new System.Drawing.Point(308, 20);
            this.label102.Name = "label102";
            this.label102.Size = new System.Drawing.Size(39, 17);
            this.label102.TabIndex = 7;
            this.label102.Text = "Gate";
            // 
            // txtCaneGate
            // 
            this.txtCaneGate.Location = new System.Drawing.Point(294, 43);
            this.txtCaneGate.Name = "txtCaneGate";
            this.txtCaneGate.Size = new System.Drawing.Size(67, 22);
            this.txtCaneGate.TabIndex = 4;
            this.txtCaneGate.Text = "0";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(184, 20);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(48, 17);
            this.label3.TabIndex = 5;
            this.label3.Text = "Reject";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(99, 20);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(59, 17);
            this.label2.TabIndex = 4;
            this.label2.Text = "General";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(35, 20);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(40, 17);
            this.label1.TabIndex = 3;
            this.label1.Text = "Early";
            // 
            // txtReject
            // 
            this.txtReject.Location = new System.Drawing.Point(175, 43);
            this.txtReject.Name = "txtReject";
            this.txtReject.Size = new System.Drawing.Size(67, 22);
            this.txtReject.TabIndex = 3;
            this.txtReject.Text = "0";
            // 
            // txtEarly
            // 
            this.txtEarly.Location = new System.Drawing.Point(20, 43);
            this.txtEarly.Name = "txtEarly";
            this.txtEarly.Size = new System.Drawing.Size(67, 22);
            this.txtEarly.TabIndex = 1;
            this.txtEarly.Text = "0";
            // 
            // txtGeneral
            // 
            this.txtGeneral.Location = new System.Drawing.Point(95, 43);
            this.txtGeneral.Name = "txtGeneral";
            this.txtGeneral.Size = new System.Drawing.Size(67, 22);
            this.txtGeneral.TabIndex = 2;
            this.txtGeneral.Text = "0";
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.label5);
            this.groupBox3.Controls.Add(this.label6);
            this.groupBox3.Controls.Add(this.txtJuice);
            this.groupBox3.Controls.Add(this.txtSpGrvity);
            this.groupBox3.Location = new System.Drawing.Point(704, 74);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(235, 82);
            this.groupBox3.TabIndex = 1;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Juice";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(139, 23);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(74, 17);
            this.label5.TabIndex = 4;
            this.label5.Text = "Sp Gravity";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(32, 20);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(77, 17);
            this.label6.TabIndex = 3;
            this.label6.Text = "Total Juice";
            // 
            // txtJuice
            // 
            this.txtJuice.Location = new System.Drawing.Point(20, 43);
            this.txtJuice.Name = "txtJuice";
            this.txtJuice.Size = new System.Drawing.Size(100, 22);
            this.txtJuice.TabIndex = 8;
            this.txtJuice.Text = "0";
            // 
            // txtSpGrvity
            // 
            this.txtSpGrvity.Location = new System.Drawing.Point(129, 43);
            this.txtSpGrvity.Name = "txtSpGrvity";
            this.txtSpGrvity.Size = new System.Drawing.Size(100, 22);
            this.txtSpGrvity.TabIndex = 9;
            this.txtSpGrvity.Text = "0";
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.label7);
            this.groupBox4.Controls.Add(this.txtWater);
            this.groupBox4.Location = new System.Drawing.Point(955, 74);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(143, 82);
            this.groupBox4.TabIndex = 2;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Water";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(29, 20);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(82, 17);
            this.label7.TabIndex = 3;
            this.label7.Text = "Total Water";
            // 
            // txtWater
            // 
            this.txtWater.Location = new System.Drawing.Point(24, 43);
            this.txtWater.Name = "txtWater";
            this.txtWater.Size = new System.Drawing.Size(100, 22);
            this.txtWater.TabIndex = 10;
            this.txtWater.Text = "0";
            // 
            // groupBox5
            // 
            this.groupBox5.Controls.Add(this.label4);
            this.groupBox5.Controls.Add(this.txtPressCake);
            this.groupBox5.Location = new System.Drawing.Point(1116, 74);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(143, 82);
            this.groupBox5.TabIndex = 3;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "Press Cake";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(30, 20);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(80, 17);
            this.label4.TabIndex = 3;
            this.label4.Text = "Press Cake";
            // 
            // txtPressCake
            // 
            this.txtPressCake.Location = new System.Drawing.Point(20, 43);
            this.txtPressCake.Name = "txtPressCake";
            this.txtPressCake.Size = new System.Drawing.Size(100, 22);
            this.txtPressCake.TabIndex = 11;
            this.txtPressCake.Text = "0";
            // 
            // groupBox6
            // 
            this.groupBox6.Controls.Add(this.label8);
            this.groupBox6.Controls.Add(this.txtMolassesSentOut);
            this.groupBox6.Location = new System.Drawing.Point(1265, 74);
            this.groupBox6.Name = "groupBox6";
            this.groupBox6.Size = new System.Drawing.Size(155, 82);
            this.groupBox6.TabIndex = 4;
            this.groupBox6.TabStop = false;
            this.groupBox6.Text = "Molasses";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(38, 20);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(64, 17);
            this.label8.TabIndex = 3;
            this.label8.Text = "Sent Out";
            // 
            // txtMolassesSentOut
            // 
            this.txtMolassesSentOut.Location = new System.Drawing.Point(20, 43);
            this.txtMolassesSentOut.Name = "txtMolassesSentOut";
            this.txtMolassesSentOut.Size = new System.Drawing.Size(100, 22);
            this.txtMolassesSentOut.TabIndex = 12;
            this.txtMolassesSentOut.Text = "0";
            // 
            // groupBox7
            // 
            this.groupBox7.Controls.Add(this.label10);
            this.groupBox7.Controls.Add(this.label11);
            this.groupBox7.Controls.Add(this.txtBissSugar);
            this.groupBox7.Controls.Add(this.txtBissMolasses);
            this.groupBox7.Location = new System.Drawing.Point(20, 21);
            this.groupBox7.Name = "groupBox7";
            this.groupBox7.Size = new System.Drawing.Size(239, 82);
            this.groupBox7.TabIndex = 5;
            this.groupBox7.TabStop = false;
            this.groupBox7.Text = "Biss";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(147, 23);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(67, 17);
            this.label10.TabIndex = 4;
            this.label10.Text = "Molasses";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(50, 20);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(46, 17);
            this.label11.TabIndex = 3;
            this.label11.Text = "Sugar";
            // 
            // txtBissSugar
            // 
            this.txtBissSugar.Location = new System.Drawing.Point(20, 43);
            this.txtBissSugar.Name = "txtBissSugar";
            this.txtBissSugar.Size = new System.Drawing.Size(100, 22);
            this.txtBissSugar.TabIndex = 13;
            this.txtBissSugar.Text = "0";
            // 
            // txtBissMolasses
            // 
            this.txtBissMolasses.Location = new System.Drawing.Point(126, 43);
            this.txtBissMolasses.Name = "txtBissMolasses";
            this.txtBissMolasses.Size = new System.Drawing.Size(100, 22);
            this.txtBissMolasses.TabIndex = 14;
            this.txtBissMolasses.Text = "0";
            // 
            // groupBox8
            // 
            this.groupBox8.Controls.Add(this.label9);
            this.groupBox8.Controls.Add(this.label12);
            this.groupBox8.Controls.Add(this.txtScrapSugar);
            this.groupBox8.Controls.Add(this.txtScrapMolasses);
            this.groupBox8.Location = new System.Drawing.Point(274, 21);
            this.groupBox8.Name = "groupBox8";
            this.groupBox8.Size = new System.Drawing.Size(239, 82);
            this.groupBox8.TabIndex = 6;
            this.groupBox8.TabStop = false;
            this.groupBox8.Text = "Scrap";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(147, 23);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(67, 17);
            this.label9.TabIndex = 4;
            this.label9.Text = "Molasses";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(50, 20);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(46, 17);
            this.label12.TabIndex = 3;
            this.label12.Text = "Sugar";
            // 
            // txtScrapSugar
            // 
            this.txtScrapSugar.Location = new System.Drawing.Point(20, 43);
            this.txtScrapSugar.Name = "txtScrapSugar";
            this.txtScrapSugar.Size = new System.Drawing.Size(100, 22);
            this.txtScrapSugar.TabIndex = 15;
            this.txtScrapSugar.Text = "0";
            // 
            // txtScrapMolasses
            // 
            this.txtScrapMolasses.Location = new System.Drawing.Point(126, 43);
            this.txtScrapMolasses.Name = "txtScrapMolasses";
            this.txtScrapMolasses.Size = new System.Drawing.Size(100, 22);
            this.txtScrapMolasses.TabIndex = 16;
            this.txtScrapMolasses.Text = "0";
            // 
            // groupBox9
            // 
            this.groupBox9.Controls.Add(this.label13);
            this.groupBox9.Controls.Add(this.label14);
            this.groupBox9.Controls.Add(this.txtMoistSugar);
            this.groupBox9.Controls.Add(this.txtMoistMolasses);
            this.groupBox9.Location = new System.Drawing.Point(519, 21);
            this.groupBox9.Name = "groupBox9";
            this.groupBox9.Size = new System.Drawing.Size(239, 82);
            this.groupBox9.TabIndex = 7;
            this.groupBox9.TabStop = false;
            this.groupBox9.Text = "Moist Sugar";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(147, 23);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(67, 17);
            this.label13.TabIndex = 4;
            this.label13.Text = "Molasses";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(50, 20);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(46, 17);
            this.label14.TabIndex = 3;
            this.label14.Text = "Sugar";
            // 
            // txtMoistSugar
            // 
            this.txtMoistSugar.Location = new System.Drawing.Point(20, 43);
            this.txtMoistSugar.Name = "txtMoistSugar";
            this.txtMoistSugar.Size = new System.Drawing.Size(100, 22);
            this.txtMoistSugar.TabIndex = 17;
            this.txtMoistSugar.Text = "0";
            // 
            // txtMoistMolasses
            // 
            this.txtMoistMolasses.Location = new System.Drawing.Point(126, 43);
            this.txtMoistMolasses.Name = "txtMoistMolasses";
            this.txtMoistMolasses.Size = new System.Drawing.Size(100, 22);
            this.txtMoistMolasses.TabIndex = 18;
            this.txtMoistMolasses.Text = "0";
            // 
            // groupBox10
            // 
            this.groupBox10.Controls.Add(this.label15);
            this.groupBox10.Controls.Add(this.label16);
            this.groupBox10.Controls.Add(this.txtRawSugar);
            this.groupBox10.Controls.Add(this.txtRawMolasses);
            this.groupBox10.Location = new System.Drawing.Point(764, 21);
            this.groupBox10.Name = "groupBox10";
            this.groupBox10.Size = new System.Drawing.Size(239, 82);
            this.groupBox10.TabIndex = 8;
            this.groupBox10.TabStop = false;
            this.groupBox10.Text = "Raw Sugar";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(147, 23);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(67, 17);
            this.label15.TabIndex = 4;
            this.label15.Text = "Molasses";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(50, 20);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(46, 17);
            this.label16.TabIndex = 3;
            this.label16.Text = "Sugar";
            // 
            // txtRawSugar
            // 
            this.txtRawSugar.Location = new System.Drawing.Point(20, 43);
            this.txtRawSugar.Name = "txtRawSugar";
            this.txtRawSugar.Size = new System.Drawing.Size(100, 22);
            this.txtRawSugar.TabIndex = 19;
            this.txtRawSugar.Text = "0";
            // 
            // txtRawMolasses
            // 
            this.txtRawMolasses.Location = new System.Drawing.Point(126, 43);
            this.txtRawMolasses.Name = "txtRawMolasses";
            this.txtRawMolasses.Size = new System.Drawing.Size(100, 22);
            this.txtRawMolasses.TabIndex = 20;
            this.txtRawMolasses.Text = "0";
            // 
            // groupBox11
            // 
            this.groupBox11.Controls.Add(this.label17);
            this.groupBox11.Controls.Add(this.label18);
            this.groupBox11.Controls.Add(this.txtOtherSugar);
            this.groupBox11.Controls.Add(this.txtOtherMolasses);
            this.groupBox11.Location = new System.Drawing.Point(1009, 21);
            this.groupBox11.Name = "groupBox11";
            this.groupBox11.Size = new System.Drawing.Size(239, 82);
            this.groupBox11.TabIndex = 9;
            this.groupBox11.TabStop = false;
            this.groupBox11.Text = "Other";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(147, 23);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(67, 17);
            this.label17.TabIndex = 4;
            this.label17.Text = "Molasses";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(50, 20);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(46, 17);
            this.label18.TabIndex = 3;
            this.label18.Text = "Sugar";
            // 
            // txtOtherSugar
            // 
            this.txtOtherSugar.Location = new System.Drawing.Point(20, 43);
            this.txtOtherSugar.Name = "txtOtherSugar";
            this.txtOtherSugar.Size = new System.Drawing.Size(100, 22);
            this.txtOtherSugar.TabIndex = 21;
            this.txtOtherSugar.Text = "0";
            // 
            // txtOtherMolasses
            // 
            this.txtOtherMolasses.Location = new System.Drawing.Point(126, 43);
            this.txtOtherMolasses.Name = "txtOtherMolasses";
            this.txtOtherMolasses.Size = new System.Drawing.Size(100, 22);
            this.txtOtherMolasses.TabIndex = 22;
            this.txtOtherMolasses.Text = "0";
            // 
            // groupBox12
            // 
            this.groupBox12.Controls.Add(this.label19);
            this.groupBox12.Controls.Add(this.txtUnknownLosses);
            this.groupBox12.Location = new System.Drawing.Point(1126, 579);
            this.groupBox12.Name = "groupBox12";
            this.groupBox12.Size = new System.Drawing.Size(143, 82);
            this.groupBox12.TabIndex = 13;
            this.groupBox12.TabStop = false;
            this.groupBox12.Text = "Un-known Losses";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(44, 20);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(53, 17);
            this.label19.TabIndex = 3;
            this.label19.Text = "Losses";
            // 
            // txtUnknownLosses
            // 
            this.txtUnknownLosses.Location = new System.Drawing.Point(20, 43);
            this.txtUnknownLosses.Name = "txtUnknownLosses";
            this.txtUnknownLosses.Size = new System.Drawing.Size(100, 22);
            this.txtUnknownLosses.TabIndex = 60;
            this.txtUnknownLosses.Text = "0";
            // 
            // groupBox13
            // 
            this.groupBox13.Controls.Add(this.label20);
            this.groupBox13.Controls.Add(this.txtDirtCorrection);
            this.groupBox13.Location = new System.Drawing.Point(1277, 579);
            this.groupBox13.Name = "groupBox13";
            this.groupBox13.Size = new System.Drawing.Size(143, 82);
            this.groupBox13.TabIndex = 14;
            this.groupBox13.TabStop = false;
            this.groupBox13.Text = "Dirt ";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(21, 23);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(111, 17);
            this.label20.TabIndex = 3;
            this.label20.Text = "Dirt Correction%";
            // 
            // txtDirtCorrection
            // 
            this.txtDirtCorrection.Location = new System.Drawing.Point(20, 43);
            this.txtDirtCorrection.Name = "txtDirtCorrection";
            this.txtDirtCorrection.Size = new System.Drawing.Size(100, 22);
            this.txtDirtCorrection.TabIndex = 61;
            this.txtDirtCorrection.Text = "0";
            // 
            // groupBox14
            // 
            this.groupBox14.Controls.Add(this.label30);
            this.groupBox14.Controls.Add(this.txtStorePhosphoric);
            this.groupBox14.Controls.Add(this.label29);
            this.groupBox14.Controls.Add(this.label24);
            this.groupBox14.Controls.Add(this.txtStoreBoilerChemical);
            this.groupBox14.Controls.Add(this.txtStoreBioeide);
            this.groupBox14.Controls.Add(this.label23);
            this.groupBox14.Controls.Add(this.txtStoreViscocty);
            this.groupBox14.Controls.Add(this.label28);
            this.groupBox14.Controls.Add(this.label21);
            this.groupBox14.Controls.Add(this.txtStoreLubGreece);
            this.groupBox14.Controls.Add(this.label22);
            this.groupBox14.Controls.Add(this.txtStoreSulpher);
            this.groupBox14.Controls.Add(this.label27);
            this.groupBox14.Controls.Add(this.label25);
            this.groupBox14.Controls.Add(this.txtStoreLime);
            this.groupBox14.Controls.Add(this.txtStoreLubOil);
            this.groupBox14.Controls.Add(this.txtStoreColorReducer);
            this.groupBox14.Controls.Add(this.label26);
            this.groupBox14.Controls.Add(this.txtStoreMegnafloe);
            this.groupBox14.Location = new System.Drawing.Point(21, 291);
            this.groupBox14.Name = "groupBox14";
            this.groupBox14.Size = new System.Drawing.Size(1289, 139);
            this.groupBox14.TabIndex = 6;
            this.groupBox14.TabStop = false;
            this.groupBox14.Text = "Store Consumption";
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Location = new System.Drawing.Point(531, 46);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(110, 17);
            this.label30.TabIndex = 20;
            this.label30.Text = "Phosphoric Acid";
            // 
            // txtStorePhosphoric
            // 
            this.txtStorePhosphoric.Location = new System.Drawing.Point(645, 43);
            this.txtStorePhosphoric.Name = "txtStorePhosphoric";
            this.txtStorePhosphoric.Size = new System.Drawing.Size(100, 22);
            this.txtStorePhosphoric.TabIndex = 25;
            this.txtStorePhosphoric.Text = "0";
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Location = new System.Drawing.Point(1011, 86);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(105, 17);
            this.label29.TabIndex = 18;
            this.label29.Text = "Boiler Chemical";
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Location = new System.Drawing.Point(1061, 42);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(54, 17);
            this.label24.TabIndex = 8;
            this.label24.Text = "Biocide";
            // 
            // txtStoreBoilerChemical
            // 
            this.txtStoreBoilerChemical.Location = new System.Drawing.Point(1138, 83);
            this.txtStoreBoilerChemical.Name = "txtStoreBoilerChemical";
            this.txtStoreBoilerChemical.Size = new System.Drawing.Size(100, 22);
            this.txtStoreBoilerChemical.TabIndex = 32;
            this.txtStoreBoilerChemical.Text = "0";
            // 
            // txtStoreBioeide
            // 
            this.txtStoreBioeide.Location = new System.Drawing.Point(1138, 39);
            this.txtStoreBioeide.Name = "txtStoreBioeide";
            this.txtStoreBioeide.Size = new System.Drawing.Size(100, 22);
            this.txtStoreBioeide.TabIndex = 27;
            this.txtStoreBioeide.Text = "0";
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Location = new System.Drawing.Point(751, 45);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(121, 17);
            this.label23.TabIndex = 6;
            this.label23.Text = "Viscosity Reducer";
            // 
            // txtStoreViscocty
            // 
            this.txtStoreViscocty.Location = new System.Drawing.Point(890, 42);
            this.txtStoreViscocty.Name = "txtStoreViscocty";
            this.txtStoreViscocty.Size = new System.Drawing.Size(100, 22);
            this.txtStoreViscocty.TabIndex = 26;
            this.txtStoreViscocty.Text = "0";
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Location = new System.Drawing.Point(786, 89);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(83, 17);
            this.label28.TabIndex = 16;
            this.label28.Text = "Lub Greace";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(309, 43);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(38, 17);
            this.label21.TabIndex = 4;
            this.label21.Text = "Lime";
            // 
            // txtStoreLubGreece
            // 
            this.txtStoreLubGreece.Location = new System.Drawing.Point(890, 86);
            this.txtStoreLubGreece.Name = "txtStoreLubGreece";
            this.txtStoreLubGreece.Size = new System.Drawing.Size(100, 22);
            this.txtStoreLubGreece.TabIndex = 31;
            this.txtStoreLubGreece.Text = "0";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Location = new System.Drawing.Point(79, 43);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(57, 17);
            this.label22.TabIndex = 3;
            this.label22.Text = "Sulpher";
            // 
            // txtStoreSulpher
            // 
            this.txtStoreSulpher.Location = new System.Drawing.Point(142, 40);
            this.txtStoreSulpher.Name = "txtStoreSulpher";
            this.txtStoreSulpher.Size = new System.Drawing.Size(100, 22);
            this.txtStoreSulpher.TabIndex = 23;
            this.txtStoreSulpher.Text = "0";
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Location = new System.Drawing.Point(574, 90);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(50, 17);
            this.label27.TabIndex = 14;
            this.label27.Text = "Lub oil";
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Location = new System.Drawing.Point(29, 87);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(107, 17);
            this.label25.TabIndex = 10;
            this.label25.Text = "Colour Reducer";
            // 
            // txtStoreLime
            // 
            this.txtStoreLime.Location = new System.Drawing.Point(366, 40);
            this.txtStoreLime.Name = "txtStoreLime";
            this.txtStoreLime.Size = new System.Drawing.Size(100, 22);
            this.txtStoreLime.TabIndex = 24;
            this.txtStoreLime.Text = "0";
            // 
            // txtStoreLubOil
            // 
            this.txtStoreLubOil.Location = new System.Drawing.Point(645, 90);
            this.txtStoreLubOil.Name = "txtStoreLubOil";
            this.txtStoreLubOil.Size = new System.Drawing.Size(100, 22);
            this.txtStoreLubOil.TabIndex = 30;
            this.txtStoreLubOil.Text = "0";
            // 
            // txtStoreColorReducer
            // 
            this.txtStoreColorReducer.Location = new System.Drawing.Point(142, 84);
            this.txtStoreColorReducer.Name = "txtStoreColorReducer";
            this.txtStoreColorReducer.Size = new System.Drawing.Size(100, 22);
            this.txtStoreColorReducer.TabIndex = 28;
            this.txtStoreColorReducer.Text = "0";
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Location = new System.Drawing.Point(280, 85);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(74, 17);
            this.label26.TabIndex = 12;
            this.label26.Text = "Megnafloe";
            // 
            // txtStoreMegnafloe
            // 
            this.txtStoreMegnafloe.Location = new System.Drawing.Point(366, 85);
            this.txtStoreMegnafloe.Name = "txtStoreMegnafloe";
            this.txtStoreMegnafloe.Size = new System.Drawing.Size(100, 22);
            this.txtStoreMegnafloe.TabIndex = 29;
            this.txtStoreMegnafloe.Text = "0";
            // 
            // groupBox15
            // 
            this.groupBox15.Controls.Add(this.label34);
            this.groupBox15.Controls.Add(this.txtIcumsaS30);
            this.groupBox15.Controls.Add(this.label35);
            this.groupBox15.Controls.Add(this.label36);
            this.groupBox15.Controls.Add(this.txtIcumsaL30);
            this.groupBox15.Controls.Add(this.txtIcumsaM30);
            this.groupBox15.Controls.Add(this.label33);
            this.groupBox15.Controls.Add(this.txtIcumsaS31);
            this.groupBox15.Controls.Add(this.label31);
            this.groupBox15.Controls.Add(this.label32);
            this.groupBox15.Controls.Add(this.txtIcumsaL31);
            this.groupBox15.Controls.Add(this.txtIcumsaM31);
            this.groupBox15.Location = new System.Drawing.Point(21, 436);
            this.groupBox15.Name = "groupBox15";
            this.groupBox15.Size = new System.Drawing.Size(349, 137);
            this.groupBox15.TabIndex = 7;
            this.groupBox15.TabStop = false;
            this.groupBox15.Text = "Icumsa";
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.Location = new System.Drawing.Point(253, 71);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(33, 17);
            this.label34.TabIndex = 12;
            this.label34.Text = "S30";
            // 
            // txtIcumsaS30
            // 
            this.txtIcumsaS30.Location = new System.Drawing.Point(232, 91);
            this.txtIcumsaS30.Name = "txtIcumsaS30";
            this.txtIcumsaS30.Size = new System.Drawing.Size(100, 22);
            this.txtIcumsaS30.TabIndex = 38;
            this.txtIcumsaS30.Text = "0";
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.Location = new System.Drawing.Point(147, 71);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(40, 17);
            this.label35.TabIndex = 10;
            this.label35.Text = "M-30";
            // 
            // label36
            // 
            this.label36.AutoSize = true;
            this.label36.Location = new System.Drawing.Point(50, 68);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(37, 17);
            this.label36.TabIndex = 9;
            this.label36.Text = "L-30";
            // 
            // txtIcumsaL30
            // 
            this.txtIcumsaL30.Location = new System.Drawing.Point(20, 91);
            this.txtIcumsaL30.Name = "txtIcumsaL30";
            this.txtIcumsaL30.Size = new System.Drawing.Size(100, 22);
            this.txtIcumsaL30.TabIndex = 36;
            this.txtIcumsaL30.Text = "0";
            // 
            // txtIcumsaM30
            // 
            this.txtIcumsaM30.Location = new System.Drawing.Point(126, 91);
            this.txtIcumsaM30.Name = "txtIcumsaM30";
            this.txtIcumsaM30.Size = new System.Drawing.Size(100, 22);
            this.txtIcumsaM30.TabIndex = 37;
            this.txtIcumsaM30.Text = "0";
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.Location = new System.Drawing.Point(253, 23);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(33, 17);
            this.label33.TabIndex = 6;
            this.label33.Text = "S31";
            // 
            // txtIcumsaS31
            // 
            this.txtIcumsaS31.Location = new System.Drawing.Point(232, 43);
            this.txtIcumsaS31.Name = "txtIcumsaS31";
            this.txtIcumsaS31.Size = new System.Drawing.Size(100, 22);
            this.txtIcumsaS31.TabIndex = 35;
            this.txtIcumsaS31.Text = "0";
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Location = new System.Drawing.Point(147, 23);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(40, 17);
            this.label31.TabIndex = 4;
            this.label31.Text = "M-31";
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Location = new System.Drawing.Point(50, 20);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(37, 17);
            this.label32.TabIndex = 3;
            this.label32.Text = "L-31";
            // 
            // txtIcumsaL31
            // 
            this.txtIcumsaL31.Location = new System.Drawing.Point(20, 43);
            this.txtIcumsaL31.Name = "txtIcumsaL31";
            this.txtIcumsaL31.Size = new System.Drawing.Size(100, 22);
            this.txtIcumsaL31.TabIndex = 33;
            this.txtIcumsaL31.Text = "0";
            // 
            // txtIcumsaM31
            // 
            this.txtIcumsaM31.Location = new System.Drawing.Point(126, 43);
            this.txtIcumsaM31.Name = "txtIcumsaM31";
            this.txtIcumsaM31.Size = new System.Drawing.Size(100, 22);
            this.txtIcumsaM31.TabIndex = 34;
            this.txtIcumsaM31.Text = "0";
            // 
            // groupBox16
            // 
            this.groupBox16.Controls.Add(this.label37);
            this.groupBox16.Controls.Add(this.txtForeignS30);
            this.groupBox16.Controls.Add(this.label38);
            this.groupBox16.Controls.Add(this.label39);
            this.groupBox16.Controls.Add(this.txtForeignL30);
            this.groupBox16.Controls.Add(this.txtForeignM30);
            this.groupBox16.Controls.Add(this.label40);
            this.groupBox16.Controls.Add(this.txtForeignS31);
            this.groupBox16.Controls.Add(this.label41);
            this.groupBox16.Controls.Add(this.label42);
            this.groupBox16.Controls.Add(this.txtForeIgnL31);
            this.groupBox16.Controls.Add(this.txtForeignM31);
            this.groupBox16.Location = new System.Drawing.Point(376, 436);
            this.groupBox16.Name = "groupBox16";
            this.groupBox16.Size = new System.Drawing.Size(349, 137);
            this.groupBox16.TabIndex = 8;
            this.groupBox16.TabStop = false;
            this.groupBox16.Text = "Foreign Matter";
            // 
            // label37
            // 
            this.label37.AutoSize = true;
            this.label37.Location = new System.Drawing.Point(253, 71);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(33, 17);
            this.label37.TabIndex = 12;
            this.label37.Text = "S30";
            // 
            // txtForeignS30
            // 
            this.txtForeignS30.Location = new System.Drawing.Point(232, 91);
            this.txtForeignS30.Name = "txtForeignS30";
            this.txtForeignS30.Size = new System.Drawing.Size(100, 22);
            this.txtForeignS30.TabIndex = 44;
            this.txtForeignS30.Text = "0";
            // 
            // label38
            // 
            this.label38.AutoSize = true;
            this.label38.Location = new System.Drawing.Point(147, 71);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(40, 17);
            this.label38.TabIndex = 10;
            this.label38.Text = "M-30";
            // 
            // label39
            // 
            this.label39.AutoSize = true;
            this.label39.Location = new System.Drawing.Point(50, 68);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(37, 17);
            this.label39.TabIndex = 9;
            this.label39.Text = "L-30";
            // 
            // txtForeignL30
            // 
            this.txtForeignL30.Location = new System.Drawing.Point(20, 91);
            this.txtForeignL30.Name = "txtForeignL30";
            this.txtForeignL30.Size = new System.Drawing.Size(100, 22);
            this.txtForeignL30.TabIndex = 42;
            this.txtForeignL30.Text = "0";
            // 
            // txtForeignM30
            // 
            this.txtForeignM30.Location = new System.Drawing.Point(126, 91);
            this.txtForeignM30.Name = "txtForeignM30";
            this.txtForeignM30.Size = new System.Drawing.Size(100, 22);
            this.txtForeignM30.TabIndex = 43;
            this.txtForeignM30.Text = "0";
            // 
            // label40
            // 
            this.label40.AutoSize = true;
            this.label40.Location = new System.Drawing.Point(253, 23);
            this.label40.Name = "label40";
            this.label40.Size = new System.Drawing.Size(33, 17);
            this.label40.TabIndex = 6;
            this.label40.Text = "S31";
            // 
            // txtForeignS31
            // 
            this.txtForeignS31.Location = new System.Drawing.Point(232, 43);
            this.txtForeignS31.Name = "txtForeignS31";
            this.txtForeignS31.Size = new System.Drawing.Size(100, 22);
            this.txtForeignS31.TabIndex = 41;
            this.txtForeignS31.Text = "0";
            // 
            // label41
            // 
            this.label41.AutoSize = true;
            this.label41.Location = new System.Drawing.Point(147, 23);
            this.label41.Name = "label41";
            this.label41.Size = new System.Drawing.Size(40, 17);
            this.label41.TabIndex = 4;
            this.label41.Text = "M-31";
            // 
            // label42
            // 
            this.label42.AutoSize = true;
            this.label42.Location = new System.Drawing.Point(50, 20);
            this.label42.Name = "label42";
            this.label42.Size = new System.Drawing.Size(37, 17);
            this.label42.TabIndex = 3;
            this.label42.Text = "L-31";
            // 
            // txtForeIgnL31
            // 
            this.txtForeIgnL31.Location = new System.Drawing.Point(20, 43);
            this.txtForeIgnL31.Name = "txtForeIgnL31";
            this.txtForeIgnL31.Size = new System.Drawing.Size(100, 22);
            this.txtForeIgnL31.TabIndex = 39;
            this.txtForeIgnL31.Text = "0";
            // 
            // txtForeignM31
            // 
            this.txtForeignM31.Location = new System.Drawing.Point(126, 43);
            this.txtForeignM31.Name = "txtForeignM31";
            this.txtForeignM31.Size = new System.Drawing.Size(100, 22);
            this.txtForeignM31.TabIndex = 40;
            this.txtForeignM31.Text = "0";
            // 
            // groupBox17
            // 
            this.groupBox17.Controls.Add(this.label43);
            this.groupBox17.Controls.Add(this.txtRetentionS30);
            this.groupBox17.Controls.Add(this.label44);
            this.groupBox17.Controls.Add(this.label45);
            this.groupBox17.Controls.Add(this.txtRetentionL30);
            this.groupBox17.Controls.Add(this.txtRetentionM30);
            this.groupBox17.Controls.Add(this.label46);
            this.groupBox17.Controls.Add(this.txtRetentionS31);
            this.groupBox17.Controls.Add(this.label47);
            this.groupBox17.Controls.Add(this.label48);
            this.groupBox17.Controls.Add(this.txtRetentionL31);
            this.groupBox17.Controls.Add(this.txtRetentionM31);
            this.groupBox17.Location = new System.Drawing.Point(742, 436);
            this.groupBox17.Name = "groupBox17";
            this.groupBox17.Size = new System.Drawing.Size(349, 137);
            this.groupBox17.TabIndex = 9;
            this.groupBox17.TabStop = false;
            this.groupBox17.Text = "Retention";
            // 
            // label43
            // 
            this.label43.AutoSize = true;
            this.label43.Location = new System.Drawing.Point(253, 71);
            this.label43.Name = "label43";
            this.label43.Size = new System.Drawing.Size(33, 17);
            this.label43.TabIndex = 12;
            this.label43.Text = "S30";
            // 
            // txtRetentionS30
            // 
            this.txtRetentionS30.Location = new System.Drawing.Point(232, 91);
            this.txtRetentionS30.Name = "txtRetentionS30";
            this.txtRetentionS30.Size = new System.Drawing.Size(100, 22);
            this.txtRetentionS30.TabIndex = 50;
            this.txtRetentionS30.Text = "0";
            // 
            // label44
            // 
            this.label44.AutoSize = true;
            this.label44.Location = new System.Drawing.Point(147, 71);
            this.label44.Name = "label44";
            this.label44.Size = new System.Drawing.Size(40, 17);
            this.label44.TabIndex = 10;
            this.label44.Text = "M-30";
            // 
            // label45
            // 
            this.label45.AutoSize = true;
            this.label45.Location = new System.Drawing.Point(50, 68);
            this.label45.Name = "label45";
            this.label45.Size = new System.Drawing.Size(37, 17);
            this.label45.TabIndex = 9;
            this.label45.Text = "L-30";
            // 
            // txtRetentionL30
            // 
            this.txtRetentionL30.Location = new System.Drawing.Point(20, 91);
            this.txtRetentionL30.Name = "txtRetentionL30";
            this.txtRetentionL30.Size = new System.Drawing.Size(100, 22);
            this.txtRetentionL30.TabIndex = 48;
            this.txtRetentionL30.Text = "0";
            // 
            // txtRetentionM30
            // 
            this.txtRetentionM30.Location = new System.Drawing.Point(126, 91);
            this.txtRetentionM30.Name = "txtRetentionM30";
            this.txtRetentionM30.Size = new System.Drawing.Size(100, 22);
            this.txtRetentionM30.TabIndex = 49;
            this.txtRetentionM30.Text = "0";
            // 
            // label46
            // 
            this.label46.AutoSize = true;
            this.label46.Location = new System.Drawing.Point(253, 23);
            this.label46.Name = "label46";
            this.label46.Size = new System.Drawing.Size(33, 17);
            this.label46.TabIndex = 6;
            this.label46.Text = "S31";
            // 
            // txtRetentionS31
            // 
            this.txtRetentionS31.Location = new System.Drawing.Point(232, 43);
            this.txtRetentionS31.Name = "txtRetentionS31";
            this.txtRetentionS31.Size = new System.Drawing.Size(100, 22);
            this.txtRetentionS31.TabIndex = 47;
            this.txtRetentionS31.Text = "0";
            // 
            // label47
            // 
            this.label47.AutoSize = true;
            this.label47.Location = new System.Drawing.Point(147, 23);
            this.label47.Name = "label47";
            this.label47.Size = new System.Drawing.Size(40, 17);
            this.label47.TabIndex = 4;
            this.label47.Text = "M-31";
            // 
            // label48
            // 
            this.label48.AutoSize = true;
            this.label48.Location = new System.Drawing.Point(50, 20);
            this.label48.Name = "label48";
            this.label48.Size = new System.Drawing.Size(37, 17);
            this.label48.TabIndex = 3;
            this.label48.Text = "L-31";
            // 
            // txtRetentionL31
            // 
            this.txtRetentionL31.Location = new System.Drawing.Point(20, 43);
            this.txtRetentionL31.Name = "txtRetentionL31";
            this.txtRetentionL31.Size = new System.Drawing.Size(100, 22);
            this.txtRetentionL31.TabIndex = 45;
            this.txtRetentionL31.Text = "0";
            // 
            // txtRetentionM31
            // 
            this.txtRetentionM31.Location = new System.Drawing.Point(126, 43);
            this.txtRetentionM31.Name = "txtRetentionM31";
            this.txtRetentionM31.Size = new System.Drawing.Size(100, 22);
            this.txtRetentionM31.TabIndex = 46;
            this.txtRetentionM31.Text = "0";
            // 
            // groupBox18
            // 
            this.groupBox18.Controls.Add(this.label69);
            this.groupBox18.Controls.Add(this.txtEtpPh);
            this.groupBox18.Controls.Add(this.label50);
            this.groupBox18.Controls.Add(this.txtEtpBod);
            this.groupBox18.Controls.Add(this.label49);
            this.groupBox18.Controls.Add(this.txtEtpCod);
            this.groupBox18.Controls.Add(this.label52);
            this.groupBox18.Controls.Add(this.txtEtpWaterFlow);
            this.groupBox18.Controls.Add(this.label56);
            this.groupBox18.Controls.Add(this.txtEtpTss);
            this.groupBox18.Location = new System.Drawing.Point(21, 579);
            this.groupBox18.Name = "groupBox18";
            this.groupBox18.Size = new System.Drawing.Size(581, 85);
            this.groupBox18.TabIndex = 10;
            this.groupBox18.TabStop = false;
            this.groupBox18.Text = "ETP";
            // 
            // label69
            // 
            this.label69.AutoSize = true;
            this.label69.Location = new System.Drawing.Point(58, 20);
            this.label69.Name = "label69";
            this.label69.Size = new System.Drawing.Size(26, 17);
            this.label69.TabIndex = 65;
            this.label69.Text = "pH";
            // 
            // txtEtpPh
            // 
            this.txtEtpPh.Location = new System.Drawing.Point(20, 43);
            this.txtEtpPh.Name = "txtEtpPh";
            this.txtEtpPh.Size = new System.Drawing.Size(100, 22);
            this.txtEtpPh.TabIndex = 51;
            this.txtEtpPh.Text = "0";
            // 
            // label50
            // 
            this.label50.AutoSize = true;
            this.label50.Location = new System.Drawing.Point(373, 20);
            this.label50.Name = "label50";
            this.label50.Size = new System.Drawing.Size(38, 17);
            this.label50.TabIndex = 61;
            this.label50.Text = "BOD";
            // 
            // txtEtpBod
            // 
            this.txtEtpBod.Location = new System.Drawing.Point(342, 43);
            this.txtEtpBod.Name = "txtEtpBod";
            this.txtEtpBod.Size = new System.Drawing.Size(100, 22);
            this.txtEtpBod.TabIndex = 54;
            this.txtEtpBod.Text = "0";
            // 
            // label49
            // 
            this.label49.AutoSize = true;
            this.label49.Location = new System.Drawing.Point(267, 20);
            this.label49.Name = "label49";
            this.label49.Size = new System.Drawing.Size(38, 17);
            this.label49.TabIndex = 59;
            this.label49.Text = "COD";
            // 
            // txtEtpCod
            // 
            this.txtEtpCod.Location = new System.Drawing.Point(236, 43);
            this.txtEtpCod.Name = "txtEtpCod";
            this.txtEtpCod.Size = new System.Drawing.Size(100, 22);
            this.txtEtpCod.TabIndex = 53;
            this.txtEtpCod.Text = "0";
            // 
            // label52
            // 
            this.label52.AutoSize = true;
            this.label52.Location = new System.Drawing.Point(449, 20);
            this.label52.Name = "label52";
            this.label52.Size = new System.Drawing.Size(98, 17);
            this.label52.TabIndex = 63;
            this.label52.Text = "Water Flow M³";
            // 
            // txtEtpWaterFlow
            // 
            this.txtEtpWaterFlow.Location = new System.Drawing.Point(448, 43);
            this.txtEtpWaterFlow.Name = "txtEtpWaterFlow";
            this.txtEtpWaterFlow.Size = new System.Drawing.Size(100, 22);
            this.txtEtpWaterFlow.TabIndex = 55;
            this.txtEtpWaterFlow.Text = "0";
            // 
            // label56
            // 
            this.label56.AutoSize = true;
            this.label56.Location = new System.Drawing.Point(158, 20);
            this.label56.Name = "label56";
            this.label56.Size = new System.Drawing.Size(35, 17);
            this.label56.TabIndex = 3;
            this.label56.Text = "TSS";
            // 
            // txtEtpTss
            // 
            this.txtEtpTss.Location = new System.Drawing.Point(125, 43);
            this.txtEtpTss.Name = "txtEtpTss";
            this.txtEtpTss.Size = new System.Drawing.Size(100, 22);
            this.txtEtpTss.TabIndex = 52;
            this.txtEtpTss.Text = "0";
            // 
            // btnNewRecord
            // 
            this.btnNewRecord.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnNewRecord.Location = new System.Drawing.Point(1218, 768);
            this.btnNewRecord.Name = "btnNewRecord";
            this.btnNewRecord.Size = new System.Drawing.Size(105, 31);
            this.btnNewRecord.TabIndex = 61;
            this.btnNewRecord.Text = "&New Record";
            this.btnNewRecord.UseVisualStyleBackColor = true;
            this.btnNewRecord.Click += new System.EventHandler(this.btnNewRecord_Click);
            // 
            // btnSave
            // 
            this.btnSave.Enabled = false;
            this.btnSave.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnSave.Location = new System.Drawing.Point(1329, 768);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(105, 31);
            this.btnSave.TabIndex = 60;
            this.btnSave.Text = "&Save";
            this.btnSave.UseVisualStyleBackColor = true;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabParameter1);
            this.tabControl1.Controls.Add(this.tabParameter2);
            this.tabControl1.Location = new System.Drawing.Point(3, 2);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(1444, 764);
            this.tabControl1.TabIndex = 17;
            // 
            // tabParameter1
            // 
            this.tabParameter1.Controls.Add(this.groupBox24);
            this.tabParameter1.Controls.Add(this.groupBox22);
            this.tabParameter1.Controls.Add(this.groupBox21);
            this.tabParameter1.Controls.Add(this.groupBox19);
            this.tabParameter1.Controls.Add(this.groupBox2);
            this.tabParameter1.Controls.Add(this.groupBox18);
            this.tabParameter1.Controls.Add(this.groupBox3);
            this.tabParameter1.Controls.Add(this.groupBox17);
            this.tabParameter1.Controls.Add(this.groupBox4);
            this.tabParameter1.Controls.Add(this.groupBox16);
            this.tabParameter1.Controls.Add(this.groupBox5);
            this.tabParameter1.Controls.Add(this.groupBox15);
            this.tabParameter1.Controls.Add(this.groupBox6);
            this.tabParameter1.Controls.Add(this.groupBox14);
            this.tabParameter1.Controls.Add(this.groupBox13);
            this.tabParameter1.Controls.Add(this.groupBox12);
            this.tabParameter1.Controls.Add(this.groupBox25);
            this.tabParameter1.Location = new System.Drawing.Point(4, 25);
            this.tabParameter1.Name = "tabParameter1";
            this.tabParameter1.Padding = new System.Windows.Forms.Padding(3);
            this.tabParameter1.Size = new System.Drawing.Size(1436, 735);
            this.tabParameter1.TabIndex = 0;
            this.tabParameter1.Text = "Page-1";
            this.tabParameter1.UseVisualStyleBackColor = true;
            // 
            // groupBox24
            // 
            this.groupBox24.Controls.Add(this.txtTransTime);
            this.groupBox24.Controls.Add(this.label98);
            this.groupBox24.Controls.Add(this.label99);
            this.groupBox24.Controls.Add(this.txtTransDate);
            this.groupBox24.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.groupBox24.Location = new System.Drawing.Point(21, 22);
            this.groupBox24.Name = "groupBox24";
            this.groupBox24.Size = new System.Drawing.Size(443, 46);
            this.groupBox24.TabIndex = 20;
            this.groupBox24.TabStop = false;
            // 
            // txtTransTime
            // 
            this.txtTransTime.Location = new System.Drawing.Point(311, 14);
            this.txtTransTime.Name = "txtTransTime";
            this.txtTransTime.ReadOnly = true;
            this.txtTransTime.Size = new System.Drawing.Size(100, 22);
            this.txtTransTime.TabIndex = 1;
            // 
            // label98
            // 
            this.label98.AutoSize = true;
            this.label98.Location = new System.Drawing.Point(23, 15);
            this.label98.Name = "label98";
            this.label98.Size = new System.Drawing.Size(96, 17);
            this.label98.TabIndex = 7;
            this.label98.Text = "ENTRY DATE";
            // 
            // label99
            // 
            this.label99.AutoSize = true;
            this.label99.Location = new System.Drawing.Point(257, 17);
            this.label99.Name = "label99";
            this.label99.Size = new System.Drawing.Size(40, 17);
            this.label99.TabIndex = 6;
            this.label99.Text = "TIME";
            // 
            // txtTransDate
            // 
            this.txtTransDate.CustomFormat = "yyyy-MM-dd";
            this.txtTransDate.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.txtTransDate.Location = new System.Drawing.Point(135, 15);
            this.txtTransDate.Name = "txtTransDate";
            this.txtTransDate.Size = new System.Drawing.Size(100, 22);
            this.txtTransDate.TabIndex = 8;
            // 
            // groupBox22
            // 
            this.groupBox22.Controls.Add(this.txt80tCMassecuitePan);
            this.groupBox22.Controls.Add(this.label111);
            this.groupBox22.Controls.Add(this.txtExhaustCondensateRecovery);
            this.groupBox22.Controls.Add(this.label54);
            this.groupBox22.Controls.Add(this.label53);
            this.groupBox22.Controls.Add(this.txtTotalOperatingTubeWell);
            this.groupBox22.Location = new System.Drawing.Point(21, 670);
            this.groupBox22.Name = "groupBox22";
            this.groupBox22.Size = new System.Drawing.Size(1105, 56);
            this.groupBox22.TabIndex = 15;
            this.groupBox22.TabStop = false;
            // 
            // txt80tCMassecuitePan
            // 
            this.txt80tCMassecuitePan.Location = new System.Drawing.Point(946, 17);
            this.txt80tCMassecuitePan.Name = "txt80tCMassecuitePan";
            this.txt80tCMassecuitePan.Size = new System.Drawing.Size(100, 22);
            this.txt80tCMassecuitePan.TabIndex = 64;
            this.txt80tCMassecuitePan.Text = "0";
            // 
            // label111
            // 
            this.label111.AutoSize = true;
            this.label111.Location = new System.Drawing.Point(715, 20);
            this.label111.Name = "label111";
            this.label111.Size = new System.Drawing.Size(188, 17);
            this.label111.TabIndex = 26;
            this.label111.Text = "No of 80T C Massecuite Pan";
            // 
            // txtExhaustCondensateRecovery
            // 
            this.txtExhaustCondensateRecovery.Location = new System.Drawing.Point(600, 15);
            this.txtExhaustCondensateRecovery.Name = "txtExhaustCondensateRecovery";
            this.txtExhaustCondensateRecovery.Size = new System.Drawing.Size(100, 22);
            this.txtExhaustCondensateRecovery.TabIndex = 63;
            this.txtExhaustCondensateRecovery.Text = "0";
            // 
            // label54
            // 
            this.label54.AutoSize = true;
            this.label54.Location = new System.Drawing.Point(363, 18);
            this.label54.Name = "label54";
            this.label54.Size = new System.Drawing.Size(194, 17);
            this.label54.TabIndex = 24;
            this.label54.Text = "Exhaust Condensate Rcovery";
            // 
            // label53
            // 
            this.label53.AutoSize = true;
            this.label53.Location = new System.Drawing.Point(35, 18);
            this.label53.Name = "label53";
            this.label53.Size = new System.Drawing.Size(171, 17);
            this.label53.TabIndex = 22;
            this.label53.Text = "Total Operating Tube well";
            // 
            // txtTotalOperatingTubeWell
            // 
            this.txtTotalOperatingTubeWell.Location = new System.Drawing.Point(249, 15);
            this.txtTotalOperatingTubeWell.Name = "txtTotalOperatingTubeWell";
            this.txtTotalOperatingTubeWell.Size = new System.Drawing.Size(100, 22);
            this.txtTotalOperatingTubeWell.TabIndex = 62;
            this.txtTotalOperatingTubeWell.Text = "0";
            // 
            // groupBox21
            // 
            this.groupBox21.Controls.Add(this.label51);
            this.groupBox21.Controls.Add(this.label55);
            this.groupBox21.Controls.Add(this.txtPhosphateMixedJuice);
            this.groupBox21.Controls.Add(this.txtPhosphateClearJuice);
            this.groupBox21.Location = new System.Drawing.Point(864, 579);
            this.groupBox21.Name = "groupBox21";
            this.groupBox21.Size = new System.Drawing.Size(246, 85);
            this.groupBox21.TabIndex = 12;
            this.groupBox21.TabStop = false;
            this.groupBox21.Text = "Phosphate Content";
            // 
            // label51
            // 
            this.label51.AutoSize = true;
            this.label51.Location = new System.Drawing.Point(137, 23);
            this.label51.Name = "label51";
            this.label51.Size = new System.Drawing.Size(78, 17);
            this.label51.TabIndex = 4;
            this.label51.Text = "Clear Juice";
            // 
            // label55
            // 
            this.label55.AutoSize = true;
            this.label55.Location = new System.Drawing.Point(28, 23);
            this.label55.Name = "label55";
            this.label55.Size = new System.Drawing.Size(81, 17);
            this.label55.TabIndex = 3;
            this.label55.Text = "Mixed Juice";
            // 
            // txtPhosphateMixedJuice
            // 
            this.txtPhosphateMixedJuice.Location = new System.Drawing.Point(20, 43);
            this.txtPhosphateMixedJuice.Name = "txtPhosphateMixedJuice";
            this.txtPhosphateMixedJuice.Size = new System.Drawing.Size(100, 22);
            this.txtPhosphateMixedJuice.TabIndex = 58;
            this.txtPhosphateMixedJuice.Text = "0";
            // 
            // txtPhosphateClearJuice
            // 
            this.txtPhosphateClearJuice.Location = new System.Drawing.Point(126, 43);
            this.txtPhosphateClearJuice.Name = "txtPhosphateClearJuice";
            this.txtPhosphateClearJuice.Size = new System.Drawing.Size(100, 22);
            this.txtPhosphateClearJuice.TabIndex = 59;
            this.txtPhosphateClearJuice.Text = "0";
            // 
            // groupBox19
            // 
            this.groupBox19.Controls.Add(this.label57);
            this.groupBox19.Controls.Add(this.label58);
            this.groupBox19.Controls.Add(this.txtCalciumMixedJuice);
            this.groupBox19.Controls.Add(this.txtCalciumClearJuice);
            this.groupBox19.Location = new System.Drawing.Point(608, 579);
            this.groupBox19.Name = "groupBox19";
            this.groupBox19.Size = new System.Drawing.Size(246, 85);
            this.groupBox19.TabIndex = 11;
            this.groupBox19.TabStop = false;
            this.groupBox19.Text = "Calcium Content";
            // 
            // label57
            // 
            this.label57.AutoSize = true;
            this.label57.Location = new System.Drawing.Point(137, 23);
            this.label57.Name = "label57";
            this.label57.Size = new System.Drawing.Size(78, 17);
            this.label57.TabIndex = 4;
            this.label57.Text = "Clear Juice";
            // 
            // label58
            // 
            this.label58.AutoSize = true;
            this.label58.Location = new System.Drawing.Point(28, 23);
            this.label58.Name = "label58";
            this.label58.Size = new System.Drawing.Size(81, 17);
            this.label58.TabIndex = 3;
            this.label58.Text = "Mixed Juice";
            // 
            // txtCalciumMixedJuice
            // 
            this.txtCalciumMixedJuice.Location = new System.Drawing.Point(20, 43);
            this.txtCalciumMixedJuice.Name = "txtCalciumMixedJuice";
            this.txtCalciumMixedJuice.Size = new System.Drawing.Size(100, 22);
            this.txtCalciumMixedJuice.TabIndex = 56;
            this.txtCalciumMixedJuice.Text = "0";
            // 
            // txtCalciumClearJuice
            // 
            this.txtCalciumClearJuice.Location = new System.Drawing.Point(126, 43);
            this.txtCalciumClearJuice.Name = "txtCalciumClearJuice";
            this.txtCalciumClearJuice.Size = new System.Drawing.Size(100, 22);
            this.txtCalciumClearJuice.TabIndex = 57;
            this.txtCalciumClearJuice.Text = "0";
            // 
            // groupBox25
            // 
            this.groupBox25.Controls.Add(this.groupBox7);
            this.groupBox25.Controls.Add(this.groupBox10);
            this.groupBox25.Controls.Add(this.groupBox11);
            this.groupBox25.Controls.Add(this.groupBox9);
            this.groupBox25.Controls.Add(this.groupBox8);
            this.groupBox25.Location = new System.Drawing.Point(21, 162);
            this.groupBox25.Name = "groupBox25";
            this.groupBox25.Size = new System.Drawing.Size(1289, 117);
            this.groupBox25.TabIndex = 5;
            this.groupBox25.TabStop = false;
            this.groupBox25.Text = "Re-Melting";
            // 
            // tabParameter2
            // 
            this.tabParameter2.Controls.Add(this.groupBox23);
            this.tabParameter2.Controls.Add(this.groupBox20);
            this.tabParameter2.Controls.Add(this.groupBox1);
            this.tabParameter2.Location = new System.Drawing.Point(4, 25);
            this.tabParameter2.Name = "tabParameter2";
            this.tabParameter2.Padding = new System.Windows.Forms.Padding(3);
            this.tabParameter2.Size = new System.Drawing.Size(1436, 735);
            this.tabParameter2.TabIndex = 1;
            this.tabParameter2.Text = "Page-2";
            this.tabParameter2.UseVisualStyleBackColor = true;
            // 
            // groupBox23
            // 
            this.groupBox23.Controls.Add(this.txtPowerPerQtlOfSugar);
            this.groupBox23.Controls.Add(this.label114);
            this.groupBox23.Controls.Add(this.txtPowerPerTonOfCane);
            this.groupBox23.Controls.Add(this.label113);
            this.groupBox23.Controls.Add(this.txtPowerGen3OldTurbine);
            this.groupBox23.Controls.Add(this.label112);
            this.groupBox23.Controls.Add(this.txTotalPower);
            this.groupBox23.Controls.Add(this.label104);
            this.groupBox23.Controls.Add(this.txtPowerGenImportFromCogen);
            this.groupBox23.Controls.Add(this.label105);
            this.groupBox23.Controls.Add(this.txtPowerGenDg);
            this.groupBox23.Controls.Add(this.label106);
            this.groupBox23.Controls.Add(this.txtPowerGen1Turbine);
            this.groupBox23.Controls.Add(this.label107);
            this.groupBox23.Controls.Add(this.txtPowerGen3NewTurbine);
            this.groupBox23.Controls.Add(this.label108);
            this.groupBox23.Controls.Add(this.txtPowerGen25Turbine);
            this.groupBox23.Controls.Add(this.label109);
            this.groupBox23.Location = new System.Drawing.Point(7, 532);
            this.groupBox23.Name = "groupBox23";
            this.groupBox23.Size = new System.Drawing.Size(1398, 141);
            this.groupBox23.TabIndex = 12;
            this.groupBox23.TabStop = false;
            this.groupBox23.Text = "Power Generation";
            // 
            // txtPowerPerQtlOfSugar
            // 
            this.txtPowerPerQtlOfSugar.Location = new System.Drawing.Point(996, 90);
            this.txtPowerPerQtlOfSugar.Name = "txtPowerPerQtlOfSugar";
            this.txtPowerPerQtlOfSugar.ReadOnly = true;
            this.txtPowerPerQtlOfSugar.Size = new System.Drawing.Size(100, 22);
            this.txtPowerPerQtlOfSugar.TabIndex = 77;
            this.txtPowerPerQtlOfSugar.Text = "0";
            // 
            // label114
            // 
            this.label114.AutoSize = true;
            this.label114.Location = new System.Drawing.Point(850, 93);
            this.label114.Name = "label114";
            this.label114.Size = new System.Drawing.Size(111, 17);
            this.label114.TabIndex = 51;
            this.label114.Text = "Power/Qtl Sugar";
            // 
            // txtPowerPerTonOfCane
            // 
            this.txtPowerPerTonOfCane.Location = new System.Drawing.Point(543, 92);
            this.txtPowerPerTonOfCane.Name = "txtPowerPerTonOfCane";
            this.txtPowerPerTonOfCane.ReadOnly = true;
            this.txtPowerPerTonOfCane.Size = new System.Drawing.Size(100, 22);
            this.txtPowerPerTonOfCane.TabIndex = 76;
            this.txtPowerPerTonOfCane.Text = "0";
            // 
            // label113
            // 
            this.label113.AutoSize = true;
            this.label113.Location = new System.Drawing.Point(397, 95);
            this.label113.Name = "label113";
            this.label113.Size = new System.Drawing.Size(129, 17);
            this.label113.TabIndex = 49;
            this.label113.Text = "Power/Ton of Cane";
            // 
            // txtPowerGen3OldTurbine
            // 
            this.txtPowerGen3OldTurbine.Location = new System.Drawing.Point(815, 19);
            this.txtPowerGen3OldTurbine.Name = "txtPowerGen3OldTurbine";
            this.txtPowerGen3OldTurbine.Size = new System.Drawing.Size(100, 22);
            this.txtPowerGen3OldTurbine.TabIndex = 44;
            this.txtPowerGen3OldTurbine.Text = "0";
            // 
            // label112
            // 
            this.label112.AutoSize = true;
            this.label112.Location = new System.Drawing.Point(669, 22);
            this.label112.Name = "label112";
            this.label112.Size = new System.Drawing.Size(135, 17);
            this.label112.TabIndex = 47;
            this.label112.Text = "3.0 MW Old Turbine";
            // 
            // txTotalPower
            // 
            this.txTotalPower.Location = new System.Drawing.Point(216, 87);
            this.txTotalPower.Name = "txTotalPower";
            this.txTotalPower.ReadOnly = true;
            this.txTotalPower.Size = new System.Drawing.Size(100, 22);
            this.txTotalPower.TabIndex = 75;
            this.txTotalPower.Text = "0";
            // 
            // label104
            // 
            this.label104.AutoSize = true;
            this.label104.Location = new System.Drawing.Point(123, 90);
            this.label104.Name = "label104";
            this.label104.Size = new System.Drawing.Size(83, 17);
            this.label104.TabIndex = 18;
            this.label104.Text = "Total Power";
            // 
            // txtPowerGenImportFromCogen
            // 
            this.txtPowerGenImportFromCogen.Location = new System.Drawing.Point(543, 56);
            this.txtPowerGenImportFromCogen.Name = "txtPowerGenImportFromCogen";
            this.txtPowerGenImportFromCogen.Size = new System.Drawing.Size(100, 22);
            this.txtPowerGenImportFromCogen.TabIndex = 47;
            this.txtPowerGenImportFromCogen.Text = "0";
            // 
            // label105
            // 
            this.label105.AutoSize = true;
            this.label105.Location = new System.Drawing.Point(380, 58);
            this.label105.Name = "label105";
            this.label105.Size = new System.Drawing.Size(132, 17);
            this.label105.TabIndex = 16;
            this.label105.Text = "Import from Co-Gen";
            // 
            // txtPowerGenDg
            // 
            this.txtPowerGenDg.Location = new System.Drawing.Point(216, 50);
            this.txtPowerGenDg.Name = "txtPowerGenDg";
            this.txtPowerGenDg.Size = new System.Drawing.Size(100, 22);
            this.txtPowerGenDg.TabIndex = 46;
            this.txtPowerGenDg.Text = "0";
            // 
            // label106
            // 
            this.label106.AutoSize = true;
            this.label106.Location = new System.Drawing.Point(156, 55);
            this.label106.Name = "label106";
            this.label106.Size = new System.Drawing.Size(54, 17);
            this.label106.TabIndex = 14;
            this.label106.Text = "DG Set";
            // 
            // txtPowerGen1Turbine
            // 
            this.txtPowerGen1Turbine.Location = new System.Drawing.Point(1098, 17);
            this.txtPowerGen1Turbine.Name = "txtPowerGen1Turbine";
            this.txtPowerGen1Turbine.Size = new System.Drawing.Size(100, 22);
            this.txtPowerGen1Turbine.TabIndex = 45;
            this.txtPowerGen1Turbine.Text = "0";
            // 
            // label107
            // 
            this.label107.AutoSize = true;
            this.label107.Location = new System.Drawing.Point(983, 20);
            this.label107.Name = "label107";
            this.label107.Size = new System.Drawing.Size(109, 17);
            this.label107.TabIndex = 12;
            this.label107.Text = "1.6 MW Turnine";
            // 
            // txtPowerGen3NewTurbine
            // 
            this.txtPowerGen3NewTurbine.Location = new System.Drawing.Point(543, 21);
            this.txtPowerGen3NewTurbine.Name = "txtPowerGen3NewTurbine";
            this.txtPowerGen3NewTurbine.Size = new System.Drawing.Size(100, 22);
            this.txtPowerGen3NewTurbine.TabIndex = 43;
            this.txtPowerGen3NewTurbine.Text = "0";
            // 
            // label108
            // 
            this.label108.AutoSize = true;
            this.label108.Location = new System.Drawing.Point(397, 24);
            this.label108.Name = "label108";
            this.label108.Size = new System.Drawing.Size(140, 17);
            this.label108.TabIndex = 10;
            this.label108.Text = "3.0 MW New Turbine";
            // 
            // txtPowerGen25Turbine
            // 
            this.txtPowerGen25Turbine.Location = new System.Drawing.Point(215, 21);
            this.txtPowerGen25Turbine.Name = "txtPowerGen25Turbine";
            this.txtPowerGen25Turbine.Size = new System.Drawing.Size(100, 22);
            this.txtPowerGen25Turbine.TabIndex = 42;
            this.txtPowerGen25Turbine.Text = "0";
            // 
            // label109
            // 
            this.label109.AutoSize = true;
            this.label109.Location = new System.Drawing.Point(63, 24);
            this.label109.Name = "label109";
            this.label109.Size = new System.Drawing.Size(121, 17);
            this.label109.TabIndex = 8;
            this.label109.Text = "25.3 MW Turbine ";
            // 
            // groupBox20
            // 
            this.groupBox20.Controls.Add(this.txtSteamPercentCane);
            this.groupBox20.Controls.Add(this.label117);
            this.groupBox20.Controls.Add(this.txtSteamPerTonOfCane);
            this.groupBox20.Controls.Add(this.label116);
            this.groupBox20.Controls.Add(this.txtSteamPerQtlOfSugar);
            this.groupBox20.Controls.Add(this.label115);
            this.groupBox20.Controls.Add(this.txtD_sulpher_heating);
            this.groupBox20.Controls.Add(this.label100);
            this.groupBox20.Controls.Add(this.txtExhaustStamConsumption);
            this.groupBox20.Controls.Add(this.label101);
            this.groupBox20.Controls.Add(this.txtExhaustSteamGeneration);
            this.groupBox20.Controls.Add(this.label94);
            this.groupBox20.Controls.Add(this.txtDrainPipeLoss);
            this.groupBox20.Controls.Add(this.label95);
            this.groupBox20.Controls.Add(this.txtAtaFromCogen);
            this.groupBox20.Controls.Add(this.label96);
            this.groupBox20.Controls.Add(this.txtBleedingAcf);
            this.groupBox20.Controls.Add(this.txtBleedingProcess);
            this.groupBox20.Controls.Add(this.label97);
            this.groupBox20.Controls.Add(this.label87);
            this.groupBox20.Controls.Add(this.txtPowerTurbines);
            this.groupBox20.Controls.Add(this.label91);
            this.groupBox20.Controls.Add(this.txtLiveSteamConsumption);
            this.groupBox20.Controls.Add(this.label92);
            this.groupBox20.Controls.Add(this.txtLiveStamGeneration);
            this.groupBox20.Controls.Add(this.label93);
            this.groupBox20.Location = new System.Drawing.Point(7, 388);
            this.groupBox20.Name = "groupBox20";
            this.groupBox20.Size = new System.Drawing.Size(1398, 141);
            this.groupBox20.TabIndex = 11;
            this.groupBox20.TabStop = false;
            // 
            // txtSteamPercentCane
            // 
            this.txtSteamPercentCane.Location = new System.Drawing.Point(724, 101);
            this.txtSteamPercentCane.Name = "txtSteamPercentCane";
            this.txtSteamPercentCane.ReadOnly = true;
            this.txtSteamPercentCane.Size = new System.Drawing.Size(100, 22);
            this.txtSteamPercentCane.TabIndex = 72;
            this.txtSteamPercentCane.Text = "0";
            // 
            // label117
            // 
            this.label117.AutoSize = true;
            this.label117.Location = new System.Drawing.Point(617, 102);
            this.label117.Name = "label117";
            this.label117.Size = new System.Drawing.Size(101, 17);
            this.label117.TabIndex = 45;
            this.label117.Text = "Steam % Cane";
            // 
            // txtSteamPerTonOfCane
            // 
            this.txtSteamPerTonOfCane.Location = new System.Drawing.Point(986, 102);
            this.txtSteamPerTonOfCane.Name = "txtSteamPerTonOfCane";
            this.txtSteamPerTonOfCane.ReadOnly = true;
            this.txtSteamPerTonOfCane.Size = new System.Drawing.Size(100, 22);
            this.txtSteamPerTonOfCane.TabIndex = 73;
            this.txtSteamPerTonOfCane.Text = "0";
            // 
            // label116
            // 
            this.label116.AutoSize = true;
            this.label116.Location = new System.Drawing.Point(836, 103);
            this.label116.Name = "label116";
            this.label116.Size = new System.Drawing.Size(130, 17);
            this.label116.TabIndex = 43;
            this.label116.Text = "Steam/Ton of Cane";
            // 
            // txtSteamPerQtlOfSugar
            // 
            this.txtSteamPerQtlOfSugar.Location = new System.Drawing.Point(1242, 102);
            this.txtSteamPerQtlOfSugar.Name = "txtSteamPerQtlOfSugar";
            this.txtSteamPerQtlOfSugar.ReadOnly = true;
            this.txtSteamPerQtlOfSugar.Size = new System.Drawing.Size(100, 22);
            this.txtSteamPerQtlOfSugar.TabIndex = 74;
            this.txtSteamPerQtlOfSugar.Text = "0";
            // 
            // label115
            // 
            this.label115.AutoSize = true;
            this.label115.Location = new System.Drawing.Point(1101, 105);
            this.label115.Name = "label115";
            this.label115.Size = new System.Drawing.Size(135, 17);
            this.label115.TabIndex = 41;
            this.label115.Text = "Steam/Ton of Sugar";
            // 
            // txtD_sulpher_heating
            // 
            this.txtD_sulpher_heating.Location = new System.Drawing.Point(815, 58);
            this.txtD_sulpher_heating.Name = "txtD_sulpher_heating";
            this.txtD_sulpher_heating.Size = new System.Drawing.Size(100, 22);
            this.txtD_sulpher_heating.TabIndex = 40;
            this.txtD_sulpher_heating.Text = "0";
            // 
            // label100
            // 
            this.label100.AutoSize = true;
            this.label100.Location = new System.Drawing.Point(680, 61);
            this.label100.Name = "label100";
            this.label100.Size = new System.Drawing.Size(125, 17);
            this.label100.TabIndex = 26;
            this.label100.Text = "D-Sulpher Heating";
            // 
            // txtExhaustStamConsumption
            // 
            this.txtExhaustStamConsumption.Location = new System.Drawing.Point(509, 101);
            this.txtExhaustStamConsumption.Name = "txtExhaustStamConsumption";
            this.txtExhaustStamConsumption.ReadOnly = true;
            this.txtExhaustStamConsumption.Size = new System.Drawing.Size(100, 22);
            this.txtExhaustStamConsumption.TabIndex = 71;
            this.txtExhaustStamConsumption.Text = "0";
            // 
            // label101
            // 
            this.label101.AutoSize = true;
            this.label101.Location = new System.Drawing.Point(323, 101);
            this.label101.Name = "label101";
            this.label101.Size = new System.Drawing.Size(180, 17);
            this.label101.TabIndex = 24;
            this.label101.Text = "Exhaust Stam Consumption";
            // 
            // txtExhaustSteamGeneration
            // 
            this.txtExhaustSteamGeneration.Location = new System.Drawing.Point(215, 98);
            this.txtExhaustSteamGeneration.Name = "txtExhaustSteamGeneration";
            this.txtExhaustSteamGeneration.ReadOnly = true;
            this.txtExhaustSteamGeneration.Size = new System.Drawing.Size(100, 22);
            this.txtExhaustSteamGeneration.TabIndex = 70;
            this.txtExhaustSteamGeneration.Text = "0";
            // 
            // label94
            // 
            this.label94.AutoSize = true;
            this.label94.Location = new System.Drawing.Point(32, 101);
            this.label94.Name = "label94";
            this.label94.Size = new System.Drawing.Size(177, 17);
            this.label94.TabIndex = 22;
            this.label94.Text = "Exhaust Steam Generation";
            // 
            // txtDrainPipeLoss
            // 
            this.txtDrainPipeLoss.Location = new System.Drawing.Point(1097, 58);
            this.txtDrainPipeLoss.Name = "txtDrainPipeLoss";
            this.txtDrainPipeLoss.Size = new System.Drawing.Size(100, 22);
            this.txtDrainPipeLoss.TabIndex = 41;
            this.txtDrainPipeLoss.Text = "0";
            // 
            // label95
            // 
            this.label95.AutoSize = true;
            this.label95.Location = new System.Drawing.Point(971, 61);
            this.label95.Name = "label95";
            this.label95.Size = new System.Drawing.Size(121, 17);
            this.label95.TabIndex = 20;
            this.label95.Text = "Drain && Pipe Loss";
            // 
            // txtAtaFromCogen
            // 
            this.txtAtaFromCogen.Location = new System.Drawing.Point(543, 60);
            this.txtAtaFromCogen.Name = "txtAtaFromCogen";
            this.txtAtaFromCogen.Size = new System.Drawing.Size(100, 22);
            this.txtAtaFromCogen.TabIndex = 39;
            this.txtAtaFromCogen.Text = "0";
            // 
            // label96
            // 
            this.label96.AutoSize = true;
            this.label96.Location = new System.Drawing.Point(417, 63);
            this.label96.Name = "label96";
            this.label96.Size = new System.Drawing.Size(116, 17);
            this.label96.TabIndex = 18;
            this.label96.Text = "3 Ata from cogen";
            // 
            // txtBleedingAcf
            // 
            this.txtBleedingAcf.Location = new System.Drawing.Point(216, 58);
            this.txtBleedingAcf.Name = "txtBleedingAcf";
            this.txtBleedingAcf.Size = new System.Drawing.Size(100, 22);
            this.txtBleedingAcf.TabIndex = 38;
            this.txtBleedingAcf.Text = "0";
            // 
            // txtBleedingProcess
            // 
            this.txtBleedingProcess.Location = new System.Drawing.Point(1098, 16);
            this.txtBleedingProcess.Name = "txtBleedingProcess";
            this.txtBleedingProcess.Size = new System.Drawing.Size(100, 22);
            this.txtBleedingProcess.TabIndex = 37;
            this.txtBleedingProcess.Text = "0";
            // 
            // label97
            // 
            this.label97.AutoSize = true;
            this.label97.Location = new System.Drawing.Point(7, 63);
            this.label97.Name = "label97";
            this.label97.Size = new System.Drawing.Size(198, 17);
            this.label97.TabIndex = 16;
            this.label97.Text = "Blee. at ACF && Sul Burn/ 9 Ata";
            // 
            // label87
            // 
            this.label87.AutoSize = true;
            this.label87.Location = new System.Drawing.Point(959, 19);
            this.label87.Name = "label87";
            this.label87.Size = new System.Drawing.Size(133, 17);
            this.label87.TabIndex = 14;
            this.label87.Text = "Bleeding in Process";
            // 
            // txtPowerTurbines
            // 
            this.txtPowerTurbines.Location = new System.Drawing.Point(815, 18);
            this.txtPowerTurbines.Name = "txtPowerTurbines";
            this.txtPowerTurbines.Size = new System.Drawing.Size(100, 22);
            this.txtPowerTurbines.TabIndex = 36;
            this.txtPowerTurbines.Text = "0";
            // 
            // label91
            // 
            this.label91.AutoSize = true;
            this.label91.Location = new System.Drawing.Point(690, 21);
            this.label91.Name = "label91";
            this.label91.Size = new System.Drawing.Size(107, 17);
            this.label91.TabIndex = 12;
            this.label91.Text = "Power Turbines";
            // 
            // txtLiveSteamConsumption
            // 
            this.txtLiveSteamConsumption.Location = new System.Drawing.Point(543, 18);
            this.txtLiveSteamConsumption.Name = "txtLiveSteamConsumption";
            this.txtLiveSteamConsumption.Size = new System.Drawing.Size(100, 22);
            this.txtLiveSteamConsumption.TabIndex = 35;
            this.txtLiveSteamConsumption.Text = "0";
            // 
            // label92
            // 
            this.label92.AutoSize = true;
            this.label92.Location = new System.Drawing.Point(377, 21);
            this.label92.Name = "label92";
            this.label92.Size = new System.Drawing.Size(156, 17);
            this.label92.TabIndex = 10;
            this.label92.Text = "Live Stem Consumption";
            // 
            // txtLiveStamGeneration
            // 
            this.txtLiveStamGeneration.Location = new System.Drawing.Point(215, 18);
            this.txtLiveStamGeneration.Name = "txtLiveStamGeneration";
            this.txtLiveStamGeneration.Size = new System.Drawing.Size(100, 22);
            this.txtLiveStamGeneration.TabIndex = 34;
            this.txtLiveStamGeneration.Text = "0";
            this.txtLiveStamGeneration.TextChanged += new System.EventHandler(this.txtLiveStamGeneration_TextChanged);
            // 
            // label93
            // 
            this.label93.AutoSize = true;
            this.label93.Location = new System.Drawing.Point(52, 21);
            this.label93.Name = "label93";
            this.label93.Size = new System.Drawing.Size(153, 17);
            this.label93.TabIndex = 8;
            this.label93.Text = "Live Steam Generation";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.txtBoilerWater);
            this.groupBox1.Controls.Add(this.label120);
            this.groupBox1.Controls.Add(this.txtOmPryExt);
            this.groupBox1.Controls.Add(this.label118);
            this.groupBox1.Controls.Add(this.txtOmPIndex);
            this.groupBox1.Controls.Add(this.label119);
            this.groupBox1.Controls.Add(this.txtPhMixedJuice);
            this.groupBox1.Controls.Add(this.label88);
            this.groupBox1.Controls.Add(this.txtPhPrimaryJuice);
            this.groupBox1.Controls.Add(this.label89);
            this.groupBox1.Controls.Add(this.txtIuClearJuice);
            this.groupBox1.Controls.Add(this.label90);
            this.groupBox1.Controls.Add(this.txtIuMixedJuice);
            this.groupBox1.Controls.Add(this.label83);
            this.groupBox1.Controls.Add(this.txtIuPrimaryJuice);
            this.groupBox1.Controls.Add(this.label84);
            this.groupBox1.Controls.Add(this.txtRainFall);
            this.groupBox1.Controls.Add(this.label85);
            this.groupBox1.Controls.Add(this.txtHumidity);
            this.groupBox1.Controls.Add(this.label86);
            this.groupBox1.Controls.Add(this.txtTempMin);
            this.groupBox1.Controls.Add(this.label79);
            this.groupBox1.Controls.Add(this.txtTempMax);
            this.groupBox1.Controls.Add(this.label80);
            this.groupBox1.Controls.Add(this.TxtRsPercentage);
            this.groupBox1.Controls.Add(this.label81);
            this.groupBox1.Controls.Add(this.txtTrsPercentage);
            this.groupBox1.Controls.Add(this.label82);
            this.groupBox1.Controls.Add(this.txtNmPryExt);
            this.groupBox1.Controls.Add(this.label75);
            this.groupBox1.Controls.Add(this.txtNmPIndex);
            this.groupBox1.Controls.Add(this.label76);
            this.groupBox1.Controls.Add(this.txtBagasseStock);
            this.groupBox1.Controls.Add(this.label77);
            this.groupBox1.Controls.Add(this.txtBagasseSold);
            this.groupBox1.Controls.Add(this.label78);
            this.groupBox1.Controls.Add(this.txtCfWater);
            this.groupBox1.Controls.Add(this.label71);
            this.groupBox1.Controls.Add(this.txtPanWater);
            this.groupBox1.Controls.Add(this.label72);
            this.groupBox1.Controls.Add(this.txtFilterWater);
            this.groupBox1.Controls.Add(this.label73);
            this.groupBox1.Controls.Add(this.txtPowerExportUppcb);
            this.groupBox1.Controls.Add(this.label74);
            this.groupBox1.Controls.Add(this.txtPowerFromUppcb);
            this.groupBox1.Controls.Add(this.label67);
            this.groupBox1.Controls.Add(this.txtBaggasseBaed);
            this.groupBox1.Controls.Add(this.label68);
            this.groupBox1.Controls.Add(this.txtBoilerFeedWater);
            this.groupBox1.Controls.Add(this.label70);
            this.groupBox1.Controls.Add(this.txtBoilerSteamPressHp);
            this.groupBox1.Controls.Add(this.label66);
            this.groupBox1.Controls.Add(this.txtBoilerSteamPressLp);
            this.groupBox1.Controls.Add(this.label65);
            this.groupBox1.Controls.Add(this.txtExhaustSteamPressHp);
            this.groupBox1.Controls.Add(this.label64);
            this.groupBox1.Controls.Add(this.txtExhaustSteamPressLp);
            this.groupBox1.Controls.Add(this.label63);
            this.groupBox1.Controls.Add(this.txtVaccumeOnEvap);
            this.groupBox1.Controls.Add(this.label62);
            this.groupBox1.Controls.Add(this.txtVaccumeOnPan);
            this.groupBox1.Controls.Add(this.label61);
            this.groupBox1.Controls.Add(this.txtInjectionOutlet);
            this.groupBox1.Controls.Add(this.label60);
            this.groupBox1.Controls.Add(this.txtInjectionInlet);
            this.groupBox1.Controls.Add(this.label59);
            this.groupBox1.Location = new System.Drawing.Point(7, 6);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(1398, 375);
            this.groupBox1.TabIndex = 10;
            this.groupBox1.TabStop = false;
            // 
            // txtBoilerWater
            // 
            this.txtBoilerWater.Location = new System.Drawing.Point(543, 107);
            this.txtBoilerWater.Name = "txtBoilerWater";
            this.txtBoilerWater.Size = new System.Drawing.Size(100, 22);
            this.txtBoilerWater.TabIndex = 10;
            this.txtBoilerWater.Text = "0";
            // 
            // label120
            // 
            this.label120.AutoSize = true;
            this.label120.Location = new System.Drawing.Point(451, 110);
            this.label120.Name = "label120";
            this.label120.Size = new System.Drawing.Size(86, 17);
            this.label120.TabIndex = 66;
            this.label120.Text = "Boiler Water";
            // 
            // txtOmPryExt
            // 
            this.txtOmPryExt.Location = new System.Drawing.Point(1097, 226);
            this.txtOmPryExt.Name = "txtOmPryExt";
            this.txtOmPryExt.Size = new System.Drawing.Size(100, 22);
            this.txtOmPryExt.TabIndex = 22;
            this.txtOmPryExt.Text = "0";
            // 
            // label118
            // 
            this.label118.AutoSize = true;
            this.label118.Location = new System.Drawing.Point(976, 229);
            this.label118.Name = "label118";
            this.label118.Size = new System.Drawing.Size(106, 17);
            this.label118.TabIndex = 64;
            this.label118.Text = "Pry. Ext Old Mill";
            // 
            // txtOmPIndex
            // 
            this.txtOmPIndex.Location = new System.Drawing.Point(815, 226);
            this.txtOmPIndex.Name = "txtOmPIndex";
            this.txtOmPIndex.Size = new System.Drawing.Size(100, 22);
            this.txtOmPIndex.TabIndex = 21;
            this.txtOmPIndex.Text = "0";
            // 
            // label119
            // 
            this.label119.AutoSize = true;
            this.label119.Location = new System.Drawing.Point(696, 229);
            this.label119.Name = "label119";
            this.label119.Size = new System.Drawing.Size(108, 17);
            this.label119.TabIndex = 63;
            this.label119.Text = "P. Index Old Mill";
            // 
            // txtPhMixedJuice
            // 
            this.txtPhMixedJuice.Location = new System.Drawing.Point(815, 344);
            this.txtPhMixedJuice.Name = "txtPhMixedJuice";
            this.txtPhMixedJuice.Size = new System.Drawing.Size(100, 22);
            this.txtPhMixedJuice.TabIndex = 33;
            this.txtPhMixedJuice.Text = "0";
            // 
            // label88
            // 
            this.label88.AutoSize = true;
            this.label88.Location = new System.Drawing.Point(708, 347);
            this.label88.Name = "label88";
            this.label88.Size = new System.Drawing.Size(101, 17);
            this.label88.TabIndex = 60;
            this.label88.Text = "ph Mixed Juice";
            // 
            // txtPhPrimaryJuice
            // 
            this.txtPhPrimaryJuice.Location = new System.Drawing.Point(543, 345);
            this.txtPhPrimaryJuice.Name = "txtPhPrimaryJuice";
            this.txtPhPrimaryJuice.Size = new System.Drawing.Size(100, 22);
            this.txtPhPrimaryJuice.TabIndex = 32;
            this.txtPhPrimaryJuice.Text = "0";
            // 
            // label89
            // 
            this.label89.AutoSize = true;
            this.label89.Location = new System.Drawing.Point(420, 348);
            this.label89.Name = "label89";
            this.label89.Size = new System.Drawing.Size(113, 17);
            this.label89.TabIndex = 58;
            this.label89.Text = "ph Primary Juice";
            // 
            // txtIuClearJuice
            // 
            this.txtIuClearJuice.Location = new System.Drawing.Point(215, 347);
            this.txtIuClearJuice.Name = "txtIuClearJuice";
            this.txtIuClearJuice.Size = new System.Drawing.Size(100, 22);
            this.txtIuClearJuice.TabIndex = 31;
            this.txtIuClearJuice.Text = "0";
            // 
            // label90
            // 
            this.label90.AutoSize = true;
            this.label90.Location = new System.Drawing.Point(99, 350);
            this.label90.Name = "label90";
            this.label90.Size = new System.Drawing.Size(110, 17);
            this.label90.TabIndex = 56;
            this.label90.Text = "IU in Clear Juice";
            // 
            // txtIuMixedJuice
            // 
            this.txtIuMixedJuice.Location = new System.Drawing.Point(1098, 306);
            this.txtIuMixedJuice.Name = "txtIuMixedJuice";
            this.txtIuMixedJuice.Size = new System.Drawing.Size(100, 22);
            this.txtIuMixedJuice.TabIndex = 30;
            this.txtIuMixedJuice.Text = "0";
            // 
            // label83
            // 
            this.label83.AutoSize = true;
            this.label83.Location = new System.Drawing.Point(979, 309);
            this.label83.Name = "label83";
            this.label83.Size = new System.Drawing.Size(113, 17);
            this.label83.TabIndex = 54;
            this.label83.Text = "IU in Mixed Juice";
            // 
            // txtIuPrimaryJuice
            // 
            this.txtIuPrimaryJuice.Location = new System.Drawing.Point(815, 306);
            this.txtIuPrimaryJuice.Name = "txtIuPrimaryJuice";
            this.txtIuPrimaryJuice.Size = new System.Drawing.Size(100, 22);
            this.txtIuPrimaryJuice.TabIndex = 29;
            this.txtIuPrimaryJuice.Text = "0";
            // 
            // label84
            // 
            this.label84.AutoSize = true;
            this.label84.Location = new System.Drawing.Point(684, 309);
            this.label84.Name = "label84";
            this.label84.Size = new System.Drawing.Size(125, 17);
            this.label84.TabIndex = 52;
            this.label84.Text = "IU in Primary Juice";
            // 
            // txtRainFall
            // 
            this.txtRainFall.Location = new System.Drawing.Point(543, 306);
            this.txtRainFall.Name = "txtRainFall";
            this.txtRainFall.Size = new System.Drawing.Size(100, 22);
            this.txtRainFall.TabIndex = 28;
            this.txtRainFall.Text = "0";
            // 
            // label85
            // 
            this.label85.AutoSize = true;
            this.label85.Location = new System.Drawing.Point(438, 309);
            this.label85.Name = "label85";
            this.label85.Size = new System.Drawing.Size(95, 17);
            this.label85.TabIndex = 50;
            this.label85.Text = "Rain Fall(mm)";
            // 
            // txtHumidity
            // 
            this.txtHumidity.Location = new System.Drawing.Point(215, 306);
            this.txtHumidity.Name = "txtHumidity";
            this.txtHumidity.Size = new System.Drawing.Size(100, 22);
            this.txtHumidity.TabIndex = 27;
            this.txtHumidity.Text = "0";
            // 
            // label86
            // 
            this.label86.AutoSize = true;
            this.label86.Location = new System.Drawing.Point(150, 309);
            this.label86.Name = "label86";
            this.label86.Size = new System.Drawing.Size(59, 17);
            this.label86.TabIndex = 48;
            this.label86.Text = "Humdity";
            // 
            // txtTempMin
            // 
            this.txtTempMin.Location = new System.Drawing.Point(1098, 264);
            this.txtTempMin.Name = "txtTempMin";
            this.txtTempMin.Size = new System.Drawing.Size(100, 22);
            this.txtTempMin.TabIndex = 26;
            this.txtTempMin.Text = "0";
            // 
            // label79
            // 
            this.label79.AutoSize = true;
            this.label79.Location = new System.Drawing.Point(1003, 267);
            this.label79.Name = "label79";
            this.label79.Size = new System.Drawing.Size(89, 17);
            this.label79.TabIndex = 46;
            this.label79.Text = "Temp°C Min.";
            // 
            // txtTempMax
            // 
            this.txtTempMax.Location = new System.Drawing.Point(815, 264);
            this.txtTempMax.Name = "txtTempMax";
            this.txtTempMax.Size = new System.Drawing.Size(100, 22);
            this.txtTempMax.TabIndex = 25;
            this.txtTempMax.Text = "0";
            // 
            // label80
            // 
            this.label80.AutoSize = true;
            this.label80.Location = new System.Drawing.Point(721, 267);
            this.label80.Name = "label80";
            this.label80.Size = new System.Drawing.Size(88, 17);
            this.label80.TabIndex = 44;
            this.label80.Text = "Temp°C Max";
            // 
            // TxtRsPercentage
            // 
            this.TxtRsPercentage.Location = new System.Drawing.Point(543, 264);
            this.TxtRsPercentage.Name = "TxtRsPercentage";
            this.TxtRsPercentage.Size = new System.Drawing.Size(100, 22);
            this.TxtRsPercentage.TabIndex = 24;
            this.TxtRsPercentage.Text = "0";
            // 
            // label81
            // 
            this.label81.AutoSize = true;
            this.label81.Location = new System.Drawing.Point(494, 267);
            this.label81.Name = "label81";
            this.label81.Size = new System.Drawing.Size(39, 17);
            this.label81.TabIndex = 42;
            this.label81.Text = "RS%";
            // 
            // txtTrsPercentage
            // 
            this.txtTrsPercentage.Location = new System.Drawing.Point(215, 264);
            this.txtTrsPercentage.Name = "txtTrsPercentage";
            this.txtTrsPercentage.Size = new System.Drawing.Size(100, 22);
            this.txtTrsPercentage.TabIndex = 23;
            this.txtTrsPercentage.Text = "0";
            // 
            // label82
            // 
            this.label82.AutoSize = true;
            this.label82.Location = new System.Drawing.Point(161, 267);
            this.label82.Name = "label82";
            this.label82.Size = new System.Drawing.Size(48, 17);
            this.label82.TabIndex = 40;
            this.label82.Text = "TRS%";
            // 
            // txtNmPryExt
            // 
            this.txtNmPryExt.Location = new System.Drawing.Point(543, 228);
            this.txtNmPryExt.Name = "txtNmPryExt";
            this.txtNmPryExt.Size = new System.Drawing.Size(100, 22);
            this.txtNmPryExt.TabIndex = 20;
            this.txtNmPryExt.Text = "0";
            // 
            // label75
            // 
            this.label75.AutoSize = true;
            this.label75.Location = new System.Drawing.Point(422, 231);
            this.label75.Name = "label75";
            this.label75.Size = new System.Drawing.Size(111, 17);
            this.label75.TabIndex = 38;
            this.label75.Text = "Pry. Ext New Mill";
            // 
            // txtNmPIndex
            // 
            this.txtNmPIndex.Location = new System.Drawing.Point(215, 228);
            this.txtNmPIndex.Name = "txtNmPIndex";
            this.txtNmPIndex.Size = new System.Drawing.Size(100, 22);
            this.txtNmPIndex.TabIndex = 19;
            this.txtNmPIndex.Text = "0";
            // 
            // label76
            // 
            this.label76.AutoSize = true;
            this.label76.Location = new System.Drawing.Point(96, 231);
            this.label76.Name = "label76";
            this.label76.Size = new System.Drawing.Size(113, 17);
            this.label76.TabIndex = 36;
            this.label76.Text = "P. Index New Mill";
            // 
            // txtBagasseStock
            // 
            this.txtBagasseStock.Location = new System.Drawing.Point(543, 185);
            this.txtBagasseStock.Name = "txtBagasseStock";
            this.txtBagasseStock.Size = new System.Drawing.Size(100, 22);
            this.txtBagasseStock.TabIndex = 18;
            this.txtBagasseStock.Text = "0";
            // 
            // label77
            // 
            this.label77.AutoSize = true;
            this.label77.Location = new System.Drawing.Point(431, 188);
            this.label77.Name = "label77";
            this.label77.Size = new System.Drawing.Size(102, 17);
            this.label77.TabIndex = 34;
            this.label77.Text = "Bagasse Stock";
            // 
            // txtBagasseSold
            // 
            this.txtBagasseSold.Location = new System.Drawing.Point(215, 187);
            this.txtBagasseSold.Name = "txtBagasseSold";
            this.txtBagasseSold.Size = new System.Drawing.Size(100, 22);
            this.txtBagasseSold.TabIndex = 17;
            this.txtBagasseSold.Text = "0";
            // 
            // label78
            // 
            this.label78.AutoSize = true;
            this.label78.Location = new System.Drawing.Point(114, 190);
            this.label78.Name = "label78";
            this.label78.Size = new System.Drawing.Size(95, 17);
            this.label78.TabIndex = 32;
            this.label78.Text = "Bagasse Sold";
            // 
            // txtCfWater
            // 
            this.txtCfWater.Location = new System.Drawing.Point(1098, 149);
            this.txtCfWater.Name = "txtCfWater";
            this.txtCfWater.Size = new System.Drawing.Size(100, 22);
            this.txtCfWater.TabIndex = 16;
            this.txtCfWater.Text = "0";
            // 
            // label71
            // 
            this.label71.AutoSize = true;
            this.label71.Location = new System.Drawing.Point(1021, 152);
            this.label71.Name = "label71";
            this.label71.Size = new System.Drawing.Size(71, 17);
            this.label71.TabIndex = 30;
            this.label71.Text = "C/F Water";
            // 
            // txtPanWater
            // 
            this.txtPanWater.Location = new System.Drawing.Point(815, 149);
            this.txtPanWater.Name = "txtPanWater";
            this.txtPanWater.Size = new System.Drawing.Size(100, 22);
            this.txtPanWater.TabIndex = 15;
            this.txtPanWater.Text = "0";
            // 
            // label72
            // 
            this.label72.AutoSize = true;
            this.label72.Location = new System.Drawing.Point(734, 152);
            this.label72.Name = "label72";
            this.label72.Size = new System.Drawing.Size(75, 17);
            this.label72.TabIndex = 28;
            this.label72.Text = "Pan Water";
            // 
            // txtFilterWater
            // 
            this.txtFilterWater.Location = new System.Drawing.Point(543, 149);
            this.txtFilterWater.Name = "txtFilterWater";
            this.txtFilterWater.Size = new System.Drawing.Size(100, 22);
            this.txtFilterWater.TabIndex = 14;
            this.txtFilterWater.Text = "0";
            // 
            // label73
            // 
            this.label73.AutoSize = true;
            this.label73.Location = new System.Drawing.Point(456, 152);
            this.label73.Name = "label73";
            this.label73.Size = new System.Drawing.Size(81, 17);
            this.label73.TabIndex = 26;
            this.label73.Text = "Filter Water";
            // 
            // txtPowerExportUppcb
            // 
            this.txtPowerExportUppcb.Location = new System.Drawing.Point(215, 149);
            this.txtPowerExportUppcb.Name = "txtPowerExportUppcb";
            this.txtPowerExportUppcb.Size = new System.Drawing.Size(100, 22);
            this.txtPowerExportUppcb.TabIndex = 13;
            this.txtPowerExportUppcb.Text = "0";
            // 
            // label74
            // 
            this.label74.AutoSize = true;
            this.label74.Location = new System.Drawing.Point(36, 152);
            this.label74.Name = "label74";
            this.label74.Size = new System.Drawing.Size(173, 17);
            this.label74.TabIndex = 24;
            this.label74.Text = "Power Exported to UPPCB";
            // 
            // txtPowerFromUppcb
            // 
            this.txtPowerFromUppcb.Location = new System.Drawing.Point(1098, 107);
            this.txtPowerFromUppcb.Name = "txtPowerFromUppcb";
            this.txtPowerFromUppcb.Size = new System.Drawing.Size(100, 22);
            this.txtPowerFromUppcb.TabIndex = 12;
            this.txtPowerFromUppcb.Text = "0";
            // 
            // label67
            // 
            this.label67.AutoSize = true;
            this.label67.Location = new System.Drawing.Point(963, 110);
            this.label67.Name = "label67";
            this.label67.Size = new System.Drawing.Size(129, 17);
            this.label67.TabIndex = 22;
            this.label67.Text = "Power from UPPCB";
            // 
            // txtBaggasseBaed
            // 
            this.txtBaggasseBaed.Location = new System.Drawing.Point(815, 107);
            this.txtBaggasseBaed.Name = "txtBaggasseBaed";
            this.txtBaggasseBaed.Size = new System.Drawing.Size(100, 22);
            this.txtBaggasseBaed.TabIndex = 11;
            this.txtBaggasseBaed.Text = "0";
            // 
            // label68
            // 
            this.label68.AutoSize = true;
            this.label68.Location = new System.Drawing.Point(709, 110);
            this.label68.Name = "label68";
            this.label68.Size = new System.Drawing.Size(100, 17);
            this.label68.TabIndex = 20;
            this.label68.Text = "Bagasse Baed";
            // 
            // txtBoilerFeedWater
            // 
            this.txtBoilerFeedWater.Location = new System.Drawing.Point(215, 107);
            this.txtBoilerFeedWater.Name = "txtBoilerFeedWater";
            this.txtBoilerFeedWater.Size = new System.Drawing.Size(100, 22);
            this.txtBoilerFeedWater.TabIndex = 9;
            this.txtBoilerFeedWater.Text = "0";
            // 
            // label70
            // 
            this.label70.AutoSize = true;
            this.label70.Location = new System.Drawing.Point(63, 110);
            this.label70.Name = "label70";
            this.label70.Size = new System.Drawing.Size(146, 17);
            this.label70.TabIndex = 16;
            this.label70.Text = "ph Boiler Feed Water ";
            // 
            // txtBoilerSteamPressHp
            // 
            this.txtBoilerSteamPressHp.Location = new System.Drawing.Point(1098, 68);
            this.txtBoilerSteamPressHp.Name = "txtBoilerSteamPressHp";
            this.txtBoilerSteamPressHp.Size = new System.Drawing.Size(100, 22);
            this.txtBoilerSteamPressHp.TabIndex = 8;
            this.txtBoilerSteamPressHp.Text = "0";
            // 
            // label66
            // 
            this.label66.AutoSize = true;
            this.label66.Location = new System.Drawing.Point(941, 71);
            this.label66.Name = "label66";
            this.label66.Size = new System.Drawing.Size(151, 17);
            this.label66.TabIndex = 14;
            this.label66.Text = "Boiler Steam Press HP";
            // 
            // txtBoilerSteamPressLp
            // 
            this.txtBoilerSteamPressLp.Location = new System.Drawing.Point(815, 65);
            this.txtBoilerSteamPressLp.Name = "txtBoilerSteamPressLp";
            this.txtBoilerSteamPressLp.Size = new System.Drawing.Size(100, 22);
            this.txtBoilerSteamPressLp.TabIndex = 7;
            this.txtBoilerSteamPressLp.Text = "0";
            // 
            // label65
            // 
            this.label65.AutoSize = true;
            this.label65.Location = new System.Drawing.Point(660, 68);
            this.label65.Name = "label65";
            this.label65.Size = new System.Drawing.Size(149, 17);
            this.label65.TabIndex = 12;
            this.label65.Text = "Boiler Steam Press LP";
            // 
            // txtExhaustSteamPressHp
            // 
            this.txtExhaustSteamPressHp.Location = new System.Drawing.Point(543, 66);
            this.txtExhaustSteamPressHp.Name = "txtExhaustSteamPressHp";
            this.txtExhaustSteamPressHp.Size = new System.Drawing.Size(100, 22);
            this.txtExhaustSteamPressHp.TabIndex = 6;
            this.txtExhaustSteamPressHp.Text = "0";
            // 
            // label64
            // 
            this.label64.AutoSize = true;
            this.label64.Location = new System.Drawing.Point(350, 69);
            this.label64.Name = "label64";
            this.label64.Size = new System.Drawing.Size(187, 17);
            this.label64.TabIndex = 10;
            this.label64.Text = "Exhaust Steam Press lbs HP";
            // 
            // txtExhaustSteamPressLp
            // 
            this.txtExhaustSteamPressLp.Location = new System.Drawing.Point(215, 68);
            this.txtExhaustSteamPressLp.Name = "txtExhaustSteamPressLp";
            this.txtExhaustSteamPressLp.Size = new System.Drawing.Size(100, 22);
            this.txtExhaustSteamPressLp.TabIndex = 5;
            this.txtExhaustSteamPressLp.Text = "0";
            // 
            // label63
            // 
            this.label63.AutoSize = true;
            this.label63.Location = new System.Drawing.Point(24, 71);
            this.label63.Name = "label63";
            this.label63.Size = new System.Drawing.Size(185, 17);
            this.label63.TabIndex = 8;
            this.label63.Text = "Exhaust Steam Press lbs LP";
            // 
            // txtVaccumeOnEvap
            // 
            this.txtVaccumeOnEvap.Location = new System.Drawing.Point(1098, 28);
            this.txtVaccumeOnEvap.Name = "txtVaccumeOnEvap";
            this.txtVaccumeOnEvap.Size = new System.Drawing.Size(100, 22);
            this.txtVaccumeOnEvap.TabIndex = 4;
            this.txtVaccumeOnEvap.Text = "0";
            // 
            // label62
            // 
            this.label62.AutoSize = true;
            this.label62.Location = new System.Drawing.Point(941, 31);
            this.label62.Name = "label62";
            this.label62.Size = new System.Drawing.Size(151, 17);
            this.label62.TabIndex = 6;
            this.label62.Text = "Avg. VacCum On Evap";
            // 
            // txtVaccumeOnPan
            // 
            this.txtVaccumeOnPan.Location = new System.Drawing.Point(815, 28);
            this.txtVaccumeOnPan.Name = "txtVaccumeOnPan";
            this.txtVaccumeOnPan.Size = new System.Drawing.Size(100, 22);
            this.txtVaccumeOnPan.TabIndex = 3;
            this.txtVaccumeOnPan.Text = "0";
            // 
            // label61
            // 
            this.label61.AutoSize = true;
            this.label61.Location = new System.Drawing.Point(657, 31);
            this.label61.Name = "label61";
            this.label61.Size = new System.Drawing.Size(152, 17);
            this.label61.TabIndex = 4;
            this.label61.Text = "Avg. VacCume On Pan";
            // 
            // txtInjectionOutlet
            // 
            this.txtInjectionOutlet.Location = new System.Drawing.Point(543, 28);
            this.txtInjectionOutlet.Name = "txtInjectionOutlet";
            this.txtInjectionOutlet.Size = new System.Drawing.Size(100, 22);
            this.txtInjectionOutlet.TabIndex = 2;
            this.txtInjectionOutlet.Text = "0";
            // 
            // label60
            // 
            this.label60.AutoSize = true;
            this.label60.Location = new System.Drawing.Point(396, 31);
            this.label60.Name = "label60";
            this.label60.Size = new System.Drawing.Size(141, 17);
            this.label60.TabIndex = 2;
            this.label60.Text = "ph Injection Outlet(C)";
            // 
            // txtInjectionInlet
            // 
            this.txtInjectionInlet.Location = new System.Drawing.Point(215, 28);
            this.txtInjectionInlet.Name = "txtInjectionInlet";
            this.txtInjectionInlet.Size = new System.Drawing.Size(100, 22);
            this.txtInjectionInlet.TabIndex = 1;
            this.txtInjectionInlet.Text = "0";
            // 
            // label59
            // 
            this.label59.AutoSize = true;
            this.label59.Location = new System.Drawing.Point(80, 31);
            this.label59.Name = "label59";
            this.label59.Size = new System.Drawing.Size(129, 17);
            this.label59.TabIndex = 0;
            this.label59.Text = "ph Injection Inlet(C)";
            // 
            // frm_day_analysis
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSize = true;
            this.ClientSize = new System.Drawing.Size(1446, 802);
            this.Controls.Add(this.tabControl1);
            this.Controls.Add(this.btnNewRecord);
            this.Controls.Add(this.btnSave);
            this.Name = "frm_day_analysis";
            this.ShowInTaskbar = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "24 HOUR ANALYSIS";
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.groupBox5.ResumeLayout(false);
            this.groupBox5.PerformLayout();
            this.groupBox6.ResumeLayout(false);
            this.groupBox6.PerformLayout();
            this.groupBox7.ResumeLayout(false);
            this.groupBox7.PerformLayout();
            this.groupBox8.ResumeLayout(false);
            this.groupBox8.PerformLayout();
            this.groupBox9.ResumeLayout(false);
            this.groupBox9.PerformLayout();
            this.groupBox10.ResumeLayout(false);
            this.groupBox10.PerformLayout();
            this.groupBox11.ResumeLayout(false);
            this.groupBox11.PerformLayout();
            this.groupBox12.ResumeLayout(false);
            this.groupBox12.PerformLayout();
            this.groupBox13.ResumeLayout(false);
            this.groupBox13.PerformLayout();
            this.groupBox14.ResumeLayout(false);
            this.groupBox14.PerformLayout();
            this.groupBox15.ResumeLayout(false);
            this.groupBox15.PerformLayout();
            this.groupBox16.ResumeLayout(false);
            this.groupBox16.PerformLayout();
            this.groupBox17.ResumeLayout(false);
            this.groupBox17.PerformLayout();
            this.groupBox18.ResumeLayout(false);
            this.groupBox18.PerformLayout();
            this.tabControl1.ResumeLayout(false);
            this.tabParameter1.ResumeLayout(false);
            this.groupBox24.ResumeLayout(false);
            this.groupBox24.PerformLayout();
            this.groupBox22.ResumeLayout(false);
            this.groupBox22.PerformLayout();
            this.groupBox21.ResumeLayout(false);
            this.groupBox21.PerformLayout();
            this.groupBox19.ResumeLayout(false);
            this.groupBox19.PerformLayout();
            this.groupBox25.ResumeLayout(false);
            this.tabParameter2.ResumeLayout(false);
            this.groupBox23.ResumeLayout(false);
            this.groupBox23.PerformLayout();
            this.groupBox20.ResumeLayout(false);
            this.groupBox20.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox6;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox txtMolassesSentOut;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txtPressCake;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox txtWater;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox txtJuice;
        private System.Windows.Forms.TextBox txtSpGrvity;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtReject;
        private System.Windows.Forms.TextBox txtEarly;
        private System.Windows.Forms.TextBox txtGeneral;
        private System.Windows.Forms.GroupBox groupBox17;
        private System.Windows.Forms.Label label43;
        private System.Windows.Forms.TextBox txtRetentionS30;
        private System.Windows.Forms.Label label44;
        private System.Windows.Forms.Label label45;
        private System.Windows.Forms.TextBox txtRetentionL30;
        private System.Windows.Forms.TextBox txtRetentionM30;
        private System.Windows.Forms.Label label46;
        private System.Windows.Forms.TextBox txtRetentionS31;
        private System.Windows.Forms.Label label47;
        private System.Windows.Forms.Label label48;
        private System.Windows.Forms.TextBox txtRetentionL31;
        private System.Windows.Forms.TextBox txtRetentionM31;
        private System.Windows.Forms.GroupBox groupBox16;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.TextBox txtForeignS30;
        private System.Windows.Forms.Label label38;
        private System.Windows.Forms.Label label39;
        private System.Windows.Forms.TextBox txtForeignL30;
        private System.Windows.Forms.TextBox txtForeignM30;
        private System.Windows.Forms.Label label40;
        private System.Windows.Forms.TextBox txtForeignS31;
        private System.Windows.Forms.Label label41;
        private System.Windows.Forms.Label label42;
        private System.Windows.Forms.TextBox txtForeIgnL31;
        private System.Windows.Forms.TextBox txtForeignM31;
        private System.Windows.Forms.GroupBox groupBox15;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.TextBox txtIcumsaS30;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.TextBox txtIcumsaL30;
        private System.Windows.Forms.TextBox txtIcumsaM30;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.TextBox txtIcumsaS31;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.TextBox txtIcumsaL31;
        private System.Windows.Forms.TextBox txtIcumsaM31;
        private System.Windows.Forms.GroupBox groupBox14;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.TextBox txtStorePhosphoric;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.TextBox txtStoreBoilerChemical;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.TextBox txtStoreLubGreece;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.TextBox txtStoreLubOil;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.TextBox txtStoreMegnafloe;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.TextBox txtStoreColorReducer;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.TextBox txtStoreBioeide;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.TextBox txtStoreViscocty;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.TextBox txtStoreSulpher;
        private System.Windows.Forms.TextBox txtStoreLime;
        private System.Windows.Forms.GroupBox groupBox13;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.TextBox txtDirtCorrection;
        private System.Windows.Forms.GroupBox groupBox12;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.TextBox txtUnknownLosses;
        private System.Windows.Forms.GroupBox groupBox11;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.TextBox txtOtherSugar;
        private System.Windows.Forms.TextBox txtOtherMolasses;
        private System.Windows.Forms.GroupBox groupBox10;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.TextBox txtRawSugar;
        private System.Windows.Forms.TextBox txtRawMolasses;
        private System.Windows.Forms.GroupBox groupBox9;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.TextBox txtMoistSugar;
        private System.Windows.Forms.TextBox txtMoistMolasses;
        private System.Windows.Forms.GroupBox groupBox8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox txtScrapSugar;
        private System.Windows.Forms.TextBox txtScrapMolasses;
        private System.Windows.Forms.GroupBox groupBox7;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox txtBissSugar;
        private System.Windows.Forms.TextBox txtBissMolasses;
        private System.Windows.Forms.GroupBox groupBox18;
        private System.Windows.Forms.Button btnNewRecord;
        private System.Windows.Forms.Button btnSave;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabParameter1;
        private System.Windows.Forms.GroupBox groupBox19;
        private System.Windows.Forms.Label label57;
        private System.Windows.Forms.Label label58;
        private System.Windows.Forms.TextBox txtCalciumMixedJuice;
        private System.Windows.Forms.TextBox txtCalciumClearJuice;
        private System.Windows.Forms.TabPage tabParameter2;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TextBox txtExhaustSteamPressLp;
        private System.Windows.Forms.Label label63;
        private System.Windows.Forms.TextBox txtVaccumeOnEvap;
        private System.Windows.Forms.Label label62;
        private System.Windows.Forms.TextBox txtVaccumeOnPan;
        private System.Windows.Forms.Label label61;
        private System.Windows.Forms.TextBox txtInjectionOutlet;
        private System.Windows.Forms.Label label60;
        private System.Windows.Forms.TextBox txtInjectionInlet;
        private System.Windows.Forms.Label label59;
        private System.Windows.Forms.TextBox txtPhMixedJuice;
        private System.Windows.Forms.Label label88;
        private System.Windows.Forms.TextBox txtPhPrimaryJuice;
        private System.Windows.Forms.Label label89;
        private System.Windows.Forms.TextBox txtIuClearJuice;
        private System.Windows.Forms.Label label90;
        private System.Windows.Forms.TextBox txtIuMixedJuice;
        private System.Windows.Forms.Label label83;
        private System.Windows.Forms.TextBox txtIuPrimaryJuice;
        private System.Windows.Forms.Label label84;
        private System.Windows.Forms.TextBox txtRainFall;
        private System.Windows.Forms.Label label85;
        private System.Windows.Forms.TextBox txtHumidity;
        private System.Windows.Forms.Label label86;
        private System.Windows.Forms.TextBox txtTempMin;
        private System.Windows.Forms.Label label79;
        private System.Windows.Forms.TextBox txtTempMax;
        private System.Windows.Forms.Label label80;
        private System.Windows.Forms.TextBox TxtRsPercentage;
        private System.Windows.Forms.Label label81;
        private System.Windows.Forms.TextBox txtTrsPercentage;
        private System.Windows.Forms.Label label82;
        private System.Windows.Forms.TextBox txtNmPryExt;
        private System.Windows.Forms.Label label75;
        private System.Windows.Forms.TextBox txtNmPIndex;
        private System.Windows.Forms.Label label76;
        private System.Windows.Forms.TextBox txtBagasseStock;
        private System.Windows.Forms.Label label77;
        private System.Windows.Forms.TextBox txtBagasseSold;
        private System.Windows.Forms.Label label78;
        private System.Windows.Forms.TextBox txtCfWater;
        private System.Windows.Forms.Label label71;
        private System.Windows.Forms.TextBox txtPanWater;
        private System.Windows.Forms.Label label72;
        private System.Windows.Forms.TextBox txtFilterWater;
        private System.Windows.Forms.Label label73;
        private System.Windows.Forms.TextBox txtPowerExportUppcb;
        private System.Windows.Forms.Label label74;
        private System.Windows.Forms.TextBox txtPowerFromUppcb;
        private System.Windows.Forms.Label label67;
        private System.Windows.Forms.TextBox txtBaggasseBaed;
        private System.Windows.Forms.Label label68;
        private System.Windows.Forms.TextBox txtBoilerFeedWater;
        private System.Windows.Forms.Label label70;
        private System.Windows.Forms.TextBox txtBoilerSteamPressHp;
        private System.Windows.Forms.Label label66;
        private System.Windows.Forms.TextBox txtBoilerSteamPressLp;
        private System.Windows.Forms.Label label65;
        private System.Windows.Forms.TextBox txtExhaustSteamPressHp;
        private System.Windows.Forms.Label label64;
        private System.Windows.Forms.GroupBox groupBox20;
        private System.Windows.Forms.TextBox txtD_sulpher_heating;
        private System.Windows.Forms.Label label100;
        private System.Windows.Forms.TextBox txtExhaustStamConsumption;
        private System.Windows.Forms.Label label101;
        private System.Windows.Forms.TextBox txtExhaustSteamGeneration;
        private System.Windows.Forms.Label label94;
        private System.Windows.Forms.TextBox txtDrainPipeLoss;
        private System.Windows.Forms.Label label95;
        private System.Windows.Forms.TextBox txtAtaFromCogen;
        private System.Windows.Forms.Label label96;
        private System.Windows.Forms.TextBox txtBleedingAcf;
        private System.Windows.Forms.Label label97;
        private System.Windows.Forms.TextBox txtBleedingProcess;
        private System.Windows.Forms.Label label87;
        private System.Windows.Forms.TextBox txtPowerTurbines;
        private System.Windows.Forms.Label label91;
        private System.Windows.Forms.TextBox txtLiveSteamConsumption;
        private System.Windows.Forms.Label label92;
        private System.Windows.Forms.TextBox txtLiveStamGeneration;
        private System.Windows.Forms.Label label93;
        private System.Windows.Forms.GroupBox groupBox22;
        private System.Windows.Forms.Label label56;
        private System.Windows.Forms.TextBox txtEtpTss;
        private System.Windows.Forms.GroupBox groupBox21;
        private System.Windows.Forms.Label label51;
        private System.Windows.Forms.Label label55;
        private System.Windows.Forms.TextBox txtPhosphateMixedJuice;
        private System.Windows.Forms.TextBox txtPhosphateClearJuice;
        private System.Windows.Forms.GroupBox groupBox23;
        private System.Windows.Forms.TextBox txTotalPower;
        private System.Windows.Forms.Label label104;
        private System.Windows.Forms.TextBox txtPowerGenImportFromCogen;
        private System.Windows.Forms.Label label105;
        private System.Windows.Forms.TextBox txtPowerGenDg;
        private System.Windows.Forms.Label label106;
        private System.Windows.Forms.TextBox txtPowerGen1Turbine;
        private System.Windows.Forms.Label label107;
        private System.Windows.Forms.TextBox txtPowerGen3NewTurbine;
        private System.Windows.Forms.Label label108;
        private System.Windows.Forms.TextBox txtPowerGen25Turbine;
        private System.Windows.Forms.Label label109;
        private System.Windows.Forms.GroupBox groupBox24;
        private System.Windows.Forms.TextBox txtTransTime;
        private System.Windows.Forms.Label label98;
        private System.Windows.Forms.Label label99;
        private System.Windows.Forms.DateTimePicker txtTransDate;
        private System.Windows.Forms.GroupBox groupBox25;
        private System.Windows.Forms.Label label103;
        private System.Windows.Forms.TextBox txtCaneCentre;
        private System.Windows.Forms.Label label102;
        private System.Windows.Forms.TextBox txtCaneGate;
        private System.Windows.Forms.Label label110;
        private System.Windows.Forms.TextBox txtCaneCrushed;
        private System.Windows.Forms.Label label52;
        private System.Windows.Forms.TextBox txtEtpWaterFlow;
        private System.Windows.Forms.Label label50;
        private System.Windows.Forms.TextBox txtEtpBod;
        private System.Windows.Forms.Label label49;
        private System.Windows.Forms.TextBox txtEtpCod;
        private System.Windows.Forms.TextBox txt80tCMassecuitePan;
        private System.Windows.Forms.Label label111;
        private System.Windows.Forms.TextBox txtExhaustCondensateRecovery;
        private System.Windows.Forms.Label label54;
        private System.Windows.Forms.Label label53;
        private System.Windows.Forms.TextBox txtTotalOperatingTubeWell;
        private System.Windows.Forms.Label label69;
        private System.Windows.Forms.TextBox txtEtpPh;
        private System.Windows.Forms.TextBox txtPowerGen3OldTurbine;
        private System.Windows.Forms.Label label112;
        private System.Windows.Forms.TextBox txtPowerPerQtlOfSugar;
        private System.Windows.Forms.Label label114;
        private System.Windows.Forms.TextBox txtPowerPerTonOfCane;
        private System.Windows.Forms.Label label113;
        private System.Windows.Forms.TextBox txtSteamPerQtlOfSugar;
        private System.Windows.Forms.Label label115;
        private System.Windows.Forms.TextBox txtSteamPerTonOfCane;
        private System.Windows.Forms.Label label116;
        private System.Windows.Forms.TextBox txtSteamPercentCane;
        private System.Windows.Forms.Label label117;
        private System.Windows.Forms.Label txtFarmCana;
        private System.Windows.Forms.TextBox txtCaneFarm;
        private System.Windows.Forms.TextBox txtOmPryExt;
        private System.Windows.Forms.Label label118;
        private System.Windows.Forms.TextBox txtOmPIndex;
        private System.Windows.Forms.Label label119;
        private System.Windows.Forms.TextBox txtBoilerWater;
        private System.Windows.Forms.Label label120;
    }
}