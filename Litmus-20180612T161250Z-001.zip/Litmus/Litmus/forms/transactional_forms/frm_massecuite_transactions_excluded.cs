﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Litmus.forms.transactional_forms
{

   public partial class frm_massecuite_transactions : Form
    {
       classes.generalFunctions genFunc = new classes.generalFunctions();

        public frm_massecuite_transactions()
        {
            InitializeComponent();
            bind_massecute_categories();
        }

        private void bind_massecute_categories()
        {
            DataTable dt = genFunc.get_parameter_types("massecuite", 1).Tables[0];
            DataRow dr = dt.NewRow();
            dr["param_code"] = "0";
            dr["param_desc"] = "--Select Massecuite Category--";
            dt.Rows.InsertAt(dr, 0);
            comboBoxMassecuite.DataSource = dt;
            comboBoxMassecuite.DisplayMember = "param_desc";
            comboBoxMassecuite.ValueMember = "param_code";    
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            genFunc.disableFieldsInControl(groupBoxMassecuteEntries, typeof(TextBox));
            genFunc.disableFieldsInControl(this, typeof(Button), "btnSave");
            genFunc.disableFieldsInControl(this, typeof(Button), "btnClear");
            genFunc.enableFieldsInControl(this, typeof(Button), "btnNewRecord");
        }

        private void btnNewRecord_Click(object sender, EventArgs e)
        {
            genFunc.enableFieldsInControl(groupBoxMassecuteEntries, typeof(TextBox));
            genFunc.enableFieldsInControl(this, typeof(Button), "btnSave");
            genFunc.enableFieldsInControl(this, typeof(Button), "btnClear");
            genFunc.disableFieldsInControl(this, typeof(Button), "btnNewRecord");
        }
       
    }
}
