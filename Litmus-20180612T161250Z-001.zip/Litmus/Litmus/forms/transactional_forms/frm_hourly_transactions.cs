﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Litmus.classes;

namespace Litmus.forms.transactional_forms
{
    public partial class frm_hourly_transactions : Form
    {
        classes.generalFunctions genFunc = new classes.generalFunctions();
        classes.master_parameter_logic masterParam = new classes.master_parameter_logic();
        classes.ExceptionHelper expHelper = new classes.ExceptionHelper();
        classes.hourly_entry_logic hourlyEntryLogic = new classes.hourly_entry_logic();
        DbHelper dbHelper = new DbHelper();

        private float juiceFlowTotal = 0;
        private float waterFlowTotal = 0;
        private int LbagTotal = 0;
        private int MbagTotal = 0;
        private int SbagTotal = 0;
        private int totalBags = 0;
        string entryDate, entryTime;
        float juiceNewMill, juiceOldMill,
            waterNewMill, waterOldMill,
            sugarBagL31, sugarBagL30, sugarBagLTotal,
            sugarBagM31, sugarBagM30, sugarBagMTotal,
            sugarBagS31, sugarBagS30, sugarBagSTotal,
            sugarBagBiss, sugarBagGrandTotal;
        float truck_weight = 0, trolley_weight = 0, trippler_weight = 0, cart_weight = 0, crushed_cane = 0, un_crushed_cane = 0;
        int standing_truck = 0, standing_trolley = 0, standing_trippler = 0, standing_cart = 0;
        float coolingPol, coolingPh;
        string coolingTrace;

        string formMode = "C";
        string sessionFormCode;
        public frm_hourly_transactions()
        {
            InitializeComponent();
            masterParam.setParameters();
            dateTimeTranDate.Text = masterParam.entryDate;
            hourlyEntryLogic.CurrentEntryTime(masterParam.entryDate);
            
            user_rights_controller();

            int Currenthour = Convert.ToInt16(masterParam.reportStartTime);
            
            txtTime.Text = hourlyEntryLogic.entryTime.ToString();
            bindCoolingTowerTacesCombo();
            disableTextBoxes();

            btnSave.Click += new EventHandler(this.sugarBagTextLostFocus);
            btnSave.GotFocus += new EventHandler(this.sugarBagTextLostFocus);
            #region Data entry for hourly form

            foreach (Control ctrl in groupBoxJuice.Controls)
            {
                if (ctrl.GetType() == typeof(TextBox))
                {
                    ctrl.LostFocus += new EventHandler(this.juiceFlowTextLostFocus);
                }
            }

            foreach (Control ctrl in groupBoxWater.Controls)
            {
                if (ctrl.GetType() == typeof(TextBox))
                {
                    ctrl.LostFocus += new EventHandler(this.waterFlowTextLostFocus);
                    
                }
                
            }
            foreach (Control ctrl in groupBoxSugarBags.Controls)
            {
                if (ctrl.GetType() == typeof(TextBox))
                {
                    ctrl.LostFocus += new System.EventHandler(this.sugarBagTextLostFocus);
                }
            }
            
            #endregion
        }

        private void btnNewRecord_Click(object sender, EventArgs e)
        {
            if (hourlyEntryLogic.isHourlyTransactionEntryPossible(dateTimeTranDate.Text,txtTime.Text) == true)
            {
                enableTextBoxes();
                btnSave.Enabled = true;
                btnNewRecord.Enabled = false;
                txtjuiceNewMill.Focus();
            }
            else
            {
                MessageBox.Show("Entry for this date and time is not possible.\nKindly contact admin and ask to change Entry date parameter","Entry not allowed",MessageBoxButtons.OK,MessageBoxIcon.Hand);
            }
        }

        #region Enable Disable text boxes on Hourly Transaction form
        ///<summary>
        ///created Date: 23-May-2017
        ///Enable or disable text boxes exist on form
        ///</summary>
        ///
        private void enableTextBoxes()
        {
            
            txtjuiceNewMill.Enabled = true;
            txtjuiceOldMill.Enabled = true;
            txtWaterNewMill.Enabled = true;
            txtWaterOldMill.Enabled = true;
            txtSugarBagsM30.Enabled = true;
            txtSugarBagsBiss.Enabled = true;
            txtSugarBagsL30.Enabled = true;
            txtSugarBagsL31.Enabled = true;
            txtSugarBagsM31.Enabled = true;
            txtSugarBagsS30.Enabled = true;
            txtSugarBagsS31.Enabled = true;
            comboCoolingTowerTraces.Enabled = true;
            txtCoolingPol.Enabled = true;
            txtCoolingPh.Enabled = true;
            txtStandingTrucks.Enabled = true;
            txtStandingTrolleys.Enabled = true;
            txtStandingTripplers.Enabled = true;
            txtStandingCarts.Enabled = true;
            txtCaneCrushed.Enabled = true;
        }
        private void disableTextBoxes()
        {
            txtTime.Enabled = false;
            txtjuiceNewMill.Enabled = false;
            txtjuiceOldMill.Enabled = false;
            txtWaterNewMill.Enabled = false;
            txtWaterOldMill.Enabled = false;
            txtSugarBagsM30.Enabled = false;
            txtSugarBagsBiss.Enabled = false;
            txtSugarBagsL30.Enabled = false;
            txtSugarBagsL31.Enabled = false;
            txtSugarBagsM31.Enabled = false;
            txtSugarBagsS30.Enabled = false;
            txtSugarBagsS31.Enabled = false;
            btnSave.Enabled = false;
            comboCoolingTowerTraces.Enabled = false;
            txtCoolingPol.Enabled = false;
            txtCoolingPh.Enabled = false;
            txtStandingTrucks.Enabled = false;
            txtStandingTrolleys.Enabled = false;
            txtStandingTripplers.Enabled = false;
            txtStandingCarts.Enabled = false;
            txtCaneCrushed.Enabled = false;
        }

        private void resetForm()
        {
            formMode = "C";
            txtTime.LostFocus -= new EventHandler(txtTimeLostFocus);
            juiceFlowTotal = 0;
            waterFlowTotal = 0;
            LbagTotal = 0;
            MbagTotal = 0;
            SbagTotal = 0;
            totalBags = 0;
            sugarBagLTotal = 0;
            sugarBagMTotal = 0;
            sugarBagSTotal = 0;
            sugarBagGrandTotal = 0;

            txtjuiceNewMill.Text = "0";
            txtjuiceOldMill.Text = "0";
            txtWaterNewMill.Text = "0";
            txtWaterOldMill.Text = "0";
            txtSugarBagsM30.Text = "0";
            txtSugarBagsBiss.Text = "0";
            txtSugarBagsL30.Text = "0";
            txtSugarBagsL31.Text = "0";
            txtSugarBagsM31.Text = "0";
            txtSugarBagsS30.Text = "0";
            txtSugarBagsS31.Text = "0";
            txtJuiceTotal.Text = "0";
            txtWaterTotal.Text = "0";

            txtSugarBagLTotal.Text = "0";
            txtSugarBagMTotal.Text = "0";
            txtSugarBagSTotal.Text = "0";
            txtSugarBagSTotal.Text = "0";
            txtSugarbagGrandTotal.Text = "0";
           
            
            txtCoolingPol.Text = "0";
            txtCoolingPh.Text = "0";
            txtStandingTrucks.Text = "0";
            txtStandingTrolleys.Text = "0";
            txtStandingTripplers.Text = "0";
            txtStandingCarts.Text = "0";
            txtCaneCrushed.Text = "0";
            un_crushed_cane = 0;

            dateTimeTranDate.Text = masterParam.entryDate;
            txtTime.Text = hourlyEntryLogic.entryTime.ToString();
            txtTime.Focus();
            disableTextBoxes();
            btnModify.Enabled = true;
            btnSave.Text = "Save";
            btnNewRecord.Enabled = true;
            user_rights_controller(); // checking user rights
            
        }
        #endregion

        private void juiceFlowTextLostFocus(object sender, EventArgs e)
        {
            try
            {
                juiceFlowTotal = float.Parse(txtjuiceNewMill.Text) + float.Parse(txtjuiceOldMill.Text);
                txtJuiceTotal.Text = juiceFlowTotal.ToString();
            }
            catch
            {
            }
        }
        private void waterFlowTextLostFocus(object sender, EventArgs e)
        {
           
            try
            {
                waterFlowTotal = float.Parse(txtWaterNewMill.Text) + float.Parse(txtWaterOldMill.Text);
                txtWaterTotal.Text = waterFlowTotal.ToString();
            }
            catch
            {
            }

        }
        private void bindCoolingTowerTacesCombo()
        {
            DataSet ds = genFunc.getComboListOptions("cooling tower traces");
            comboCoolingTowerTraces.DataSource = ds.Tables[0];
            comboCoolingTowerTraces.DisplayMember = "display_text";
            comboCoolingTowerTraces.ValueMember = "display_text";
        }

        private void sugarBagTextLostFocus(object sender, EventArgs e)
        {

            calculateSugarBagsTotal();
            
        }

       
        private void btnClear_Click(object sender, EventArgs e)
        {
            resetForm();
            formMode = "C";
            dateTimeTranDate.Enabled = false;
            txtTime.Enabled = false;
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            calculateSugarBagsTotal();
            entryDate = dateTimeTranDate.Text;
            entryTime = txtTime.Text;
            juiceNewMill = float.Parse(txtjuiceNewMill.Text);
            juiceOldMill = float.Parse(txtjuiceOldMill.Text);
            juiceFlowTotal = float.Parse(txtJuiceTotal.Text);

            waterNewMill = float.Parse(txtWaterNewMill.Text);
            waterOldMill = float.Parse(txtWaterOldMill.Text);
            waterFlowTotal = Convert.ToInt16(txtWaterTotal.Text);

            waterFlowTotal = float.Parse(txtWaterTotal.Text);

            sugarBagL31 = float.Parse(txtSugarBagsL31.Text);
            sugarBagL30 = float.Parse(txtSugarBagsL30.Text);
            sugarBagLTotal = LbagTotal;

            sugarBagM31 = float.Parse(txtSugarBagsM31.Text);
            sugarBagM30 = float.Parse(txtSugarBagsM30.Text);
            sugarBagMTotal = MbagTotal;

            sugarBagS30 = float.Parse(txtSugarBagsS30.Text);
            sugarBagS31 = float.Parse(txtSugarBagsS31.Text);
            sugarBagSTotal = SbagTotal;

            sugarBagBiss = float.Parse(txtSugarBagsBiss.Text);
            sugarBagGrandTotal = float.Parse(txtSugarbagGrandTotal.Text);

            coolingTrace = comboCoolingTowerTraces.SelectedValue.ToString();
            coolingPol = float.Parse(txtCoolingPol.Text);
            coolingPh = float.Parse(txtCoolingPh.Text);
            
           
            DialogResult dialogResult = MessageBox.Show("Are you sure to save data?", "Save data?", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (dialogResult == DialogResult.Yes)
            {
                switch (formMode)
                {
                    case "C":
                        hourlyEntryLogic.insertHourlyRecord(entryDate, entryTime, juiceNewMill, juiceOldMill, juiceFlowTotal, waterNewMill, waterOldMill, waterFlowTotal, sugarBagL31, sugarBagL30, sugarBagLTotal, sugarBagM31, sugarBagM30, sugarBagMTotal, sugarBagS31, sugarBagS30, sugarBagSTotal, sugarBagBiss, totalBags,coolingTrace, coolingPol,coolingPh ,genFunc.userCode,standing_truck,standing_trippler,standing_trolley,standing_cart,un_crushed_cane,crushed_cane);
                        hourlyEntryLogic.CurrentEntryTime(masterParam.entryDate);
                        txtTime.Text = hourlyEntryLogic.entryTime.ToString();
                        resetForm();
                        disableTextBoxes();
                
                        if (hourlyEntryLogic.isHourlyTransactionEntryPossible(dateTimeTranDate.Text, txtTime.Text) == false)
                        {
                            MessageBox.Show("Entry for this date and time is not possible.\nKindly contact admin and ask to change Entry date parameter", "Entry not allowed", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                            disableTextBoxes();
                        }
                    break;
                    case "U":
                    hourlyEntryLogic.updateHourlyRecord(entryDate, entryTime, juiceNewMill, juiceOldMill, juiceFlowTotal, waterNewMill, waterOldMill, waterFlowTotal, sugarBagL31, sugarBagL30, sugarBagLTotal, sugarBagM31, sugarBagM30, sugarBagMTotal, sugarBagS31, sugarBagS30, sugarBagSTotal, sugarBagBiss, totalBags, coolingTrace, coolingPol, coolingPh,standing_truck,standing_trippler,standing_trolley,standing_cart,un_crushed_cane,crushed_cane);
                    resetForm();
                    disableTextBoxes();
                        break;
                }
            }   
        }

        

        private void button5_Click(object sender, EventArgs e)
        {
            formMode = "U";
            dateTimeTranDate.Enabled = true;
            txtTime.Enabled = true;
            enableTextBoxes();
            btnNewRecord.Enabled = false;
            btnModify.Enabled = false;
            btnSave.Text = "Update";
            text_time_focus_lost();
        }

        private void text_time_focus_lost()
        {
            if (formMode == "U")
            {
                txtTime.LostFocus += new EventHandler(txtTimeLostFocus);
            }
        }

        private void txtTimeLostFocus(object sender, EventArgs e)
        {
            string selectedDate = dateTimeTranDate.Text;
            int selectedTime = Convert.ToInt16(txtTime.Text);
            DataTable hourlyDataTable = hourlyEntryLogic.getHourlyData(selectedDate, selectedTime);

            if (hourlyDataTable.Rows.Count > 0)
            {
                txtjuiceNewMill.Text = hourlyDataTable.Rows[0]["new_mill_juice"].ToString();
                txtjuiceOldMill.Text = hourlyDataTable.Rows[0]["old_mill_juice"].ToString();
                txtJuiceTotal.Text = hourlyDataTable.Rows[0]["juice_total"].ToString();
                txtWaterNewMill.Text = hourlyDataTable.Rows[0]["new_mill_water"].ToString();
                txtWaterOldMill.Text = hourlyDataTable.Rows[0]["old_mill_water"].ToString();
                txtWaterTotal.Text = hourlyDataTable.Rows[0]["water_total"].ToString();
                txtSugarBagsL31.Text = hourlyDataTable.Rows[0]["sugar_bags_l31"].ToString(); ;
                txtSugarBagsL30.Text = hourlyDataTable.Rows[0]["sugar_bags_L30"].ToString();
                txtSugarBagLTotal.Text = hourlyDataTable.Rows[0]["sugar_bags_L_total"].ToString();
                txtSugarBagsM31.Text = hourlyDataTable.Rows[0]["sugar_bags_m31"].ToString();
                txtSugarBagsM30.Text = hourlyDataTable.Rows[0]["sugar_bags_m30"].ToString();
                txtSugarBagMTotal.Text = hourlyDataTable.Rows[0]["sugar_bags_m_total"].ToString();
                txtSugarBagsS31.Text = hourlyDataTable.Rows[0]["sugar_bags_s31"].ToString();
                txtSugarBagsS30.Text = hourlyDataTable.Rows[0]["sugar_bags_s30"].ToString();
                txtSugarBagSTotal.Text = hourlyDataTable.Rows[0]["sugar_bags_s_total"].ToString();
                txtSugarBagsBiss.Text = hourlyDataTable.Rows[0]["sugar_Biss"].ToString();
                txtSugarbagGrandTotal.Text = hourlyDataTable.Rows[0]["sugar_bags_total"].ToString();               
                comboCoolingTowerTraces.SelectedItem = hourlyDataTable.Rows[0]["cooling_trace"].ToString();
                txtCoolingPol.Text = hourlyDataTable.Rows[0]["cooling_pol"].ToString();
                txtCoolingPh.Text = hourlyDataTable.Rows[0]["cooling_ph"].ToString();
                txtStandingTrucks.Text = hourlyDataTable.Rows[0]["standing_truck"].ToString();
                txtStandingTrolleys.Text = hourlyDataTable.Rows[0]["standing_trolley"].ToString();
                txtStandingTripplers.Text = hourlyDataTable.Rows[0]["standing_trippler"].ToString();
                txtStandingCarts.Text = hourlyDataTable.Rows[0]["standing_cart"].ToString();
                txtUncrushedCane.Text = hourlyDataTable.Rows[0]["un_crushed_cane"].ToString();
                txtCaneCrushed.Text = hourlyDataTable.Rows[0]["crushed_cane"].ToString();

                btnSave.Enabled = true;
            }
            else
            {
                MessageBox.Show("No record found for selected date & Time", "No record!!", MessageBoxButtons.OK, MessageBoxIcon.Information);
                resetForm();
            }
        }
        protected void user_rights_controller()
        {
            foreach (char c in genFunc.userRights)
            {
                switch (c)
                {
                    case 'C': 
                        btnNewRecord.Enabled = true;
                        break;
                    case 'R':
                        this.Enabled = true;
                        break;
                    case 'U':
                        btnModify.Enabled = true;
                        break;
                    case 'D':
                        break;
                    default:
                        btnNewRecord.Enabled = false;
                        btnModify.Enabled = false;
                        btnModify.Enabled = false;
                        MessageBox.Show("User do not have any rights", "No rights assigned", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        break;
                }
            }
        }


        private void calculateSugarBagsTotal()
        {
            genFunc.forceNumericValue(txtSugarBagsL30);
            genFunc.forceNumericValue(txtSugarBagsL31);
            genFunc.forceNumericValue(txtSugarBagsL30);

            genFunc.forceNumericValue(txtSugarBagsM30);
            genFunc.forceNumericValue(txtSugarBagsM31);

            genFunc.forceNumericValue(txtSugarBagsS30);
            genFunc.forceNumericValue(txtSugarBagsS31);

            genFunc.forceNumericValue(txtSugarBagsBiss);

            calculate_uncrushed_cane();
           

            try
            {
                LbagTotal = Convert.ToInt16(txtSugarBagsL30.Text) + Convert.ToInt16(txtSugarBagsL31.Text);
                MbagTotal = Convert.ToInt16(txtSugarBagsM30.Text) + Convert.ToInt16(txtSugarBagsM31.Text);
                SbagTotal = Convert.ToInt16(txtSugarBagsS30.Text) + Convert.ToInt16(txtSugarBagsS31.Text);
                totalBags = LbagTotal + MbagTotal + SbagTotal + Convert.ToInt16(txtSugarBagsBiss.Text);

                txtSugarBagLTotal.Text = LbagTotal.ToString();
                txtSugarBagMTotal.Text = MbagTotal.ToString();
                txtSugarBagSTotal.Text = SbagTotal.ToString();

                txtSugarbagGrandTotal.Text = totalBags.ToString();


            }
            catch (Exception ex)
            {
                expHelper.statusMsg = "ERR: " + ex.StackTrace;
            }
        }

        private void calculate_uncrushed_cane()
        {
            standing_truck = Convert.ToInt16(txtStandingTrucks.Text);
            standing_trolley = Convert.ToInt16(txtStandingTrolleys.Text);
            standing_trippler = Convert.ToInt16(txtStandingTripplers.Text);
            standing_cart = Convert.ToInt16(txtStandingCarts.Text);

            truck_weight = 0; trolley_weight = 0; trippler_weight = 0; cart_weight = 0; un_crushed_cane = 0; crushed_cane = 0;
            truck_weight = standing_truck * hourlyEntryLogic.truck_avg_weight;
            trolley_weight = standing_trolley * hourlyEntryLogic.trolley_avg_weight;
            trippler_weight = standing_trippler * hourlyEntryLogic.trippler_avg_weight;
            cart_weight = standing_cart * hourlyEntryLogic.cart_avg_weight;

            un_crushed_cane = truck_weight + trolley_weight + trippler_weight + cart_weight;
            txtUncrushedCane.Text = un_crushed_cane.ToString();
            crushed_cane = float.Parse(txtCaneCrushed.Text);
            genFunc.forceNumericValue(txtCaneCrushed);
        }

        private void calculatedStandingCartWeight(object sender, EventArgs e)
        {
            genFunc.forceNumericValue(txtStandingCarts);
            if (txtStandingCarts.Text == string.Empty)
            {
                txtStandingCarts.Text = "0";
                txtStandingCarts.SelectAll();
            }
        }
        private void calculateStandingTripplerWeight(object sender, EventArgs e)
        {
            genFunc.forceNumericValue(txtStandingTripplers);
            if (txtStandingTripplers.Text == string.Empty)
            {
                txtStandingTripplers.Text = "0";
                txtStandingTripplers.SelectAll();
            }
        }
        private void calculateStandingTrolleyWeight(object sender, EventArgs e)
        {
            genFunc.forceNumericValue(txtStandingTrolleys);
            if (txtStandingTrolleys.Text == string.Empty)
            {
                txtStandingTrolleys.Text = "0";
                txtStandingTripplers.SelectAll();
            }
        }
        private void calculateStandingTrucksWeight(object sender, EventArgs e)
        {
            genFunc.forceNumericValue(txtStandingTrucks);
            if (txtStandingTrucks.Text == string.Empty)
            {
                txtStandingTrucks.Text = "0";
                txtStandingTrucks.SelectAll();
            }
        }
    }
}
