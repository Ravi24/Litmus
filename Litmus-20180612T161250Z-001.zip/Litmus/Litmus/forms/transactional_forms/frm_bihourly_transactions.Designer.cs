﻿namespace Litmus.forms.transactional_forms
{
    partial class frm_bihourly_transactions
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.groupBox9 = new System.Windows.Forms.GroupBox();
            this.txtOmLastJuicePurity = new System.Windows.Forms.TextBox();
            this.label53 = new System.Windows.Forms.Label();
            this.txtOmLastJuicePol = new System.Windows.Forms.TextBox();
            this.txtOmLastJuiceBrix = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.groupBox10 = new System.Windows.Forms.GroupBox();
            this.txtNmLastJuicePurity = new System.Windows.Forms.TextBox();
            this.label52 = new System.Windows.Forms.Label();
            this.txtNmLastJuicePol = new System.Windows.Forms.TextBox();
            this.txtNmLastJuiceBrix = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.groupBox7 = new System.Windows.Forms.GroupBox();
            this.txtOmMixedJuicePurity = new System.Windows.Forms.TextBox();
            this.label51 = new System.Windows.Forms.Label();
            this.txtOmMixedJuicePol = new System.Windows.Forms.TextBox();
            this.txtOmMixedJuiceBrix = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.groupBox8 = new System.Windows.Forms.GroupBox();
            this.txtNmMixedJuicePurity = new System.Windows.Forms.TextBox();
            this.label50 = new System.Windows.Forms.Label();
            this.txtNmMixedJuicePol = new System.Windows.Forms.TextBox();
            this.txtNmMixedJuiceBrix = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.groupBox6 = new System.Windows.Forms.GroupBox();
            this.txtOmPrimaryJuicePurity = new System.Windows.Forms.TextBox();
            this.label43 = new System.Windows.Forms.Label();
            this.txtOmPrimaryJuicePol = new System.Windows.Forms.TextBox();
            this.txtOmPrimaryJuiceBrix = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.groupBoxNmPurity = new System.Windows.Forms.GroupBox();
            this.txtNmPrimaryJuicePurity = new System.Windows.Forms.TextBox();
            this.label40 = new System.Windows.Forms.Label();
            this.txtNmPrimaryJuicePol = new System.Windows.Forms.TextBox();
            this.txtNmPrimaryJuiceBrix = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.txtTime = new System.Windows.Forms.TextBox();
            this.lblDate = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.dateTimeTranDate = new System.Windows.Forms.DateTimePicker();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.groupBox11 = new System.Windows.Forms.GroupBox();
            this.txtFinalMolassesPurity = new System.Windows.Forms.TextBox();
            this.label58 = new System.Windows.Forms.Label();
            this.txtFinalMolassesTanks = new System.Windows.Forms.TextBox();
            this.txtFinalMolassesTemp = new System.Windows.Forms.TextBox();
            this.label24 = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.txtFinalMolassesPol = new System.Windows.Forms.TextBox();
            this.txtFinalMolassesBrix = new System.Windows.Forms.TextBox();
            this.label14 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.groupBox12 = new System.Windows.Forms.GroupBox();
            this.txtSulphuredSyrupPurity = new System.Windows.Forms.TextBox();
            this.label57 = new System.Windows.Forms.Label();
            this.txtSulphuredSyrupPh = new System.Windows.Forms.TextBox();
            this.label29 = new System.Windows.Forms.Label();
            this.txtSulphuredSyrupPol = new System.Windows.Forms.TextBox();
            this.txtSulphuredSyrupBrix = new System.Windows.Forms.TextBox();
            this.label16 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.groupBox13 = new System.Windows.Forms.GroupBox();
            this.txtUnsulphuredSyrupPurity = new System.Windows.Forms.TextBox();
            this.label56 = new System.Windows.Forms.Label();
            this.txtUnsulphuredSyrupPh = new System.Windows.Forms.TextBox();
            this.label28 = new System.Windows.Forms.Label();
            this.txtUnsulphuredSyrupPol = new System.Windows.Forms.TextBox();
            this.txtUnsulphuredSyrupBrix = new System.Windows.Forms.TextBox();
            this.label18 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.groupBox14 = new System.Windows.Forms.GroupBox();
            this.txtClearJuicePurity = new System.Windows.Forms.TextBox();
            this.label55 = new System.Windows.Forms.Label();
            this.txtClearJuicePh = new System.Windows.Forms.TextBox();
            this.txtClearJuicePol = new System.Windows.Forms.TextBox();
            this.label27 = new System.Windows.Forms.Label();
            this.txtClearJuiceBrix = new System.Windows.Forms.TextBox();
            this.label20 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.groupBox15 = new System.Windows.Forms.GroupBox();
            this.txtOliverFilteredPurity = new System.Windows.Forms.TextBox();
            this.label54 = new System.Windows.Forms.Label();
            this.txtOliverFilteredPh = new System.Windows.Forms.TextBox();
            this.txtOliverFilteredPol = new System.Windows.Forms.TextBox();
            this.label26 = new System.Windows.Forms.Label();
            this.txtOliverFilteredBirx = new System.Windows.Forms.TextBox();
            this.label22 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.groupBox25 = new System.Windows.Forms.GroupBox();
            this.btnModify = new System.Windows.Forms.Button();
            this.btnNewRecord = new System.Windows.Forms.Button();
            this.btnSave = new System.Windows.Forms.Button();
            this.btnClear = new System.Windows.Forms.Button();
            this.groupBoxBagasse = new System.Windows.Forms.GroupBox();
            this.groupBoxBagasse_oldMill = new System.Windows.Forms.GroupBox();
            this.txtOmMoisture = new System.Windows.Forms.TextBox();
            this.txtOmBagassPol = new System.Windows.Forms.TextBox();
            this.label41 = new System.Windows.Forms.Label();
            this.label42 = new System.Windows.Forms.Label();
            this.groupBoxBagasseNewMill = new System.Windows.Forms.GroupBox();
            this.txtBagassNmMoisture = new System.Windows.Forms.TextBox();
            this.txtBagasseNmPol = new System.Windows.Forms.TextBox();
            this.label44 = new System.Windows.Forms.Label();
            this.label45 = new System.Windows.Forms.Label();
            this.groupBox16 = new System.Windows.Forms.GroupBox();
            this.groupBoxPolPressCake = new System.Windows.Forms.GroupBox();
            this.txtFilteMudAverage = new System.Windows.Forms.TextBox();
            this.label37 = new System.Windows.Forms.Label();
            this.txtFilteMudComposite = new System.Windows.Forms.TextBox();
            this.label36 = new System.Windows.Forms.Label();
            this.txtFilteMudMoisture = new System.Windows.Forms.TextBox();
            this.label35 = new System.Windows.Forms.Label();
            this.label34 = new System.Windows.Forms.Label();
            this.txtFilteMudSample5 = new System.Windows.Forms.TextBox();
            this.label31 = new System.Windows.Forms.Label();
            this.txtFilteMudSample4 = new System.Windows.Forms.TextBox();
            this.txtFilteMudSample3 = new System.Windows.Forms.TextBox();
            this.label32 = new System.Windows.Forms.Label();
            this.label30 = new System.Windows.Forms.Label();
            this.txtFilteMudSample2 = new System.Windows.Forms.TextBox();
            this.txtFilteMudSample1 = new System.Windows.Forms.TextBox();
            this.label33 = new System.Windows.Forms.Label();
            this.groupBox17 = new System.Windows.Forms.GroupBox();
            this.groupBoxCaneStatus = new System.Windows.Forms.GroupBox();
            this.txtCaneCrushed = new System.Windows.Forms.TextBox();
            this.label49 = new System.Windows.Forms.Label();
            this.txtUncrushedCane = new System.Windows.Forms.TextBox();
            this.label48 = new System.Windows.Forms.Label();
            this.txtStandingCarts = new System.Windows.Forms.TextBox();
            this.label47 = new System.Windows.Forms.Label();
            this.txtStandingTripplers = new System.Windows.Forms.TextBox();
            this.label46 = new System.Windows.Forms.Label();
            this.txtStandingTrolleys = new System.Windows.Forms.TextBox();
            this.label39 = new System.Windows.Forms.Label();
            this.txtStandingTrucks = new System.Windows.Forms.TextBox();
            this.label38 = new System.Windows.Forms.Label();
            this.groupBox1.SuspendLayout();
            this.groupBox9.SuspendLayout();
            this.groupBox10.SuspendLayout();
            this.groupBox7.SuspendLayout();
            this.groupBox8.SuspendLayout();
            this.groupBox6.SuspendLayout();
            this.groupBoxNmPurity.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.groupBox11.SuspendLayout();
            this.groupBox12.SuspendLayout();
            this.groupBox13.SuspendLayout();
            this.groupBox14.SuspendLayout();
            this.groupBox15.SuspendLayout();
            this.groupBox25.SuspendLayout();
            this.groupBoxBagasse.SuspendLayout();
            this.groupBoxBagasse_oldMill.SuspendLayout();
            this.groupBoxBagasseNewMill.SuspendLayout();
            this.groupBox16.SuspendLayout();
            this.groupBoxPolPressCake.SuspendLayout();
            this.groupBox17.SuspendLayout();
            this.groupBoxCaneStatus.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.groupBox9);
            this.groupBox1.Controls.Add(this.groupBox10);
            this.groupBox1.Controls.Add(this.groupBox7);
            this.groupBox1.Controls.Add(this.groupBox8);
            this.groupBox1.Controls.Add(this.groupBox6);
            this.groupBox1.Controls.Add(this.groupBoxNmPurity);
            this.groupBox1.Location = new System.Drawing.Point(18, 64);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(1249, 157);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            // 
            // groupBox9
            // 
            this.groupBox9.Controls.Add(this.txtOmLastJuicePurity);
            this.groupBox9.Controls.Add(this.label53);
            this.groupBox9.Controls.Add(this.txtOmLastJuicePol);
            this.groupBox9.Controls.Add(this.txtOmLastJuiceBrix);
            this.groupBox9.Controls.Add(this.label10);
            this.groupBox9.Controls.Add(this.label11);
            this.groupBox9.Location = new System.Drawing.Point(1043, 21);
            this.groupBox9.Name = "groupBox9";
            this.groupBox9.Size = new System.Drawing.Size(185, 121);
            this.groupBox9.TabIndex = 5;
            this.groupBox9.TabStop = false;
            this.groupBox9.Text = "Old Mill Last Juice";
            // 
            // txtOmLastJuicePurity
            // 
            this.txtOmLastJuicePurity.Enabled = false;
            this.txtOmLastJuicePurity.Location = new System.Drawing.Point(66, 78);
            this.txtOmLastJuicePurity.Name = "txtOmLastJuicePurity";
            this.txtOmLastJuicePurity.Size = new System.Drawing.Size(100, 22);
            this.txtOmLastJuicePurity.TabIndex = 14;
            this.txtOmLastJuicePurity.Text = "0";
            // 
            // label53
            // 
            this.label53.AutoSize = true;
            this.label53.Location = new System.Drawing.Point(20, 81);
            this.label53.Name = "label53";
            this.label53.Size = new System.Drawing.Size(44, 17);
            this.label53.TabIndex = 13;
            this.label53.Text = "Purity";
            // 
            // txtOmLastJuicePol
            // 
            this.txtOmLastJuicePol.Enabled = false;
            this.txtOmLastJuicePol.Location = new System.Drawing.Point(66, 50);
            this.txtOmLastJuicePol.Name = "txtOmLastJuicePol";
            this.txtOmLastJuicePol.Size = new System.Drawing.Size(100, 22);
            this.txtOmLastJuicePol.TabIndex = 12;
            this.txtOmLastJuicePol.Text = "0";
            // 
            // txtOmLastJuiceBrix
            // 
            this.txtOmLastJuiceBrix.Enabled = false;
            this.txtOmLastJuiceBrix.Location = new System.Drawing.Point(66, 24);
            this.txtOmLastJuiceBrix.Name = "txtOmLastJuiceBrix";
            this.txtOmLastJuiceBrix.Size = new System.Drawing.Size(100, 22);
            this.txtOmLastJuiceBrix.TabIndex = 11;
            this.txtOmLastJuiceBrix.Text = "0";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(20, 53);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(40, 17);
            this.label10.TabIndex = 1;
            this.label10.Text = "Pol%";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(17, 27);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(43, 17);
            this.label11.TabIndex = 0;
            this.label11.Text = "Brix%";
            // 
            // groupBox10
            // 
            this.groupBox10.Controls.Add(this.txtNmLastJuicePurity);
            this.groupBox10.Controls.Add(this.label52);
            this.groupBox10.Controls.Add(this.txtNmLastJuicePol);
            this.groupBox10.Controls.Add(this.txtNmLastJuiceBrix);
            this.groupBox10.Controls.Add(this.label12);
            this.groupBox10.Controls.Add(this.label13);
            this.groupBox10.Location = new System.Drawing.Point(839, 21);
            this.groupBox10.Name = "groupBox10";
            this.groupBox10.Size = new System.Drawing.Size(185, 121);
            this.groupBox10.TabIndex = 4;
            this.groupBox10.TabStop = false;
            this.groupBox10.Text = "New Mill Last Juice";
            // 
            // txtNmLastJuicePurity
            // 
            this.txtNmLastJuicePurity.Enabled = false;
            this.txtNmLastJuicePurity.Location = new System.Drawing.Point(66, 78);
            this.txtNmLastJuicePurity.Name = "txtNmLastJuicePurity";
            this.txtNmLastJuicePurity.Size = new System.Drawing.Size(100, 22);
            this.txtNmLastJuicePurity.TabIndex = 12;
            this.txtNmLastJuicePurity.Text = "0";
            // 
            // label52
            // 
            this.label52.AutoSize = true;
            this.label52.Location = new System.Drawing.Point(20, 81);
            this.label52.Name = "label52";
            this.label52.Size = new System.Drawing.Size(44, 17);
            this.label52.TabIndex = 11;
            this.label52.Text = "Purity";
            // 
            // txtNmLastJuicePol
            // 
            this.txtNmLastJuicePol.Enabled = false;
            this.txtNmLastJuicePol.Location = new System.Drawing.Point(66, 50);
            this.txtNmLastJuicePol.Name = "txtNmLastJuicePol";
            this.txtNmLastJuicePol.Size = new System.Drawing.Size(100, 22);
            this.txtNmLastJuicePol.TabIndex = 10;
            this.txtNmLastJuicePol.Text = "0";
            // 
            // txtNmLastJuiceBrix
            // 
            this.txtNmLastJuiceBrix.Enabled = false;
            this.txtNmLastJuiceBrix.Location = new System.Drawing.Point(66, 24);
            this.txtNmLastJuiceBrix.Name = "txtNmLastJuiceBrix";
            this.txtNmLastJuiceBrix.Size = new System.Drawing.Size(100, 22);
            this.txtNmLastJuiceBrix.TabIndex = 9;
            this.txtNmLastJuiceBrix.Text = "0";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(20, 53);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(40, 17);
            this.label12.TabIndex = 1;
            this.label12.Text = "Pol%";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(17, 27);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(43, 17);
            this.label13.TabIndex = 0;
            this.label13.Text = "Brix%";
            // 
            // groupBox7
            // 
            this.groupBox7.Controls.Add(this.txtOmMixedJuicePurity);
            this.groupBox7.Controls.Add(this.label51);
            this.groupBox7.Controls.Add(this.txtOmMixedJuicePol);
            this.groupBox7.Controls.Add(this.txtOmMixedJuiceBrix);
            this.groupBox7.Controls.Add(this.label6);
            this.groupBox7.Controls.Add(this.label7);
            this.groupBox7.Location = new System.Drawing.Point(639, 21);
            this.groupBox7.Name = "groupBox7";
            this.groupBox7.Size = new System.Drawing.Size(185, 121);
            this.groupBox7.TabIndex = 3;
            this.groupBox7.TabStop = false;
            this.groupBox7.Text = "Old Mill Mixed Juice";
            // 
            // txtOmMixedJuicePurity
            // 
            this.txtOmMixedJuicePurity.Enabled = false;
            this.txtOmMixedJuicePurity.Location = new System.Drawing.Point(66, 78);
            this.txtOmMixedJuicePurity.Name = "txtOmMixedJuicePurity";
            this.txtOmMixedJuicePurity.Size = new System.Drawing.Size(100, 22);
            this.txtOmMixedJuicePurity.TabIndex = 10;
            this.txtOmMixedJuicePurity.Text = "0";
            // 
            // label51
            // 
            this.label51.AutoSize = true;
            this.label51.Location = new System.Drawing.Point(18, 81);
            this.label51.Name = "label51";
            this.label51.Size = new System.Drawing.Size(44, 17);
            this.label51.TabIndex = 9;
            this.label51.Text = "Purity";
            // 
            // txtOmMixedJuicePol
            // 
            this.txtOmMixedJuicePol.Enabled = false;
            this.txtOmMixedJuicePol.Location = new System.Drawing.Point(66, 50);
            this.txtOmMixedJuicePol.Name = "txtOmMixedJuicePol";
            this.txtOmMixedJuicePol.Size = new System.Drawing.Size(100, 22);
            this.txtOmMixedJuicePol.TabIndex = 8;
            this.txtOmMixedJuicePol.Text = "0";
            // 
            // txtOmMixedJuiceBrix
            // 
            this.txtOmMixedJuiceBrix.Enabled = false;
            this.txtOmMixedJuiceBrix.Location = new System.Drawing.Point(66, 24);
            this.txtOmMixedJuiceBrix.Name = "txtOmMixedJuiceBrix";
            this.txtOmMixedJuiceBrix.Size = new System.Drawing.Size(100, 22);
            this.txtOmMixedJuiceBrix.TabIndex = 7;
            this.txtOmMixedJuiceBrix.Text = "0";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(20, 53);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(40, 17);
            this.label6.TabIndex = 1;
            this.label6.Text = "Pol%";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(17, 27);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(43, 17);
            this.label7.TabIndex = 0;
            this.label7.Text = "Brix%";
            // 
            // groupBox8
            // 
            this.groupBox8.Controls.Add(this.txtNmMixedJuicePurity);
            this.groupBox8.Controls.Add(this.label50);
            this.groupBox8.Controls.Add(this.txtNmMixedJuicePol);
            this.groupBox8.Controls.Add(this.txtNmMixedJuiceBrix);
            this.groupBox8.Controls.Add(this.label8);
            this.groupBox8.Controls.Add(this.label9);
            this.groupBox8.Location = new System.Drawing.Point(437, 21);
            this.groupBox8.Name = "groupBox8";
            this.groupBox8.Size = new System.Drawing.Size(185, 121);
            this.groupBox8.TabIndex = 2;
            this.groupBox8.TabStop = false;
            this.groupBox8.Text = "New Mill Mixed Juice";
            // 
            // txtNmMixedJuicePurity
            // 
            this.txtNmMixedJuicePurity.Enabled = false;
            this.txtNmMixedJuicePurity.Location = new System.Drawing.Point(66, 78);
            this.txtNmMixedJuicePurity.Name = "txtNmMixedJuicePurity";
            this.txtNmMixedJuicePurity.Size = new System.Drawing.Size(100, 22);
            this.txtNmMixedJuicePurity.TabIndex = 8;
            this.txtNmMixedJuicePurity.Text = "0";
            // 
            // label50
            // 
            this.label50.AutoSize = true;
            this.label50.Location = new System.Drawing.Point(20, 81);
            this.label50.Name = "label50";
            this.label50.Size = new System.Drawing.Size(44, 17);
            this.label50.TabIndex = 7;
            this.label50.Text = "Purity";
            // 
            // txtNmMixedJuicePol
            // 
            this.txtNmMixedJuicePol.Enabled = false;
            this.txtNmMixedJuicePol.Location = new System.Drawing.Point(66, 50);
            this.txtNmMixedJuicePol.Name = "txtNmMixedJuicePol";
            this.txtNmMixedJuicePol.Size = new System.Drawing.Size(100, 22);
            this.txtNmMixedJuicePol.TabIndex = 6;
            this.txtNmMixedJuicePol.Text = "0";
            // 
            // txtNmMixedJuiceBrix
            // 
            this.txtNmMixedJuiceBrix.Enabled = false;
            this.txtNmMixedJuiceBrix.Location = new System.Drawing.Point(66, 24);
            this.txtNmMixedJuiceBrix.Name = "txtNmMixedJuiceBrix";
            this.txtNmMixedJuiceBrix.Size = new System.Drawing.Size(100, 22);
            this.txtNmMixedJuiceBrix.TabIndex = 5;
            this.txtNmMixedJuiceBrix.Text = "0";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(20, 53);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(40, 17);
            this.label8.TabIndex = 1;
            this.label8.Text = "Pol%";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(17, 27);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(43, 17);
            this.label9.TabIndex = 0;
            this.label9.Text = "Brix%";
            // 
            // groupBox6
            // 
            this.groupBox6.Controls.Add(this.txtOmPrimaryJuicePurity);
            this.groupBox6.Controls.Add(this.label43);
            this.groupBox6.Controls.Add(this.txtOmPrimaryJuicePol);
            this.groupBox6.Controls.Add(this.txtOmPrimaryJuiceBrix);
            this.groupBox6.Controls.Add(this.label4);
            this.groupBox6.Controls.Add(this.label5);
            this.groupBox6.Location = new System.Drawing.Point(241, 21);
            this.groupBox6.Name = "groupBox6";
            this.groupBox6.Size = new System.Drawing.Size(185, 121);
            this.groupBox6.TabIndex = 1;
            this.groupBox6.TabStop = false;
            this.groupBox6.Text = "Old Mill Primary Juice";
            // 
            // txtOmPrimaryJuicePurity
            // 
            this.txtOmPrimaryJuicePurity.Enabled = false;
            this.txtOmPrimaryJuicePurity.Location = new System.Drawing.Point(66, 78);
            this.txtOmPrimaryJuicePurity.Name = "txtOmPrimaryJuicePurity";
            this.txtOmPrimaryJuicePurity.Size = new System.Drawing.Size(100, 22);
            this.txtOmPrimaryJuicePurity.TabIndex = 6;
            this.txtOmPrimaryJuicePurity.Text = "0";
            // 
            // label43
            // 
            this.label43.AutoSize = true;
            this.label43.Location = new System.Drawing.Point(21, 81);
            this.label43.Name = "label43";
            this.label43.Size = new System.Drawing.Size(44, 17);
            this.label43.TabIndex = 5;
            this.label43.Text = "Purity";
            // 
            // txtOmPrimaryJuicePol
            // 
            this.txtOmPrimaryJuicePol.Enabled = false;
            this.txtOmPrimaryJuicePol.Location = new System.Drawing.Point(66, 50);
            this.txtOmPrimaryJuicePol.Name = "txtOmPrimaryJuicePol";
            this.txtOmPrimaryJuicePol.Size = new System.Drawing.Size(100, 22);
            this.txtOmPrimaryJuicePol.TabIndex = 4;
            this.txtOmPrimaryJuicePol.Text = "0";
            // 
            // txtOmPrimaryJuiceBrix
            // 
            this.txtOmPrimaryJuiceBrix.Enabled = false;
            this.txtOmPrimaryJuiceBrix.Location = new System.Drawing.Point(66, 24);
            this.txtOmPrimaryJuiceBrix.Name = "txtOmPrimaryJuiceBrix";
            this.txtOmPrimaryJuiceBrix.Size = new System.Drawing.Size(100, 22);
            this.txtOmPrimaryJuiceBrix.TabIndex = 3;
            this.txtOmPrimaryJuiceBrix.Text = "0";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(20, 53);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(40, 17);
            this.label4.TabIndex = 1;
            this.label4.Text = "Pol%";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(17, 27);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(43, 17);
            this.label5.TabIndex = 0;
            this.label5.Text = "Brix%";
            // 
            // groupBoxNmPurity
            // 
            this.groupBoxNmPurity.Controls.Add(this.txtNmPrimaryJuicePurity);
            this.groupBoxNmPurity.Controls.Add(this.label40);
            this.groupBoxNmPurity.Controls.Add(this.txtNmPrimaryJuicePol);
            this.groupBoxNmPurity.Controls.Add(this.txtNmPrimaryJuiceBrix);
            this.groupBoxNmPurity.Controls.Add(this.label3);
            this.groupBoxNmPurity.Controls.Add(this.label2);
            this.groupBoxNmPurity.Location = new System.Drawing.Point(26, 21);
            this.groupBoxNmPurity.Name = "groupBoxNmPurity";
            this.groupBoxNmPurity.Size = new System.Drawing.Size(185, 121);
            this.groupBoxNmPurity.TabIndex = 0;
            this.groupBoxNmPurity.TabStop = false;
            this.groupBoxNmPurity.Text = "New Mill Primary Juice";
            // 
            // txtNmPrimaryJuicePurity
            // 
            this.txtNmPrimaryJuicePurity.Enabled = false;
            this.txtNmPrimaryJuicePurity.Location = new System.Drawing.Point(63, 78);
            this.txtNmPrimaryJuicePurity.Name = "txtNmPrimaryJuicePurity";
            this.txtNmPrimaryJuicePurity.Size = new System.Drawing.Size(100, 22);
            this.txtNmPrimaryJuicePurity.TabIndex = 4;
            this.txtNmPrimaryJuicePurity.Text = "0";
            // 
            // label40
            // 
            this.label40.AutoSize = true;
            this.label40.Location = new System.Drawing.Point(17, 81);
            this.label40.Name = "label40";
            this.label40.Size = new System.Drawing.Size(44, 17);
            this.label40.TabIndex = 3;
            this.label40.Text = "Purity";
            // 
            // txtNmPrimaryJuicePol
            // 
            this.txtNmPrimaryJuicePol.Enabled = false;
            this.txtNmPrimaryJuicePol.Location = new System.Drawing.Point(63, 50);
            this.txtNmPrimaryJuicePol.Name = "txtNmPrimaryJuicePol";
            this.txtNmPrimaryJuicePol.Size = new System.Drawing.Size(100, 22);
            this.txtNmPrimaryJuicePol.TabIndex = 2;
            this.txtNmPrimaryJuicePol.Text = "0";
            // 
            // txtNmPrimaryJuiceBrix
            // 
            this.txtNmPrimaryJuiceBrix.Enabled = false;
            this.txtNmPrimaryJuiceBrix.Location = new System.Drawing.Point(63, 24);
            this.txtNmPrimaryJuiceBrix.Name = "txtNmPrimaryJuiceBrix";
            this.txtNmPrimaryJuiceBrix.Size = new System.Drawing.Size(100, 22);
            this.txtNmPrimaryJuiceBrix.TabIndex = 1;
            this.txtNmPrimaryJuiceBrix.Text = "0";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(20, 53);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(40, 17);
            this.label3.TabIndex = 1;
            this.label3.Text = "Pol%";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(17, 27);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(43, 17);
            this.label2.TabIndex = 0;
            this.label2.Text = "Brix%";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.txtTime);
            this.groupBox2.Controls.Add(this.lblDate);
            this.groupBox2.Controls.Add(this.label1);
            this.groupBox2.Controls.Add(this.dateTimeTranDate);
            this.groupBox2.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.groupBox2.Location = new System.Drawing.Point(18, 12);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(439, 46);
            this.groupBox2.TabIndex = 14;
            this.groupBox2.TabStop = false;
            // 
            // txtTime
            // 
            this.txtTime.Enabled = false;
            this.txtTime.Location = new System.Drawing.Point(308, 14);
            this.txtTime.Name = "txtTime";
            this.txtTime.Size = new System.Drawing.Size(100, 22);
            this.txtTime.TabIndex = 9;
            // 
            // lblDate
            // 
            this.lblDate.AutoSize = true;
            this.lblDate.Location = new System.Drawing.Point(23, 15);
            this.lblDate.Name = "lblDate";
            this.lblDate.Size = new System.Drawing.Size(96, 17);
            this.lblDate.TabIndex = 7;
            this.lblDate.Text = "ENTRY DATE";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(257, 17);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(40, 17);
            this.label1.TabIndex = 6;
            this.label1.Text = "TIME";
            // 
            // dateTimeTranDate
            // 
            this.dateTimeTranDate.CustomFormat = "yyyy-MM-dd";
            this.dateTimeTranDate.Enabled = false;
            this.dateTimeTranDate.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dateTimeTranDate.Location = new System.Drawing.Point(135, 15);
            this.dateTimeTranDate.Name = "dateTimeTranDate";
            this.dateTimeTranDate.Size = new System.Drawing.Size(100, 22);
            this.dateTimeTranDate.TabIndex = 8;
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.groupBox11);
            this.groupBox3.Controls.Add(this.groupBox12);
            this.groupBox3.Controls.Add(this.groupBox13);
            this.groupBox3.Controls.Add(this.groupBox14);
            this.groupBox3.Controls.Add(this.groupBox15);
            this.groupBox3.Location = new System.Drawing.Point(18, 222);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(1249, 175);
            this.groupBox3.TabIndex = 2;
            this.groupBox3.TabStop = false;
            // 
            // groupBox11
            // 
            this.groupBox11.Controls.Add(this.txtFinalMolassesPurity);
            this.groupBox11.Controls.Add(this.label58);
            this.groupBox11.Controls.Add(this.txtFinalMolassesTanks);
            this.groupBox11.Controls.Add(this.txtFinalMolassesTemp);
            this.groupBox11.Controls.Add(this.label24);
            this.groupBox11.Controls.Add(this.label25);
            this.groupBox11.Controls.Add(this.txtFinalMolassesPol);
            this.groupBox11.Controls.Add(this.txtFinalMolassesBrix);
            this.groupBox11.Controls.Add(this.label14);
            this.groupBox11.Controls.Add(this.label15);
            this.groupBox11.Location = new System.Drawing.Point(839, 14);
            this.groupBox11.Name = "groupBox11";
            this.groupBox11.Size = new System.Drawing.Size(389, 157);
            this.groupBox11.TabIndex = 9;
            this.groupBox11.TabStop = false;
            this.groupBox11.Text = "Final Molasses";
            // 
            // txtFinalMolassesPurity
            // 
            this.txtFinalMolassesPurity.Enabled = false;
            this.txtFinalMolassesPurity.Location = new System.Drawing.Point(66, 83);
            this.txtFinalMolassesPurity.Name = "txtFinalMolassesPurity";
            this.txtFinalMolassesPurity.Size = new System.Drawing.Size(100, 22);
            this.txtFinalMolassesPurity.TabIndex = 30;
            this.txtFinalMolassesPurity.Text = "0";
            // 
            // label58
            // 
            this.label58.AutoSize = true;
            this.label58.Location = new System.Drawing.Point(12, 87);
            this.label58.Name = "label58";
            this.label58.Size = new System.Drawing.Size(44, 17);
            this.label58.TabIndex = 29;
            this.label58.Text = "Purity";
            // 
            // txtFinalMolassesTanks
            // 
            this.txtFinalMolassesTanks.Enabled = false;
            this.txtFinalMolassesTanks.Location = new System.Drawing.Point(270, 55);
            this.txtFinalMolassesTanks.Name = "txtFinalMolassesTanks";
            this.txtFinalMolassesTanks.Size = new System.Drawing.Size(100, 22);
            this.txtFinalMolassesTanks.TabIndex = 28;
            this.txtFinalMolassesTanks.Text = "0";
            // 
            // txtFinalMolassesTemp
            // 
            this.txtFinalMolassesTemp.Enabled = false;
            this.txtFinalMolassesTemp.Location = new System.Drawing.Point(270, 27);
            this.txtFinalMolassesTemp.Name = "txtFinalMolassesTemp";
            this.txtFinalMolassesTemp.Size = new System.Drawing.Size(100, 22);
            this.txtFinalMolassesTemp.TabIndex = 27;
            this.txtFinalMolassesTemp.Text = "0";
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Location = new System.Drawing.Point(176, 53);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(89, 17);
            this.label24.TabIndex = 5;
            this.label24.Text = "No. of Tanks";
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Location = new System.Drawing.Point(183, 27);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(82, 17);
            this.label25.TabIndex = 4;
            this.label25.Text = "Temprature";
            // 
            // txtFinalMolassesPol
            // 
            this.txtFinalMolassesPol.Enabled = false;
            this.txtFinalMolassesPol.Location = new System.Drawing.Point(66, 55);
            this.txtFinalMolassesPol.Name = "txtFinalMolassesPol";
            this.txtFinalMolassesPol.Size = new System.Drawing.Size(100, 22);
            this.txtFinalMolassesPol.TabIndex = 26;
            this.txtFinalMolassesPol.Text = "0";
            // 
            // txtFinalMolassesBrix
            // 
            this.txtFinalMolassesBrix.Enabled = false;
            this.txtFinalMolassesBrix.Location = new System.Drawing.Point(66, 27);
            this.txtFinalMolassesBrix.Name = "txtFinalMolassesBrix";
            this.txtFinalMolassesBrix.Size = new System.Drawing.Size(100, 22);
            this.txtFinalMolassesBrix.TabIndex = 25;
            this.txtFinalMolassesBrix.Text = "0";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(17, 53);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(40, 17);
            this.label14.TabIndex = 1;
            this.label14.Text = "Pol%";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(14, 27);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(43, 17);
            this.label15.TabIndex = 0;
            this.label15.Text = "Brix%";
            // 
            // groupBox12
            // 
            this.groupBox12.Controls.Add(this.txtSulphuredSyrupPurity);
            this.groupBox12.Controls.Add(this.label57);
            this.groupBox12.Controls.Add(this.txtSulphuredSyrupPh);
            this.groupBox12.Controls.Add(this.label29);
            this.groupBox12.Controls.Add(this.txtSulphuredSyrupPol);
            this.groupBox12.Controls.Add(this.txtSulphuredSyrupBrix);
            this.groupBox12.Controls.Add(this.label16);
            this.groupBox12.Controls.Add(this.label17);
            this.groupBox12.Location = new System.Drawing.Point(639, 14);
            this.groupBox12.Name = "groupBox12";
            this.groupBox12.Size = new System.Drawing.Size(185, 157);
            this.groupBox12.TabIndex = 8;
            this.groupBox12.TabStop = false;
            this.groupBox12.Text = "Sulphured Syrup";
            // 
            // txtSulphuredSyrupPurity
            // 
            this.txtSulphuredSyrupPurity.Enabled = false;
            this.txtSulphuredSyrupPurity.Location = new System.Drawing.Point(66, 111);
            this.txtSulphuredSyrupPurity.Name = "txtSulphuredSyrupPurity";
            this.txtSulphuredSyrupPurity.Size = new System.Drawing.Size(100, 22);
            this.txtSulphuredSyrupPurity.TabIndex = 26;
            this.txtSulphuredSyrupPurity.Text = "0";
            // 
            // label57
            // 
            this.label57.AutoSize = true;
            this.label57.Location = new System.Drawing.Point(12, 115);
            this.label57.Name = "label57";
            this.label57.Size = new System.Drawing.Size(44, 17);
            this.label57.TabIndex = 25;
            this.label57.Text = "Purity";
            // 
            // txtSulphuredSyrupPh
            // 
            this.txtSulphuredSyrupPh.Enabled = false;
            this.txtSulphuredSyrupPh.Location = new System.Drawing.Point(66, 83);
            this.txtSulphuredSyrupPh.Name = "txtSulphuredSyrupPh";
            this.txtSulphuredSyrupPh.Size = new System.Drawing.Size(100, 22);
            this.txtSulphuredSyrupPh.TabIndex = 24;
            this.txtSulphuredSyrupPh.Text = "0";
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Location = new System.Drawing.Point(30, 81);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(26, 17);
            this.label29.TabIndex = 23;
            this.label29.Text = "pH";
            // 
            // txtSulphuredSyrupPol
            // 
            this.txtSulphuredSyrupPol.Enabled = false;
            this.txtSulphuredSyrupPol.Location = new System.Drawing.Point(66, 55);
            this.txtSulphuredSyrupPol.Name = "txtSulphuredSyrupPol";
            this.txtSulphuredSyrupPol.Size = new System.Drawing.Size(100, 22);
            this.txtSulphuredSyrupPol.TabIndex = 23;
            this.txtSulphuredSyrupPol.Text = "0";
            // 
            // txtSulphuredSyrupBrix
            // 
            this.txtSulphuredSyrupBrix.Enabled = false;
            this.txtSulphuredSyrupBrix.Location = new System.Drawing.Point(66, 27);
            this.txtSulphuredSyrupBrix.Name = "txtSulphuredSyrupBrix";
            this.txtSulphuredSyrupBrix.Size = new System.Drawing.Size(100, 22);
            this.txtSulphuredSyrupBrix.TabIndex = 22;
            this.txtSulphuredSyrupBrix.Text = "0";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(16, 54);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(40, 17);
            this.label16.TabIndex = 1;
            this.label16.Text = "Pol%";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(13, 27);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(43, 17);
            this.label17.TabIndex = 0;
            this.label17.Text = "Brix%";
            // 
            // groupBox13
            // 
            this.groupBox13.Controls.Add(this.txtUnsulphuredSyrupPurity);
            this.groupBox13.Controls.Add(this.label56);
            this.groupBox13.Controls.Add(this.txtUnsulphuredSyrupPh);
            this.groupBox13.Controls.Add(this.label28);
            this.groupBox13.Controls.Add(this.txtUnsulphuredSyrupPol);
            this.groupBox13.Controls.Add(this.txtUnsulphuredSyrupBrix);
            this.groupBox13.Controls.Add(this.label18);
            this.groupBox13.Controls.Add(this.label19);
            this.groupBox13.Location = new System.Drawing.Point(437, 14);
            this.groupBox13.Name = "groupBox13";
            this.groupBox13.Size = new System.Drawing.Size(185, 157);
            this.groupBox13.TabIndex = 7;
            this.groupBox13.TabStop = false;
            this.groupBox13.Text = "Unsulphured Syrup";
            // 
            // txtUnsulphuredSyrupPurity
            // 
            this.txtUnsulphuredSyrupPurity.Enabled = false;
            this.txtUnsulphuredSyrupPurity.Location = new System.Drawing.Point(66, 111);
            this.txtUnsulphuredSyrupPurity.Name = "txtUnsulphuredSyrupPurity";
            this.txtUnsulphuredSyrupPurity.Size = new System.Drawing.Size(100, 22);
            this.txtUnsulphuredSyrupPurity.TabIndex = 25;
            this.txtUnsulphuredSyrupPurity.Text = "0";
            // 
            // label56
            // 
            this.label56.AutoSize = true;
            this.label56.Location = new System.Drawing.Point(15, 112);
            this.label56.Name = "label56";
            this.label56.Size = new System.Drawing.Size(44, 17);
            this.label56.TabIndex = 24;
            this.label56.Text = "Purity";
            // 
            // txtUnsulphuredSyrupPh
            // 
            this.txtUnsulphuredSyrupPh.Enabled = false;
            this.txtUnsulphuredSyrupPh.Location = new System.Drawing.Point(66, 83);
            this.txtUnsulphuredSyrupPh.Name = "txtUnsulphuredSyrupPh";
            this.txtUnsulphuredSyrupPh.Size = new System.Drawing.Size(100, 22);
            this.txtUnsulphuredSyrupPh.TabIndex = 21;
            this.txtUnsulphuredSyrupPh.Text = "0";
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Location = new System.Drawing.Point(33, 83);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(26, 17);
            this.label28.TabIndex = 23;
            this.label28.Text = "pH";
            // 
            // txtUnsulphuredSyrupPol
            // 
            this.txtUnsulphuredSyrupPol.Enabled = false;
            this.txtUnsulphuredSyrupPol.Location = new System.Drawing.Point(66, 55);
            this.txtUnsulphuredSyrupPol.Name = "txtUnsulphuredSyrupPol";
            this.txtUnsulphuredSyrupPol.Size = new System.Drawing.Size(100, 22);
            this.txtUnsulphuredSyrupPol.TabIndex = 20;
            this.txtUnsulphuredSyrupPol.Text = "0";
            // 
            // txtUnsulphuredSyrupBrix
            // 
            this.txtUnsulphuredSyrupBrix.Enabled = false;
            this.txtUnsulphuredSyrupBrix.Location = new System.Drawing.Point(66, 27);
            this.txtUnsulphuredSyrupBrix.Name = "txtUnsulphuredSyrupBrix";
            this.txtUnsulphuredSyrupBrix.Size = new System.Drawing.Size(100, 22);
            this.txtUnsulphuredSyrupBrix.TabIndex = 19;
            this.txtUnsulphuredSyrupBrix.Text = "0";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(19, 55);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(40, 17);
            this.label18.TabIndex = 1;
            this.label18.Text = "Pol%";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(16, 27);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(43, 17);
            this.label19.TabIndex = 0;
            this.label19.Text = "Brix%";
            // 
            // groupBox14
            // 
            this.groupBox14.Controls.Add(this.txtClearJuicePurity);
            this.groupBox14.Controls.Add(this.label55);
            this.groupBox14.Controls.Add(this.txtClearJuicePh);
            this.groupBox14.Controls.Add(this.txtClearJuicePol);
            this.groupBox14.Controls.Add(this.label27);
            this.groupBox14.Controls.Add(this.txtClearJuiceBrix);
            this.groupBox14.Controls.Add(this.label20);
            this.groupBox14.Controls.Add(this.label21);
            this.groupBox14.Location = new System.Drawing.Point(241, 14);
            this.groupBox14.Name = "groupBox14";
            this.groupBox14.Size = new System.Drawing.Size(185, 157);
            this.groupBox14.TabIndex = 6;
            this.groupBox14.TabStop = false;
            this.groupBox14.Text = "Clear Juice";
            // 
            // txtClearJuicePurity
            // 
            this.txtClearJuicePurity.Enabled = false;
            this.txtClearJuicePurity.Location = new System.Drawing.Point(66, 111);
            this.txtClearJuicePurity.Name = "txtClearJuicePurity";
            this.txtClearJuicePurity.Size = new System.Drawing.Size(100, 22);
            this.txtClearJuicePurity.TabIndex = 23;
            this.txtClearJuicePurity.Text = "0";
            // 
            // label55
            // 
            this.label55.AutoSize = true;
            this.label55.Location = new System.Drawing.Point(12, 114);
            this.label55.Name = "label55";
            this.label55.Size = new System.Drawing.Size(44, 17);
            this.label55.TabIndex = 22;
            this.label55.Text = "Purity";
            // 
            // txtClearJuicePh
            // 
            this.txtClearJuicePh.Enabled = false;
            this.txtClearJuicePh.Location = new System.Drawing.Point(66, 83);
            this.txtClearJuicePh.Name = "txtClearJuicePh";
            this.txtClearJuicePh.Size = new System.Drawing.Size(100, 22);
            this.txtClearJuicePh.TabIndex = 18;
            this.txtClearJuicePh.Text = "0";
            // 
            // txtClearJuicePol
            // 
            this.txtClearJuicePol.Enabled = false;
            this.txtClearJuicePol.Location = new System.Drawing.Point(66, 55);
            this.txtClearJuicePol.Name = "txtClearJuicePol";
            this.txtClearJuicePol.Size = new System.Drawing.Size(100, 22);
            this.txtClearJuicePol.TabIndex = 17;
            this.txtClearJuicePol.Text = "0";
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Location = new System.Drawing.Point(30, 83);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(26, 17);
            this.label27.TabIndex = 21;
            this.label27.Text = "pH";
            // 
            // txtClearJuiceBrix
            // 
            this.txtClearJuiceBrix.Enabled = false;
            this.txtClearJuiceBrix.Location = new System.Drawing.Point(66, 27);
            this.txtClearJuiceBrix.Name = "txtClearJuiceBrix";
            this.txtClearJuiceBrix.Size = new System.Drawing.Size(100, 22);
            this.txtClearJuiceBrix.TabIndex = 16;
            this.txtClearJuiceBrix.Text = "0";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(16, 55);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(40, 17);
            this.label20.TabIndex = 1;
            this.label20.Text = "Pol%";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(13, 27);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(43, 17);
            this.label21.TabIndex = 0;
            this.label21.Text = "Brix%";
            // 
            // groupBox15
            // 
            this.groupBox15.Controls.Add(this.txtOliverFilteredPurity);
            this.groupBox15.Controls.Add(this.label54);
            this.groupBox15.Controls.Add(this.txtOliverFilteredPh);
            this.groupBox15.Controls.Add(this.txtOliverFilteredPol);
            this.groupBox15.Controls.Add(this.label26);
            this.groupBox15.Controls.Add(this.txtOliverFilteredBirx);
            this.groupBox15.Controls.Add(this.label22);
            this.groupBox15.Controls.Add(this.label23);
            this.groupBox15.Location = new System.Drawing.Point(26, 14);
            this.groupBox15.Name = "groupBox15";
            this.groupBox15.Size = new System.Drawing.Size(185, 157);
            this.groupBox15.TabIndex = 5;
            this.groupBox15.TabStop = false;
            this.groupBox15.Text = "Oliver Filter Juice";
            // 
            // txtOliverFilteredPurity
            // 
            this.txtOliverFilteredPurity.Enabled = false;
            this.txtOliverFilteredPurity.Location = new System.Drawing.Point(62, 111);
            this.txtOliverFilteredPurity.Name = "txtOliverFilteredPurity";
            this.txtOliverFilteredPurity.Size = new System.Drawing.Size(100, 22);
            this.txtOliverFilteredPurity.TabIndex = 21;
            this.txtOliverFilteredPurity.Text = "0";
            // 
            // label54
            // 
            this.label54.AutoSize = true;
            this.label54.Location = new System.Drawing.Point(13, 114);
            this.label54.Name = "label54";
            this.label54.Size = new System.Drawing.Size(44, 17);
            this.label54.TabIndex = 20;
            this.label54.Text = "Purity";
            // 
            // txtOliverFilteredPh
            // 
            this.txtOliverFilteredPh.Enabled = false;
            this.txtOliverFilteredPh.Location = new System.Drawing.Point(63, 83);
            this.txtOliverFilteredPh.Name = "txtOliverFilteredPh";
            this.txtOliverFilteredPh.Size = new System.Drawing.Size(100, 22);
            this.txtOliverFilteredPh.TabIndex = 15;
            this.txtOliverFilteredPh.Text = "0";
            // 
            // txtOliverFilteredPol
            // 
            this.txtOliverFilteredPol.Enabled = false;
            this.txtOliverFilteredPol.Location = new System.Drawing.Point(63, 55);
            this.txtOliverFilteredPol.Name = "txtOliverFilteredPol";
            this.txtOliverFilteredPol.Size = new System.Drawing.Size(100, 22);
            this.txtOliverFilteredPol.TabIndex = 14;
            this.txtOliverFilteredPol.Text = "0";
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Location = new System.Drawing.Point(31, 83);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(26, 17);
            this.label26.TabIndex = 19;
            this.label26.Text = "pH";
            // 
            // txtOliverFilteredBirx
            // 
            this.txtOliverFilteredBirx.Enabled = false;
            this.txtOliverFilteredBirx.Location = new System.Drawing.Point(63, 27);
            this.txtOliverFilteredBirx.Name = "txtOliverFilteredBirx";
            this.txtOliverFilteredBirx.Size = new System.Drawing.Size(100, 22);
            this.txtOliverFilteredBirx.TabIndex = 13;
            this.txtOliverFilteredBirx.Text = "0";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Location = new System.Drawing.Point(17, 55);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(40, 17);
            this.label22.TabIndex = 1;
            this.label22.Text = "Pol%";
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Location = new System.Drawing.Point(14, 27);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(43, 17);
            this.label23.TabIndex = 0;
            this.label23.Text = "Brix%";
            // 
            // groupBox25
            // 
            this.groupBox25.Controls.Add(this.btnModify);
            this.groupBox25.Controls.Add(this.btnNewRecord);
            this.groupBox25.Controls.Add(this.btnSave);
            this.groupBox25.Controls.Add(this.btnClear);
            this.groupBox25.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.groupBox25.Location = new System.Drawing.Point(460, 661);
            this.groupBox25.Name = "groupBox25";
            this.groupBox25.Size = new System.Drawing.Size(453, 48);
            this.groupBox25.TabIndex = 18;
            this.groupBox25.TabStop = false;
            // 
            // btnModify
            // 
            this.btnModify.Enabled = false;
            this.btnModify.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnModify.Location = new System.Drawing.Point(118, 11);
            this.btnModify.Name = "btnModify";
            this.btnModify.Size = new System.Drawing.Size(105, 31);
            this.btnModify.TabIndex = 25;
            this.btnModify.Text = "MODIFY";
            this.btnModify.UseVisualStyleBackColor = true;
            this.btnModify.Click += new System.EventHandler(this.btnModify_Click);
            // 
            // btnNewRecord
            // 
            this.btnNewRecord.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnNewRecord.Location = new System.Drawing.Point(9, 11);
            this.btnNewRecord.Name = "btnNewRecord";
            this.btnNewRecord.Size = new System.Drawing.Size(105, 31);
            this.btnNewRecord.TabIndex = 48;
            this.btnNewRecord.Text = "&New Record";
            this.btnNewRecord.UseVisualStyleBackColor = true;
            this.btnNewRecord.Click += new System.EventHandler(this.btnNewRecord_Click);
            // 
            // btnSave
            // 
            this.btnSave.Enabled = false;
            this.btnSave.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnSave.Location = new System.Drawing.Point(229, 11);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(105, 31);
            this.btnSave.TabIndex = 23;
            this.btnSave.Text = "&Save";
            this.btnSave.UseVisualStyleBackColor = true;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // btnClear
            // 
            this.btnClear.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnClear.Location = new System.Drawing.Point(340, 11);
            this.btnClear.Name = "btnClear";
            this.btnClear.Size = new System.Drawing.Size(105, 31);
            this.btnClear.TabIndex = 47;
            this.btnClear.Text = "&Reset";
            this.btnClear.UseVisualStyleBackColor = true;
            this.btnClear.Click += new System.EventHandler(this.btnClear_Click);
            // 
            // groupBoxBagasse
            // 
            this.groupBoxBagasse.Controls.Add(this.groupBoxBagasse_oldMill);
            this.groupBoxBagasse.Controls.Add(this.groupBoxBagasseNewMill);
            this.groupBoxBagasse.Location = new System.Drawing.Point(8, 14);
            this.groupBoxBagasse.Name = "groupBoxBagasse";
            this.groupBoxBagasse.Size = new System.Drawing.Size(476, 137);
            this.groupBoxBagasse.TabIndex = 19;
            this.groupBoxBagasse.TabStop = false;
            this.groupBoxBagasse.Text = "Bagasse";
            // 
            // groupBoxBagasse_oldMill
            // 
            this.groupBoxBagasse_oldMill.Controls.Add(this.txtOmMoisture);
            this.groupBoxBagasse_oldMill.Controls.Add(this.txtOmBagassPol);
            this.groupBoxBagasse_oldMill.Controls.Add(this.label41);
            this.groupBoxBagasse_oldMill.Controls.Add(this.label42);
            this.groupBoxBagasse_oldMill.Location = new System.Drawing.Point(251, 18);
            this.groupBoxBagasse_oldMill.Name = "groupBoxBagasse_oldMill";
            this.groupBoxBagasse_oldMill.Size = new System.Drawing.Size(207, 101);
            this.groupBoxBagasse_oldMill.TabIndex = 6;
            this.groupBoxBagasse_oldMill.TabStop = false;
            this.groupBoxBagasse_oldMill.Text = "Old Mill";
            // 
            // txtOmMoisture
            // 
            this.txtOmMoisture.Enabled = false;
            this.txtOmMoisture.Location = new System.Drawing.Point(95, 53);
            this.txtOmMoisture.Name = "txtOmMoisture";
            this.txtOmMoisture.Size = new System.Drawing.Size(100, 22);
            this.txtOmMoisture.TabIndex = 32;
            this.txtOmMoisture.Text = "0";
            // 
            // txtOmBagassPol
            // 
            this.txtOmBagassPol.Enabled = false;
            this.txtOmBagassPol.Location = new System.Drawing.Point(95, 24);
            this.txtOmBagassPol.Name = "txtOmBagassPol";
            this.txtOmBagassPol.Size = new System.Drawing.Size(100, 22);
            this.txtOmBagassPol.TabIndex = 31;
            this.txtOmBagassPol.Text = "0";
            // 
            // label41
            // 
            this.label41.AutoSize = true;
            this.label41.Location = new System.Drawing.Point(16, 53);
            this.label41.Name = "label41";
            this.label41.Size = new System.Drawing.Size(74, 17);
            this.label41.TabIndex = 1;
            this.label41.Text = "Moisture%";
            // 
            // label42
            // 
            this.label42.AutoSize = true;
            this.label42.Location = new System.Drawing.Point(13, 27);
            this.label42.Name = "label42";
            this.label42.Size = new System.Drawing.Size(40, 17);
            this.label42.TabIndex = 0;
            this.label42.Text = "Pol%";
            // 
            // groupBoxBagasseNewMill
            // 
            this.groupBoxBagasseNewMill.Controls.Add(this.txtBagassNmMoisture);
            this.groupBoxBagasseNewMill.Controls.Add(this.txtBagasseNmPol);
            this.groupBoxBagasseNewMill.Controls.Add(this.label44);
            this.groupBoxBagasseNewMill.Controls.Add(this.label45);
            this.groupBoxBagasseNewMill.Location = new System.Drawing.Point(26, 18);
            this.groupBoxBagasseNewMill.Name = "groupBoxBagasseNewMill";
            this.groupBoxBagasseNewMill.Size = new System.Drawing.Size(203, 101);
            this.groupBoxBagasseNewMill.TabIndex = 5;
            this.groupBoxBagasseNewMill.TabStop = false;
            this.groupBoxBagasseNewMill.Text = "New Mill";
            // 
            // txtBagassNmMoisture
            // 
            this.txtBagassNmMoisture.Enabled = false;
            this.txtBagassNmMoisture.Location = new System.Drawing.Point(97, 53);
            this.txtBagassNmMoisture.Name = "txtBagassNmMoisture";
            this.txtBagassNmMoisture.Size = new System.Drawing.Size(100, 22);
            this.txtBagassNmMoisture.TabIndex = 30;
            this.txtBagassNmMoisture.Text = "0";
            // 
            // txtBagasseNmPol
            // 
            this.txtBagasseNmPol.Enabled = false;
            this.txtBagasseNmPol.Location = new System.Drawing.Point(97, 24);
            this.txtBagasseNmPol.Name = "txtBagasseNmPol";
            this.txtBagasseNmPol.Size = new System.Drawing.Size(100, 22);
            this.txtBagasseNmPol.TabIndex = 29;
            this.txtBagasseNmPol.Text = "0";
            // 
            // label44
            // 
            this.label44.AutoSize = true;
            this.label44.Location = new System.Drawing.Point(17, 53);
            this.label44.Name = "label44";
            this.label44.Size = new System.Drawing.Size(74, 17);
            this.label44.TabIndex = 1;
            this.label44.Text = "Moisture%";
            // 
            // label45
            // 
            this.label45.AutoSize = true;
            this.label45.Location = new System.Drawing.Point(51, 27);
            this.label45.Name = "label45";
            this.label45.Size = new System.Drawing.Size(40, 17);
            this.label45.TabIndex = 0;
            this.label45.Text = "Pol%";
            // 
            // groupBox16
            // 
            this.groupBox16.Controls.Add(this.groupBoxPolPressCake);
            this.groupBox16.Location = new System.Drawing.Point(490, 14);
            this.groupBox16.Name = "groupBox16";
            this.groupBox16.Size = new System.Drawing.Size(738, 152);
            this.groupBox16.TabIndex = 20;
            this.groupBox16.TabStop = false;
            this.groupBox16.Text = "Oliver Filter-Mud";
            // 
            // groupBoxPolPressCake
            // 
            this.groupBoxPolPressCake.Controls.Add(this.txtFilteMudAverage);
            this.groupBoxPolPressCake.Controls.Add(this.label37);
            this.groupBoxPolPressCake.Controls.Add(this.txtFilteMudComposite);
            this.groupBoxPolPressCake.Controls.Add(this.label36);
            this.groupBoxPolPressCake.Controls.Add(this.txtFilteMudMoisture);
            this.groupBoxPolPressCake.Controls.Add(this.label35);
            this.groupBoxPolPressCake.Controls.Add(this.label34);
            this.groupBoxPolPressCake.Controls.Add(this.txtFilteMudSample5);
            this.groupBoxPolPressCake.Controls.Add(this.label31);
            this.groupBoxPolPressCake.Controls.Add(this.txtFilteMudSample4);
            this.groupBoxPolPressCake.Controls.Add(this.txtFilteMudSample3);
            this.groupBoxPolPressCake.Controls.Add(this.label32);
            this.groupBoxPolPressCake.Controls.Add(this.label30);
            this.groupBoxPolPressCake.Controls.Add(this.txtFilteMudSample2);
            this.groupBoxPolPressCake.Controls.Add(this.txtFilteMudSample1);
            this.groupBoxPolPressCake.Controls.Add(this.label33);
            this.groupBoxPolPressCake.Location = new System.Drawing.Point(26, 18);
            this.groupBoxPolPressCake.Name = "groupBoxPolPressCake";
            this.groupBoxPolPressCake.Size = new System.Drawing.Size(693, 119);
            this.groupBoxPolPressCake.TabIndex = 5;
            this.groupBoxPolPressCake.TabStop = false;
            this.groupBoxPolPressCake.Text = "Pol% Press Cake";
            // 
            // txtFilteMudAverage
            // 
            this.txtFilteMudAverage.Enabled = false;
            this.txtFilteMudAverage.Location = new System.Drawing.Point(81, 81);
            this.txtFilteMudAverage.Name = "txtFilteMudAverage";
            this.txtFilteMudAverage.Size = new System.Drawing.Size(100, 22);
            this.txtFilteMudAverage.TabIndex = 40;
            this.txtFilteMudAverage.Text = "0";
            // 
            // label37
            // 
            this.label37.AutoSize = true;
            this.label37.Location = new System.Drawing.Point(14, 84);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(61, 17);
            this.label37.TabIndex = 15;
            this.label37.Text = "Average";
            // 
            // txtFilteMudComposite
            // 
            this.txtFilteMudComposite.Enabled = false;
            this.txtFilteMudComposite.Location = new System.Drawing.Point(459, 78);
            this.txtFilteMudComposite.Name = "txtFilteMudComposite";
            this.txtFilteMudComposite.Size = new System.Drawing.Size(100, 22);
            this.txtFilteMudComposite.TabIndex = 39;
            this.txtFilteMudComposite.Text = "0";
            // 
            // label36
            // 
            this.label36.AutoSize = true;
            this.label36.Location = new System.Drawing.Point(379, 81);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(74, 17);
            this.label36.TabIndex = 13;
            this.label36.Text = "Composite";
            // 
            // txtFilteMudMoisture
            // 
            this.txtFilteMudMoisture.Enabled = false;
            this.txtFilteMudMoisture.Location = new System.Drawing.Point(264, 83);
            this.txtFilteMudMoisture.Name = "txtFilteMudMoisture";
            this.txtFilteMudMoisture.Size = new System.Drawing.Size(100, 22);
            this.txtFilteMudMoisture.TabIndex = 38;
            this.txtFilteMudMoisture.Text = "0";
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.Location = new System.Drawing.Point(191, 86);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(74, 17);
            this.label35.TabIndex = 11;
            this.label35.Text = "Moisture%";
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.Location = new System.Drawing.Point(191, 58);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(67, 17);
            this.label34.TabIndex = 10;
            this.label34.Text = "Sample 5";
            // 
            // txtFilteMudSample5
            // 
            this.txtFilteMudSample5.Enabled = false;
            this.txtFilteMudSample5.Location = new System.Drawing.Point(264, 55);
            this.txtFilteMudSample5.Name = "txtFilteMudSample5";
            this.txtFilteMudSample5.Size = new System.Drawing.Size(100, 22);
            this.txtFilteMudSample5.TabIndex = 37;
            this.txtFilteMudSample5.Text = "0";
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Location = new System.Drawing.Point(8, 56);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(67, 17);
            this.label31.TabIndex = 8;
            this.label31.Text = "Sample 4";
            // 
            // txtFilteMudSample4
            // 
            this.txtFilteMudSample4.Enabled = false;
            this.txtFilteMudSample4.Location = new System.Drawing.Point(81, 53);
            this.txtFilteMudSample4.Name = "txtFilteMudSample4";
            this.txtFilteMudSample4.Size = new System.Drawing.Size(100, 22);
            this.txtFilteMudSample4.TabIndex = 36;
            this.txtFilteMudSample4.Text = "0";
            // 
            // txtFilteMudSample3
            // 
            this.txtFilteMudSample3.Enabled = false;
            this.txtFilteMudSample3.Location = new System.Drawing.Point(459, 21);
            this.txtFilteMudSample3.Name = "txtFilteMudSample3";
            this.txtFilteMudSample3.Size = new System.Drawing.Size(100, 22);
            this.txtFilteMudSample3.TabIndex = 35;
            this.txtFilteMudSample3.Text = "0";
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Location = new System.Drawing.Point(386, 24);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(67, 17);
            this.label32.TabIndex = 5;
            this.label32.Text = "Sample 3";
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Location = new System.Drawing.Point(191, 27);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(67, 17);
            this.label30.TabIndex = 4;
            this.label30.Text = "Sample 2";
            // 
            // txtFilteMudSample2
            // 
            this.txtFilteMudSample2.Enabled = false;
            this.txtFilteMudSample2.Location = new System.Drawing.Point(264, 24);
            this.txtFilteMudSample2.Name = "txtFilteMudSample2";
            this.txtFilteMudSample2.Size = new System.Drawing.Size(100, 22);
            this.txtFilteMudSample2.TabIndex = 34;
            this.txtFilteMudSample2.Text = "0";
            // 
            // txtFilteMudSample1
            // 
            this.txtFilteMudSample1.Enabled = false;
            this.txtFilteMudSample1.Location = new System.Drawing.Point(81, 24);
            this.txtFilteMudSample1.Name = "txtFilteMudSample1";
            this.txtFilteMudSample1.Size = new System.Drawing.Size(100, 22);
            this.txtFilteMudSample1.TabIndex = 33;
            this.txtFilteMudSample1.Text = "0";
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.Location = new System.Drawing.Point(8, 27);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(67, 17);
            this.label33.TabIndex = 0;
            this.label33.Text = "Sample 1";
            // 
            // groupBox17
            // 
            this.groupBox17.Controls.Add(this.groupBoxBagasse);
            this.groupBox17.Controls.Add(this.groupBox16);
            this.groupBox17.Location = new System.Drawing.Point(18, 401);
            this.groupBox17.Name = "groupBox17";
            this.groupBox17.Size = new System.Drawing.Size(1249, 175);
            this.groupBox17.TabIndex = 3;
            this.groupBox17.TabStop = false;
            // 
            // groupBoxCaneStatus
            // 
            this.groupBoxCaneStatus.Controls.Add(this.txtCaneCrushed);
            this.groupBoxCaneStatus.Controls.Add(this.label49);
            this.groupBoxCaneStatus.Controls.Add(this.txtUncrushedCane);
            this.groupBoxCaneStatus.Controls.Add(this.label48);
            this.groupBoxCaneStatus.Controls.Add(this.txtStandingCarts);
            this.groupBoxCaneStatus.Controls.Add(this.label47);
            this.groupBoxCaneStatus.Controls.Add(this.txtStandingTripplers);
            this.groupBoxCaneStatus.Controls.Add(this.label46);
            this.groupBoxCaneStatus.Controls.Add(this.txtStandingTrolleys);
            this.groupBoxCaneStatus.Controls.Add(this.label39);
            this.groupBoxCaneStatus.Controls.Add(this.txtStandingTrucks);
            this.groupBoxCaneStatus.Controls.Add(this.label38);
            this.groupBoxCaneStatus.Location = new System.Drawing.Point(18, 577);
            this.groupBoxCaneStatus.Name = "groupBoxCaneStatus";
            this.groupBoxCaneStatus.Size = new System.Drawing.Size(804, 78);
            this.groupBoxCaneStatus.TabIndex = 5;
            this.groupBoxCaneStatus.TabStop = false;
            // 
            // txtCaneCrushed
            // 
            this.txtCaneCrushed.Enabled = false;
            this.txtCaneCrushed.Location = new System.Drawing.Point(671, 42);
            this.txtCaneCrushed.Name = "txtCaneCrushed";
            this.txtCaneCrushed.ReadOnly = true;
            this.txtCaneCrushed.Size = new System.Drawing.Size(100, 22);
            this.txtCaneCrushed.TabIndex = 46;
            this.txtCaneCrushed.Text = "0";
            // 
            // label49
            // 
            this.label49.AutoSize = true;
            this.label49.Location = new System.Drawing.Point(528, 45);
            this.label49.Name = "label49";
            this.label49.Size = new System.Drawing.Size(137, 17);
            this.label49.TabIndex = 13;
            this.label49.Text = "Crushed Cane(Qtls.)";
            // 
            // txtUncrushedCane
            // 
            this.txtUncrushedCane.Enabled = false;
            this.txtUncrushedCane.Location = new System.Drawing.Point(422, 42);
            this.txtUncrushedCane.Name = "txtUncrushedCane";
            this.txtUncrushedCane.ReadOnly = true;
            this.txtUncrushedCane.Size = new System.Drawing.Size(100, 22);
            this.txtUncrushedCane.TabIndex = 44;
            this.txtUncrushedCane.Text = "0";
            // 
            // label48
            // 
            this.label48.AutoSize = true;
            this.label48.Location = new System.Drawing.Point(267, 45);
            this.label48.Name = "label48";
            this.label48.Size = new System.Drawing.Size(149, 17);
            this.label48.TabIndex = 11;
            this.label48.Text = "Uncrushed Cane(Qtls)";
            // 
            // txtStandingCarts
            // 
            this.txtStandingCarts.Enabled = false;
            this.txtStandingCarts.Location = new System.Drawing.Point(161, 42);
            this.txtStandingCarts.Name = "txtStandingCarts";
            this.txtStandingCarts.Size = new System.Drawing.Size(100, 22);
            this.txtStandingCarts.TabIndex = 42;
            this.txtStandingCarts.Text = "0";
            // 
            // label47
            // 
            this.label47.AutoSize = true;
            this.label47.Location = new System.Drawing.Point(54, 45);
            this.label47.Name = "label47";
            this.label47.Size = new System.Drawing.Size(101, 17);
            this.label47.TabIndex = 9;
            this.label47.Text = "Standing Carts";
            // 
            // txtStandingTripplers
            // 
            this.txtStandingTripplers.Enabled = false;
            this.txtStandingTripplers.Location = new System.Drawing.Point(671, 15);
            this.txtStandingTripplers.Name = "txtStandingTripplers";
            this.txtStandingTripplers.Size = new System.Drawing.Size(100, 22);
            this.txtStandingTripplers.TabIndex = 45;
            this.txtStandingTripplers.Text = "0";
            // 
            // label46
            // 
            this.label46.AutoSize = true;
            this.label46.Location = new System.Drawing.Point(541, 18);
            this.label46.Name = "label46";
            this.label46.Size = new System.Drawing.Size(124, 17);
            this.label46.TabIndex = 7;
            this.label46.Text = "Standing Tripplers";
            // 
            // txtStandingTrolleys
            // 
            this.txtStandingTrolleys.Enabled = false;
            this.txtStandingTrolleys.Location = new System.Drawing.Point(422, 17);
            this.txtStandingTrolleys.Name = "txtStandingTrolleys";
            this.txtStandingTrolleys.Size = new System.Drawing.Size(100, 22);
            this.txtStandingTrolleys.TabIndex = 43;
            this.txtStandingTrolleys.Text = "0";
            // 
            // label39
            // 
            this.label39.AutoSize = true;
            this.label39.Location = new System.Drawing.Point(298, 20);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(118, 17);
            this.label39.TabIndex = 5;
            this.label39.Text = "Standing Trolleys";
            // 
            // txtStandingTrucks
            // 
            this.txtStandingTrucks.Enabled = false;
            this.txtStandingTrucks.Location = new System.Drawing.Point(161, 15);
            this.txtStandingTrucks.Name = "txtStandingTrucks";
            this.txtStandingTrucks.Size = new System.Drawing.Size(100, 22);
            this.txtStandingTrucks.TabIndex = 41;
            this.txtStandingTrucks.Text = "0";
            // 
            // label38
            // 
            this.label38.AutoSize = true;
            this.label38.Location = new System.Drawing.Point(40, 18);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(115, 17);
            this.label38.TabIndex = 3;
            this.label38.Text = "Statnding Trucks";
            // 
            // frm_bihourly_transactions
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1290, 715);
            this.Controls.Add(this.groupBoxCaneStatus);
            this.Controls.Add(this.groupBox17);
            this.Controls.Add(this.groupBox25);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Name = "frm_bihourly_transactions";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "Two Hourly Analysis";
            this.groupBox1.ResumeLayout(false);
            this.groupBox9.ResumeLayout(false);
            this.groupBox9.PerformLayout();
            this.groupBox10.ResumeLayout(false);
            this.groupBox10.PerformLayout();
            this.groupBox7.ResumeLayout(false);
            this.groupBox7.PerformLayout();
            this.groupBox8.ResumeLayout(false);
            this.groupBox8.PerformLayout();
            this.groupBox6.ResumeLayout(false);
            this.groupBox6.PerformLayout();
            this.groupBoxNmPurity.ResumeLayout(false);
            this.groupBoxNmPurity.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox11.ResumeLayout(false);
            this.groupBox11.PerformLayout();
            this.groupBox12.ResumeLayout(false);
            this.groupBox12.PerformLayout();
            this.groupBox13.ResumeLayout(false);
            this.groupBox13.PerformLayout();
            this.groupBox14.ResumeLayout(false);
            this.groupBox14.PerformLayout();
            this.groupBox15.ResumeLayout(false);
            this.groupBox15.PerformLayout();
            this.groupBox25.ResumeLayout(false);
            this.groupBoxBagasse.ResumeLayout(false);
            this.groupBoxBagasse_oldMill.ResumeLayout(false);
            this.groupBoxBagasse_oldMill.PerformLayout();
            this.groupBoxBagasseNewMill.ResumeLayout(false);
            this.groupBoxBagasseNewMill.PerformLayout();
            this.groupBox16.ResumeLayout(false);
            this.groupBoxPolPressCake.ResumeLayout(false);
            this.groupBoxPolPressCake.PerformLayout();
            this.groupBox17.ResumeLayout(false);
            this.groupBoxCaneStatus.ResumeLayout(false);
            this.groupBoxCaneStatus.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.TextBox txtTime;
        private System.Windows.Forms.Label lblDate;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.DateTimePicker dateTimeTranDate;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.GroupBox groupBox9;
        private System.Windows.Forms.TextBox txtOmLastJuicePol;
        private System.Windows.Forms.TextBox txtOmLastJuiceBrix;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.GroupBox groupBox10;
        private System.Windows.Forms.TextBox txtNmLastJuicePol;
        private System.Windows.Forms.TextBox txtNmLastJuiceBrix;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.GroupBox groupBox7;
        private System.Windows.Forms.TextBox txtOmMixedJuicePol;
        private System.Windows.Forms.TextBox txtOmMixedJuiceBrix;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.GroupBox groupBox8;
        private System.Windows.Forms.TextBox txtNmMixedJuicePol;
        private System.Windows.Forms.TextBox txtNmMixedJuiceBrix;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.GroupBox groupBox6;
        private System.Windows.Forms.TextBox txtOmPrimaryJuicePol;
        private System.Windows.Forms.TextBox txtOmPrimaryJuiceBrix;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.GroupBox groupBoxNmPurity;
        private System.Windows.Forms.TextBox txtNmPrimaryJuicePol;
        private System.Windows.Forms.TextBox txtNmPrimaryJuiceBrix;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.GroupBox groupBox11;
        private System.Windows.Forms.TextBox txtFinalMolassesPol;
        private System.Windows.Forms.TextBox txtFinalMolassesBrix;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.GroupBox groupBox12;
        private System.Windows.Forms.TextBox txtSulphuredSyrupPol;
        private System.Windows.Forms.TextBox txtSulphuredSyrupBrix;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.GroupBox groupBox13;
        private System.Windows.Forms.TextBox txtUnsulphuredSyrupPol;
        private System.Windows.Forms.TextBox txtUnsulphuredSyrupBrix;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.GroupBox groupBox14;
        private System.Windows.Forms.TextBox txtClearJuicePol;
        private System.Windows.Forms.TextBox txtClearJuiceBrix;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.GroupBox groupBox15;
        private System.Windows.Forms.TextBox txtOliverFilteredPol;
        private System.Windows.Forms.TextBox txtOliverFilteredBirx;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.GroupBox groupBox25;
        private System.Windows.Forms.Button btnModify;
        private System.Windows.Forms.Button btnNewRecord;
        private System.Windows.Forms.Button btnSave;
        private System.Windows.Forms.Button btnClear;
        private System.Windows.Forms.TextBox txtFinalMolassesTanks;
        private System.Windows.Forms.TextBox txtFinalMolassesTemp;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.TextBox txtSulphuredSyrupPh;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.TextBox txtUnsulphuredSyrupPh;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.TextBox txtClearJuicePh;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.TextBox txtOliverFilteredPh;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.GroupBox groupBoxBagasse;
        private System.Windows.Forms.GroupBox groupBoxBagasse_oldMill;
        private System.Windows.Forms.TextBox txtOmMoisture;
        private System.Windows.Forms.TextBox txtOmBagassPol;
        private System.Windows.Forms.Label label41;
        private System.Windows.Forms.Label label42;
        private System.Windows.Forms.GroupBox groupBoxBagasseNewMill;
        private System.Windows.Forms.TextBox txtBagassNmMoisture;
        private System.Windows.Forms.TextBox txtBagasseNmPol;
        private System.Windows.Forms.Label label44;
        private System.Windows.Forms.Label label45;
        private System.Windows.Forms.GroupBox groupBox16;
        private System.Windows.Forms.GroupBox groupBoxPolPressCake;
        private System.Windows.Forms.TextBox txtFilteMudSample2;
        private System.Windows.Forms.TextBox txtFilteMudSample1;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.TextBox txtFilteMudSample5;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.TextBox txtFilteMudSample4;
        private System.Windows.Forms.TextBox txtFilteMudSample3;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.TextBox txtFilteMudAverage;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.TextBox txtFilteMudComposite;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.TextBox txtFilteMudMoisture;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.GroupBox groupBox17;
        private System.Windows.Forms.GroupBox groupBoxCaneStatus;
        private System.Windows.Forms.TextBox txtCaneCrushed;
        private System.Windows.Forms.Label label49;
        private System.Windows.Forms.TextBox txtUncrushedCane;
        private System.Windows.Forms.Label label48;
        private System.Windows.Forms.TextBox txtStandingCarts;
        private System.Windows.Forms.Label label47;
        private System.Windows.Forms.TextBox txtStandingTripplers;
        private System.Windows.Forms.Label label46;
        private System.Windows.Forms.TextBox txtStandingTrolleys;
        private System.Windows.Forms.Label label39;
        private System.Windows.Forms.TextBox txtStandingTrucks;
        private System.Windows.Forms.Label label38;
        private System.Windows.Forms.TextBox txtOmLastJuicePurity;
        private System.Windows.Forms.Label label53;
        private System.Windows.Forms.TextBox txtNmLastJuicePurity;
        private System.Windows.Forms.Label label52;
        private System.Windows.Forms.TextBox txtOmMixedJuicePurity;
        private System.Windows.Forms.Label label51;
        private System.Windows.Forms.TextBox txtNmMixedJuicePurity;
        private System.Windows.Forms.Label label50;
        private System.Windows.Forms.TextBox txtOmPrimaryJuicePurity;
        private System.Windows.Forms.Label label43;
        private System.Windows.Forms.TextBox txtNmPrimaryJuicePurity;
        private System.Windows.Forms.Label label40;
        private System.Windows.Forms.TextBox txtSulphuredSyrupPurity;
        private System.Windows.Forms.Label label57;
        private System.Windows.Forms.TextBox txtUnsulphuredSyrupPurity;
        private System.Windows.Forms.Label label56;
        private System.Windows.Forms.TextBox txtClearJuicePurity;
        private System.Windows.Forms.Label label55;
        private System.Windows.Forms.TextBox txtOliverFilteredPurity;
        private System.Windows.Forms.Label label54;
        private System.Windows.Forms.TextBox txtFinalMolassesPurity;
        private System.Windows.Forms.Label label58;
    }
}