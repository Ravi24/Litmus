﻿namespace Litmus.forms.transactional_forms
{
    partial class frm_molasses
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.TabMolasses = new System.Windows.Forms.TabControl();
            this.tabPageMolAHeavy = new System.Windows.Forms.TabPage();
            this.groupBoxAHeavyMol = new System.Windows.Forms.GroupBox();
            this.txtMolAHeavy_transTime = new System.Windows.Forms.TextBox();
            this.txtMolAHeavyPurity = new System.Windows.Forms.TextBox();
            this.label54 = new System.Windows.Forms.Label();
            this.label50 = new System.Windows.Forms.Label();
            this.label51 = new System.Windows.Forms.Label();
            this.txtMolAHeavy_pol = new System.Windows.Forms.TextBox();
            this.txtMolAHeavy_TranDate = new System.Windows.Forms.DateTimePicker();
            this.label53 = new System.Windows.Forms.Label();
            this.txtMolAHeavy_brix = new System.Windows.Forms.TextBox();
            this.label52 = new System.Windows.Forms.Label();
            this.tabPageMolA1Heavy = new System.Windows.Forms.TabPage();
            this.groupBox13 = new System.Windows.Forms.GroupBox();
            this.txtMolA1Heavy_Purity = new System.Windows.Forms.TextBox();
            this.label55 = new System.Windows.Forms.Label();
            this.txtMolA1Heavy_pol = new System.Windows.Forms.TextBox();
            this.label56 = new System.Windows.Forms.Label();
            this.txtMolA1Heavy_brix = new System.Windows.Forms.TextBox();
            this.label57 = new System.Windows.Forms.Label();
            this.groupBox14 = new System.Windows.Forms.GroupBox();
            this.txtMolA1Heavy_transTime = new System.Windows.Forms.TextBox();
            this.label58 = new System.Windows.Forms.Label();
            this.label59 = new System.Windows.Forms.Label();
            this.txtMolA1Heavy_TransDate = new System.Windows.Forms.DateTimePicker();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.groupBox15 = new System.Windows.Forms.GroupBox();
            this.txtMolBHeavy_purity = new System.Windows.Forms.TextBox();
            this.label60 = new System.Windows.Forms.Label();
            this.txtMolBHeavy_pol = new System.Windows.Forms.TextBox();
            this.label61 = new System.Windows.Forms.Label();
            this.txtMolBHeavy_brix = new System.Windows.Forms.TextBox();
            this.label62 = new System.Windows.Forms.Label();
            this.groupBox16 = new System.Windows.Forms.GroupBox();
            this.txtMolBHeavy_transTime = new System.Windows.Forms.TextBox();
            this.label63 = new System.Windows.Forms.Label();
            this.label64 = new System.Windows.Forms.Label();
            this.txtMolBHeavy_trans_dateTime = new System.Windows.Forms.DateTimePicker();
            this.tabPage4 = new System.Windows.Forms.TabPage();
            this.groupBox17 = new System.Windows.Forms.GroupBox();
            this.txtMolC1Heavy_purity = new System.Windows.Forms.TextBox();
            this.label65 = new System.Windows.Forms.Label();
            this.txtMolC1Heavy_pol = new System.Windows.Forms.TextBox();
            this.label66 = new System.Windows.Forms.Label();
            this.txtMolC1Heavy_brix = new System.Windows.Forms.TextBox();
            this.label67 = new System.Windows.Forms.Label();
            this.groupBox18 = new System.Windows.Forms.GroupBox();
            this.txtMolC1Heavy_transTime = new System.Windows.Forms.TextBox();
            this.label68 = new System.Windows.Forms.Label();
            this.label69 = new System.Windows.Forms.Label();
            this.txtMolC1Heavy_transDate = new System.Windows.Forms.DateTimePicker();
            this.tabPage5 = new System.Windows.Forms.TabPage();
            this.groupBox19 = new System.Windows.Forms.GroupBox();
            this.txtMolALight_purity = new System.Windows.Forms.TextBox();
            this.label70 = new System.Windows.Forms.Label();
            this.txtMolALight_pol = new System.Windows.Forms.TextBox();
            this.label71 = new System.Windows.Forms.Label();
            this.txtMolALight_brix = new System.Windows.Forms.TextBox();
            this.label72 = new System.Windows.Forms.Label();
            this.groupBox20 = new System.Windows.Forms.GroupBox();
            this.txtMolALight_transTime = new System.Windows.Forms.TextBox();
            this.label73 = new System.Windows.Forms.Label();
            this.label74 = new System.Windows.Forms.Label();
            this.txtMolALight_transDate = new System.Windows.Forms.DateTimePicker();
            this.tabPage6 = new System.Windows.Forms.TabPage();
            this.groupBox21 = new System.Windows.Forms.GroupBox();
            this.txtMolCHeavy_purity = new System.Windows.Forms.TextBox();
            this.label75 = new System.Windows.Forms.Label();
            this.txtMolCHeavy_pol = new System.Windows.Forms.TextBox();
            this.label76 = new System.Windows.Forms.Label();
            this.txtMolCHeavy_brix = new System.Windows.Forms.TextBox();
            this.label77 = new System.Windows.Forms.Label();
            this.groupBox22 = new System.Windows.Forms.GroupBox();
            this.txtMolCHeavy_transTime = new System.Windows.Forms.TextBox();
            this.label78 = new System.Windows.Forms.Label();
            this.label79 = new System.Windows.Forms.Label();
            this.txtMolCHeavy_transDate = new System.Windows.Forms.DateTimePicker();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.txtMolCLight_purity = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.txtMolCLight_pol = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.txtMolCLight_brix = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.txtMolCLight_transTime = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.txtMolCLight_transDate = new System.Windows.Forms.DateTimePicker();
            this.button5 = new System.Windows.Forms.Button();
            this.btnNewRecord = new System.Windows.Forms.Button();
            this.btnSave = new System.Windows.Forms.Button();
            this.btnClear = new System.Windows.Forms.Button();
            this.TabMolasses.SuspendLayout();
            this.tabPageMolAHeavy.SuspendLayout();
            this.groupBoxAHeavyMol.SuspendLayout();
            this.tabPageMolA1Heavy.SuspendLayout();
            this.groupBox13.SuspendLayout();
            this.groupBox14.SuspendLayout();
            this.tabPage3.SuspendLayout();
            this.groupBox15.SuspendLayout();
            this.groupBox16.SuspendLayout();
            this.tabPage4.SuspendLayout();
            this.groupBox17.SuspendLayout();
            this.groupBox18.SuspendLayout();
            this.tabPage5.SuspendLayout();
            this.groupBox19.SuspendLayout();
            this.groupBox20.SuspendLayout();
            this.tabPage6.SuspendLayout();
            this.groupBox21.SuspendLayout();
            this.groupBox22.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.SuspendLayout();
            // 
            // TabMolasses
            // 
            this.TabMolasses.Controls.Add(this.tabPageMolAHeavy);
            this.TabMolasses.Controls.Add(this.tabPageMolA1Heavy);
            this.TabMolasses.Controls.Add(this.tabPage3);
            this.TabMolasses.Controls.Add(this.tabPage4);
            this.TabMolasses.Controls.Add(this.tabPage5);
            this.TabMolasses.Controls.Add(this.tabPage6);
            this.TabMolasses.Controls.Add(this.tabPage1);
            this.TabMolasses.Location = new System.Drawing.Point(12, 6);
            this.TabMolasses.Name = "TabMolasses";
            this.TabMolasses.SelectedIndex = 0;
            this.TabMolasses.Size = new System.Drawing.Size(907, 210);
            this.TabMolasses.TabIndex = 1;
            // 
            // tabPageMolAHeavy
            // 
            this.tabPageMolAHeavy.Controls.Add(this.groupBoxAHeavyMol);
            this.tabPageMolAHeavy.Location = new System.Drawing.Point(4, 25);
            this.tabPageMolAHeavy.Name = "tabPageMolAHeavy";
            this.tabPageMolAHeavy.Padding = new System.Windows.Forms.Padding(3);
            this.tabPageMolAHeavy.Size = new System.Drawing.Size(899, 181);
            this.tabPageMolAHeavy.TabIndex = 0;
            this.tabPageMolAHeavy.Text = "A-Heavy";
            this.tabPageMolAHeavy.UseVisualStyleBackColor = true;
            // 
            // groupBoxAHeavyMol
            // 
            this.groupBoxAHeavyMol.Controls.Add(this.txtMolAHeavy_transTime);
            this.groupBoxAHeavyMol.Controls.Add(this.txtMolAHeavyPurity);
            this.groupBoxAHeavyMol.Controls.Add(this.label54);
            this.groupBoxAHeavyMol.Controls.Add(this.label50);
            this.groupBoxAHeavyMol.Controls.Add(this.label51);
            this.groupBoxAHeavyMol.Controls.Add(this.txtMolAHeavy_pol);
            this.groupBoxAHeavyMol.Controls.Add(this.txtMolAHeavy_TranDate);
            this.groupBoxAHeavyMol.Controls.Add(this.label53);
            this.groupBoxAHeavyMol.Controls.Add(this.txtMolAHeavy_brix);
            this.groupBoxAHeavyMol.Controls.Add(this.label52);
            this.groupBoxAHeavyMol.Location = new System.Drawing.Point(8, 6);
            this.groupBoxAHeavyMol.Name = "groupBoxAHeavyMol";
            this.groupBoxAHeavyMol.Size = new System.Drawing.Size(883, 169);
            this.groupBoxAHeavyMol.TabIndex = 16;
            this.groupBoxAHeavyMol.TabStop = false;
            this.groupBoxAHeavyMol.Text = "A-Heavy Molasses";
            // 
            // txtMolAHeavy_transTime
            // 
            this.txtMolAHeavy_transTime.Location = new System.Drawing.Point(326, 43);
            this.txtMolAHeavy_transTime.Name = "txtMolAHeavy_transTime";
            this.txtMolAHeavy_transTime.Size = new System.Drawing.Size(100, 22);
            this.txtMolAHeavy_transTime.TabIndex = 1;
            // 
            // txtMolAHeavyPurity
            // 
            this.txtMolAHeavyPurity.Location = new System.Drawing.Point(509, 97);
            this.txtMolAHeavyPurity.Name = "txtMolAHeavyPurity";
            this.txtMolAHeavyPurity.ReadOnly = true;
            this.txtMolAHeavyPurity.Size = new System.Drawing.Size(100, 22);
            this.txtMolAHeavyPurity.TabIndex = 5;
            // 
            // label54
            // 
            this.label54.AutoSize = true;
            this.label54.Location = new System.Drawing.Point(447, 100);
            this.label54.Name = "label54";
            this.label54.Size = new System.Drawing.Size(44, 17);
            this.label54.TabIndex = 4;
            this.label54.Text = "Purity";
            // 
            // label50
            // 
            this.label50.AutoSize = true;
            this.label50.Location = new System.Drawing.Point(32, 44);
            this.label50.Name = "label50";
            this.label50.Size = new System.Drawing.Size(96, 17);
            this.label50.TabIndex = 7;
            this.label50.Text = "ENTRY DATE";
            // 
            // label51
            // 
            this.label51.AutoSize = true;
            this.label51.Location = new System.Drawing.Point(266, 46);
            this.label51.Name = "label51";
            this.label51.Size = new System.Drawing.Size(40, 17);
            this.label51.TabIndex = 6;
            this.label51.Text = "TIME";
            // 
            // txtMolAHeavy_pol
            // 
            this.txtMolAHeavy_pol.Location = new System.Drawing.Point(326, 97);
            this.txtMolAHeavy_pol.Name = "txtMolAHeavy_pol";
            this.txtMolAHeavy_pol.Size = new System.Drawing.Size(100, 22);
            this.txtMolAHeavy_pol.TabIndex = 3;
            this.txtMolAHeavy_pol.Text = "0";
            // 
            // txtMolAHeavy_TranDate
            // 
            this.txtMolAHeavy_TranDate.CustomFormat = "yyyy-MM-dd";
            this.txtMolAHeavy_TranDate.Enabled = false;
            this.txtMolAHeavy_TranDate.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.txtMolAHeavy_TranDate.Location = new System.Drawing.Point(144, 44);
            this.txtMolAHeavy_TranDate.Name = "txtMolAHeavy_TranDate";
            this.txtMolAHeavy_TranDate.Size = new System.Drawing.Size(100, 22);
            this.txtMolAHeavy_TranDate.TabIndex = 8;
            // 
            // label53
            // 
            this.label53.AutoSize = true;
            this.label53.Location = new System.Drawing.Point(266, 100);
            this.label53.Name = "label53";
            this.label53.Size = new System.Drawing.Size(40, 17);
            this.label53.TabIndex = 2;
            this.label53.Text = "Pol%";
            // 
            // txtMolAHeavy_brix
            // 
            this.txtMolAHeavy_brix.Location = new System.Drawing.Point(144, 97);
            this.txtMolAHeavy_brix.Name = "txtMolAHeavy_brix";
            this.txtMolAHeavy_brix.Size = new System.Drawing.Size(100, 22);
            this.txtMolAHeavy_brix.TabIndex = 1;
            this.txtMolAHeavy_brix.Text = "0";
            // 
            // label52
            // 
            this.label52.AutoSize = true;
            this.label52.Location = new System.Drawing.Point(85, 100);
            this.label52.Name = "label52";
            this.label52.Size = new System.Drawing.Size(43, 17);
            this.label52.TabIndex = 0;
            this.label52.Text = "Brix%";
            // 
            // tabPageMolA1Heavy
            // 
            this.tabPageMolA1Heavy.Controls.Add(this.groupBox13);
            this.tabPageMolA1Heavy.Controls.Add(this.groupBox14);
            this.tabPageMolA1Heavy.Location = new System.Drawing.Point(4, 25);
            this.tabPageMolA1Heavy.Name = "tabPageMolA1Heavy";
            this.tabPageMolA1Heavy.Padding = new System.Windows.Forms.Padding(3);
            this.tabPageMolA1Heavy.Size = new System.Drawing.Size(899, 181);
            this.tabPageMolA1Heavy.TabIndex = 1;
            this.tabPageMolA1Heavy.Text = "A1-Heavy";
            this.tabPageMolA1Heavy.UseVisualStyleBackColor = true;
            // 
            // groupBox13
            // 
            this.groupBox13.Controls.Add(this.txtMolA1Heavy_Purity);
            this.groupBox13.Controls.Add(this.label55);
            this.groupBox13.Controls.Add(this.txtMolA1Heavy_pol);
            this.groupBox13.Controls.Add(this.label56);
            this.groupBox13.Controls.Add(this.txtMolA1Heavy_brix);
            this.groupBox13.Controls.Add(this.label57);
            this.groupBox13.Location = new System.Drawing.Point(8, 87);
            this.groupBox13.Name = "groupBox13";
            this.groupBox13.Size = new System.Drawing.Size(883, 88);
            this.groupBox13.TabIndex = 18;
            this.groupBox13.TabStop = false;
            this.groupBox13.Text = "A1-Heavy Molasses";
            // 
            // txtMolA1Heavy_Purity
            // 
            this.txtMolA1Heavy_Purity.Location = new System.Drawing.Point(500, 41);
            this.txtMolA1Heavy_Purity.Name = "txtMolA1Heavy_Purity";
            this.txtMolA1Heavy_Purity.ReadOnly = true;
            this.txtMolA1Heavy_Purity.Size = new System.Drawing.Size(100, 22);
            this.txtMolA1Heavy_Purity.TabIndex = 5;
            // 
            // label55
            // 
            this.label55.AutoSize = true;
            this.label55.Location = new System.Drawing.Point(438, 44);
            this.label55.Name = "label55";
            this.label55.Size = new System.Drawing.Size(44, 17);
            this.label55.TabIndex = 4;
            this.label55.Text = "Purity";
            // 
            // txtMolA1Heavy_pol
            // 
            this.txtMolA1Heavy_pol.Location = new System.Drawing.Point(317, 41);
            this.txtMolA1Heavy_pol.Name = "txtMolA1Heavy_pol";
            this.txtMolA1Heavy_pol.Size = new System.Drawing.Size(100, 22);
            this.txtMolA1Heavy_pol.TabIndex = 3;
            this.txtMolA1Heavy_pol.Text = "0";
            // 
            // label56
            // 
            this.label56.AutoSize = true;
            this.label56.Location = new System.Drawing.Point(257, 44);
            this.label56.Name = "label56";
            this.label56.Size = new System.Drawing.Size(40, 17);
            this.label56.TabIndex = 2;
            this.label56.Text = "Pol%";
            // 
            // txtMolA1Heavy_brix
            // 
            this.txtMolA1Heavy_brix.Location = new System.Drawing.Point(135, 41);
            this.txtMolA1Heavy_brix.Name = "txtMolA1Heavy_brix";
            this.txtMolA1Heavy_brix.Size = new System.Drawing.Size(100, 22);
            this.txtMolA1Heavy_brix.TabIndex = 1;
            this.txtMolA1Heavy_brix.Text = "0";
            // 
            // label57
            // 
            this.label57.AutoSize = true;
            this.label57.Location = new System.Drawing.Point(76, 44);
            this.label57.Name = "label57";
            this.label57.Size = new System.Drawing.Size(43, 17);
            this.label57.TabIndex = 0;
            this.label57.Text = "Brix%";
            // 
            // groupBox14
            // 
            this.groupBox14.Controls.Add(this.txtMolA1Heavy_transTime);
            this.groupBox14.Controls.Add(this.label58);
            this.groupBox14.Controls.Add(this.label59);
            this.groupBox14.Controls.Add(this.txtMolA1Heavy_TransDate);
            this.groupBox14.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.groupBox14.Location = new System.Drawing.Point(8, 18);
            this.groupBox14.Name = "groupBox14";
            this.groupBox14.Size = new System.Drawing.Size(883, 46);
            this.groupBox14.TabIndex = 17;
            this.groupBox14.TabStop = false;
            // 
            // txtMolA1Heavy_transTime
            // 
            this.txtMolA1Heavy_transTime.Location = new System.Drawing.Point(311, 14);
            this.txtMolA1Heavy_transTime.Name = "txtMolA1Heavy_transTime";
            this.txtMolA1Heavy_transTime.Size = new System.Drawing.Size(100, 22);
            this.txtMolA1Heavy_transTime.TabIndex = 1;
            // 
            // label58
            // 
            this.label58.AutoSize = true;
            this.label58.Location = new System.Drawing.Point(23, 15);
            this.label58.Name = "label58";
            this.label58.Size = new System.Drawing.Size(96, 17);
            this.label58.TabIndex = 7;
            this.label58.Text = "ENTRY DATE";
            // 
            // label59
            // 
            this.label59.AutoSize = true;
            this.label59.Location = new System.Drawing.Point(257, 17);
            this.label59.Name = "label59";
            this.label59.Size = new System.Drawing.Size(40, 17);
            this.label59.TabIndex = 6;
            this.label59.Text = "TIME";
            // 
            // txtMolA1Heavy_TransDate
            // 
            this.txtMolA1Heavy_TransDate.CustomFormat = "yyyy-MM-dd";
            this.txtMolA1Heavy_TransDate.Enabled = false;
            this.txtMolA1Heavy_TransDate.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.txtMolA1Heavy_TransDate.Location = new System.Drawing.Point(135, 15);
            this.txtMolA1Heavy_TransDate.Name = "txtMolA1Heavy_TransDate";
            this.txtMolA1Heavy_TransDate.Size = new System.Drawing.Size(100, 22);
            this.txtMolA1Heavy_TransDate.TabIndex = 8;
            // 
            // tabPage3
            // 
            this.tabPage3.Controls.Add(this.groupBox15);
            this.tabPage3.Controls.Add(this.groupBox16);
            this.tabPage3.Location = new System.Drawing.Point(4, 25);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage3.Size = new System.Drawing.Size(899, 181);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "B-Heavy";
            this.tabPage3.UseVisualStyleBackColor = true;
            // 
            // groupBox15
            // 
            this.groupBox15.Controls.Add(this.txtMolBHeavy_purity);
            this.groupBox15.Controls.Add(this.label60);
            this.groupBox15.Controls.Add(this.txtMolBHeavy_pol);
            this.groupBox15.Controls.Add(this.label61);
            this.groupBox15.Controls.Add(this.txtMolBHeavy_brix);
            this.groupBox15.Controls.Add(this.label62);
            this.groupBox15.Location = new System.Drawing.Point(8, 87);
            this.groupBox15.Name = "groupBox15";
            this.groupBox15.Size = new System.Drawing.Size(883, 88);
            this.groupBox15.TabIndex = 18;
            this.groupBox15.TabStop = false;
            this.groupBox15.Text = "B-Heavy Molasses";
            // 
            // txtMolBHeavy_purity
            // 
            this.txtMolBHeavy_purity.Location = new System.Drawing.Point(500, 41);
            this.txtMolBHeavy_purity.Name = "txtMolBHeavy_purity";
            this.txtMolBHeavy_purity.ReadOnly = true;
            this.txtMolBHeavy_purity.Size = new System.Drawing.Size(100, 22);
            this.txtMolBHeavy_purity.TabIndex = 5;
            // 
            // label60
            // 
            this.label60.AutoSize = true;
            this.label60.Location = new System.Drawing.Point(438, 44);
            this.label60.Name = "label60";
            this.label60.Size = new System.Drawing.Size(44, 17);
            this.label60.TabIndex = 4;
            this.label60.Text = "Purity";
            // 
            // txtMolBHeavy_pol
            // 
            this.txtMolBHeavy_pol.Location = new System.Drawing.Point(317, 41);
            this.txtMolBHeavy_pol.Name = "txtMolBHeavy_pol";
            this.txtMolBHeavy_pol.Size = new System.Drawing.Size(100, 22);
            this.txtMolBHeavy_pol.TabIndex = 3;
            this.txtMolBHeavy_pol.Text = "0";
            // 
            // label61
            // 
            this.label61.AutoSize = true;
            this.label61.Location = new System.Drawing.Point(257, 44);
            this.label61.Name = "label61";
            this.label61.Size = new System.Drawing.Size(40, 17);
            this.label61.TabIndex = 2;
            this.label61.Text = "Pol%";
            // 
            // txtMolBHeavy_brix
            // 
            this.txtMolBHeavy_brix.Location = new System.Drawing.Point(135, 41);
            this.txtMolBHeavy_brix.Name = "txtMolBHeavy_brix";
            this.txtMolBHeavy_brix.Size = new System.Drawing.Size(100, 22);
            this.txtMolBHeavy_brix.TabIndex = 1;
            this.txtMolBHeavy_brix.Text = "0";
            // 
            // label62
            // 
            this.label62.AutoSize = true;
            this.label62.Location = new System.Drawing.Point(76, 44);
            this.label62.Name = "label62";
            this.label62.Size = new System.Drawing.Size(43, 17);
            this.label62.TabIndex = 0;
            this.label62.Text = "Brix%";
            // 
            // groupBox16
            // 
            this.groupBox16.Controls.Add(this.txtMolBHeavy_transTime);
            this.groupBox16.Controls.Add(this.label63);
            this.groupBox16.Controls.Add(this.label64);
            this.groupBox16.Controls.Add(this.txtMolBHeavy_trans_dateTime);
            this.groupBox16.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.groupBox16.Location = new System.Drawing.Point(8, 18);
            this.groupBox16.Name = "groupBox16";
            this.groupBox16.Size = new System.Drawing.Size(883, 46);
            this.groupBox16.TabIndex = 17;
            this.groupBox16.TabStop = false;
            // 
            // txtMolBHeavy_transTime
            // 
            this.txtMolBHeavy_transTime.Location = new System.Drawing.Point(311, 14);
            this.txtMolBHeavy_transTime.Name = "txtMolBHeavy_transTime";
            this.txtMolBHeavy_transTime.Size = new System.Drawing.Size(100, 22);
            this.txtMolBHeavy_transTime.TabIndex = 1;
            // 
            // label63
            // 
            this.label63.AutoSize = true;
            this.label63.Location = new System.Drawing.Point(23, 15);
            this.label63.Name = "label63";
            this.label63.Size = new System.Drawing.Size(96, 17);
            this.label63.TabIndex = 7;
            this.label63.Text = "ENTRY DATE";
            // 
            // label64
            // 
            this.label64.AutoSize = true;
            this.label64.Location = new System.Drawing.Point(257, 17);
            this.label64.Name = "label64";
            this.label64.Size = new System.Drawing.Size(40, 17);
            this.label64.TabIndex = 6;
            this.label64.Text = "TIME";
            // 
            // txtMolBHeavy_trans_dateTime
            // 
            this.txtMolBHeavy_trans_dateTime.CustomFormat = "yyyy-MM-dd";
            this.txtMolBHeavy_trans_dateTime.Enabled = false;
            this.txtMolBHeavy_trans_dateTime.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.txtMolBHeavy_trans_dateTime.Location = new System.Drawing.Point(135, 15);
            this.txtMolBHeavy_trans_dateTime.Name = "txtMolBHeavy_trans_dateTime";
            this.txtMolBHeavy_trans_dateTime.Size = new System.Drawing.Size(100, 22);
            this.txtMolBHeavy_trans_dateTime.TabIndex = 8;
            // 
            // tabPage4
            // 
            this.tabPage4.Controls.Add(this.groupBox17);
            this.tabPage4.Controls.Add(this.groupBox18);
            this.tabPage4.Location = new System.Drawing.Point(4, 25);
            this.tabPage4.Name = "tabPage4";
            this.tabPage4.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage4.Size = new System.Drawing.Size(899, 181);
            this.tabPage4.TabIndex = 3;
            this.tabPage4.Text = "C1-Heavy";
            this.tabPage4.UseVisualStyleBackColor = true;
            // 
            // groupBox17
            // 
            this.groupBox17.Controls.Add(this.txtMolC1Heavy_purity);
            this.groupBox17.Controls.Add(this.label65);
            this.groupBox17.Controls.Add(this.txtMolC1Heavy_pol);
            this.groupBox17.Controls.Add(this.label66);
            this.groupBox17.Controls.Add(this.txtMolC1Heavy_brix);
            this.groupBox17.Controls.Add(this.label67);
            this.groupBox17.Location = new System.Drawing.Point(8, 87);
            this.groupBox17.Name = "groupBox17";
            this.groupBox17.Size = new System.Drawing.Size(883, 88);
            this.groupBox17.TabIndex = 18;
            this.groupBox17.TabStop = false;
            this.groupBox17.Text = "C1-Heavy Molasses";
            // 
            // txtMolC1Heavy_purity
            // 
            this.txtMolC1Heavy_purity.Location = new System.Drawing.Point(500, 41);
            this.txtMolC1Heavy_purity.Name = "txtMolC1Heavy_purity";
            this.txtMolC1Heavy_purity.ReadOnly = true;
            this.txtMolC1Heavy_purity.Size = new System.Drawing.Size(100, 22);
            this.txtMolC1Heavy_purity.TabIndex = 5;
            // 
            // label65
            // 
            this.label65.AutoSize = true;
            this.label65.Location = new System.Drawing.Point(438, 44);
            this.label65.Name = "label65";
            this.label65.Size = new System.Drawing.Size(44, 17);
            this.label65.TabIndex = 4;
            this.label65.Text = "Purity";
            // 
            // txtMolC1Heavy_pol
            // 
            this.txtMolC1Heavy_pol.Location = new System.Drawing.Point(317, 41);
            this.txtMolC1Heavy_pol.Name = "txtMolC1Heavy_pol";
            this.txtMolC1Heavy_pol.Size = new System.Drawing.Size(100, 22);
            this.txtMolC1Heavy_pol.TabIndex = 3;
            this.txtMolC1Heavy_pol.Text = "0";
            // 
            // label66
            // 
            this.label66.AutoSize = true;
            this.label66.Location = new System.Drawing.Point(257, 44);
            this.label66.Name = "label66";
            this.label66.Size = new System.Drawing.Size(40, 17);
            this.label66.TabIndex = 2;
            this.label66.Text = "Pol%";
            // 
            // txtMolC1Heavy_brix
            // 
            this.txtMolC1Heavy_brix.Location = new System.Drawing.Point(135, 41);
            this.txtMolC1Heavy_brix.Name = "txtMolC1Heavy_brix";
            this.txtMolC1Heavy_brix.Size = new System.Drawing.Size(100, 22);
            this.txtMolC1Heavy_brix.TabIndex = 1;
            this.txtMolC1Heavy_brix.Text = "0";
            // 
            // label67
            // 
            this.label67.AutoSize = true;
            this.label67.Location = new System.Drawing.Point(76, 44);
            this.label67.Name = "label67";
            this.label67.Size = new System.Drawing.Size(43, 17);
            this.label67.TabIndex = 0;
            this.label67.Text = "Brix%";
            // 
            // groupBox18
            // 
            this.groupBox18.Controls.Add(this.txtMolC1Heavy_transTime);
            this.groupBox18.Controls.Add(this.label68);
            this.groupBox18.Controls.Add(this.label69);
            this.groupBox18.Controls.Add(this.txtMolC1Heavy_transDate);
            this.groupBox18.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.groupBox18.Location = new System.Drawing.Point(8, 18);
            this.groupBox18.Name = "groupBox18";
            this.groupBox18.Size = new System.Drawing.Size(883, 46);
            this.groupBox18.TabIndex = 17;
            this.groupBox18.TabStop = false;
            // 
            // txtMolC1Heavy_transTime
            // 
            this.txtMolC1Heavy_transTime.Location = new System.Drawing.Point(311, 14);
            this.txtMolC1Heavy_transTime.Name = "txtMolC1Heavy_transTime";
            this.txtMolC1Heavy_transTime.Size = new System.Drawing.Size(100, 22);
            this.txtMolC1Heavy_transTime.TabIndex = 1;
            // 
            // label68
            // 
            this.label68.AutoSize = true;
            this.label68.Location = new System.Drawing.Point(23, 15);
            this.label68.Name = "label68";
            this.label68.Size = new System.Drawing.Size(96, 17);
            this.label68.TabIndex = 7;
            this.label68.Text = "ENTRY DATE";
            // 
            // label69
            // 
            this.label69.AutoSize = true;
            this.label69.Location = new System.Drawing.Point(257, 17);
            this.label69.Name = "label69";
            this.label69.Size = new System.Drawing.Size(40, 17);
            this.label69.TabIndex = 6;
            this.label69.Text = "TIME";
            // 
            // txtMolC1Heavy_transDate
            // 
            this.txtMolC1Heavy_transDate.CustomFormat = "yyyy-MM-dd";
            this.txtMolC1Heavy_transDate.Enabled = false;
            this.txtMolC1Heavy_transDate.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.txtMolC1Heavy_transDate.Location = new System.Drawing.Point(135, 15);
            this.txtMolC1Heavy_transDate.Name = "txtMolC1Heavy_transDate";
            this.txtMolC1Heavy_transDate.Size = new System.Drawing.Size(100, 22);
            this.txtMolC1Heavy_transDate.TabIndex = 8;
            // 
            // tabPage5
            // 
            this.tabPage5.Controls.Add(this.groupBox19);
            this.tabPage5.Controls.Add(this.groupBox20);
            this.tabPage5.Location = new System.Drawing.Point(4, 25);
            this.tabPage5.Name = "tabPage5";
            this.tabPage5.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage5.Size = new System.Drawing.Size(899, 181);
            this.tabPage5.TabIndex = 4;
            this.tabPage5.Text = "A-Light";
            this.tabPage5.UseVisualStyleBackColor = true;
            // 
            // groupBox19
            // 
            this.groupBox19.Controls.Add(this.txtMolALight_purity);
            this.groupBox19.Controls.Add(this.label70);
            this.groupBox19.Controls.Add(this.txtMolALight_pol);
            this.groupBox19.Controls.Add(this.label71);
            this.groupBox19.Controls.Add(this.txtMolALight_brix);
            this.groupBox19.Controls.Add(this.label72);
            this.groupBox19.Location = new System.Drawing.Point(8, 87);
            this.groupBox19.Name = "groupBox19";
            this.groupBox19.Size = new System.Drawing.Size(883, 88);
            this.groupBox19.TabIndex = 18;
            this.groupBox19.TabStop = false;
            this.groupBox19.Text = "A-Light Molasses";
            // 
            // txtMolALight_purity
            // 
            this.txtMolALight_purity.Location = new System.Drawing.Point(500, 41);
            this.txtMolALight_purity.Name = "txtMolALight_purity";
            this.txtMolALight_purity.ReadOnly = true;
            this.txtMolALight_purity.Size = new System.Drawing.Size(100, 22);
            this.txtMolALight_purity.TabIndex = 5;
            // 
            // label70
            // 
            this.label70.AutoSize = true;
            this.label70.Location = new System.Drawing.Point(438, 44);
            this.label70.Name = "label70";
            this.label70.Size = new System.Drawing.Size(44, 17);
            this.label70.TabIndex = 4;
            this.label70.Text = "Purity";
            // 
            // txtMolALight_pol
            // 
            this.txtMolALight_pol.Location = new System.Drawing.Point(317, 41);
            this.txtMolALight_pol.Name = "txtMolALight_pol";
            this.txtMolALight_pol.Size = new System.Drawing.Size(100, 22);
            this.txtMolALight_pol.TabIndex = 3;
            this.txtMolALight_pol.Text = "0";
            // 
            // label71
            // 
            this.label71.AutoSize = true;
            this.label71.Location = new System.Drawing.Point(257, 44);
            this.label71.Name = "label71";
            this.label71.Size = new System.Drawing.Size(40, 17);
            this.label71.TabIndex = 2;
            this.label71.Text = "Pol%";
            // 
            // txtMolALight_brix
            // 
            this.txtMolALight_brix.Location = new System.Drawing.Point(135, 41);
            this.txtMolALight_brix.Name = "txtMolALight_brix";
            this.txtMolALight_brix.Size = new System.Drawing.Size(100, 22);
            this.txtMolALight_brix.TabIndex = 1;
            this.txtMolALight_brix.Text = "0";
            // 
            // label72
            // 
            this.label72.AutoSize = true;
            this.label72.Location = new System.Drawing.Point(76, 44);
            this.label72.Name = "label72";
            this.label72.Size = new System.Drawing.Size(43, 17);
            this.label72.TabIndex = 0;
            this.label72.Text = "Brix%";
            // 
            // groupBox20
            // 
            this.groupBox20.Controls.Add(this.txtMolALight_transTime);
            this.groupBox20.Controls.Add(this.label73);
            this.groupBox20.Controls.Add(this.label74);
            this.groupBox20.Controls.Add(this.txtMolALight_transDate);
            this.groupBox20.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.groupBox20.Location = new System.Drawing.Point(8, 18);
            this.groupBox20.Name = "groupBox20";
            this.groupBox20.Size = new System.Drawing.Size(883, 46);
            this.groupBox20.TabIndex = 17;
            this.groupBox20.TabStop = false;
            // 
            // txtMolALight_transTime
            // 
            this.txtMolALight_transTime.Location = new System.Drawing.Point(311, 14);
            this.txtMolALight_transTime.Name = "txtMolALight_transTime";
            this.txtMolALight_transTime.Size = new System.Drawing.Size(100, 22);
            this.txtMolALight_transTime.TabIndex = 1;
            // 
            // label73
            // 
            this.label73.AutoSize = true;
            this.label73.Location = new System.Drawing.Point(23, 15);
            this.label73.Name = "label73";
            this.label73.Size = new System.Drawing.Size(96, 17);
            this.label73.TabIndex = 7;
            this.label73.Text = "ENTRY DATE";
            // 
            // label74
            // 
            this.label74.AutoSize = true;
            this.label74.Location = new System.Drawing.Point(257, 17);
            this.label74.Name = "label74";
            this.label74.Size = new System.Drawing.Size(40, 17);
            this.label74.TabIndex = 6;
            this.label74.Text = "TIME";
            // 
            // txtMolALight_transDate
            // 
            this.txtMolALight_transDate.CustomFormat = "yyyy-MM-dd";
            this.txtMolALight_transDate.Enabled = false;
            this.txtMolALight_transDate.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.txtMolALight_transDate.Location = new System.Drawing.Point(135, 15);
            this.txtMolALight_transDate.Name = "txtMolALight_transDate";
            this.txtMolALight_transDate.Size = new System.Drawing.Size(100, 22);
            this.txtMolALight_transDate.TabIndex = 8;
            // 
            // tabPage6
            // 
            this.tabPage6.Controls.Add(this.groupBox21);
            this.tabPage6.Controls.Add(this.groupBox22);
            this.tabPage6.Location = new System.Drawing.Point(4, 25);
            this.tabPage6.Name = "tabPage6";
            this.tabPage6.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage6.Size = new System.Drawing.Size(899, 181);
            this.tabPage6.TabIndex = 5;
            this.tabPage6.Text = "C-Heavy";
            this.tabPage6.UseVisualStyleBackColor = true;
            // 
            // groupBox21
            // 
            this.groupBox21.Controls.Add(this.txtMolCHeavy_purity);
            this.groupBox21.Controls.Add(this.label75);
            this.groupBox21.Controls.Add(this.txtMolCHeavy_pol);
            this.groupBox21.Controls.Add(this.label76);
            this.groupBox21.Controls.Add(this.txtMolCHeavy_brix);
            this.groupBox21.Controls.Add(this.label77);
            this.groupBox21.Location = new System.Drawing.Point(8, 87);
            this.groupBox21.Name = "groupBox21";
            this.groupBox21.Size = new System.Drawing.Size(883, 88);
            this.groupBox21.TabIndex = 18;
            this.groupBox21.TabStop = false;
            this.groupBox21.Text = "C-Heavy Molasses";
            // 
            // txtMolCHeavy_purity
            // 
            this.txtMolCHeavy_purity.Location = new System.Drawing.Point(500, 41);
            this.txtMolCHeavy_purity.Name = "txtMolCHeavy_purity";
            this.txtMolCHeavy_purity.ReadOnly = true;
            this.txtMolCHeavy_purity.Size = new System.Drawing.Size(100, 22);
            this.txtMolCHeavy_purity.TabIndex = 5;
            // 
            // label75
            // 
            this.label75.AutoSize = true;
            this.label75.Location = new System.Drawing.Point(438, 44);
            this.label75.Name = "label75";
            this.label75.Size = new System.Drawing.Size(44, 17);
            this.label75.TabIndex = 4;
            this.label75.Text = "Purity";
            // 
            // txtMolCHeavy_pol
            // 
            this.txtMolCHeavy_pol.Location = new System.Drawing.Point(317, 41);
            this.txtMolCHeavy_pol.Name = "txtMolCHeavy_pol";
            this.txtMolCHeavy_pol.Size = new System.Drawing.Size(100, 22);
            this.txtMolCHeavy_pol.TabIndex = 3;
            this.txtMolCHeavy_pol.Text = "0";
            // 
            // label76
            // 
            this.label76.AutoSize = true;
            this.label76.Location = new System.Drawing.Point(257, 44);
            this.label76.Name = "label76";
            this.label76.Size = new System.Drawing.Size(40, 17);
            this.label76.TabIndex = 2;
            this.label76.Text = "Pol%";
            // 
            // txtMolCHeavy_brix
            // 
            this.txtMolCHeavy_brix.Location = new System.Drawing.Point(135, 41);
            this.txtMolCHeavy_brix.Name = "txtMolCHeavy_brix";
            this.txtMolCHeavy_brix.Size = new System.Drawing.Size(100, 22);
            this.txtMolCHeavy_brix.TabIndex = 1;
            this.txtMolCHeavy_brix.Text = "0";
            // 
            // label77
            // 
            this.label77.AutoSize = true;
            this.label77.Location = new System.Drawing.Point(76, 44);
            this.label77.Name = "label77";
            this.label77.Size = new System.Drawing.Size(43, 17);
            this.label77.TabIndex = 0;
            this.label77.Text = "Brix%";
            // 
            // groupBox22
            // 
            this.groupBox22.Controls.Add(this.txtMolCHeavy_transTime);
            this.groupBox22.Controls.Add(this.label78);
            this.groupBox22.Controls.Add(this.label79);
            this.groupBox22.Controls.Add(this.txtMolCHeavy_transDate);
            this.groupBox22.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.groupBox22.Location = new System.Drawing.Point(8, 17);
            this.groupBox22.Name = "groupBox22";
            this.groupBox22.Size = new System.Drawing.Size(883, 46);
            this.groupBox22.TabIndex = 17;
            this.groupBox22.TabStop = false;
            // 
            // txtMolCHeavy_transTime
            // 
            this.txtMolCHeavy_transTime.Location = new System.Drawing.Point(311, 14);
            this.txtMolCHeavy_transTime.Name = "txtMolCHeavy_transTime";
            this.txtMolCHeavy_transTime.Size = new System.Drawing.Size(100, 22);
            this.txtMolCHeavy_transTime.TabIndex = 1;
            // 
            // label78
            // 
            this.label78.AutoSize = true;
            this.label78.Location = new System.Drawing.Point(23, 15);
            this.label78.Name = "label78";
            this.label78.Size = new System.Drawing.Size(96, 17);
            this.label78.TabIndex = 7;
            this.label78.Text = "ENTRY DATE";
            // 
            // label79
            // 
            this.label79.AutoSize = true;
            this.label79.Location = new System.Drawing.Point(257, 17);
            this.label79.Name = "label79";
            this.label79.Size = new System.Drawing.Size(40, 17);
            this.label79.TabIndex = 6;
            this.label79.Text = "TIME";
            // 
            // txtMolCHeavy_transDate
            // 
            this.txtMolCHeavy_transDate.CustomFormat = "yyyy-MM-dd";
            this.txtMolCHeavy_transDate.Enabled = false;
            this.txtMolCHeavy_transDate.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.txtMolCHeavy_transDate.Location = new System.Drawing.Point(135, 15);
            this.txtMolCHeavy_transDate.Name = "txtMolCHeavy_transDate";
            this.txtMolCHeavy_transDate.Size = new System.Drawing.Size(100, 22);
            this.txtMolCHeavy_transDate.TabIndex = 8;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.groupBox1);
            this.tabPage1.Controls.Add(this.groupBox2);
            this.tabPage1.Location = new System.Drawing.Point(4, 25);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(899, 181);
            this.tabPage1.TabIndex = 6;
            this.tabPage1.Text = "C-Light";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.txtMolCLight_purity);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.txtMolCLight_pol);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.txtMolCLight_brix);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Location = new System.Drawing.Point(8, 87);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(883, 88);
            this.groupBox1.TabIndex = 20;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "C-Heavy Molasses";
            // 
            // txtMolCLight_purity
            // 
            this.txtMolCLight_purity.Location = new System.Drawing.Point(500, 41);
            this.txtMolCLight_purity.Name = "txtMolCLight_purity";
            this.txtMolCLight_purity.ReadOnly = true;
            this.txtMolCLight_purity.Size = new System.Drawing.Size(100, 22);
            this.txtMolCLight_purity.TabIndex = 5;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(438, 44);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(44, 17);
            this.label1.TabIndex = 4;
            this.label1.Text = "Purity";
            // 
            // txtMolCLight_pol
            // 
            this.txtMolCLight_pol.Location = new System.Drawing.Point(317, 41);
            this.txtMolCLight_pol.Name = "txtMolCLight_pol";
            this.txtMolCLight_pol.Size = new System.Drawing.Size(100, 22);
            this.txtMolCLight_pol.TabIndex = 3;
            this.txtMolCLight_pol.Text = "0";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(257, 44);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(40, 17);
            this.label2.TabIndex = 2;
            this.label2.Text = "Pol%";
            // 
            // txtMolCLight_brix
            // 
            this.txtMolCLight_brix.Location = new System.Drawing.Point(135, 41);
            this.txtMolCLight_brix.Name = "txtMolCLight_brix";
            this.txtMolCLight_brix.Size = new System.Drawing.Size(100, 22);
            this.txtMolCLight_brix.TabIndex = 1;
            this.txtMolCLight_brix.Text = "0";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(76, 44);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(43, 17);
            this.label3.TabIndex = 0;
            this.label3.Text = "Brix%";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.txtMolCLight_transTime);
            this.groupBox2.Controls.Add(this.label4);
            this.groupBox2.Controls.Add(this.label5);
            this.groupBox2.Controls.Add(this.txtMolCLight_transDate);
            this.groupBox2.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.groupBox2.Location = new System.Drawing.Point(8, 17);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(883, 46);
            this.groupBox2.TabIndex = 19;
            this.groupBox2.TabStop = false;
            // 
            // txtMolCLight_transTime
            // 
            this.txtMolCLight_transTime.Location = new System.Drawing.Point(311, 14);
            this.txtMolCLight_transTime.Name = "txtMolCLight_transTime";
            this.txtMolCLight_transTime.Size = new System.Drawing.Size(100, 22);
            this.txtMolCLight_transTime.TabIndex = 1;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(23, 15);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(96, 17);
            this.label4.TabIndex = 7;
            this.label4.Text = "ENTRY DATE";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(257, 17);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(40, 17);
            this.label5.TabIndex = 6;
            this.label5.Text = "TIME";
            // 
            // txtMolCLight_transDate
            // 
            this.txtMolCLight_transDate.CustomFormat = "yyyy-MM-dd";
            this.txtMolCLight_transDate.Enabled = false;
            this.txtMolCLight_transDate.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.txtMolCLight_transDate.Location = new System.Drawing.Point(135, 15);
            this.txtMolCLight_transDate.Name = "txtMolCLight_transDate";
            this.txtMolCLight_transDate.Size = new System.Drawing.Size(100, 22);
            this.txtMolCLight_transDate.TabIndex = 8;
            // 
            // button5
            // 
            this.button5.Enabled = false;
            this.button5.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.button5.Location = new System.Drawing.Point(696, 220);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(105, 31);
            this.button5.TabIndex = 29;
            this.button5.Text = "MODIFY";
            this.button5.UseVisualStyleBackColor = true;
            // 
            // btnNewRecord
            // 
            this.btnNewRecord.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnNewRecord.Location = new System.Drawing.Point(474, 220);
            this.btnNewRecord.Name = "btnNewRecord";
            this.btnNewRecord.Size = new System.Drawing.Size(105, 31);
            this.btnNewRecord.TabIndex = 13;
            this.btnNewRecord.Text = "&New Record";
            this.btnNewRecord.UseVisualStyleBackColor = true;
            this.btnNewRecord.Click += new System.EventHandler(this.btnNewRecord_Click);
            // 
            // btnSave
            // 
            this.btnSave.Enabled = false;
            this.btnSave.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnSave.Location = new System.Drawing.Point(585, 220);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(105, 31);
            this.btnSave.TabIndex = 12;
            this.btnSave.Text = "&Save";
            this.btnSave.UseVisualStyleBackColor = true;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // btnClear
            // 
            this.btnClear.Enabled = false;
            this.btnClear.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnClear.Location = new System.Drawing.Point(807, 220);
            this.btnClear.Name = "btnClear";
            this.btnClear.Size = new System.Drawing.Size(105, 31);
            this.btnClear.TabIndex = 14;
            this.btnClear.Text = "&Clear";
            this.btnClear.UseVisualStyleBackColor = true;
            this.btnClear.Click += new System.EventHandler(this.btnClear_Click);
            // 
            // frm_molasses
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(923, 257);
            this.Controls.Add(this.button5);
            this.Controls.Add(this.btnNewRecord);
            this.Controls.Add(this.btnSave);
            this.Controls.Add(this.btnClear);
            this.Controls.Add(this.TabMolasses);
            this.Name = "frm_molasses";
            this.Text = "Molasses Analysis";
            this.TabMolasses.ResumeLayout(false);
            this.tabPageMolAHeavy.ResumeLayout(false);
            this.groupBoxAHeavyMol.ResumeLayout(false);
            this.groupBoxAHeavyMol.PerformLayout();
            this.tabPageMolA1Heavy.ResumeLayout(false);
            this.groupBox13.ResumeLayout(false);
            this.groupBox13.PerformLayout();
            this.groupBox14.ResumeLayout(false);
            this.groupBox14.PerformLayout();
            this.tabPage3.ResumeLayout(false);
            this.groupBox15.ResumeLayout(false);
            this.groupBox15.PerformLayout();
            this.groupBox16.ResumeLayout(false);
            this.groupBox16.PerformLayout();
            this.tabPage4.ResumeLayout(false);
            this.groupBox17.ResumeLayout(false);
            this.groupBox17.PerformLayout();
            this.groupBox18.ResumeLayout(false);
            this.groupBox18.PerformLayout();
            this.tabPage5.ResumeLayout(false);
            this.groupBox19.ResumeLayout(false);
            this.groupBox19.PerformLayout();
            this.groupBox20.ResumeLayout(false);
            this.groupBox20.PerformLayout();
            this.tabPage6.ResumeLayout(false);
            this.groupBox21.ResumeLayout(false);
            this.groupBox21.PerformLayout();
            this.groupBox22.ResumeLayout(false);
            this.groupBox22.PerformLayout();
            this.tabPage1.ResumeLayout(false);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl TabMolasses;
        private System.Windows.Forms.TabPage tabPageMolAHeavy;
        private System.Windows.Forms.GroupBox groupBoxAHeavyMol;
        private System.Windows.Forms.TextBox txtMolAHeavyPurity;
        private System.Windows.Forms.Label label54;
        private System.Windows.Forms.TextBox txtMolAHeavy_pol;
        private System.Windows.Forms.Label label53;
        private System.Windows.Forms.TextBox txtMolAHeavy_brix;
        private System.Windows.Forms.Label label52;
        private System.Windows.Forms.TextBox txtMolAHeavy_transTime;
        private System.Windows.Forms.Label label50;
        private System.Windows.Forms.Label label51;
        private System.Windows.Forms.DateTimePicker txtMolAHeavy_TranDate;
        private System.Windows.Forms.TabPage tabPageMolA1Heavy;
        private System.Windows.Forms.GroupBox groupBox13;
        private System.Windows.Forms.TextBox txtMolA1Heavy_Purity;
        private System.Windows.Forms.Label label55;
        private System.Windows.Forms.TextBox txtMolA1Heavy_pol;
        private System.Windows.Forms.Label label56;
        private System.Windows.Forms.TextBox txtMolA1Heavy_brix;
        private System.Windows.Forms.Label label57;
        private System.Windows.Forms.GroupBox groupBox14;
        private System.Windows.Forms.TextBox txtMolA1Heavy_transTime;
        private System.Windows.Forms.Label label58;
        private System.Windows.Forms.Label label59;
        private System.Windows.Forms.DateTimePicker txtMolA1Heavy_TransDate;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.GroupBox groupBox15;
        private System.Windows.Forms.TextBox txtMolBHeavy_purity;
        private System.Windows.Forms.Label label60;
        private System.Windows.Forms.TextBox txtMolBHeavy_pol;
        private System.Windows.Forms.Label label61;
        private System.Windows.Forms.TextBox txtMolBHeavy_brix;
        private System.Windows.Forms.Label label62;
        private System.Windows.Forms.GroupBox groupBox16;
        private System.Windows.Forms.TextBox txtMolBHeavy_transTime;
        private System.Windows.Forms.Label label63;
        private System.Windows.Forms.Label label64;
        private System.Windows.Forms.DateTimePicker txtMolBHeavy_trans_dateTime;
        private System.Windows.Forms.TabPage tabPage4;
        private System.Windows.Forms.GroupBox groupBox17;
        private System.Windows.Forms.TextBox txtMolC1Heavy_purity;
        private System.Windows.Forms.Label label65;
        private System.Windows.Forms.TextBox txtMolC1Heavy_pol;
        private System.Windows.Forms.Label label66;
        private System.Windows.Forms.TextBox txtMolC1Heavy_brix;
        private System.Windows.Forms.Label label67;
        private System.Windows.Forms.GroupBox groupBox18;
        private System.Windows.Forms.TextBox txtMolC1Heavy_transTime;
        private System.Windows.Forms.Label label68;
        private System.Windows.Forms.Label label69;
        private System.Windows.Forms.DateTimePicker txtMolC1Heavy_transDate;
        private System.Windows.Forms.TabPage tabPage5;
        private System.Windows.Forms.GroupBox groupBox19;
        private System.Windows.Forms.TextBox txtMolALight_purity;
        private System.Windows.Forms.Label label70;
        private System.Windows.Forms.TextBox txtMolALight_pol;
        private System.Windows.Forms.Label label71;
        private System.Windows.Forms.TextBox txtMolALight_brix;
        private System.Windows.Forms.Label label72;
        private System.Windows.Forms.GroupBox groupBox20;
        private System.Windows.Forms.TextBox txtMolALight_transTime;
        private System.Windows.Forms.Label label73;
        private System.Windows.Forms.Label label74;
        private System.Windows.Forms.DateTimePicker txtMolALight_transDate;
        private System.Windows.Forms.TabPage tabPage6;
        private System.Windows.Forms.GroupBox groupBox21;
        private System.Windows.Forms.TextBox txtMolCHeavy_purity;
        private System.Windows.Forms.Label label75;
        private System.Windows.Forms.TextBox txtMolCHeavy_pol;
        private System.Windows.Forms.Label label76;
        private System.Windows.Forms.TextBox txtMolCHeavy_brix;
        private System.Windows.Forms.Label label77;
        private System.Windows.Forms.GroupBox groupBox22;
        private System.Windows.Forms.TextBox txtMolCHeavy_transTime;
        private System.Windows.Forms.Label label78;
        private System.Windows.Forms.Label label79;
        private System.Windows.Forms.DateTimePicker txtMolCHeavy_transDate;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Button btnNewRecord;
        private System.Windows.Forms.Button btnSave;
        private System.Windows.Forms.Button btnClear;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TextBox txtMolCLight_purity;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtMolCLight_pol;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtMolCLight_brix;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.TextBox txtMolCLight_transTime;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.DateTimePicker txtMolCLight_transDate;
    }
}