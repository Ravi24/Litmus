﻿namespace Litmus.forms.transactional_forms
{
    partial class frm_massecuite_transactions
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtMassA_Pol = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.txtMassA_Purity = new System.Windows.Forms.TextBox();
            this.groupBoxAMassecuite = new System.Windows.Forms.GroupBox();
            this.txtMassA_Brix = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.txtMassA_CrystNo = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.txtMassA_DropTime = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.txtMassA_StartTime = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.txtMassA_PanNo = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.txtMassA_HL = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.TabChild = new System.Windows.Forms.TabControl();
            this.tabMassecuiteA = new System.Windows.Forms.TabPage();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.txtMassA_Tans_Time = new System.Windows.Forms.TextBox();
            this.lblDate = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.txtMassA_dateTimeTranDate = new System.Windows.Forms.DateTimePicker();
            this.tabMassecuiteA1 = new System.Windows.Forms.TabPage();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.txtMassA1_Tans_Time = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.txtMassA1_dateTimeTranDate = new System.Windows.Forms.DateTimePicker();
            this.groupBoxA1Massecuite = new System.Windows.Forms.GroupBox();
            this.txtMassA1_Brix = new System.Windows.Forms.TextBox();
            this.txtMassA1_Purity = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.txtMassA1_CrystNo = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.txtMassA1_DropTime = new System.Windows.Forms.TextBox();
            this.txtMassA1_Pol = new System.Windows.Forms.TextBox();
            this.label16 = new System.Windows.Forms.Label();
            this.txtMassA1_StartTime = new System.Windows.Forms.TextBox();
            this.label17 = new System.Windows.Forms.Label();
            this.txtMassA1_PanNo = new System.Windows.Forms.TextBox();
            this.label18 = new System.Windows.Forms.Label();
            this.txtMassA1_HL = new System.Windows.Forms.TextBox();
            this.label19 = new System.Windows.Forms.Label();
            this.tabMassecuiteB = new System.Windows.Forms.TabPage();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.txtMassB_Tans_Time = new System.Windows.Forms.TextBox();
            this.label20 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.txtMassB_dateTimeTranDate = new System.Windows.Forms.DateTimePicker();
            this.groupBoxBMassecuite = new System.Windows.Forms.GroupBox();
            this.txtMassB_Brix = new System.Windows.Forms.TextBox();
            this.txtMassB_Purity = new System.Windows.Forms.TextBox();
            this.label22 = new System.Windows.Forms.Label();
            this.txtMassB_CrystNo = new System.Windows.Forms.TextBox();
            this.label23 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.txtMassB_DropTime = new System.Windows.Forms.TextBox();
            this.txtMassB_Pol = new System.Windows.Forms.TextBox();
            this.label26 = new System.Windows.Forms.Label();
            this.txtMassB_StartTime = new System.Windows.Forms.TextBox();
            this.label27 = new System.Windows.Forms.Label();
            this.txtMassB_PanNo = new System.Windows.Forms.TextBox();
            this.label28 = new System.Windows.Forms.Label();
            this.txtMassB_HL = new System.Windows.Forms.TextBox();
            this.label29 = new System.Windows.Forms.Label();
            this.tabMassecuiteC1 = new System.Windows.Forms.TabPage();
            this.groupBox7 = new System.Windows.Forms.GroupBox();
            this.txtMassC1_Tans_Time = new System.Windows.Forms.TextBox();
            this.label30 = new System.Windows.Forms.Label();
            this.label31 = new System.Windows.Forms.Label();
            this.txtMassC1_dateTimeTranDate = new System.Windows.Forms.DateTimePicker();
            this.groupBoxC1Massecuite = new System.Windows.Forms.GroupBox();
            this.txtMassC1_Brix = new System.Windows.Forms.TextBox();
            this.txtMassC1_Purity = new System.Windows.Forms.TextBox();
            this.label32 = new System.Windows.Forms.Label();
            this.txtMassC1_CrystNo = new System.Windows.Forms.TextBox();
            this.label33 = new System.Windows.Forms.Label();
            this.label34 = new System.Windows.Forms.Label();
            this.label35 = new System.Windows.Forms.Label();
            this.txtMassC1_DropTime = new System.Windows.Forms.TextBox();
            this.txtMassC1_Pol = new System.Windows.Forms.TextBox();
            this.label36 = new System.Windows.Forms.Label();
            this.txtMassC1_StartTime = new System.Windows.Forms.TextBox();
            this.label37 = new System.Windows.Forms.Label();
            this.txtMassC1_PanNo = new System.Windows.Forms.TextBox();
            this.label38 = new System.Windows.Forms.Label();
            this.txtMassC1_HL = new System.Windows.Forms.TextBox();
            this.label39 = new System.Windows.Forms.Label();
            this.tabMassecuiteC = new System.Windows.Forms.TabPage();
            this.groupBox9 = new System.Windows.Forms.GroupBox();
            this.txtMassC_Tans_Time = new System.Windows.Forms.TextBox();
            this.label40 = new System.Windows.Forms.Label();
            this.label41 = new System.Windows.Forms.Label();
            this.txtMassC_dateTimeTranDate = new System.Windows.Forms.DateTimePicker();
            this.groupBoxCMassecuite = new System.Windows.Forms.GroupBox();
            this.txtMassC_Brix = new System.Windows.Forms.TextBox();
            this.txtMassC_Purity = new System.Windows.Forms.TextBox();
            this.label42 = new System.Windows.Forms.Label();
            this.txtMassC_CrystNo = new System.Windows.Forms.TextBox();
            this.label43 = new System.Windows.Forms.Label();
            this.label44 = new System.Windows.Forms.Label();
            this.label45 = new System.Windows.Forms.Label();
            this.txtMassC_DropTime = new System.Windows.Forms.TextBox();
            this.txtMassC_Pol = new System.Windows.Forms.TextBox();
            this.label46 = new System.Windows.Forms.Label();
            this.txtMassC_StartTime = new System.Windows.Forms.TextBox();
            this.label47 = new System.Windows.Forms.Label();
            this.txtMassC_PanNo = new System.Windows.Forms.TextBox();
            this.label48 = new System.Windows.Forms.Label();
            this.txtMassC_HL = new System.Windows.Forms.TextBox();
            this.label49 = new System.Windows.Forms.Label();
            this.button5 = new System.Windows.Forms.Button();
            this.btnNewRecord = new System.Windows.Forms.Button();
            this.btnSave = new System.Windows.Forms.Button();
            this.btnClear = new System.Windows.Forms.Button();
            this.TabMaster = new System.Windows.Forms.TabControl();
            this.Massecuite = new System.Windows.Forms.TabPage();
            this.groupBoxAMassecuite.SuspendLayout();
            this.TabChild.SuspendLayout();
            this.tabMassecuiteA.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.tabMassecuiteA1.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.groupBoxA1Massecuite.SuspendLayout();
            this.tabMassecuiteB.SuspendLayout();
            this.groupBox5.SuspendLayout();
            this.groupBoxBMassecuite.SuspendLayout();
            this.tabMassecuiteC1.SuspendLayout();
            this.groupBox7.SuspendLayout();
            this.groupBoxC1Massecuite.SuspendLayout();
            this.tabMassecuiteC.SuspendLayout();
            this.groupBox9.SuspendLayout();
            this.groupBoxCMassecuite.SuspendLayout();
            this.TabMaster.SuspendLayout();
            this.Massecuite.SuspendLayout();
            this.SuspendLayout();
            // 
            // txtMassA_Pol
            // 
            this.txtMassA_Pol.Location = new System.Drawing.Point(508, 96);
            this.txtMassA_Pol.Name = "txtMassA_Pol";
            this.txtMassA_Pol.Size = new System.Drawing.Size(100, 22);
            this.txtMassA_Pol.TabIndex = 8;
            this.txtMassA_Pol.Text = "0";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(454, 99);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(40, 17);
            this.label7.TabIndex = 6;
            this.label7.Text = "Pol%";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(649, 99);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(44, 17);
            this.label8.TabIndex = 8;
            this.label8.Text = "Purity";
            // 
            // txtMassA_Purity
            // 
            this.txtMassA_Purity.Enabled = false;
            this.txtMassA_Purity.Location = new System.Drawing.Point(707, 96);
            this.txtMassA_Purity.Name = "txtMassA_Purity";
            this.txtMassA_Purity.Size = new System.Drawing.Size(100, 22);
            this.txtMassA_Purity.TabIndex = 9;
            this.txtMassA_Purity.Text = "0";
            // 
            // groupBoxAMassecuite
            // 
            this.groupBoxAMassecuite.Controls.Add(this.txtMassA_Brix);
            this.groupBoxAMassecuite.Controls.Add(this.txtMassA_Purity);
            this.groupBoxAMassecuite.Controls.Add(this.label6);
            this.groupBoxAMassecuite.Controls.Add(this.txtMassA_CrystNo);
            this.groupBoxAMassecuite.Controls.Add(this.label8);
            this.groupBoxAMassecuite.Controls.Add(this.label5);
            this.groupBoxAMassecuite.Controls.Add(this.label7);
            this.groupBoxAMassecuite.Controls.Add(this.txtMassA_DropTime);
            this.groupBoxAMassecuite.Controls.Add(this.txtMassA_Pol);
            this.groupBoxAMassecuite.Controls.Add(this.label4);
            this.groupBoxAMassecuite.Controls.Add(this.txtMassA_StartTime);
            this.groupBoxAMassecuite.Controls.Add(this.label3);
            this.groupBoxAMassecuite.Controls.Add(this.txtMassA_PanNo);
            this.groupBoxAMassecuite.Controls.Add(this.label2);
            this.groupBoxAMassecuite.Controls.Add(this.txtMassA_HL);
            this.groupBoxAMassecuite.Controls.Add(this.label1);
            this.groupBoxAMassecuite.Location = new System.Drawing.Point(11, 60);
            this.groupBoxAMassecuite.Name = "groupBoxAMassecuite";
            this.groupBoxAMassecuite.Size = new System.Drawing.Size(882, 139);
            this.groupBoxAMassecuite.TabIndex = 3;
            this.groupBoxAMassecuite.TabStop = false;
            this.groupBoxAMassecuite.Text = "A Massceuite";
            // 
            // txtMassA_Brix
            // 
            this.txtMassA_Brix.Location = new System.Drawing.Point(311, 96);
            this.txtMassA_Brix.Name = "txtMassA_Brix";
            this.txtMassA_Brix.Size = new System.Drawing.Size(100, 22);
            this.txtMassA_Brix.TabIndex = 7;
            this.txtMassA_Brix.Text = "0";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(254, 99);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(43, 17);
            this.label6.TabIndex = 10;
            this.label6.Text = "Brix%";
            // 
            // txtMassA_CrystNo
            // 
            this.txtMassA_CrystNo.Location = new System.Drawing.Point(134, 96);
            this.txtMassA_CrystNo.Name = "txtMassA_CrystNo";
            this.txtMassA_CrystNo.Size = new System.Drawing.Size(100, 22);
            this.txtMassA_CrystNo.TabIndex = 6;
            this.txtMassA_CrystNo.Text = "0";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(54, 99);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(66, 17);
            this.label5.TabIndex = 8;
            this.label5.Text = "Cryst No.";
            // 
            // txtMassA_DropTime
            // 
            this.txtMassA_DropTime.Location = new System.Drawing.Point(707, 32);
            this.txtMassA_DropTime.Name = "txtMassA_DropTime";
            this.txtMassA_DropTime.Size = new System.Drawing.Size(100, 22);
            this.txtMassA_DropTime.TabIndex = 5;
            this.txtMassA_DropTime.Text = "0";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(619, 35);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(74, 17);
            this.label4.TabIndex = 6;
            this.label4.Text = "Drop Time";
            // 
            // txtMassA_StartTime
            // 
            this.txtMassA_StartTime.Location = new System.Drawing.Point(508, 32);
            this.txtMassA_StartTime.Name = "txtMassA_StartTime";
            this.txtMassA_StartTime.Size = new System.Drawing.Size(100, 22);
            this.txtMassA_StartTime.TabIndex = 4;
            this.txtMassA_StartTime.Text = "0";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(421, 35);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(73, 17);
            this.label3.TabIndex = 4;
            this.label3.Text = "Start Time";
            // 
            // txtMassA_PanNo
            // 
            this.txtMassA_PanNo.Location = new System.Drawing.Point(311, 32);
            this.txtMassA_PanNo.Name = "txtMassA_PanNo";
            this.txtMassA_PanNo.Size = new System.Drawing.Size(100, 22);
            this.txtMassA_PanNo.TabIndex = 3;
            this.txtMassA_PanNo.Text = "0";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(242, 35);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(55, 17);
            this.label2.TabIndex = 2;
            this.label2.Text = "Pan No";
            // 
            // txtMassA_HL
            // 
            this.txtMassA_HL.Location = new System.Drawing.Point(134, 32);
            this.txtMassA_HL.Name = "txtMassA_HL";
            this.txtMassA_HL.Size = new System.Drawing.Size(100, 22);
            this.txtMassA_HL.TabIndex = 2;
            this.txtMassA_HL.Text = "0";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(86, 35);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(34, 17);
            this.label1.TabIndex = 0;
            this.label1.Text = "H.L.";
            // 
            // TabChild
            // 
            this.TabChild.Controls.Add(this.tabMassecuiteA);
            this.TabChild.Controls.Add(this.tabMassecuiteA1);
            this.TabChild.Controls.Add(this.tabMassecuiteB);
            this.TabChild.Controls.Add(this.tabMassecuiteC1);
            this.TabChild.Controls.Add(this.tabMassecuiteC);
            this.TabChild.Location = new System.Drawing.Point(8, 15);
            this.TabChild.Name = "TabChild";
            this.TabChild.SelectedIndex = 0;
            this.TabChild.Size = new System.Drawing.Size(907, 250);
            this.TabChild.TabIndex = 1;
            // 
            // tabMassecuiteA
            // 
            this.tabMassecuiteA.Controls.Add(this.groupBox1);
            this.tabMassecuiteA.Controls.Add(this.groupBoxAMassecuite);
            this.tabMassecuiteA.Location = new System.Drawing.Point(4, 25);
            this.tabMassecuiteA.Name = "tabMassecuiteA";
            this.tabMassecuiteA.Padding = new System.Windows.Forms.Padding(3);
            this.tabMassecuiteA.Size = new System.Drawing.Size(899, 221);
            this.tabMassecuiteA.TabIndex = 0;
            this.tabMassecuiteA.Text = "A Massecuite";
            this.tabMassecuiteA.UseVisualStyleBackColor = true;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.txtMassA_Tans_Time);
            this.groupBox1.Controls.Add(this.lblDate);
            this.groupBox1.Controls.Add(this.label9);
            this.groupBox1.Controls.Add(this.txtMassA_dateTimeTranDate);
            this.groupBox1.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.groupBox1.Location = new System.Drawing.Point(10, 14);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(883, 46);
            this.groupBox1.TabIndex = 2;
            this.groupBox1.TabStop = false;
            // 
            // txtMassA_Tans_Time
            // 
            this.txtMassA_Tans_Time.Location = new System.Drawing.Point(311, 14);
            this.txtMassA_Tans_Time.Name = "txtMassA_Tans_Time";
            this.txtMassA_Tans_Time.Size = new System.Drawing.Size(100, 22);
            this.txtMassA_Tans_Time.TabIndex = 1;
            // 
            // lblDate
            // 
            this.lblDate.AutoSize = true;
            this.lblDate.Location = new System.Drawing.Point(23, 15);
            this.lblDate.Name = "lblDate";
            this.lblDate.Size = new System.Drawing.Size(96, 17);
            this.lblDate.TabIndex = 7;
            this.lblDate.Text = "ENTRY DATE";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(257, 17);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(40, 17);
            this.label9.TabIndex = 6;
            this.label9.Text = "TIME";
            // 
            // txtMassA_dateTimeTranDate
            // 
            this.txtMassA_dateTimeTranDate.CustomFormat = "yyyy-MM-dd";
            this.txtMassA_dateTimeTranDate.Enabled = false;
            this.txtMassA_dateTimeTranDate.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.txtMassA_dateTimeTranDate.Location = new System.Drawing.Point(135, 15);
            this.txtMassA_dateTimeTranDate.Name = "txtMassA_dateTimeTranDate";
            this.txtMassA_dateTimeTranDate.Size = new System.Drawing.Size(100, 22);
            this.txtMassA_dateTimeTranDate.TabIndex = 1;
            // 
            // tabMassecuiteA1
            // 
            this.tabMassecuiteA1.Controls.Add(this.groupBox3);
            this.tabMassecuiteA1.Controls.Add(this.groupBoxA1Massecuite);
            this.tabMassecuiteA1.Location = new System.Drawing.Point(4, 25);
            this.tabMassecuiteA1.Name = "tabMassecuiteA1";
            this.tabMassecuiteA1.Padding = new System.Windows.Forms.Padding(3);
            this.tabMassecuiteA1.Size = new System.Drawing.Size(899, 221);
            this.tabMassecuiteA1.TabIndex = 1;
            this.tabMassecuiteA1.Text = "A1- Massecuite";
            this.tabMassecuiteA1.UseVisualStyleBackColor = true;
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.txtMassA1_Tans_Time);
            this.groupBox3.Controls.Add(this.label10);
            this.groupBox3.Controls.Add(this.label11);
            this.groupBox3.Controls.Add(this.txtMassA1_dateTimeTranDate);
            this.groupBox3.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.groupBox3.Location = new System.Drawing.Point(10, 14);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(883, 46);
            this.groupBox3.TabIndex = 2;
            this.groupBox3.TabStop = false;
            // 
            // txtMassA1_Tans_Time
            // 
            this.txtMassA1_Tans_Time.Location = new System.Drawing.Point(311, 14);
            this.txtMassA1_Tans_Time.Name = "txtMassA1_Tans_Time";
            this.txtMassA1_Tans_Time.Size = new System.Drawing.Size(100, 22);
            this.txtMassA1_Tans_Time.TabIndex = 1;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(23, 15);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(96, 17);
            this.label10.TabIndex = 7;
            this.label10.Text = "ENTRY DATE";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(257, 17);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(40, 17);
            this.label11.TabIndex = 6;
            this.label11.Text = "TIME";
            // 
            // txtMassA1_dateTimeTranDate
            // 
            this.txtMassA1_dateTimeTranDate.CustomFormat = "yyyy-MM-dd";
            this.txtMassA1_dateTimeTranDate.Enabled = false;
            this.txtMassA1_dateTimeTranDate.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.txtMassA1_dateTimeTranDate.Location = new System.Drawing.Point(135, 15);
            this.txtMassA1_dateTimeTranDate.Name = "txtMassA1_dateTimeTranDate";
            this.txtMassA1_dateTimeTranDate.Size = new System.Drawing.Size(100, 22);
            this.txtMassA1_dateTimeTranDate.TabIndex = 8;
            // 
            // groupBoxA1Massecuite
            // 
            this.groupBoxA1Massecuite.Controls.Add(this.txtMassA1_Brix);
            this.groupBoxA1Massecuite.Controls.Add(this.txtMassA1_Purity);
            this.groupBoxA1Massecuite.Controls.Add(this.label12);
            this.groupBoxA1Massecuite.Controls.Add(this.txtMassA1_CrystNo);
            this.groupBoxA1Massecuite.Controls.Add(this.label13);
            this.groupBoxA1Massecuite.Controls.Add(this.label14);
            this.groupBoxA1Massecuite.Controls.Add(this.label15);
            this.groupBoxA1Massecuite.Controls.Add(this.txtMassA1_DropTime);
            this.groupBoxA1Massecuite.Controls.Add(this.txtMassA1_Pol);
            this.groupBoxA1Massecuite.Controls.Add(this.label16);
            this.groupBoxA1Massecuite.Controls.Add(this.txtMassA1_StartTime);
            this.groupBoxA1Massecuite.Controls.Add(this.label17);
            this.groupBoxA1Massecuite.Controls.Add(this.txtMassA1_PanNo);
            this.groupBoxA1Massecuite.Controls.Add(this.label18);
            this.groupBoxA1Massecuite.Controls.Add(this.txtMassA1_HL);
            this.groupBoxA1Massecuite.Controls.Add(this.label19);
            this.groupBoxA1Massecuite.Location = new System.Drawing.Point(11, 60);
            this.groupBoxA1Massecuite.Name = "groupBoxA1Massecuite";
            this.groupBoxA1Massecuite.Size = new System.Drawing.Size(882, 139);
            this.groupBoxA1Massecuite.TabIndex = 15;
            this.groupBoxA1Massecuite.TabStop = false;
            this.groupBoxA1Massecuite.Text = "A1- Massceuite";
            // 
            // txtMassA1_Brix
            // 
            this.txtMassA1_Brix.Location = new System.Drawing.Point(311, 96);
            this.txtMassA1_Brix.Name = "txtMassA1_Brix";
            this.txtMassA1_Brix.Size = new System.Drawing.Size(100, 22);
            this.txtMassA1_Brix.TabIndex = 7;
            this.txtMassA1_Brix.Text = "0";
            // 
            // txtMassA1_Purity
            // 
            this.txtMassA1_Purity.Enabled = false;
            this.txtMassA1_Purity.Location = new System.Drawing.Point(707, 96);
            this.txtMassA1_Purity.Name = "txtMassA1_Purity";
            this.txtMassA1_Purity.Size = new System.Drawing.Size(100, 22);
            this.txtMassA1_Purity.TabIndex = 9;
            this.txtMassA1_Purity.Text = "0";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(254, 99);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(43, 17);
            this.label12.TabIndex = 10;
            this.label12.Text = "Brix%";
            // 
            // txtMassA1_CrystNo
            // 
            this.txtMassA1_CrystNo.Location = new System.Drawing.Point(134, 96);
            this.txtMassA1_CrystNo.Name = "txtMassA1_CrystNo";
            this.txtMassA1_CrystNo.Size = new System.Drawing.Size(100, 22);
            this.txtMassA1_CrystNo.TabIndex = 6;
            this.txtMassA1_CrystNo.Text = "0";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(649, 99);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(44, 17);
            this.label13.TabIndex = 8;
            this.label13.Text = "Purity";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(54, 99);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(66, 17);
            this.label14.TabIndex = 8;
            this.label14.Text = "Cryst No.";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(454, 99);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(40, 17);
            this.label15.TabIndex = 6;
            this.label15.Text = "Pol%";
            // 
            // txtMassA1_DropTime
            // 
            this.txtMassA1_DropTime.Location = new System.Drawing.Point(707, 32);
            this.txtMassA1_DropTime.Name = "txtMassA1_DropTime";
            this.txtMassA1_DropTime.Size = new System.Drawing.Size(100, 22);
            this.txtMassA1_DropTime.TabIndex = 5;
            this.txtMassA1_DropTime.Text = "0";
            // 
            // txtMassA1_Pol
            // 
            this.txtMassA1_Pol.Location = new System.Drawing.Point(508, 96);
            this.txtMassA1_Pol.Name = "txtMassA1_Pol";
            this.txtMassA1_Pol.Size = new System.Drawing.Size(100, 22);
            this.txtMassA1_Pol.TabIndex = 8;
            this.txtMassA1_Pol.Text = "0";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(619, 35);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(74, 17);
            this.label16.TabIndex = 6;
            this.label16.Text = "Drop Time";
            // 
            // txtMassA1_StartTime
            // 
            this.txtMassA1_StartTime.Location = new System.Drawing.Point(508, 32);
            this.txtMassA1_StartTime.Name = "txtMassA1_StartTime";
            this.txtMassA1_StartTime.Size = new System.Drawing.Size(100, 22);
            this.txtMassA1_StartTime.TabIndex = 4;
            this.txtMassA1_StartTime.Text = "0";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(421, 35);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(73, 17);
            this.label17.TabIndex = 4;
            this.label17.Text = "Start Time";
            // 
            // txtMassA1_PanNo
            // 
            this.txtMassA1_PanNo.Location = new System.Drawing.Point(311, 32);
            this.txtMassA1_PanNo.Name = "txtMassA1_PanNo";
            this.txtMassA1_PanNo.Size = new System.Drawing.Size(100, 22);
            this.txtMassA1_PanNo.TabIndex = 3;
            this.txtMassA1_PanNo.Text = "0";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(242, 35);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(55, 17);
            this.label18.TabIndex = 2;
            this.label18.Text = "Pan No";
            // 
            // txtMassA1_HL
            // 
            this.txtMassA1_HL.AcceptsTab = true;
            this.txtMassA1_HL.Location = new System.Drawing.Point(134, 32);
            this.txtMassA1_HL.Name = "txtMassA1_HL";
            this.txtMassA1_HL.Size = new System.Drawing.Size(100, 22);
            this.txtMassA1_HL.TabIndex = 2;
            this.txtMassA1_HL.Text = "0";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(86, 35);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(34, 17);
            this.label19.TabIndex = 0;
            this.label19.Text = "H.L.";
            // 
            // tabMassecuiteB
            // 
            this.tabMassecuiteB.Controls.Add(this.groupBox5);
            this.tabMassecuiteB.Controls.Add(this.groupBoxBMassecuite);
            this.tabMassecuiteB.Location = new System.Drawing.Point(4, 25);
            this.tabMassecuiteB.Name = "tabMassecuiteB";
            this.tabMassecuiteB.Padding = new System.Windows.Forms.Padding(3);
            this.tabMassecuiteB.Size = new System.Drawing.Size(899, 221);
            this.tabMassecuiteB.TabIndex = 2;
            this.tabMassecuiteB.Text = "B- Massecuite";
            this.tabMassecuiteB.UseVisualStyleBackColor = true;
            // 
            // groupBox5
            // 
            this.groupBox5.Controls.Add(this.txtMassB_Tans_Time);
            this.groupBox5.Controls.Add(this.label20);
            this.groupBox5.Controls.Add(this.label21);
            this.groupBox5.Controls.Add(this.txtMassB_dateTimeTranDate);
            this.groupBox5.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.groupBox5.Location = new System.Drawing.Point(10, 14);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(883, 46);
            this.groupBox5.TabIndex = 2;
            this.groupBox5.TabStop = false;
            // 
            // txtMassB_Tans_Time
            // 
            this.txtMassB_Tans_Time.Location = new System.Drawing.Point(311, 14);
            this.txtMassB_Tans_Time.Name = "txtMassB_Tans_Time";
            this.txtMassB_Tans_Time.Size = new System.Drawing.Size(100, 22);
            this.txtMassB_Tans_Time.TabIndex = 1;
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(23, 15);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(96, 17);
            this.label20.TabIndex = 7;
            this.label20.Text = "ENTRY DATE";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(257, 17);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(40, 17);
            this.label21.TabIndex = 6;
            this.label21.Text = "TIME";
            // 
            // txtMassB_dateTimeTranDate
            // 
            this.txtMassB_dateTimeTranDate.CustomFormat = "yyyy-MM-dd";
            this.txtMassB_dateTimeTranDate.Enabled = false;
            this.txtMassB_dateTimeTranDate.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.txtMassB_dateTimeTranDate.Location = new System.Drawing.Point(135, 15);
            this.txtMassB_dateTimeTranDate.Name = "txtMassB_dateTimeTranDate";
            this.txtMassB_dateTimeTranDate.Size = new System.Drawing.Size(100, 22);
            this.txtMassB_dateTimeTranDate.TabIndex = 8;
            // 
            // groupBoxBMassecuite
            // 
            this.groupBoxBMassecuite.Controls.Add(this.txtMassB_Brix);
            this.groupBoxBMassecuite.Controls.Add(this.txtMassB_Purity);
            this.groupBoxBMassecuite.Controls.Add(this.label22);
            this.groupBoxBMassecuite.Controls.Add(this.txtMassB_CrystNo);
            this.groupBoxBMassecuite.Controls.Add(this.label23);
            this.groupBoxBMassecuite.Controls.Add(this.label24);
            this.groupBoxBMassecuite.Controls.Add(this.label25);
            this.groupBoxBMassecuite.Controls.Add(this.txtMassB_DropTime);
            this.groupBoxBMassecuite.Controls.Add(this.txtMassB_Pol);
            this.groupBoxBMassecuite.Controls.Add(this.label26);
            this.groupBoxBMassecuite.Controls.Add(this.txtMassB_StartTime);
            this.groupBoxBMassecuite.Controls.Add(this.label27);
            this.groupBoxBMassecuite.Controls.Add(this.txtMassB_PanNo);
            this.groupBoxBMassecuite.Controls.Add(this.label28);
            this.groupBoxBMassecuite.Controls.Add(this.txtMassB_HL);
            this.groupBoxBMassecuite.Controls.Add(this.label29);
            this.groupBoxBMassecuite.Location = new System.Drawing.Point(11, 60);
            this.groupBoxBMassecuite.Name = "groupBoxBMassecuite";
            this.groupBoxBMassecuite.Size = new System.Drawing.Size(882, 139);
            this.groupBoxBMassecuite.TabIndex = 15;
            this.groupBoxBMassecuite.TabStop = false;
            this.groupBoxBMassecuite.Text = "B Massceuite";
            // 
            // txtMassB_Brix
            // 
            this.txtMassB_Brix.Location = new System.Drawing.Point(311, 96);
            this.txtMassB_Brix.Name = "txtMassB_Brix";
            this.txtMassB_Brix.Size = new System.Drawing.Size(100, 22);
            this.txtMassB_Brix.TabIndex = 6;
            this.txtMassB_Brix.Text = "0";
            // 
            // txtMassB_Purity
            // 
            this.txtMassB_Purity.Enabled = false;
            this.txtMassB_Purity.Location = new System.Drawing.Point(707, 96);
            this.txtMassB_Purity.Name = "txtMassB_Purity";
            this.txtMassB_Purity.Size = new System.Drawing.Size(100, 22);
            this.txtMassB_Purity.TabIndex = 8;
            this.txtMassB_Purity.Text = "0";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Location = new System.Drawing.Point(254, 99);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(43, 17);
            this.label22.TabIndex = 10;
            this.label22.Text = "Brix%";
            // 
            // txtMassB_CrystNo
            // 
            this.txtMassB_CrystNo.Location = new System.Drawing.Point(134, 96);
            this.txtMassB_CrystNo.Name = "txtMassB_CrystNo";
            this.txtMassB_CrystNo.Size = new System.Drawing.Size(100, 22);
            this.txtMassB_CrystNo.TabIndex = 5;
            this.txtMassB_CrystNo.Text = "0";
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Location = new System.Drawing.Point(649, 99);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(44, 17);
            this.label23.TabIndex = 8;
            this.label23.Text = "Purity";
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Location = new System.Drawing.Point(54, 99);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(66, 17);
            this.label24.TabIndex = 8;
            this.label24.Text = "Cryst No.";
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Location = new System.Drawing.Point(454, 99);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(40, 17);
            this.label25.TabIndex = 6;
            this.label25.Text = "Pol%";
            // 
            // txtMassB_DropTime
            // 
            this.txtMassB_DropTime.Location = new System.Drawing.Point(707, 32);
            this.txtMassB_DropTime.Name = "txtMassB_DropTime";
            this.txtMassB_DropTime.Size = new System.Drawing.Size(100, 22);
            this.txtMassB_DropTime.TabIndex = 4;
            this.txtMassB_DropTime.Text = "0";
            // 
            // txtMassB_Pol
            // 
            this.txtMassB_Pol.Location = new System.Drawing.Point(508, 96);
            this.txtMassB_Pol.Name = "txtMassB_Pol";
            this.txtMassB_Pol.Size = new System.Drawing.Size(100, 22);
            this.txtMassB_Pol.TabIndex = 7;
            this.txtMassB_Pol.Text = "0";
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Location = new System.Drawing.Point(619, 35);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(74, 17);
            this.label26.TabIndex = 6;
            this.label26.Text = "Drop Time";
            // 
            // txtMassB_StartTime
            // 
            this.txtMassB_StartTime.Location = new System.Drawing.Point(508, 32);
            this.txtMassB_StartTime.Name = "txtMassB_StartTime";
            this.txtMassB_StartTime.Size = new System.Drawing.Size(100, 22);
            this.txtMassB_StartTime.TabIndex = 3;
            this.txtMassB_StartTime.Text = "0";
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Location = new System.Drawing.Point(421, 35);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(73, 17);
            this.label27.TabIndex = 4;
            this.label27.Text = "Start Time";
            // 
            // txtMassB_PanNo
            // 
            this.txtMassB_PanNo.Location = new System.Drawing.Point(311, 32);
            this.txtMassB_PanNo.Name = "txtMassB_PanNo";
            this.txtMassB_PanNo.Size = new System.Drawing.Size(100, 22);
            this.txtMassB_PanNo.TabIndex = 2;
            this.txtMassB_PanNo.Text = "0";
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Location = new System.Drawing.Point(242, 35);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(55, 17);
            this.label28.TabIndex = 2;
            this.label28.Text = "Pan No";
            // 
            // txtMassB_HL
            // 
            this.txtMassB_HL.Location = new System.Drawing.Point(134, 32);
            this.txtMassB_HL.Name = "txtMassB_HL";
            this.txtMassB_HL.Size = new System.Drawing.Size(100, 22);
            this.txtMassB_HL.TabIndex = 1;
            this.txtMassB_HL.Text = "0";
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Location = new System.Drawing.Point(86, 35);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(34, 17);
            this.label29.TabIndex = 0;
            this.label29.Text = "H.L.";
            // 
            // tabMassecuiteC1
            // 
            this.tabMassecuiteC1.Controls.Add(this.groupBox7);
            this.tabMassecuiteC1.Controls.Add(this.groupBoxC1Massecuite);
            this.tabMassecuiteC1.Location = new System.Drawing.Point(4, 25);
            this.tabMassecuiteC1.Name = "tabMassecuiteC1";
            this.tabMassecuiteC1.Padding = new System.Windows.Forms.Padding(3);
            this.tabMassecuiteC1.Size = new System.Drawing.Size(899, 221);
            this.tabMassecuiteC1.TabIndex = 3;
            this.tabMassecuiteC1.Text = "C1- Massecuite";
            this.tabMassecuiteC1.UseVisualStyleBackColor = true;
            // 
            // groupBox7
            // 
            this.groupBox7.Controls.Add(this.txtMassC1_Tans_Time);
            this.groupBox7.Controls.Add(this.label30);
            this.groupBox7.Controls.Add(this.label31);
            this.groupBox7.Controls.Add(this.txtMassC1_dateTimeTranDate);
            this.groupBox7.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.groupBox7.Location = new System.Drawing.Point(10, 14);
            this.groupBox7.Name = "groupBox7";
            this.groupBox7.Size = new System.Drawing.Size(868, 46);
            this.groupBox7.TabIndex = 2;
            this.groupBox7.TabStop = false;
            // 
            // txtMassC1_Tans_Time
            // 
            this.txtMassC1_Tans_Time.Location = new System.Drawing.Point(311, 14);
            this.txtMassC1_Tans_Time.Name = "txtMassC1_Tans_Time";
            this.txtMassC1_Tans_Time.Size = new System.Drawing.Size(100, 22);
            this.txtMassC1_Tans_Time.TabIndex = 1;
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Location = new System.Drawing.Point(23, 15);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(96, 17);
            this.label30.TabIndex = 7;
            this.label30.Text = "ENTRY DATE";
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Location = new System.Drawing.Point(257, 17);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(40, 17);
            this.label31.TabIndex = 6;
            this.label31.Text = "TIME";
            // 
            // txtMassC1_dateTimeTranDate
            // 
            this.txtMassC1_dateTimeTranDate.CustomFormat = "yyyy-MM-dd";
            this.txtMassC1_dateTimeTranDate.Enabled = false;
            this.txtMassC1_dateTimeTranDate.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.txtMassC1_dateTimeTranDate.Location = new System.Drawing.Point(135, 15);
            this.txtMassC1_dateTimeTranDate.Name = "txtMassC1_dateTimeTranDate";
            this.txtMassC1_dateTimeTranDate.Size = new System.Drawing.Size(100, 22);
            this.txtMassC1_dateTimeTranDate.TabIndex = 8;
            // 
            // groupBoxC1Massecuite
            // 
            this.groupBoxC1Massecuite.Controls.Add(this.txtMassC1_Brix);
            this.groupBoxC1Massecuite.Controls.Add(this.txtMassC1_Purity);
            this.groupBoxC1Massecuite.Controls.Add(this.label32);
            this.groupBoxC1Massecuite.Controls.Add(this.txtMassC1_CrystNo);
            this.groupBoxC1Massecuite.Controls.Add(this.label33);
            this.groupBoxC1Massecuite.Controls.Add(this.label34);
            this.groupBoxC1Massecuite.Controls.Add(this.label35);
            this.groupBoxC1Massecuite.Controls.Add(this.txtMassC1_DropTime);
            this.groupBoxC1Massecuite.Controls.Add(this.txtMassC1_Pol);
            this.groupBoxC1Massecuite.Controls.Add(this.label36);
            this.groupBoxC1Massecuite.Controls.Add(this.txtMassC1_StartTime);
            this.groupBoxC1Massecuite.Controls.Add(this.label37);
            this.groupBoxC1Massecuite.Controls.Add(this.txtMassC1_PanNo);
            this.groupBoxC1Massecuite.Controls.Add(this.label38);
            this.groupBoxC1Massecuite.Controls.Add(this.txtMassC1_HL);
            this.groupBoxC1Massecuite.Controls.Add(this.label39);
            this.groupBoxC1Massecuite.Location = new System.Drawing.Point(11, 60);
            this.groupBoxC1Massecuite.Name = "groupBoxC1Massecuite";
            this.groupBoxC1Massecuite.Size = new System.Drawing.Size(867, 139);
            this.groupBoxC1Massecuite.TabIndex = 3;
            this.groupBoxC1Massecuite.TabStop = false;
            this.groupBoxC1Massecuite.Text = "C1- Massceuite";
            // 
            // txtMassC1_Brix
            // 
            this.txtMassC1_Brix.Location = new System.Drawing.Point(311, 96);
            this.txtMassC1_Brix.Name = "txtMassC1_Brix";
            this.txtMassC1_Brix.Size = new System.Drawing.Size(100, 22);
            this.txtMassC1_Brix.TabIndex = 6;
            this.txtMassC1_Brix.Text = "0";
            // 
            // txtMassC1_Purity
            // 
            this.txtMassC1_Purity.Enabled = false;
            this.txtMassC1_Purity.Location = new System.Drawing.Point(707, 96);
            this.txtMassC1_Purity.Name = "txtMassC1_Purity";
            this.txtMassC1_Purity.Size = new System.Drawing.Size(100, 22);
            this.txtMassC1_Purity.TabIndex = 8;
            this.txtMassC1_Purity.Text = "0";
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Location = new System.Drawing.Point(254, 99);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(43, 17);
            this.label32.TabIndex = 10;
            this.label32.Text = "Brix%";
            // 
            // txtMassC1_CrystNo
            // 
            this.txtMassC1_CrystNo.Location = new System.Drawing.Point(134, 96);
            this.txtMassC1_CrystNo.Name = "txtMassC1_CrystNo";
            this.txtMassC1_CrystNo.Size = new System.Drawing.Size(100, 22);
            this.txtMassC1_CrystNo.TabIndex = 5;
            this.txtMassC1_CrystNo.Text = "0";
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.Location = new System.Drawing.Point(649, 99);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(44, 17);
            this.label33.TabIndex = 8;
            this.label33.Text = "Purity";
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.Location = new System.Drawing.Point(53, 99);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(66, 17);
            this.label34.TabIndex = 8;
            this.label34.Text = "Cryst No.";
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.Location = new System.Drawing.Point(454, 99);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(40, 17);
            this.label35.TabIndex = 6;
            this.label35.Text = "Pol%";
            // 
            // txtMassC1_DropTime
            // 
            this.txtMassC1_DropTime.Location = new System.Drawing.Point(707, 32);
            this.txtMassC1_DropTime.Name = "txtMassC1_DropTime";
            this.txtMassC1_DropTime.Size = new System.Drawing.Size(100, 22);
            this.txtMassC1_DropTime.TabIndex = 4;
            this.txtMassC1_DropTime.Text = "0";
            // 
            // txtMassC1_Pol
            // 
            this.txtMassC1_Pol.Location = new System.Drawing.Point(508, 96);
            this.txtMassC1_Pol.Name = "txtMassC1_Pol";
            this.txtMassC1_Pol.Size = new System.Drawing.Size(100, 22);
            this.txtMassC1_Pol.TabIndex = 7;
            this.txtMassC1_Pol.Text = "0";
            // 
            // label36
            // 
            this.label36.AutoSize = true;
            this.label36.Location = new System.Drawing.Point(619, 35);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(74, 17);
            this.label36.TabIndex = 6;
            this.label36.Text = "Drop Time";
            // 
            // txtMassC1_StartTime
            // 
            this.txtMassC1_StartTime.Location = new System.Drawing.Point(508, 32);
            this.txtMassC1_StartTime.Name = "txtMassC1_StartTime";
            this.txtMassC1_StartTime.Size = new System.Drawing.Size(100, 22);
            this.txtMassC1_StartTime.TabIndex = 3;
            this.txtMassC1_StartTime.Text = "0";
            // 
            // label37
            // 
            this.label37.AutoSize = true;
            this.label37.Location = new System.Drawing.Point(421, 35);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(73, 17);
            this.label37.TabIndex = 4;
            this.label37.Text = "Start Time";
            // 
            // txtMassC1_PanNo
            // 
            this.txtMassC1_PanNo.Location = new System.Drawing.Point(311, 32);
            this.txtMassC1_PanNo.Name = "txtMassC1_PanNo";
            this.txtMassC1_PanNo.Size = new System.Drawing.Size(100, 22);
            this.txtMassC1_PanNo.TabIndex = 2;
            this.txtMassC1_PanNo.Text = "0";
            // 
            // label38
            // 
            this.label38.AutoSize = true;
            this.label38.Location = new System.Drawing.Point(242, 35);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(55, 17);
            this.label38.TabIndex = 2;
            this.label38.Text = "Pan No";
            // 
            // txtMassC1_HL
            // 
            this.txtMassC1_HL.Location = new System.Drawing.Point(134, 32);
            this.txtMassC1_HL.Name = "txtMassC1_HL";
            this.txtMassC1_HL.Size = new System.Drawing.Size(100, 22);
            this.txtMassC1_HL.TabIndex = 1;
            this.txtMassC1_HL.Text = "0";
            // 
            // label39
            // 
            this.label39.AutoSize = true;
            this.label39.Location = new System.Drawing.Point(85, 35);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(34, 17);
            this.label39.TabIndex = 0;
            this.label39.Text = "H.L.";
            // 
            // tabMassecuiteC
            // 
            this.tabMassecuiteC.Controls.Add(this.groupBox9);
            this.tabMassecuiteC.Controls.Add(this.groupBoxCMassecuite);
            this.tabMassecuiteC.Location = new System.Drawing.Point(4, 25);
            this.tabMassecuiteC.Name = "tabMassecuiteC";
            this.tabMassecuiteC.Padding = new System.Windows.Forms.Padding(3);
            this.tabMassecuiteC.Size = new System.Drawing.Size(899, 221);
            this.tabMassecuiteC.TabIndex = 4;
            this.tabMassecuiteC.Text = "C- Massecuite";
            this.tabMassecuiteC.UseVisualStyleBackColor = true;
            // 
            // groupBox9
            // 
            this.groupBox9.Controls.Add(this.txtMassC_Tans_Time);
            this.groupBox9.Controls.Add(this.label40);
            this.groupBox9.Controls.Add(this.label41);
            this.groupBox9.Controls.Add(this.txtMassC_dateTimeTranDate);
            this.groupBox9.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.groupBox9.Location = new System.Drawing.Point(10, 14);
            this.groupBox9.Name = "groupBox9";
            this.groupBox9.Size = new System.Drawing.Size(883, 46);
            this.groupBox9.TabIndex = 2;
            this.groupBox9.TabStop = false;
            // 
            // txtMassC_Tans_Time
            // 
            this.txtMassC_Tans_Time.Location = new System.Drawing.Point(311, 14);
            this.txtMassC_Tans_Time.Name = "txtMassC_Tans_Time";
            this.txtMassC_Tans_Time.Size = new System.Drawing.Size(100, 22);
            this.txtMassC_Tans_Time.TabIndex = 1;
            // 
            // label40
            // 
            this.label40.AutoSize = true;
            this.label40.Location = new System.Drawing.Point(23, 15);
            this.label40.Name = "label40";
            this.label40.Size = new System.Drawing.Size(96, 17);
            this.label40.TabIndex = 7;
            this.label40.Text = "ENTRY DATE";
            // 
            // label41
            // 
            this.label41.AutoSize = true;
            this.label41.Location = new System.Drawing.Point(257, 17);
            this.label41.Name = "label41";
            this.label41.Size = new System.Drawing.Size(40, 17);
            this.label41.TabIndex = 6;
            this.label41.Text = "TIME";
            // 
            // txtMassC_dateTimeTranDate
            // 
            this.txtMassC_dateTimeTranDate.CustomFormat = "yyyy-MM-dd";
            this.txtMassC_dateTimeTranDate.Enabled = false;
            this.txtMassC_dateTimeTranDate.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.txtMassC_dateTimeTranDate.Location = new System.Drawing.Point(135, 15);
            this.txtMassC_dateTimeTranDate.Name = "txtMassC_dateTimeTranDate";
            this.txtMassC_dateTimeTranDate.Size = new System.Drawing.Size(100, 22);
            this.txtMassC_dateTimeTranDate.TabIndex = 8;
            // 
            // groupBoxCMassecuite
            // 
            this.groupBoxCMassecuite.Controls.Add(this.txtMassC_Brix);
            this.groupBoxCMassecuite.Controls.Add(this.txtMassC_Purity);
            this.groupBoxCMassecuite.Controls.Add(this.label42);
            this.groupBoxCMassecuite.Controls.Add(this.txtMassC_CrystNo);
            this.groupBoxCMassecuite.Controls.Add(this.label43);
            this.groupBoxCMassecuite.Controls.Add(this.label44);
            this.groupBoxCMassecuite.Controls.Add(this.label45);
            this.groupBoxCMassecuite.Controls.Add(this.txtMassC_DropTime);
            this.groupBoxCMassecuite.Controls.Add(this.txtMassC_Pol);
            this.groupBoxCMassecuite.Controls.Add(this.label46);
            this.groupBoxCMassecuite.Controls.Add(this.txtMassC_StartTime);
            this.groupBoxCMassecuite.Controls.Add(this.label47);
            this.groupBoxCMassecuite.Controls.Add(this.txtMassC_PanNo);
            this.groupBoxCMassecuite.Controls.Add(this.label48);
            this.groupBoxCMassecuite.Controls.Add(this.txtMassC_HL);
            this.groupBoxCMassecuite.Controls.Add(this.label49);
            this.groupBoxCMassecuite.Location = new System.Drawing.Point(11, 60);
            this.groupBoxCMassecuite.Name = "groupBoxCMassecuite";
            this.groupBoxCMassecuite.Size = new System.Drawing.Size(882, 139);
            this.groupBoxCMassecuite.TabIndex = 15;
            this.groupBoxCMassecuite.TabStop = false;
            this.groupBoxCMassecuite.Text = "C Massceuite";
            // 
            // txtMassC_Brix
            // 
            this.txtMassC_Brix.Location = new System.Drawing.Point(311, 96);
            this.txtMassC_Brix.Name = "txtMassC_Brix";
            this.txtMassC_Brix.Size = new System.Drawing.Size(100, 22);
            this.txtMassC_Brix.TabIndex = 6;
            this.txtMassC_Brix.Text = "0";
            // 
            // txtMassC_Purity
            // 
            this.txtMassC_Purity.Enabled = false;
            this.txtMassC_Purity.Location = new System.Drawing.Point(707, 96);
            this.txtMassC_Purity.Name = "txtMassC_Purity";
            this.txtMassC_Purity.ReadOnly = true;
            this.txtMassC_Purity.Size = new System.Drawing.Size(100, 22);
            this.txtMassC_Purity.TabIndex = 9;
            this.txtMassC_Purity.Text = "0";
            // 
            // label42
            // 
            this.label42.AutoSize = true;
            this.label42.Location = new System.Drawing.Point(254, 99);
            this.label42.Name = "label42";
            this.label42.Size = new System.Drawing.Size(43, 17);
            this.label42.TabIndex = 10;
            this.label42.Text = "Brix%";
            // 
            // txtMassC_CrystNo
            // 
            this.txtMassC_CrystNo.Location = new System.Drawing.Point(134, 96);
            this.txtMassC_CrystNo.Name = "txtMassC_CrystNo";
            this.txtMassC_CrystNo.Size = new System.Drawing.Size(100, 22);
            this.txtMassC_CrystNo.TabIndex = 5;
            this.txtMassC_CrystNo.Text = "0";
            // 
            // label43
            // 
            this.label43.AutoSize = true;
            this.label43.Location = new System.Drawing.Point(649, 99);
            this.label43.Name = "label43";
            this.label43.Size = new System.Drawing.Size(44, 17);
            this.label43.TabIndex = 8;
            this.label43.Text = "Purity";
            // 
            // label44
            // 
            this.label44.AutoSize = true;
            this.label44.Location = new System.Drawing.Point(54, 99);
            this.label44.Name = "label44";
            this.label44.Size = new System.Drawing.Size(66, 17);
            this.label44.TabIndex = 8;
            this.label44.Text = "Cryst No.";
            // 
            // label45
            // 
            this.label45.AutoSize = true;
            this.label45.Location = new System.Drawing.Point(454, 99);
            this.label45.Name = "label45";
            this.label45.Size = new System.Drawing.Size(40, 17);
            this.label45.TabIndex = 6;
            this.label45.Text = "Pol%";
            // 
            // txtMassC_DropTime
            // 
            this.txtMassC_DropTime.Location = new System.Drawing.Point(707, 32);
            this.txtMassC_DropTime.Name = "txtMassC_DropTime";
            this.txtMassC_DropTime.Size = new System.Drawing.Size(100, 22);
            this.txtMassC_DropTime.TabIndex = 4;
            this.txtMassC_DropTime.Text = "0";
            // 
            // txtMassC_Pol
            // 
            this.txtMassC_Pol.Location = new System.Drawing.Point(508, 96);
            this.txtMassC_Pol.Name = "txtMassC_Pol";
            this.txtMassC_Pol.Size = new System.Drawing.Size(100, 22);
            this.txtMassC_Pol.TabIndex = 7;
            this.txtMassC_Pol.Text = "0";
            // 
            // label46
            // 
            this.label46.AutoSize = true;
            this.label46.Location = new System.Drawing.Point(619, 35);
            this.label46.Name = "label46";
            this.label46.Size = new System.Drawing.Size(74, 17);
            this.label46.TabIndex = 6;
            this.label46.Text = "Drop Time";
            // 
            // txtMassC_StartTime
            // 
            this.txtMassC_StartTime.Location = new System.Drawing.Point(508, 32);
            this.txtMassC_StartTime.Name = "txtMassC_StartTime";
            this.txtMassC_StartTime.Size = new System.Drawing.Size(100, 22);
            this.txtMassC_StartTime.TabIndex = 3;
            this.txtMassC_StartTime.Text = "0";
            // 
            // label47
            // 
            this.label47.AutoSize = true;
            this.label47.Location = new System.Drawing.Point(421, 35);
            this.label47.Name = "label47";
            this.label47.Size = new System.Drawing.Size(73, 17);
            this.label47.TabIndex = 4;
            this.label47.Text = "Start Time";
            // 
            // txtMassC_PanNo
            // 
            this.txtMassC_PanNo.Location = new System.Drawing.Point(311, 32);
            this.txtMassC_PanNo.Name = "txtMassC_PanNo";
            this.txtMassC_PanNo.Size = new System.Drawing.Size(100, 22);
            this.txtMassC_PanNo.TabIndex = 2;
            this.txtMassC_PanNo.Text = "0";
            // 
            // label48
            // 
            this.label48.AutoSize = true;
            this.label48.Location = new System.Drawing.Point(242, 35);
            this.label48.Name = "label48";
            this.label48.Size = new System.Drawing.Size(55, 17);
            this.label48.TabIndex = 2;
            this.label48.Text = "Pan No";
            // 
            // txtMassC_HL
            // 
            this.txtMassC_HL.Location = new System.Drawing.Point(134, 32);
            this.txtMassC_HL.Name = "txtMassC_HL";
            this.txtMassC_HL.Size = new System.Drawing.Size(100, 22);
            this.txtMassC_HL.TabIndex = 1;
            this.txtMassC_HL.Text = "0";
            // 
            // label49
            // 
            this.label49.AutoSize = true;
            this.label49.Location = new System.Drawing.Point(86, 35);
            this.label49.Name = "label49";
            this.label49.Size = new System.Drawing.Size(34, 17);
            this.label49.TabIndex = 0;
            this.label49.Text = "H.L.";
            // 
            // button5
            // 
            this.button5.Enabled = false;
            this.button5.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.button5.Location = new System.Drawing.Point(728, 332);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(105, 31);
            this.button5.TabIndex = 25;
            this.button5.Text = "MODIFY";
            this.button5.UseVisualStyleBackColor = true;
            // 
            // btnNewRecord
            // 
            this.btnNewRecord.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnNewRecord.Location = new System.Drawing.Point(506, 332);
            this.btnNewRecord.Name = "btnNewRecord";
            this.btnNewRecord.Size = new System.Drawing.Size(105, 31);
            this.btnNewRecord.TabIndex = 1;
            this.btnNewRecord.Text = "&New Record";
            this.btnNewRecord.UseVisualStyleBackColor = true;
            this.btnNewRecord.Click += new System.EventHandler(this.btnNewRecord_Click);
            // 
            // btnSave
            // 
            this.btnSave.Enabled = false;
            this.btnSave.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnSave.Location = new System.Drawing.Point(617, 332);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(105, 31);
            this.btnSave.TabIndex = 10;
            this.btnSave.Text = "&Save";
            this.btnSave.UseVisualStyleBackColor = true;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // btnClear
            // 
            this.btnClear.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnClear.Location = new System.Drawing.Point(839, 332);
            this.btnClear.Name = "btnClear";
            this.btnClear.Size = new System.Drawing.Size(105, 31);
            this.btnClear.TabIndex = 23;
            this.btnClear.Text = "&Clear";
            this.btnClear.UseVisualStyleBackColor = true;
            // 
            // TabMaster
            // 
            this.TabMaster.Appearance = System.Windows.Forms.TabAppearance.FlatButtons;
            this.TabMaster.Controls.Add(this.Massecuite);
            this.TabMaster.Location = new System.Drawing.Point(12, 12);
            this.TabMaster.Multiline = true;
            this.TabMaster.Name = "TabMaster";
            this.TabMaster.SelectedIndex = 0;
            this.TabMaster.Size = new System.Drawing.Size(936, 318);
            this.TabMaster.TabIndex = 26;
            this.TabMaster.SelectedIndexChanged += new System.EventHandler(this.TabMaster_SelectedIndexChanged);
            // 
            // Massecuite
            // 
            this.Massecuite.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(196)))), ((int)(((byte)(171)))), ((int)(((byte)(166)))));
            this.Massecuite.Controls.Add(this.TabChild);
            this.Massecuite.Location = new System.Drawing.Point(4, 28);
            this.Massecuite.Name = "Massecuite";
            this.Massecuite.Padding = new System.Windows.Forms.Padding(3);
            this.Massecuite.Size = new System.Drawing.Size(928, 286);
            this.Massecuite.TabIndex = 0;
            this.Massecuite.Text = "Massecuite";
            this.Massecuite.ToolTipText = "Massecute Entries";
            // 
            // frm_massecuite_transactions
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(958, 366);
            this.Controls.Add(this.TabMaster);
            this.Controls.Add(this.button5);
            this.Controls.Add(this.btnNewRecord);
            this.Controls.Add(this.btnSave);
            this.Controls.Add(this.btnClear);
            this.Name = "frm_massecuite_transactions";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Massecuite & Molassess";
            this.groupBoxAMassecuite.ResumeLayout(false);
            this.groupBoxAMassecuite.PerformLayout();
            this.TabChild.ResumeLayout(false);
            this.tabMassecuiteA.ResumeLayout(false);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.tabMassecuiteA1.ResumeLayout(false);
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.groupBoxA1Massecuite.ResumeLayout(false);
            this.groupBoxA1Massecuite.PerformLayout();
            this.tabMassecuiteB.ResumeLayout(false);
            this.groupBox5.ResumeLayout(false);
            this.groupBox5.PerformLayout();
            this.groupBoxBMassecuite.ResumeLayout(false);
            this.groupBoxBMassecuite.PerformLayout();
            this.tabMassecuiteC1.ResumeLayout(false);
            this.groupBox7.ResumeLayout(false);
            this.groupBox7.PerformLayout();
            this.groupBoxC1Massecuite.ResumeLayout(false);
            this.groupBoxC1Massecuite.PerformLayout();
            this.tabMassecuiteC.ResumeLayout(false);
            this.groupBox9.ResumeLayout(false);
            this.groupBox9.PerformLayout();
            this.groupBoxCMassecuite.ResumeLayout(false);
            this.groupBoxCMassecuite.PerformLayout();
            this.TabMaster.ResumeLayout(false);
            this.Massecuite.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TextBox txtMassA_Pol;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox txtMassA_Purity;
        private System.Windows.Forms.GroupBox groupBoxAMassecuite;
        private System.Windows.Forms.TextBox txtMassA_Brix;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox txtMassA_CrystNo;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txtMassA_DropTime;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txtMassA_StartTime;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtMassA_PanNo;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtMassA_HL;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TabControl TabChild;
        private System.Windows.Forms.TabPage tabMassecuiteA;
        private System.Windows.Forms.TabPage tabMassecuiteB;
        private System.Windows.Forms.TabPage tabMassecuiteC1;
        private System.Windows.Forms.TabPage tabMassecuiteC;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TextBox txtMassA_Tans_Time;
        private System.Windows.Forms.Label lblDate;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.DateTimePicker txtMassA_dateTimeTranDate;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Button btnNewRecord;
        private System.Windows.Forms.Button btnSave;
        private System.Windows.Forms.Button btnClear;
        private System.Windows.Forms.TabControl TabMaster;
        private System.Windows.Forms.TabPage Massecuite;
        private System.Windows.Forms.TabPage tabMassecuiteA1;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.TextBox txtMassA1_Tans_Time;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.DateTimePicker txtMassA1_dateTimeTranDate;
        private System.Windows.Forms.GroupBox groupBoxA1Massecuite;
        private System.Windows.Forms.TextBox txtMassA1_Brix;
        private System.Windows.Forms.TextBox txtMassA1_Purity;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox txtMassA1_CrystNo;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.TextBox txtMassA1_DropTime;
        private System.Windows.Forms.TextBox txtMassA1_Pol;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.TextBox txtMassA1_StartTime;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.TextBox txtMassA1_PanNo;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.TextBox txtMassA1_HL;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.TextBox txtMassB_Tans_Time;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.DateTimePicker txtMassB_dateTimeTranDate;
        private System.Windows.Forms.GroupBox groupBoxBMassecuite;
        private System.Windows.Forms.TextBox txtMassB_Brix;
        private System.Windows.Forms.TextBox txtMassB_Purity;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.TextBox txtMassB_CrystNo;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.TextBox txtMassB_DropTime;
        private System.Windows.Forms.TextBox txtMassB_Pol;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.TextBox txtMassB_StartTime;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.TextBox txtMassB_PanNo;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.TextBox txtMassB_HL;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.GroupBox groupBox7;
        private System.Windows.Forms.TextBox txtMassC1_Tans_Time;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.DateTimePicker txtMassC1_dateTimeTranDate;
        private System.Windows.Forms.GroupBox groupBoxC1Massecuite;
        private System.Windows.Forms.TextBox txtMassC1_Brix;
        private System.Windows.Forms.TextBox txtMassC1_Purity;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.TextBox txtMassC1_CrystNo;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.TextBox txtMassC1_DropTime;
        private System.Windows.Forms.TextBox txtMassC1_Pol;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.TextBox txtMassC1_StartTime;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.TextBox txtMassC1_PanNo;
        private System.Windows.Forms.Label label38;
        private System.Windows.Forms.TextBox txtMassC1_HL;
        private System.Windows.Forms.Label label39;
        private System.Windows.Forms.GroupBox groupBox9;
        private System.Windows.Forms.TextBox txtMassC_Tans_Time;
        private System.Windows.Forms.Label label40;
        private System.Windows.Forms.Label label41;
        private System.Windows.Forms.DateTimePicker txtMassC_dateTimeTranDate;
        private System.Windows.Forms.GroupBox groupBoxCMassecuite;
        private System.Windows.Forms.TextBox txtMassC_Brix;
        private System.Windows.Forms.TextBox txtMassC_Purity;
        private System.Windows.Forms.Label label42;
        private System.Windows.Forms.TextBox txtMassC_CrystNo;
        private System.Windows.Forms.Label label43;
        private System.Windows.Forms.Label label44;
        private System.Windows.Forms.Label label45;
        private System.Windows.Forms.TextBox txtMassC_DropTime;
        private System.Windows.Forms.TextBox txtMassC_Pol;
        private System.Windows.Forms.Label label46;
        private System.Windows.Forms.TextBox txtMassC_StartTime;
        private System.Windows.Forms.Label label47;
        private System.Windows.Forms.TextBox txtMassC_PanNo;
        private System.Windows.Forms.Label label48;
        private System.Windows.Forms.TextBox txtMassC_HL;
        private System.Windows.Forms.Label label49;
    }
}