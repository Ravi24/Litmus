﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Litmus.forms.transactional_forms
{
    public partial class frm_bihourly_transactions : Form
    {
        classes.generalFunctions genFunc = new classes.generalFunctions();
        classes.ExceptionHelper expHelper = new classes.ExceptionHelper();
        classes.master_parameter_logic masterParam = new classes.master_parameter_logic();
        classes.bihourly_entry_logic biHourlyLogic = new classes.bihourly_entry_logic();

        #region Variable declaration
        string entryDate;
        int entryTime;
        int avgDivisor = 1;
        int forEachCounter = 0;
        float nmPrimaryJuiceBrix, nmPrimaryJuicePol, nmPrimaryJuicePurity, omPrimaryJuiceBrix, omPrimaryJuicePol, omPrimaryJuicePurity,
            nmMixedJuiceBrix, nmMixedJuicePol, nmMixedJuicePurity, omMixedJuiceBrix, omMixedJuicePol, omMixedJuicePurity,
            nmLastJuiceBrix, nmLastJuicePol, nmLastJuicePurity, omLastJuiceBrix, omLastJuicePol, omLastJuicePurity,
            filteredJuiceBrix, filteredJuicePol, filteredJuicePh, filteredJuicePurity,
            clearJuiceBrix, clearJuicePol, clearJuicePh, clearJuicePurity,
            unSulphuredSyrupBrix, unSulphuredSyrupPol, unSulphuredSyrupPh, unSulphuredSyrupPurity,
            sulphuredSyrupBrix, sulphuredSyrupPol, sulphuredSyrupPh, sulphuredSyrupPurity,
            finalMolassesBrix, finalMolassesPol, finalMolassesTemp, finalMolassesNoOfTanks, finalMolassesPurity,
            bagassNmPol, bagassNmMoisture, bagassOmPol, bagassOmMoisture,
            pressCakeSample1, pressCakeSample2, pressCakeSample3, pressCakeSample4, pressCakeSample5, pressCakeSampleAverage, pressCakeMoisture, pressCakeComposite,
            uncrushedCane, crushedCane;
        int standingTrucks, standingTrolley, statndingTripler, standingCart;

        IDictionary<char, string> dictFormMode = new Dictionary<char, string>();
        string formMode;
        #endregion

        public frm_bihourly_transactions()
        {
            InitializeComponent();
            masterParam.setParameters(); // setting parameters at the time of loading the form
            textBoxLoosingFocus(); // text box loosing focuse to calculate average of filtered Mud
            dateTimeTranDate.Text = masterParam.entryDate;
            biHourlyLogic.CurrentEntryTime(masterParam.entryDate);
            txtTime.Text = biHourlyLogic.entryTime.ToString();
 
            groupBoxControlsLoosingFocus();

            dictFormMode.Add('c', "create");
            dictFormMode.Add('r', "read");
            dictFormMode.Add('u', "update");
            dictFormMode.Add('d', "delete");

            formMode = dictFormMode['c'].ToString();
            
            user_rights_controller(); // checking user rights 
        }
        #region Clear/Enable/Disable TextBoxes & Reset form
        public void enableTextBoxes()
        {
            txtOmLastJuicePol.Enabled = true;
            txtOmLastJuiceBrix.Enabled = true;
            txtNmLastJuicePol.Enabled = true;
            txtNmLastJuiceBrix.Enabled = true;
            txtOmMixedJuicePol.Enabled = true;
            txtOmMixedJuiceBrix.Enabled = true;
            txtNmMixedJuicePol.Enabled = true;
            txtNmMixedJuiceBrix.Enabled = true;
            txtOmPrimaryJuicePol.Enabled = true;
            txtOmPrimaryJuiceBrix.Enabled = true;
            txtNmPrimaryJuicePol.Enabled = true;
            txtNmPrimaryJuiceBrix.Enabled = true;
            txtFinalMolassesPol.Enabled = true;
            txtFinalMolassesBrix.Enabled = true;
            txtSulphuredSyrupPol.Enabled = true;
            txtSulphuredSyrupBrix.Enabled = true;
            txtUnsulphuredSyrupPol.Enabled = true;
            txtUnsulphuredSyrupBrix.Enabled = true;
            txtClearJuicePol.Enabled = true;
            txtClearJuiceBrix.Enabled = true;
            txtOliverFilteredPol.Enabled = true;
            txtOliverFilteredBirx.Enabled = true;
            txtFinalMolassesTanks.Enabled = true;
            txtFinalMolassesTemp.Enabled = true;
            txtSulphuredSyrupPh.Enabled = true;
            txtUnsulphuredSyrupPh.Enabled = true;
            txtClearJuicePh.Enabled = true;
            txtOliverFilteredPh.Enabled = true;
            txtOmBagassPol.Enabled = true;
            txtBagassNmMoisture.Enabled = true;
            txtFilteMudSample2.Enabled = true;
            txtFilteMudSample1.Enabled = true;
            txtFilteMudSample5.Enabled = true;
            txtFilteMudSample4.Enabled = true;
            txtFilteMudSample3.Enabled = true;
            txtBagasseNmPol.Enabled = true;
            txtOmMoisture.Enabled = true;
            txtFilteMudComposite.Enabled = true;
            txtFilteMudMoisture.Enabled = true;
            txtCaneCrushed.Enabled = true;
            txtUncrushedCane.Enabled = true;
            txtStandingCarts.Enabled = true;
            txtStandingTripplers.Enabled = true;
            txtStandingTrolleys.Enabled = true;
            txtStandingTrucks.Enabled = true;
            
            
            user_rights_controller();
        }
        public void disableTextBoxes()
        {
            txtOmLastJuicePol.Enabled = false;
            txtOmLastJuiceBrix.Enabled = false;
            txtNmLastJuicePol.Enabled = false;
            txtNmLastJuiceBrix.Enabled = false;
            txtOmMixedJuicePol.Enabled = false;
            txtOmMixedJuiceBrix.Enabled = false;
            txtNmMixedJuicePol.Enabled = false;
            txtNmMixedJuiceBrix.Enabled = false;
            txtOmPrimaryJuicePol.Enabled = false;
            txtOmPrimaryJuiceBrix.Enabled = false;
            txtNmPrimaryJuicePol.Enabled = false;
            txtNmPrimaryJuiceBrix.Enabled = false;
            txtFinalMolassesPol.Enabled = false;
            txtFinalMolassesBrix.Enabled = false;
            txtSulphuredSyrupPol.Enabled = false;
            txtSulphuredSyrupBrix.Enabled = false;
            txtUnsulphuredSyrupPol.Enabled = false;
            txtUnsulphuredSyrupBrix.Enabled = false;
            txtClearJuicePol.Enabled = false;
            txtClearJuiceBrix.Enabled = false;
            txtOliverFilteredPol.Enabled = false;
            txtOliverFilteredBirx.Enabled = false;
            txtFinalMolassesTanks.Enabled = false;
            txtFinalMolassesTemp.Enabled = false;
            txtSulphuredSyrupPh.Enabled = false;
            txtUnsulphuredSyrupPh.Enabled = false;
            txtClearJuicePh.Enabled = false;
            txtOliverFilteredPh.Enabled = false;
            txtOmBagassPol.Enabled = false;
            txtBagassNmMoisture.Enabled = false;
            txtFilteMudSample2.Enabled = false;
            txtFilteMudSample1.Enabled = false;
            txtFilteMudSample5.Enabled = false;
            txtFilteMudSample4.Enabled = false;
            txtFilteMudSample3.Enabled = false;
            txtBagasseNmPol.Enabled = false;
            txtOmMoisture.Enabled = false;
            txtFilteMudComposite.Enabled = false;
            txtFilteMudMoisture.Enabled = false;
            txtCaneCrushed.Enabled = false;
            txtUncrushedCane.Enabled = false;
            txtStandingCarts.Enabled = false;
            txtStandingTripplers.Enabled = false;
            txtStandingTrolleys.Enabled = false;
            txtStandingTrucks.Enabled    = false;

            user_rights_controller();
        }
        public void resetForm()
        {
            dateTimeTranDate.Text = masterParam.entryDate;
            txtTime.Text = biHourlyLogic.entryTime.ToString();
            dateTimeTranDate.Enabled = false;
            txtTime.Enabled = false;
            txtOmLastJuicePol.Text = "0";
            txtOmLastJuiceBrix.Text = "0";
            txtNmLastJuicePol.Text = "0";
            txtNmLastJuiceBrix.Text = "0";
            txtOmMixedJuicePol.Text = "0";
            txtOmMixedJuiceBrix.Text = "0";
            txtNmMixedJuicePol.Text = "0";
            txtNmMixedJuiceBrix.Text = "0";
            txtOmPrimaryJuicePol.Text = "0";
            txtOmPrimaryJuiceBrix.Text = "0";
            txtNmPrimaryJuicePol.Text = "0";
            txtNmPrimaryJuiceBrix.Text = "0";
            txtFinalMolassesPol.Text = "0";
            txtFinalMolassesBrix.Text = "0";
            txtSulphuredSyrupPol.Text = "0";
            txtSulphuredSyrupBrix.Text = "0";
            txtUnsulphuredSyrupPol.Text = "0";
            txtUnsulphuredSyrupBrix.Text = "0";
            txtClearJuicePol.Text = "0";
            txtClearJuiceBrix.Text = "0";
            txtOliverFilteredPol.Text = "0";
            txtOliverFilteredBirx.Text = "0";
            txtFinalMolassesTanks.Text = "0";
            txtFinalMolassesTemp.Text = "0";
            txtSulphuredSyrupPh.Text = "0";
            txtUnsulphuredSyrupPh.Text = "0";
            txtClearJuicePh.Text = "0";
            txtOliverFilteredPh.Text = "0";
            txtOmBagassPol.Text = "0";
            txtBagassNmMoisture.Text = "0";
            txtFilteMudSample2.Text = "0";
            txtFilteMudSample1.Text = "0";
            txtFilteMudSample5.Text = "0";
            txtFilteMudSample4.Text = "0";
            txtFilteMudSample3.Text = "0";
            txtBagasseNmPol.Text = "0";
            txtOmMoisture.Text = "0";
            txtFilteMudComposite.Text = "0";
            txtFilteMudMoisture.Text = "0";
            txtCaneCrushed.Text = "0";
            txtUncrushedCane.Text = "0";
            txtStandingCarts.Text = "0";
            txtStandingTripplers.Text = "0";
            txtStandingTrolleys.Text = "0";
            txtStandingTrucks.Text = "0";
            txtFilteMudAverage.Text = "0";
            txtNmPrimaryJuicePurity.Text = "0";
            txtOmPrimaryJuicePurity.Text = "0";
            txtNmMixedJuicePurity.Text = "0";
            txtOmMixedJuicePurity.Text = "0";
            txtNmLastJuicePurity.Text = "0";
            txtOmLastJuicePurity.Text = "0";
            txtOliverFilteredPurity.Text = "0";
            txtClearJuicePurity.Text = "0";
            txtUnsulphuredSyrupPurity.Text = "0";
            txtSulphuredSyrupPurity.Text = "0";
            txtFinalMolassesPurity.Text = "0";

            btnSave.Text = "&Save";
            btnNewRecord.Enabled = true;
            disableTextBoxes();
        }
        #endregion

        #region calculate average of press cake samples 

        private void calculate_press_cake_sample_average(object sender, EventArgs e)
        {
            Control tb = (TextBox)sender;
            float[] sampleValues = new float[5];

            tb.KeyDown += new KeyEventHandler(moveToNextTextBox);
            //if (genFunc.forceNumericValue(tb) == true)
            {
                try
                {
                    pressCakeSample1 = float.Parse(txtFilteMudSample1.Text);
                    pressCakeSample2 = float.Parse(txtFilteMudSample2.Text);
                    pressCakeSample3 = float.Parse(txtFilteMudSample3.Text);
                    pressCakeSample4 = float.Parse(txtFilteMudSample4.Text);
                    pressCakeSample5 = float.Parse(txtFilteMudSample5.Text);

                    sampleValues[0] = pressCakeSample1;
                    sampleValues[1] = pressCakeSample2;
                    sampleValues[2] = pressCakeSample3;
                    sampleValues[3] = pressCakeSample4;
                    sampleValues[4] = pressCakeSample5;

                    avgDivisor = sampleValues.Count(i => i != 0);
                    if(avgDivisor.GetType() != typeof(int))
                    {
                        avgDivisor = 1;
                    }
                    pressCakeSampleAverage = (pressCakeSample1 + pressCakeSample2 + pressCakeSample3 + pressCakeSample4 + pressCakeSample5) / avgDivisor;
                    if (pressCakeSampleAverage.GetType() != typeof(int) && pressCakeSampleAverage <= 0)
                    {
                        pressCakeSampleAverage = 0;
                    }
                    txtFilteMudAverage.Text = pressCakeSampleAverage.ToString();
                    
                }
                   
                catch (Exception ex)
                {
                    MessageBox.Show("Invalid numeric value \n" + ex.Message, "Invalid input", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                }
            }
        }
        #endregion

        #region group boxes controls loosing focus---- to events, when to calculate purity
        private void groupBoxControlsLoosingFocus()
        {
            foreach (Control parentCtrl in groupBox1.Controls)
            {
                if (parentCtrl.GetType() == typeof(GroupBox))
                {
                    foreach (Control ctrl in parentCtrl.Controls)
                    {
                        if (ctrl.GetType() == typeof(TextBox))
                        {
                            ctrl.KeyDown += new KeyEventHandler(moveToNextTextBox);
                            ctrl.LostFocus += new EventHandler(groupBoxEvent);
                            
                        }
                    }
                }
            }

            foreach (Control parentCtrl in groupBox3.Controls)
            {
                if (parentCtrl.GetType() == typeof(GroupBox))
                {
                    foreach (Control ctrl in parentCtrl.Controls)
                    {
                       // if (ctrl.GetType() == typeof(TextBox) && genFunc.forceNumericValue(ctrl) == true)
                       // {
                        ctrl.KeyDown += new KeyEventHandler(moveToNextTextBox);
                            ctrl.LostFocus += new EventHandler(groupBoxEvent);
                        //}
                    }
                }
            }

            foreach (Control ctrl in groupBoxBagasse.Controls) // top panel
            {
                foreach (Control ctrlChild in ctrl.Controls) // second panels 
                {
                    if (ctrlChild.GetType() == typeof(TextBox))
                    {
                        ctrlChild.KeyDown += new KeyEventHandler(moveToNextTextBox);
                    }
                }
            }
            foreach (Control ctrl in groupBoxCaneStatus.Controls)
            {
                if(ctrl.GetType() == typeof(TextBox))
                {
                    ctrl.KeyDown += new KeyEventHandler(moveToNextTextBox);
                }
            }
        }
        #endregion
        /// <summary>
        /// if user press enter key, Move to next textbox 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void moveToNextTextBox(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                this.SelectNextControl((Control)sender, true, true, true, true);
                e.Handled = e.SuppressKeyPress = true;
            }
        }

        #region Text box loosing focus events -- in press cake control box
        private void textBoxLoosingFocus()
        {
            foreach (Control ctrl in groupBoxPolPressCake.Controls)
            {
                if (ctrl.GetType() == typeof(TextBox) && ctrl.Name.Contains("Sample"))
                {
                    ctrl.LostFocus += new EventHandler(calculate_press_cake_sample_average);
                }
                ctrl.KeyDown += new KeyEventHandler(moveToNextTextBox);
            }
        }
        #endregion

        public string getExpectedEntryUniqueCode()
        {
            return masterParam.entryDate + txtTime.Text;

        }

        private void calculate_purity()
        {
            nmPrimaryJuicePurity = genFunc.calculate_purity(nmPrimaryJuicePol, nmPrimaryJuiceBrix);
            txtNmPrimaryJuicePurity.Text = nmPrimaryJuicePurity.ToString();
            
            omPrimaryJuicePurity = genFunc.calculate_purity(omPrimaryJuicePol, omPrimaryJuiceBrix);
            txtOmPrimaryJuicePurity.Text = omPrimaryJuicePurity.ToString();

            nmMixedJuicePurity = genFunc.calculate_purity(nmMixedJuicePol, nmMixedJuiceBrix);
            txtNmMixedJuicePurity.Text = nmMixedJuicePurity.ToString();

            omMixedJuicePurity = genFunc.calculate_purity(omMixedJuicePol, omMixedJuiceBrix);
            txtOmMixedJuicePurity.Text = omMixedJuicePurity.ToString();

            nmLastJuicePurity = genFunc.calculate_purity(nmLastJuicePol, nmLastJuiceBrix);
            txtNmLastJuicePurity.Text = nmLastJuicePurity.ToString();

            omLastJuicePurity = genFunc.calculate_purity(omLastJuicePol, omLastJuiceBrix);
            txtOmLastJuicePurity.Text = omLastJuicePurity.ToString();

            filteredJuicePurity = genFunc.calculate_purity(filteredJuicePol, filteredJuiceBrix);
            txtOliverFilteredPurity.Text = filteredJuicePurity.ToString();

            clearJuicePurity = genFunc.calculate_purity(clearJuicePol, clearJuiceBrix);
            txtClearJuicePurity.Text = clearJuicePurity.ToString();

            unSulphuredSyrupPurity = genFunc.calculate_purity(unSulphuredSyrupPol, unSulphuredSyrupBrix);
            txtUnsulphuredSyrupPurity.Text = unSulphuredSyrupPurity.ToString();

            sulphuredSyrupPurity = genFunc.calculate_purity(sulphuredSyrupPol, sulphuredSyrupBrix);
            txtSulphuredSyrupPurity.Text = sulphuredSyrupPurity.ToString();

            finalMolassesPurity = genFunc.calculate_purity(finalMolassesPol, finalMolassesBrix);
            txtFinalMolassesPurity.Text = finalMolassesPurity.ToString();
        }
        private void groupBoxEvent(object sender, EventArgs e)
        {
            Control tb = (TextBox)sender;
            //if (genFunc.forceNumericValue(tb) == true)
            {
                try
                {
                    nmPrimaryJuicePol = float.Parse(txtNmPrimaryJuicePol.Text);
                    nmPrimaryJuiceBrix = float.Parse(txtNmPrimaryJuiceBrix.Text);

                    omPrimaryJuicePol = float.Parse(txtOmPrimaryJuicePol.Text);
                    omPrimaryJuiceBrix = float.Parse(txtOmPrimaryJuiceBrix.Text);

                    nmMixedJuiceBrix = float.Parse(txtNmMixedJuiceBrix.Text);
                    nmMixedJuicePol = float.Parse(txtNmMixedJuicePol.Text);

                    omMixedJuiceBrix = float.Parse(txtOmMixedJuiceBrix.Text);
                    omMixedJuicePol = float.Parse(txtOmMixedJuicePol.Text);

                    nmLastJuicePol = float.Parse(txtNmLastJuicePol.Text);
                    nmLastJuiceBrix = float.Parse(txtNmLastJuiceBrix.Text);

                    omLastJuicePol = float.Parse(txtOmLastJuicePol.Text);
                    omLastJuiceBrix = float.Parse(txtOmLastJuiceBrix.Text);

                    filteredJuicePol = float.Parse(txtOliverFilteredPol.Text);
                    filteredJuiceBrix = float.Parse(txtOliverFilteredBirx.Text);

                    clearJuicePol = float.Parse(txtClearJuicePol.Text);
                    clearJuiceBrix = float.Parse(txtClearJuiceBrix.Text);

                    unSulphuredSyrupPol = float.Parse(txtUnsulphuredSyrupPol.Text);
                    unSulphuredSyrupBrix = float.Parse(txtUnsulphuredSyrupBrix.Text);

                    sulphuredSyrupPol = float.Parse(txtSulphuredSyrupPol.Text);
                    sulphuredSyrupBrix = float.Parse(txtSulphuredSyrupBrix.Text);

                    finalMolassesPol = float.Parse(txtFinalMolassesPol.Text);
                    finalMolassesBrix = float.Parse(txtFinalMolassesBrix.Text);

                    calculate_purity();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Invalid numeric value \n"+ex.Message, "Invalid input", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                }
            }
        }
        #region Buttons Click Events
        private void btnNewRecord_Click(object sender, EventArgs e)
        {
            if (biHourlyLogic.isHourlyTransactionEntryPossible(dateTimeTranDate.Text, txtTime.Text) == true)
            {
                enableTextBoxes();
                txtNmPrimaryJuiceBrix.Focus();
            }
            else
            {
                MessageBox.Show("Entry for this date and time is not possible.\nKindly contact admin and ask to change Entry date parameter", "Entry not allowed", MessageBoxButtons.OK, MessageBoxIcon.Hand);
            }
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            resetForm();
        }
        #endregion

        private void btnSave_Click(object sender, EventArgs e)
        {
            try
            {
                assign_values();
                if (formMode == dictFormMode['c'].ToString())
                {
                DialogResult dialogResult = MessageBox.Show("Are you sure to save data?", "Save data?", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                if (dialogResult == DialogResult.Yes)
                {

                    int i = biHourlyLogic.insertTwoHourlyData(entryDate, entryTime, nmPrimaryJuiceBrix, nmPrimaryJuicePol, nmPrimaryJuicePurity, omPrimaryJuiceBrix,
                        omPrimaryJuicePol, omPrimaryJuicePurity, nmMixedJuiceBrix, nmMixedJuicePol, nmMixedJuicePurity, omMixedJuiceBrix, omMixedJuicePol, omMixedJuicePurity,
                        nmLastJuiceBrix, nmLastJuicePol, nmLastJuicePurity, omLastJuiceBrix, omLastJuicePol, omLastJuicePurity, filteredJuiceBrix, filteredJuicePol,
                        filteredJuicePh, filteredJuicePurity, clearJuiceBrix, clearJuicePol, clearJuicePh, clearJuicePurity,
                        unSulphuredSyrupBrix, unSulphuredSyrupPol, unSulphuredSyrupPh, unSulphuredSyrupPurity, sulphuredSyrupBrix, sulphuredSyrupPol,
                        sulphuredSyrupPh, sulphuredSyrupPurity, finalMolassesBrix, finalMolassesPol, finalMolassesTemp, finalMolassesNoOfTanks,
                        finalMolassesPurity, bagassNmPol, bagassNmMoisture, bagassOmPol, bagassOmMoisture, pressCakeSample1, pressCakeSample2,
                        pressCakeSample3, pressCakeSample4, pressCakeSample5, pressCakeSampleAverage, pressCakeMoisture, pressCakeComposite,
                        uncrushedCane, crushedCane, standingTrucks, standingTrolley, statndingTripler, standingCart);

                    MessageBox.Show(i + " Record inserted", "Data inserted", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    if (i > 0)
                    {
                        txtTime.Text = biHourlyLogic.entryTime.ToString();
                        resetForm();
                        disableTextBoxes();
                        getExpectedEntryUniqueCode();
                        if (biHourlyLogic.isHourlyTransactionEntryPossible(dateTimeTranDate.Text, txtTime.Text) == false)
                        {
                            MessageBox.Show("Entry for this date and time is not possible.\nKindly contact admin and ask to change Entry date parameter", "Entry not allowed", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                            disableTextBoxes();
                        }
                    }
                }
                }
                else if(formMode == dictFormMode['u'].ToString())
                {
                    DialogResult dialogResultUpdate = MessageBox.Show("Are you sure to update data?", "Update data?", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                    if (dialogResultUpdate == DialogResult.Yes)
                    {
                        int updated_record_count = biHourlyLogic.updateTwoHourlyData(
                         entryDate, entryTime, nmPrimaryJuiceBrix, nmPrimaryJuicePol, nmPrimaryJuicePurity, omPrimaryJuiceBrix,
                        omPrimaryJuicePol, omPrimaryJuicePurity, nmMixedJuiceBrix, nmMixedJuicePol, nmMixedJuicePurity, omMixedJuiceBrix, omMixedJuicePol, omMixedJuicePurity,
                        nmLastJuiceBrix, nmLastJuicePol, nmLastJuicePurity, omLastJuiceBrix, omLastJuicePol, omLastJuicePurity, filteredJuiceBrix, filteredJuicePol,
                        filteredJuicePh, filteredJuicePurity, clearJuiceBrix, clearJuicePol, clearJuicePh, clearJuicePurity,
                        unSulphuredSyrupBrix, unSulphuredSyrupPol, unSulphuredSyrupPh, unSulphuredSyrupPurity, sulphuredSyrupBrix, sulphuredSyrupPol,
                        sulphuredSyrupPh, sulphuredSyrupPurity, finalMolassesBrix, finalMolassesPol, finalMolassesTemp, finalMolassesNoOfTanks,
                        finalMolassesPurity, bagassNmPol, bagassNmMoisture, bagassOmPol, bagassOmMoisture, pressCakeSample1, pressCakeSample2,
                        pressCakeSample3, pressCakeSample4, pressCakeSample5, pressCakeSampleAverage, pressCakeMoisture, pressCakeComposite,
                        uncrushedCane, crushedCane, standingTrucks, standingTrolley, statndingTripler, standingCart
                        );

                        switch (updated_record_count)
                        {
                            case 0:
                                MessageBox.Show("No  record update", "Failed", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                                break;
                            case 1: MessageBox.Show("Record update", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                                break;
                            default:
                                MessageBox.Show("More than one record updated.\nContact administrator.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                                break;

                        }


                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show( "Unable to save data\n"+ ex.Message, "Error Occured!!", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                expHelper.statusMsg = "ERROR occured while saving two hourly transaction\n" + ex.StackTrace;
            }
        }


        protected void assign_values()
        {
            entryDate = dateTimeTranDate.Text;
            entryTime = Convert.ToInt16(txtTime.Text);
            
            nmPrimaryJuicePol = float.Parse(txtNmPrimaryJuicePol.Text);
            nmPrimaryJuiceBrix = float.Parse(txtNmPrimaryJuiceBrix.Text);

            omPrimaryJuicePol = float.Parse(txtOmPrimaryJuicePol.Text);
            omPrimaryJuiceBrix = float.Parse(txtOmPrimaryJuiceBrix.Text);

            nmMixedJuiceBrix = float.Parse(txtNmMixedJuiceBrix.Text);
            nmMixedJuicePol = float.Parse(txtNmMixedJuicePol.Text);

            omMixedJuiceBrix = float.Parse(txtOmMixedJuiceBrix.Text);
            omMixedJuicePol = float.Parse(txtOmMixedJuicePol.Text);

            nmLastJuicePol = float.Parse(txtNmLastJuicePol.Text);
            nmLastJuiceBrix = float.Parse(txtNmLastJuiceBrix.Text);

            omLastJuicePol = float.Parse(txtOmLastJuicePol.Text);
            omLastJuiceBrix = float.Parse(txtOmLastJuiceBrix.Text);

            filteredJuicePol = float.Parse(txtOliverFilteredPol.Text);
            filteredJuiceBrix = float.Parse(txtOliverFilteredBirx.Text);

            clearJuicePol = float.Parse(txtClearJuicePol.Text);
            clearJuiceBrix = float.Parse(txtClearJuiceBrix.Text);

            unSulphuredSyrupPol = float.Parse(txtUnsulphuredSyrupPol.Text);
            unSulphuredSyrupBrix = float.Parse(txtUnsulphuredSyrupBrix.Text);

            sulphuredSyrupPol = float.Parse(txtSulphuredSyrupPol.Text);
            sulphuredSyrupBrix = float.Parse(txtSulphuredSyrupBrix.Text);

            finalMolassesPol = float.Parse(txtFinalMolassesPol.Text);
            finalMolassesBrix = float.Parse(txtFinalMolassesBrix.Text);
            filteredJuicePh = float.Parse(txtOliverFilteredPh.Text);
            clearJuicePh = float.Parse(txtClearJuicePh.Text);
            unSulphuredSyrupPh = float.Parse(txtUnsulphuredSyrupPh.Text);
            sulphuredSyrupPh = float.Parse(txtSulphuredSyrupPh.Text);
            
            finalMolassesTemp = float.Parse(txtFinalMolassesTemp.Text);
            finalMolassesNoOfTanks = float.Parse(txtFinalMolassesTanks.Text);
            bagassNmPol = float.Parse(txtBagasseNmPol.Text);
            bagassNmMoisture = float.Parse(txtBagassNmMoisture.Text);
            bagassOmPol = float.Parse(txtOmBagassPol.Text);
            bagassOmMoisture = float.Parse(txtOmMoisture.Text);
            pressCakeSample1 = float.Parse(txtFilteMudSample1.Text);
            pressCakeSample2 = float.Parse(txtFilteMudSample2.Text);
            pressCakeSample3 = float.Parse(txtFilteMudSample3.Text);
            pressCakeSample4 = float.Parse(txtFilteMudSample4.Text);
            pressCakeSample5 = float.Parse(txtFilteMudSample5.Text);
            pressCakeSampleAverage = float.Parse(txtFilteMudAverage.Text);

            pressCakeMoisture = float.Parse(txtFilteMudMoisture.Text);
            pressCakeComposite = float.Parse(txtFilteMudComposite.Text);
            uncrushedCane = float.Parse(txtUncrushedCane.Text);
            crushedCane = float.Parse(txtCaneCrushed.Text);

            standingTrucks = Convert.ToInt16(txtStandingTrucks.Text);
            statndingTripler = Convert.ToInt16(txtStandingTripplers.Text);
            standingTrolley = Convert.ToInt16(txtStandingTrolleys.Text);
            standingCart = Convert.ToInt16(txtStandingCarts.Text);
            
            // calculate purity only after assigning all values otherwise purity may be wrong.
            calculate_purity();
        }
        private void btnModify_Click(object sender, EventArgs e)
        {
            
            formMode = dictFormMode['u'].ToString();
            btnSave.Text = "&Update";
            //enableTextBoxes();
            disableTextBoxes();
           
            btnNewRecord.Enabled = false;
            btnModify.Enabled = false;
            dateTimeTranDate.Enabled = true;
            txtTime.Enabled = true;
            txtTime.TabStop = true;
            txtTime.Focus();
            txtTime.SelectAll();
            txtTime.LostFocus += new EventHandler(txtTimeLostFocus);
        }
        protected void txtTimeLostFocus(object sender, EventArgs e)
        {
            entryDate = dateTimeTranDate.Text;
            entryTime = Convert.ToInt16(txtTime.Text);
            DataTable dt = biHourlyLogic.getTwoHourlyData(entryDate, entryTime);
            if (dt.Rows.Count > 0)
            {
                enableTextBoxes();
                btnModify.Enabled = false;
                btnSave.Enabled = true;
                txtNmPrimaryJuiceBrix.Text = dt.Rows[0]["nm_primary_juice_brix"].ToString();
                txtNmPrimaryJuicePol.Text = dt.Rows[0]["nm_primary_juice_pol"].ToString();
                txtNmPrimaryJuicePurity.Text = dt.Rows[0]["nm_primary_juice_purity"].ToString();

                txtOmPrimaryJuiceBrix.Text = dt.Rows[0]["om_primary_juice_brix"].ToString();
                txtOmPrimaryJuicePol.Text = dt.Rows[0]["om_primary_juice_pol"].ToString();
                txtOmPrimaryJuicePurity.Text = dt.Rows[0]["om_primary_juice_purity"].ToString();

                txtNmMixedJuiceBrix.Text = dt.Rows[0]["nm_mixed_juice_brix"].ToString();
                txtNmMixedJuicePol.Text = dt.Rows[0]["nm_mixed_juice_pol"].ToString();
                txtNmMixedJuicePurity.Text = dt.Rows[0]["nm_mixed_juice_purity"].ToString();

                txtOmMixedJuiceBrix.Text = dt.Rows[0]["om_mixed_juice_brix"].ToString();
                txtOmMixedJuicePol.Text = dt.Rows[0]["om_mixed_juice_pol"].ToString();
                txtOmMixedJuicePurity.Text = dt.Rows[0]["om_mixed_juice_purity"].ToString();

                txtNmLastJuiceBrix.Text = dt.Rows[0]["nm_last_juice_brix"].ToString();
                txtNmLastJuicePol.Text = dt.Rows[0]["nm_last_juice_pol"].ToString();
                txtNmLastJuicePurity.Text = dt.Rows[0]["nm_last_juice_purity"].ToString();

                txtOmLastJuiceBrix.Text = dt.Rows[0]["om_last_juice_brix"].ToString();
                txtOmLastJuicePol.Text = dt.Rows[0]["om_last_juice_pol"].ToString();
                txtOmLastJuicePurity.Text = dt.Rows[0]["om_last_juice_purity"].ToString();

                txtOliverFilteredBirx.Text = dt.Rows[0]["oliver_juice_brix"].ToString();
                txtOliverFilteredPol.Text = dt.Rows[0]["oliver_juice_pol"].ToString();
                txtOliverFilteredPh.Text = dt.Rows[0]["oliver_juice_ph"].ToString();
                txtOliverFilteredPurity.Text = dt.Rows[0]["oliver_juice_purity"].ToString();

                txtClearJuiceBrix.Text = dt.Rows[0]["clear_juice_brix"].ToString();
                txtClearJuicePol.Text = dt.Rows[0]["clear_juice_pol"].ToString();
                txtClearJuicePh.Text = dt.Rows[0]["clear_juice_ph"].ToString();
                txtClearJuicePurity.Text = dt.Rows[0]["clear_juice_purity"].ToString();

                txtUnsulphuredSyrupBrix.Text = dt.Rows[0]["unsulphured_syrup_brix"].ToString();
                txtUnsulphuredSyrupPol.Text = dt.Rows[0]["unsulphured_syrup_pol"].ToString();
                txtUnsulphuredSyrupPh.Text = dt.Rows[0]["unsulphured_syrup_ph"].ToString();
                txtUnsulphuredSyrupPurity.Text = dt.Rows[0]["unsulphured_syrup_purity"].ToString();

                txtSulphuredSyrupBrix.Text = dt.Rows[0]["sulphured_syrup_brix"].ToString();
                txtSulphuredSyrupPol.Text = dt.Rows[0]["sulphured_syrup_pol"].ToString();
                txtSulphuredSyrupPurity.Text = dt.Rows[0]["sulphured_syrup_purity"].ToString();
                txtSulphuredSyrupPh.Text = dt.Rows[0]["sulphured_syrup_ph"].ToString();

                txtFinalMolassesBrix.Text = dt.Rows[0]["final_molasses_brix"].ToString();
                txtFinalMolassesPol.Text = dt.Rows[0]["final_molasses_pol"].ToString();
                txtFinalMolassesPurity.Text = dt.Rows[0]["final_molasses_purity"].ToString();
                txtFinalMolassesTemp.Text = dt.Rows[0]["final_molasses_temp"].ToString();
                txtFinalMolassesTanks.Text = dt.Rows[0]["final_molasses_tanks"].ToString();

                txtBagasseNmPol.Text = dt.Rows[0]["nm_bagasse_pol"].ToString();
                txtBagassNmMoisture.Text = dt.Rows[0]["nm_bagasse_moisture"].ToString();
                txtOmBagassPol.Text = dt.Rows[0]["om_bagasse_pol"].ToString();
                txtOmMoisture.Text = dt.Rows[0]["om_bagasse_moisture"].ToString();

                txtFilteMudSample1.Text = dt.Rows[0]["pol_pressure_cake_sample1"].ToString();
                txtFilteMudSample2.Text = dt.Rows[0]["pol_pressure_cake_sample2"].ToString();
                txtFilteMudSample3.Text = dt.Rows[0]["pol_pressure_cake_sample3"].ToString();
                txtFilteMudSample4.Text = dt.Rows[0]["pol_pressure_cake_sample4"].ToString();
                txtFilteMudSample5.Text = dt.Rows[0]["pol_pressure_cake_sample5"].ToString();
                txtFilteMudAverage.Text = dt.Rows[0]["pol_pressure_cake_average"].ToString();
                txtFilteMudMoisture.Text = dt.Rows[0]["pol_pressure_cake_moisture"].ToString();
                txtFilteMudComposite.Text = dt.Rows[0]["pol_pressure_cake_composite"].ToString();

                txtStandingTrucks.Text = dt.Rows[0]["standing_trucks"].ToString();
                txtStandingCarts.Text = dt.Rows[0]["standing_cart"].ToString();
                txtStandingTrolleys.Text = dt.Rows[0]["standing_trolleys"].ToString();
                txtStandingTripplers.Text = dt.Rows[0]["standing_triplers"].ToString();
                txtUncrushedCane.Text = dt.Rows[0]["uncrushed_cane"].ToString();
                txtCaneCrushed.Text = dt.Rows[0]["crushed_cane"].ToString();
            }
            else
            {
                disableTextBoxes();
                MessageBox.Show("No record exist for selected date and time", "No record!", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                btnSave.Enabled = false;
                dateTimeTranDate.Focus();
            }
            
        }
        protected void user_rights_controller()
        {
            foreach (char c in genFunc.userRights)
            {
                switch (c)
                {
                    case 'C':
                        btnNewRecord.Enabled = true;
                        btnSave.Enabled = true;
                        break;
                    case 'R':
                        this.Enabled = true;
                        break;
                    case 'U':
                        btnModify.Enabled = true;
                        break;
                    case 'D':
                        break;
                    default:
                        btnNewRecord.Enabled = false;
                        btnModify.Enabled = false;
                        btnModify.Enabled = false;
                        MessageBox.Show("User do not have any rights", "No rights assigned", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        break;
                }
            }
        }
        
       
    }
}
