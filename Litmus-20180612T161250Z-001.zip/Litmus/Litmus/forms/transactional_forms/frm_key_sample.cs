﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Litmus.classes;
namespace Litmus.forms.transactional_forms
{
    public partial class frm_key_sample : Form
    {
        classes.generalFunctions genFunc = new classes.generalFunctions();
        classes.ExceptionHelper expHelper = new classes.ExceptionHelper();
        classes.key_sampe_logic keySampleLogic = new classes.key_sampe_logic();
        master_parameter_logic masterParam = new master_parameter_logic();

    

        float samplePurity = 0;
        float pol = 0;
        float brix = 0;
        int panNo;
        string transDate, transTime, userCode, sugar_stage;
        public frm_key_sample()
        {
            InitializeComponent();
            btnSave.GotFocus += new EventHandler(setFormVariables);
            txtTime.LostFocus += new EventHandler(checkInputTime);
            genFunc.disableFieldsInControl(groupBoxKeySample);
           
            txt_TranDate.Text = masterParam.entryDate;
            bindSugarStage();
           
            this.FormClosing += new FormClosingEventHandler(formClosingEvent);
        }
        private void formClosingEvent(object sender, FormClosingEventArgs e)
        {
            if (e.CloseReason == CloseReason.UserClosing)
            {   
                
            }
            if (e.CloseReason == CloseReason.WindowsShutDown)
            {
                MessageBox.Show("Litmus application is running, please save all data and exit application first", "Save your data first", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                string command = "shutdown /a";
                System.Diagnostics.Process.Start(command);
            }
        }
        private void checkInputTime(object sender, EventArgs e)
        {
            txtTime.Text = genFunc.parseHourMinuteFormat(txtTime.Text);
            genFunc.validate_hours_minutes(txtTime, btnSave);
        }
        public void setFormVariables(object sender, EventArgs e)
        {
            
            genFunc.forceNumericValue(txtPanNo);
            genFunc.ValidateTextBoxNotEmpty(txtSugarStage, btnSave);
            genFunc.validate_purity_percentage(txtPurity, btnSave);
            pol = float.Parse(txtPol.Text);
            brix = float.Parse(txtBrix.Text);
            samplePurity = genFunc.calculate_purity(pol, brix);
            txtPurity.Text = samplePurity.ToString();
            panNo = Int16.Parse(txtPanNo.Text);
            transDate = txt_TranDate.Text;
            transTime = txtTime.Text;
            userCode = genFunc.userCode;
            sugar_stage = txtSugarStage.Text.Trim();    
        }

        private void btnNewRecord_Click(object sender, EventArgs e)
        {
            genFunc.enableFieldsInControl(groupBoxKeySample);
            btnNewRecord.Enabled = false;
            btnSave.Enabled = true;
            btnClear.Enabled = true;
            txt_TranDate.Enabled = false;
            txtSugarStage.Enabled = false;
            txtTime.Focus();
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            if (txtSugarStage.Text == "0")
            {
                MessageBox.Show("Please choose a sugar Stage first", "Sugar Stage not selected", MessageBoxButtons.OK, MessageBoxIcon.Error);
                comboSugarStage.Focus();
            }
            else
            {
                if (MessageBox.Show("Are your sure to save key sample data?", "Sure to save", MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button1) == DialogResult.Yes)
                {
                    keySampleLogic.insertKeySample(transDate, transTime,sugar_stage , panNo, brix, pol, samplePurity, userCode);
                    genFunc.disableFieldsInControl(groupBoxKeySample);
                    btnNewRecord.Enabled = true;
                    btnSave.Enabled = false;
                    btnClear.Enabled = false;
                }
            }
        }

        private void bindSugarStage()
        {
            DataTable dt = genFunc.getComboListOptions("key sample sugar stages").Tables[0];
            DataRow row = dt.NewRow();
            row["ddl_value"] = "0";
            row["display_text"] = "--Select--";
            dt.Rows.InsertAt(row, 0);
            comboSugarStage.DataSource = dt;
            comboSugarStage.ValueMember = "display_text";
            comboSugarStage.DisplayMember = "display_text";

        }

        private void comboSugarStage_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (comboSugarStage.SelectedValue.ToString() == "Other")
            {
                txtSugarStage.Enabled = true;
                txtSugarStage.Text = string.Empty;
            }
            else
            {
                txtSugarStage.Enabled = false;
                txtSugarStage.Text = comboSugarStage.Text;
            }
        }

    }
}
