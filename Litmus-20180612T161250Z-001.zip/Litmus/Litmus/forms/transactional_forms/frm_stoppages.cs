﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Litmus.classes;
	
namespace Litmus.forms.transactional_forms
{

    public partial class frm_stoppages : Form
    {
        generalFunctions genFunc = new generalFunctions();
        master_parameter_logic masterParam = new master_parameter_logic();
        stoppage_master_logic stoppageMaster = new stoppage_master_logic(); // will use it to bind stoppage combo
        stoppage_transaction_logic stoppageTrans = new stoppage_transaction_logic();
        string s_start_time, s_end_time;
        string formMode;
        int millCode;
        string stoppage_date;
        int s_head_code ;
        string s_head_name;
        int s_sub_head_code;
        string s_sub_head_name;
        string s_comment;
        int selected_stoppage_id;

        IDictionary<char, string> dictFormMode = new Dictionary<char, string>();
        public frm_stoppages()
        {
            InitializeComponent();
            user_rights_controller();
            dictFormMode.Add('c', "create");
            dictFormMode.Add('r', "read");
            dictFormMode.Add('u', "update");
            dictFormMode.Add('d', "delete");

            formMode = dictFormMode['c'].ToString();
            dateTimeTranDate.Text = masterParam.entryDate;
            disbleInputFields();
            get_stoppage_head();

            txtEndTime.LostFocus += new EventHandler(txtEndTimeLostFocus);
            txtStartTime.LostFocus += new EventHandler(txtStartTimeLostFocus);
            bindStoppageGrid();
        }

        private void disbleInputFields()
        {
            txtStartTime.Enabled = false;
            txtEndTime.Enabled = false;
            ddlStoppageHead.Enabled = false;
            ddlStoppageSubHead.Enabled = false;
            
        }
        private void enableInputFields()
        {
            txtStartTime.Enabled = true;
            //txtEndTime.Enabled = true;
            ddlStoppageHead.Enabled = true;
            ddlStoppageSubHead.Enabled = true;
        }
        private void resetInputFields()
        {
            txtStartTime.Text = string.Empty;
            txtEndTime.Text = string.Empty;
            radioNewMill.Checked = false;
            radioOldMill.Checked = false;
            ddlStoppageHead.Refresh();
            ddlStoppageSubHead.Refresh();
            ddlStoppageHead.SelectedIndex = 0;
            txtComments.Text = string.Empty;
            btnNewRecord.Enabled = true;
            disbleInputFields();
        }

        protected void user_rights_controller()
        {
            foreach (char c in genFunc.userRights)
            {
                switch (c)
                {
                    case 'C':
                        btnNewRecord.Enabled = true;
                        btnSave.Enabled = true;
                        break;
                    case 'R':
                        this.Enabled = true;
                        break;
                    case 'U':
                        btnModify.Enabled = true;
                        break;
                    case 'D':
                        break;
                    default:
                        btnNewRecord.Enabled = false;
                        btnModify.Enabled = false;
                        btnModify.Enabled = false;
                        MessageBox.Show("User do not have any rights", "No rights assigned", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        break;
                }
            }
        }
        private void btnNewRecord_Click(object sender, EventArgs e)
        {
            enableInputFields();
            dateTimeTranDate.Enabled = false;
            btnSave.Text = "&Save";
            
            formMode = dictFormMode['c'].ToString();
            btnNewRecord.Enabled = false;
        }

        private void btnModify_Click(object sender, EventArgs e)
        {
            enableInputFields();
            txtStartTime.Focus();
            dateTimeTranDate.Enabled = true;
            btnNewRecord.Enabled = false;
            btnSave.Text = "&Update";
            formMode = dictFormMode['u'].ToString();
            getDataFromStoppageGrid();
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            genFunc.validate_hours_minutes(txtStartTime, btnSave);
            genFunc.validate_hours_minutes(txtEndTime, btnSave);

            if (radioNewMill.Checked == true)
            {
                millCode = 0;
            }
            else if (radioOldMill.Checked == true)
            {
                millCode = 1;
            }
            switch (formMode)
            {
                case "create":
                    insertRecord();
                    break;
                case "update":
                    updateRecord(selected_stoppage_id);
                    break;
            }
            txtDuration.Text = string.Empty;
            
        }
        private void get_stoppage_head()
        {
            DataTable dt = new DataTable();
            dt = stoppageMaster.get_stoppage_head_list(); 
            DataRow row = dt.NewRow();
            row["sh_code"] = "0";
            row["sh_name"] = "--select--";
            row["sh_description"] = "";
            dt.Rows.InsertAt(row, 0);
            
            if (dt.Rows.Count > 0)
            {
                ddlStoppageHead.DataSource = dt;
                ddlStoppageHead.ValueMember = "sh_code";
                ddlStoppageHead.DisplayMember = "sh_name";
            }
            this.ddlStoppageHead.SelectedIndexChanged += new System.EventHandler(this.ddlStoppageHead_SelectedIndexChanged);
        }

        /// <summary>
        /// Bind stoppage sub head combo box on changing Stoppage Head 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void ddlStoppageHead_SelectedIndexChanged(object sender, EventArgs e)
        {
            ComboBox cmb = (ComboBox)sender;
            DataTable dt_subHead = null;
            try
            {
                int selectedHead = (int)cmb.SelectedValue;
                dt_subHead = stoppageMaster.get_stoppage_sub_head_list(selectedHead);

                if (dt_subHead.Rows.Count > 0 && dt_subHead != null)
                {
                    ddlStoppageSubHead.DataSource = dt_subHead;
                    ddlStoppageSubHead.ValueMember = "ss_code";
                    ddlStoppageSubHead.DisplayMember = "ss_name";
                }

                else if (ddlStoppageHead.SelectedIndex == 0)
                {
                    ddlStoppageSubHead.DataSource = null;
                    ddlStoppageSubHead.Items.Clear();
                }
                else
                {
                    MessageBox.Show("No sub stoppage head exist for selected 'Stoppage Head'", "No Data", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                    ddlStoppageSubHead.DataSource = null;
                    ddlStoppageSubHead.Items.Clear();
                }
            }
            catch (Exception ex)
            {
            }
        }

        private void txtEndTimeLostFocus(object sender, EventArgs e)
        {
            txtEndTime.Text = genFunc.parseHourMinuteFormat(txtEndTime.Text);
            genFunc.validate_hours_minutes(txtEndTime);

            DateTime s_start_datetime = DateTime.ParseExact( (dateTimeTranDate.Text+" "+txtStartTime.Text),"yyyy-MM-dd HH:mm",System.Globalization.CultureInfo.InvariantCulture); 
            DateTime s_end_datetime =DateTime.ParseExact( (dateTimeTranDate.Text+" "+txtEndTime.Text),"yyyy-MM-dd HH:mm",System.Globalization.CultureInfo.InvariantCulture); 
            
            if(s_end_datetime < s_start_datetime)
            {
                s_end_datetime = s_end_datetime.AddDays(1);
            }
           
            
            
           
            TimeSpan time_diff;


            time_diff = s_end_datetime.Subtract(s_start_datetime);
                txtDuration.Text = time_diff.ToString();
            
            //{
            //    btnSave.Enabled = false;
            //    txtDuration.BackColor = Color.Red;
            //}
            //else
            //{
            //    btnSave.Enabled = true;
            //    txtDuration.BackColor = Color.LightGray;
            //}
        }
        private void txtStartTimeLostFocus(object sender, EventArgs e)
        {
            txtStartTime.Text = genFunc.parseHourMinuteFormat(txtStartTime.Text);
            s_start_time = txtStartTime.Text;
            genFunc.validate_hours_minutes(txtStartTime,btnSave);

        }

        private void bindStoppageGrid()
        {
            DataTable dt_grid = null;
            dt_grid = stoppageTrans.getStoppageRecords(masterParam.entryDate);

            dataGridViewPendingStoppages.DataSource = dt_grid;
        }

        private void getDataFromStoppageGrid()
        {
            if (dataGridViewPendingStoppages.SelectedCells.Count > 0)
            {
                int rowIndex = dataGridViewPendingStoppages.CurrentCell.RowIndex;
                DataTable dt = null;
                DataGridViewRow row = dataGridViewPendingStoppages.Rows[rowIndex];
                selected_stoppage_id = (int)row.Cells[0].Value;
                dt = stoppageTrans.getStoppageRecords(selected_stoppage_id);
                ddlStoppageHead.SelectedValue = dt.Rows[0]["s_head_code"].ToString();
                ddlStoppageSubHead.SelectedValue = dt.Rows[0]["s_sub_head_code"].ToString();
                txtStartTime.Text = dt.Rows[0]["s_start_time"].ToString();
                txtEndTime.Text = dt.Rows[0]["s_end_time"].ToString();
                txtComments.Text = dt.Rows[0]["s_comment"].ToString();
                millCode = (int)dt.Rows[0]["s_mill_code"];
                if (millCode == 0)
                {
                    radioNewMill.Checked = true;
                }
                else
                {
                    radioOldMill.Checked = true;
                }
                enableInputFields();
                txtEndTime.Enabled = true;
            }
            else
            {
                MessageBox.Show("No data selected for modification", "No salection", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
            }
        }

        private void value_assignment()
        {
            stoppage_date = dateTimeTranDate.Text;
            s_start_time = txtStartTime.Text;
            s_end_time = txtEndTime.Text;
            s_head_code = Convert.ToInt16(ddlStoppageHead.SelectedValue);
            s_head_name = ddlStoppageHead.GetItemText(ddlStoppageHead.SelectedItem);
            s_sub_head_code = Convert.ToInt16(ddlStoppageSubHead.SelectedValue);
            s_sub_head_name = ddlStoppageSubHead.GetItemText(ddlStoppageSubHead.SelectedItem);
            s_comment = txtComments.Text;
            if (radioNewMill.Checked == true)
            {
                millCode = 0;
            }
            else if (radioOldMill.Checked == true)
            {
                millCode = 1;
            }
        }
        private void insertRecord()
        {
            // insert records
            value_assignment();
            int inserted_records = 0;
            try
            {
                inserted_records = stoppageTrans.insertStoppage(dateTimeTranDate.Text, s_start_time, s_end_time, millCode, s_head_code, s_head_name, s_sub_head_code, s_sub_head_name, s_comment);

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Failed", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            switch (inserted_records)
            {
                case 0:
                    MessageBox.Show("No record inserted", "Failed", MessageBoxButtons.OK, MessageBoxIcon.Error);

                    break;
                case 1:
                    MessageBox.Show("One record inserted!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    bindStoppageGrid();
                    resetInputFields();
                    disbleInputFields();
                    break;
                default:
                    MessageBox.Show("More than one record inserted. Contact adminstrator before proceeding!", "Failed", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    break;
            }
        }

        private void updateRecord( int id)
        {
            value_assignment();
            int updatedRecords = 0;
            try
            {
                updatedRecords = stoppageTrans.updateRecord(id, s_start_time, s_end_time, millCode, s_head_code, s_head_name, s_sub_head_code, s_sub_head_name, s_comment);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Failed", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            switch (updatedRecords)
            {
                case 0:
                    MessageBox.Show("No record updated", "Failed", MessageBoxButtons.OK, MessageBoxIcon.Error);

                    break;
                case 1:
                    MessageBox.Show("One record updated!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    bindStoppageGrid();
                    resetInputFields();
                    disbleInputFields();
                    break;
                default:
                    MessageBox.Show("More than one record updated. Contact adminstrator before proceeding!", "Failed", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    break;
            }
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            disbleInputFields();
            resetInputFields();
        }

        private void txtEndTime_TextChanged(object sender, EventArgs e)
        {
            btnSave.Enabled = true;
        }

        

        
        
    }
}
