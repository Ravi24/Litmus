﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Litmus.forms.transactional_forms
{
    public partial class frm_massecuite_transactions : Form
    {
        classes.master_parameter_logic masterParameters = new classes.master_parameter_logic();
        classes.ExceptionHelper expHelper = new classes.ExceptionHelper();
        classes.generalFunctions genFunc = new classes.generalFunctions();
        classes.massecuite_molasses_KeySample_logic logic = new classes.massecuite_molasses_KeySample_logic();

        #region variable declaration
        Control activeMasterTabPAge, activeChildTabPage;
        // massecuite variables
        string  mass_tranDate, mass_start_time, mass_drop_time, mass_tarnTime;
        int massecuite_parameter_type_code, mass_panno, mass_crystal_no;
        float mass_hl, mass_brix, mass_pol, mass_purity;

        //molasses variables 
        //string mol_trans_date, mol_trans_time;
        //float mol_brix, mol_pol, mol_purity;

        // Key Sample variable
        string sample_trans_date, sample_trans_time;
        int sample_pan_no;
        float sample_brix, sample_pol, sample_purity;

        #endregion
       
        public frm_massecuite_transactions()
        {
            InitializeComponent();
         
            disbleAllFields();

            // by default TabControl name will be selected tab
            activeMasterTabPAge = TabMaster.SelectedTab;
            activeChildTabPage = TabChild.SelectedTab;

            // when user select another tab fire below events
            TabMaster.SelectedIndexChanged += new EventHandler(tabMasterIndexChanged);
            TabChild.SelectedIndexChanged += new EventHandler(tabChildIndexChanged);
            txtMassA_Tans_Time.LostFocus += new EventHandler(validateInpuTransactionTime);
            txtMassA_StartTime.LostFocus += new EventHandler(validateInpuTransactionTime);
            txtMassA_DropTime.LostFocus += new EventHandler(validateInpuTransactionTime);
            txtMassA1_Tans_Time.LostFocus += new EventHandler(validateInpuTransactionTime);
            txtMassA1_StartTime.LostFocus += new EventHandler(validateInpuTransactionTime);
            txtMassA1_DropTime.LostFocus += new EventHandler(validateInpuTransactionTime);
            txtMassB_Tans_Time.LostFocus += new EventHandler(validateInpuTransactionTime);
            txtMassB_StartTime.LostFocus += new EventHandler(validateInpuTransactionTime);
            txtMassB_DropTime.LostFocus += new EventHandler(validateInpuTransactionTime);
            txtMassC1_Tans_Time.LostFocus += new EventHandler(validateInpuTransactionTime);
            txtMassC1_StartTime.LostFocus += new EventHandler(validateInpuTransactionTime);
            txtMassC1_DropTime.LostFocus += new EventHandler(validateInpuTransactionTime);
            txtMassC_Tans_Time.LostFocus += new EventHandler(validateInpuTransactionTime);
            txtMassC_StartTime.LostFocus += new EventHandler(validateInpuTransactionTime);
            txtMassC_DropTime.LostFocus += new EventHandler(validateInpuTransactionTime);
        }

        private void TabMaster_SelectedIndexChanged(object sender, EventArgs e)
        {
        }

        #region Massecuite Tab
        #region get active master and child TabControl page
        private void tabMasterIndexChanged(object sender, EventArgs e)
        {
            activeMasterTabPAge = TabMaster.SelectedTab;
           
            disbleAllFields();
        }
        private void tabChildIndexChanged(object sender, EventArgs e)
        {
            activeChildTabPage = TabChild.SelectedTab;
            commonFunctionality();
            disbleAllFields();
        }

        #endregion

        #region A Massecuite code

        public void MassecuiteA()
        {
           
                massecuite_parameter_type_code = 20;
                txtMassA_dateTimeTranDate.Text = masterParameters.entryDate;
                mass_tranDate = txtMassA_dateTimeTranDate.Text;
                mass_tarnTime = txtMassA_Tans_Time.Text;
                mass_hl = float.Parse(txtMassA_HL.Text);
                mass_panno = Convert.ToInt16(txtMassA_PanNo.Text);
                mass_start_time = txtMassA_StartTime.Text;
                mass_drop_time = txtMassA_DropTime.Text;
                mass_crystal_no = Convert.ToInt16(txtMassA_CrystNo.Text);
                mass_brix = float.Parse(txtMassA_Brix.Text);
                mass_pol = float.Parse(txtMassA_Pol.Text);
                txtMassA_Purity.Text = genFunc.calculate_purity(mass_pol, mass_brix).ToString();
                mass_purity = float.Parse(txtMassA_Purity.Text);
        }

        #endregion

        #region A1- Massecuite code

        public void MassecuiteA1()
        {
           
                massecuite_parameter_type_code = 21;
                txtMassA1_dateTimeTranDate.Text = masterParameters.entryDate;
                mass_tranDate = txtMassA1_dateTimeTranDate.Text;
                mass_tarnTime = txtMassA1_Tans_Time.Text;
                mass_hl = float.Parse(txtMassA1_HL.Text);
                mass_panno = Convert.ToInt16(txtMassA1_PanNo.Text);
                mass_start_time = txtMassA1_StartTime.Text;
                mass_drop_time = txtMassA1_DropTime.Text;
                mass_crystal_no = Convert.ToInt16(txtMassA1_CrystNo.Text);
                mass_brix = float.Parse(txtMassA1_Brix.Text);
                mass_pol = float.Parse(txtMassA1_Pol.Text);
                txtMassA1_Purity.Text = genFunc.calculate_purity(mass_pol, mass_brix).ToString();
                mass_purity = float.Parse(txtMassA_Purity.Text);


        }

        #endregion

        #region B- Massecuite code

        public void MassecuiteB()
        {
          
                massecuite_parameter_type_code = 23;
                txtMassB_dateTimeTranDate.Text = masterParameters.entryDate;
                mass_tranDate = txtMassB_dateTimeTranDate.Text;
                mass_tarnTime = txtMassB_Tans_Time.Text;
                mass_hl = float.Parse(txtMassB_HL.Text);
                mass_panno = Convert.ToInt16(txtMassB_PanNo.Text);
                mass_start_time = txtMassB_StartTime.Text;
                mass_drop_time = txtMassB_DropTime.Text;
                mass_crystal_no = Convert.ToInt16(txtMassB_CrystNo.Text);
                mass_brix = float.Parse(txtMassB_Brix.Text);
                mass_pol = float.Parse(txtMassB_Pol.Text);
                txtMassB_Purity.Text = genFunc.calculate_purity(mass_pol, mass_brix).ToString();
                mass_purity = float.Parse(txtMassA_Purity.Text);
            

        }

        #endregion

        #region C1- Massecuite code

        public void MassecuiteC1()
        {
           
                massecuite_parameter_type_code = 22;
                txtMassC1_dateTimeTranDate.Text = masterParameters.entryDate;
                mass_tranDate = txtMassC1_dateTimeTranDate.Text;
                mass_tarnTime = txtMassC1_Tans_Time.Text;
                mass_hl = float.Parse(txtMassC1_HL.Text);
                mass_panno = Convert.ToInt16(txtMassC1_PanNo.Text);
                mass_start_time = txtMassC1_StartTime.Text;
                mass_drop_time = txtMassC1_DropTime.Text;
                mass_crystal_no = Convert.ToInt16(txtMassC1_CrystNo.Text);
                mass_brix = float.Parse(txtMassC1_Brix.Text);
                mass_pol = float.Parse(txtMassC1_Pol.Text);
                txtMassC1_Purity.Text = genFunc.calculate_purity(mass_pol, mass_brix).ToString();
                mass_purity = float.Parse(txtMassA_Purity.Text);
            

        }

        #endregion

        #region C- Massecuite code

        public void MassecuiteC()
        {
           
                massecuite_parameter_type_code = 24;
                txtMassC_dateTimeTranDate.Text = masterParameters.entryDate;
                mass_tranDate = txtMassC_dateTimeTranDate.Text;
                mass_tarnTime = txtMassC_Tans_Time.Text;
                mass_hl = float.Parse(txtMassC_HL.Text);
                mass_panno = Convert.ToInt16(txtMassC_PanNo.Text);
                mass_start_time = txtMassC_StartTime.Text;
                mass_drop_time = txtMassC_DropTime.Text;
                mass_crystal_no = Convert.ToInt16(txtMassC_CrystNo.Text);
                mass_brix = float.Parse(txtMassC_Brix.Text);
                mass_pol = float.Parse(txtMassC_Pol.Text);
                txtMassC_Purity.Text = genFunc.calculate_purity(mass_pol, mass_brix).ToString();
                mass_purity = float.Parse(txtMassA_Purity.Text);
            

        }

        #endregion

        #region Diable all fields
        private void disbleAllFields()
        {
           
            foreach (Control parentCtrl in TabMaster.Controls)
            {
                foreach (Control childCtrl in parentCtrl.Controls)
                {
                    foreach (Control grandChild in childCtrl.Controls)
                    {
                        foreach (Control groupBoxes in grandChild.Controls)
                        {
                            if (groupBoxes.GetType() == typeof(GroupBox))
                            {
                                groupBoxes.Enabled = false;
                            }
                            foreach (Control textboxes in groupBoxes.Controls)
                            {
                                if (textboxes.GetType() == typeof(TextBox))
                                {
                                    textboxes.Text = "0";
                                 
                                }
                                if (textboxes.GetType() == typeof(TextBox) && textboxes.Name.Contains("Pol"))
                                {   
                                    textboxes.LostFocus += new EventHandler(calculatePurity);
                                }
                            }
                        }
                    }
                }
            }

            btnSave.Enabled = false;
            btnNewRecord.Enabled = true;
        }
        #endregion

        #region Enable all fields on form when user clicks on New Record button
        private void btnNewRecord_Click(object sender, EventArgs e)
        {
            foreach (Control ctrl in activeChildTabPage.Controls)
            {
                if (ctrl.GetType() == typeof(GroupBox))
                {
                    ctrl.Enabled = true;
                }
                foreach (Control datetimeControl in ctrl.Controls)
                {
                    if (datetimeControl.GetType() == typeof(DateTimePicker))
                    {
                        datetimeControl.Text = masterParameters.entryDate;
                    }

                }
            }
            btnSave.Enabled = true;
            btnNewRecord.Enabled = false;
        }
        #endregion

        private void validateInpuTransactionTime(object sender, EventArgs e)
        {
            TextBox tempText = (TextBox)sender;
            tempText.Text = genFunc.parseHourMinuteFormat(tempText.Text);
            genFunc.validate_hours_minutes(tempText, btnSave);
            //genFunc.validateTransactionTime(txtMassA_Tans_Time.Text);
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show("Sure to save data?", "Save Data!!", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (result == DialogResult.Yes)
            {
                logic.insertMassecuiteRecord(massecuite_parameter_type_code, mass_tranDate, mass_tarnTime, mass_hl, mass_panno, mass_start_time, mass_drop_time,
                      mass_crystal_no, mass_brix, mass_pol, mass_purity);
                disbleAllFields();
            }
           
        }
        #endregion

        //#region Molasses Tab Codes
        //private void Molasses_A_Heavy()
        //{
        //    mol_trans_date = masterParameters.entryDate;
        //    mol_trans_time = txtMolAHeavy_transTime.Text.ToString();
        //    mol_brix = float.Parse(txtMolAHeavy_brix.Text.ToString());
        //    mol_pol = float.Parse(txtMolAHeavy_pol.Text.ToString());
        //    mol_purity = genFunc.calculate_purity(mol_pol, mol_brix);
        //}

        //private void Molasses_A1_Heavy()
        //{
        //    mol_trans_date = masterParameters.entryDate;
        //    mol_trans_time = txtMolA1Heavy_transTime.Text.ToString();
        //    mol_brix = float.Parse(txtMolA1Heavy_brix.Text.ToString());
        //    mol_pol = float.Parse(txtMolA1Heavy_pol.Text.ToString());
        //    mol_purity = genFunc.calculate_purity(mol_pol, mol_brix);
        //}
        //private void Molasses_B_Heavy()
        //{
        //    mol_trans_date = masterParameters.entryDate;
        //    mol_trans_time = txtMolBHeavy_transTime.Text.ToString();
        //    mol_brix = float.Parse(txtMolBHeavy_brix.Text.ToString());
        //    mol_pol = float.Parse(txtMolBHeavy_pol.Text.ToString());
        //    mol_purity = genFunc.calculate_purity(mol_pol, mol_brix);
        //}
        //private void Molasses_C1_Heavy()
        //{
        //    mol_trans_date = masterParameters.entryDate;
        //    mol_trans_time = txtMolC1Heavy_transTime.Text.ToString();
        //    mol_brix = float.Parse(txtMolC1Heavy_brix.Text.ToString());
        //    mol_pol = float.Parse(txtMolC1Heavy_pol.Text.ToString());
        //    mol_purity = genFunc.calculate_purity(mol_pol, mol_brix);
        //}
        //private void Molasses_A_Light()
        //{
        //    mol_trans_date = masterParameters.entryDate;
        //    mol_trans_time = txtMolALight_transTime.Text.ToString();
        //    mol_brix = float.Parse(txtMolALight_brix.Text.ToString());
        //    mol_pol = float.Parse(txtMolALight_pol.Text.ToString());
        //    mol_purity = genFunc.calculate_purity(mol_pol, mol_brix);
        //}
        //private void Molasses_C_Heavy()
        //{
        //    mol_trans_date = masterParameters.entryDate;
        //    mol_trans_time = txtMolCHeavy_transTime.Text.ToString();
        //    mol_brix = float.Parse(txtMolCHeavy_brix.Text.ToString());
        //    mol_pol = float.Parse(txtMolCHeavy_pol.Text.ToString());
        //    mol_purity = genFunc.calculate_purity(mol_pol, mol_brix);
        //}
        //#endregion

        private void calculatePurity(object sender, EventArgs e)
        {
            try
            {
                commonFunctionality();
            }
            catch
            {
            }
        }

       

        #region Common functionality of form
        ///<summary>
        /// we are using multiple tab for a master tab. many functionality would be will be common for child tabs
        ///</summary>
        ///
        public void commonFunctionality()
        {
            switch (TabMaster.SelectedIndex)
            {
                case 0: // Massecuite Tab selected
                    switch (TabChild.SelectedIndex)
                    {
                        case 0: // Massecuite
                            
                            MassecuiteA();
                            break;
                        case 1:
                            MassecuiteA1();
                            break;
                        case 2:
                            MassecuiteB();
                            break;
                        case 3:
                            MassecuiteC1();
                            break;
                        case 4:
                            MassecuiteC();
                            break;

                    }
                    break;
                
            }

        }

        #endregion

       

    }
}
