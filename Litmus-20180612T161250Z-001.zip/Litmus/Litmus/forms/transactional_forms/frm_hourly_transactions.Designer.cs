﻿namespace Litmus.forms.transactional_forms
{
    partial class frm_hourly_transactions
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param Name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.groupBoxCaneStatus = new System.Windows.Forms.GroupBox();
            this.txtCaneCrushed = new System.Windows.Forms.TextBox();
            this.label49 = new System.Windows.Forms.Label();
            this.txtUncrushedCane = new System.Windows.Forms.TextBox();
            this.label48 = new System.Windows.Forms.Label();
            this.txtStandingCarts = new System.Windows.Forms.TextBox();
            this.label47 = new System.Windows.Forms.Label();
            this.txtStandingTripplers = new System.Windows.Forms.TextBox();
            this.label46 = new System.Windows.Forms.Label();
            this.txtStandingTrolleys = new System.Windows.Forms.TextBox();
            this.label39 = new System.Windows.Forms.Label();
            this.txtStandingTrucks = new System.Windows.Forms.TextBox();
            this.label38 = new System.Windows.Forms.Label();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.comboCoolingTowerTraces = new System.Windows.Forms.ComboBox();
            this.label27 = new System.Windows.Forms.Label();
            this.label29 = new System.Windows.Forms.Label();
            this.label28 = new System.Windows.Forms.Label();
            this.txtCoolingPh = new System.Windows.Forms.TextBox();
            this.txtCoolingPol = new System.Windows.Forms.TextBox();
            this.groupBox6 = new System.Windows.Forms.GroupBox();
            this.btnModify = new System.Windows.Forms.Button();
            this.btnNewRecord = new System.Windows.Forms.Button();
            this.btnSave = new System.Windows.Forms.Button();
            this.btnClear = new System.Windows.Forms.Button();
            this.groupBoxSugarBags = new System.Windows.Forms.GroupBox();
            this.txtSugarbagGrandTotal = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.txtSugarBagSTotal = new System.Windows.Forms.TextBox();
            this.txtSugarBagMTotal = new System.Windows.Forms.TextBox();
            this.txtSugarBagLTotal = new System.Windows.Forms.TextBox();
            this.txtSugarBagsS30 = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.txtSugarBagsS31 = new System.Windows.Forms.TextBox();
            this.label14 = new System.Windows.Forms.Label();
            this.txtSugarBagsBiss = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.txtSugarBagsM30 = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.txtSugarBagsM31 = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.txtSugarBagsL30 = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.txtSugarBagsL31 = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.groupBoxWater = new System.Windows.Forms.GroupBox();
            this.label4 = new System.Windows.Forms.Label();
            this.txtWaterTotal = new System.Windows.Forms.TextBox();
            this.txtWaterNewMill = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.txtWaterOldMill = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.groupBoxJuice = new System.Windows.Forms.GroupBox();
            this.label18 = new System.Windows.Forms.Label();
            this.txtJuiceTotal = new System.Windows.Forms.TextBox();
            this.txtjuiceNewMill = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.txtjuiceOldMill = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.txtTime = new System.Windows.Forms.TextBox();
            this.lblDate = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.dateTimeTranDate = new System.Windows.Forms.DateTimePicker();
            this.groupBox1.SuspendLayout();
            this.groupBoxCaneStatus.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.groupBox6.SuspendLayout();
            this.groupBoxSugarBags.SuspendLayout();
            this.groupBoxWater.SuspendLayout();
            this.groupBoxJuice.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.groupBoxCaneStatus);
            this.groupBox1.Controls.Add(this.groupBox4);
            this.groupBox1.Controls.Add(this.groupBox6);
            this.groupBox1.Controls.Add(this.groupBoxSugarBags);
            this.groupBox1.Controls.Add(this.groupBoxWater);
            this.groupBox1.Controls.Add(this.groupBoxJuice);
            this.groupBox1.Controls.Add(this.groupBox2);
            this.groupBox1.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.groupBox1.Location = new System.Drawing.Point(5, -1);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(788, 592);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            // 
            // groupBoxCaneStatus
            // 
            this.groupBoxCaneStatus.Controls.Add(this.txtCaneCrushed);
            this.groupBoxCaneStatus.Controls.Add(this.label49);
            this.groupBoxCaneStatus.Controls.Add(this.txtUncrushedCane);
            this.groupBoxCaneStatus.Controls.Add(this.label48);
            this.groupBoxCaneStatus.Controls.Add(this.txtStandingCarts);
            this.groupBoxCaneStatus.Controls.Add(this.label47);
            this.groupBoxCaneStatus.Controls.Add(this.txtStandingTripplers);
            this.groupBoxCaneStatus.Controls.Add(this.label46);
            this.groupBoxCaneStatus.Controls.Add(this.txtStandingTrolleys);
            this.groupBoxCaneStatus.Controls.Add(this.label39);
            this.groupBoxCaneStatus.Controls.Add(this.txtStandingTrucks);
            this.groupBoxCaneStatus.Controls.Add(this.label38);
            this.groupBoxCaneStatus.Location = new System.Drawing.Point(6, 425);
            this.groupBoxCaneStatus.Name = "groupBoxCaneStatus";
            this.groupBoxCaneStatus.Size = new System.Drawing.Size(777, 78);
            this.groupBoxCaneStatus.TabIndex = 14;
            this.groupBoxCaneStatus.TabStop = false;
            // 
            // txtCaneCrushed
            // 
            this.txtCaneCrushed.Enabled = false;
            this.txtCaneCrushed.Location = new System.Drawing.Point(661, 42);
            this.txtCaneCrushed.Name = "txtCaneCrushed";
            this.txtCaneCrushed.Size = new System.Drawing.Size(100, 22);
            this.txtCaneCrushed.TabIndex = 26;
            this.txtCaneCrushed.Text = "0";
            // 
            // label49
            // 
            this.label49.AutoSize = true;
            this.label49.Location = new System.Drawing.Point(518, 45);
            this.label49.Name = "label49";
            this.label49.Size = new System.Drawing.Size(137, 17);
            this.label49.TabIndex = 13;
            this.label49.Text = "Crushed Cane(Qtls.)";
            // 
            // txtUncrushedCane
            // 
            this.txtUncrushedCane.Enabled = false;
            this.txtUncrushedCane.Location = new System.Drawing.Point(402, 40);
            this.txtUncrushedCane.Name = "txtUncrushedCane";
            this.txtUncrushedCane.ReadOnly = true;
            this.txtUncrushedCane.Size = new System.Drawing.Size(100, 22);
            this.txtUncrushedCane.TabIndex = 26;
            this.txtUncrushedCane.Text = "0";
            // 
            // label48
            // 
            this.label48.AutoSize = true;
            this.label48.Location = new System.Drawing.Point(247, 43);
            this.label48.Name = "label48";
            this.label48.Size = new System.Drawing.Size(149, 17);
            this.label48.TabIndex = 11;
            this.label48.Text = "Uncrushed Cane(Qtls)";
            // 
            // txtStandingCarts
            // 
            this.txtStandingCarts.Enabled = false;
            this.txtStandingCarts.Location = new System.Drawing.Point(130, 40);
            this.txtStandingCarts.Name = "txtStandingCarts";
            this.txtStandingCarts.Size = new System.Drawing.Size(100, 22);
            this.txtStandingCarts.TabIndex = 25;
            this.txtStandingCarts.Text = "0";
            this.txtStandingCarts.LostFocus += new System.EventHandler(this.calculatedStandingCartWeight);
            // 
            // label47
            // 
            this.label47.AutoSize = true;
            this.label47.Location = new System.Drawing.Point(23, 43);
            this.label47.Name = "label47";
            this.label47.Size = new System.Drawing.Size(101, 17);
            this.label47.TabIndex = 9;
            this.label47.Text = "Standing Carts";
            // 
            // txtStandingTripplers
            // 
            this.txtStandingTripplers.Enabled = false;
            this.txtStandingTripplers.Location = new System.Drawing.Point(661, 15);
            this.txtStandingTripplers.Name = "txtStandingTripplers";
            this.txtStandingTripplers.Size = new System.Drawing.Size(100, 22);
            this.txtStandingTripplers.TabIndex = 24;
            this.txtStandingTripplers.Text = "0";
            this.txtStandingTripplers.LostFocus += new System.EventHandler(this.calculateStandingTripplerWeight);
            // 
            // label46
            // 
            this.label46.AutoSize = true;
            this.label46.Location = new System.Drawing.Point(531, 18);
            this.label46.Name = "label46";
            this.label46.Size = new System.Drawing.Size(124, 17);
            this.label46.TabIndex = 7;
            this.label46.Text = "Standing Tripplers";
            // 
            // txtStandingTrolleys
            // 
            this.txtStandingTrolleys.Enabled = false;
            this.txtStandingTrolleys.Location = new System.Drawing.Point(402, 15);
            this.txtStandingTrolleys.Name = "txtStandingTrolleys";
            this.txtStandingTrolleys.Size = new System.Drawing.Size(100, 22);
            this.txtStandingTrolleys.TabIndex = 23;
            this.txtStandingTrolleys.Text = "0";
            this.txtStandingTrolleys.LostFocus += new System.EventHandler(this.calculateStandingTrolleyWeight);
            // 
            // label39
            // 
            this.label39.AutoSize = true;
            this.label39.Location = new System.Drawing.Point(278, 18);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(118, 17);
            this.label39.TabIndex = 5;
            this.label39.Text = "Standing Trolleys";
            // 
            // txtStandingTrucks
            // 
            this.txtStandingTrucks.Enabled = false;
            this.txtStandingTrucks.Location = new System.Drawing.Point(130, 13);
            this.txtStandingTrucks.Name = "txtStandingTrucks";
            this.txtStandingTrucks.Size = new System.Drawing.Size(100, 22);
            this.txtStandingTrucks.TabIndex = 22;
            this.txtStandingTrucks.Text = "0";
            this.txtStandingTrucks.LostFocus += new System.EventHandler(this.calculateStandingTrucksWeight);
            // 
            // label38
            // 
            this.label38.AutoSize = true;
            this.label38.Location = new System.Drawing.Point(9, 16);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(115, 17);
            this.label38.TabIndex = 3;
            this.label38.Text = "Statnding Trucks";
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.comboCoolingTowerTraces);
            this.groupBox4.Controls.Add(this.label27);
            this.groupBox4.Controls.Add(this.label29);
            this.groupBox4.Controls.Add(this.label28);
            this.groupBox4.Controls.Add(this.txtCoolingPh);
            this.groupBox4.Controls.Add(this.txtCoolingPol);
            this.groupBox4.Location = new System.Drawing.Point(11, 354);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(766, 56);
            this.groupBox4.TabIndex = 4;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Cooling Tower Traces";
            // 
            // comboCoolingTowerTraces
            // 
            this.comboCoolingTowerTraces.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboCoolingTowerTraces.FormattingEnabled = true;
            this.comboCoolingTowerTraces.Location = new System.Drawing.Point(119, 21);
            this.comboCoolingTowerTraces.Name = "comboCoolingTowerTraces";
            this.comboCoolingTowerTraces.Size = new System.Drawing.Size(121, 24);
            this.comboCoolingTowerTraces.TabIndex = 19;
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Location = new System.Drawing.Point(441, 22);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(26, 17);
            this.label27.TabIndex = 43;
            this.label27.Text = "pH";
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Location = new System.Drawing.Point(68, 24);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(45, 17);
            this.label29.TabIndex = 38;
            this.label29.Text = "Trace";
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Location = new System.Drawing.Point(250, 24);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(40, 17);
            this.label28.TabIndex = 40;
            this.label28.Text = "Pol%";
            // 
            // txtCoolingPh
            // 
            this.txtCoolingPh.Enabled = false;
            this.txtCoolingPh.Location = new System.Drawing.Point(473, 19);
            this.txtCoolingPh.Name = "txtCoolingPh";
            this.txtCoolingPh.Size = new System.Drawing.Size(100, 22);
            this.txtCoolingPh.TabIndex = 21;
            this.txtCoolingPh.Text = "0";
            // 
            // txtCoolingPol
            // 
            this.txtCoolingPol.Enabled = false;
            this.txtCoolingPol.Location = new System.Drawing.Point(308, 19);
            this.txtCoolingPol.Name = "txtCoolingPol";
            this.txtCoolingPol.Size = new System.Drawing.Size(100, 22);
            this.txtCoolingPol.TabIndex = 20;
            this.txtCoolingPol.Text = "0";
            // 
            // groupBox6
            // 
            this.groupBox6.Controls.Add(this.btnModify);
            this.groupBox6.Controls.Add(this.btnNewRecord);
            this.groupBox6.Controls.Add(this.btnSave);
            this.groupBox6.Controls.Add(this.btnClear);
            this.groupBox6.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.groupBox6.Location = new System.Drawing.Point(174, 538);
            this.groupBox6.Name = "groupBox6";
            this.groupBox6.Size = new System.Drawing.Size(453, 48);
            this.groupBox6.TabIndex = 27;
            this.groupBox6.TabStop = false;
            // 
            // btnModify
            // 
            this.btnModify.Enabled = false;
            this.btnModify.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnModify.Location = new System.Drawing.Point(118, 11);
            this.btnModify.Name = "btnModify";
            this.btnModify.Size = new System.Drawing.Size(105, 31);
            this.btnModify.TabIndex = 30;
            this.btnModify.Text = "MODIFY";
            this.btnModify.UseVisualStyleBackColor = true;
            this.btnModify.Click += new System.EventHandler(this.button5_Click);
            // 
            // btnNewRecord
            // 
            this.btnNewRecord.Enabled = false;
            this.btnNewRecord.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnNewRecord.Location = new System.Drawing.Point(9, 11);
            this.btnNewRecord.Name = "btnNewRecord";
            this.btnNewRecord.Size = new System.Drawing.Size(105, 31);
            this.btnNewRecord.TabIndex = 1;
            this.btnNewRecord.Text = "&New Record";
            this.btnNewRecord.UseVisualStyleBackColor = true;
            this.btnNewRecord.Click += new System.EventHandler(this.btnNewRecord_Click);
            // 
            // btnSave
            // 
            this.btnSave.Enabled = false;
            this.btnSave.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnSave.Location = new System.Drawing.Point(229, 11);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(105, 31);
            this.btnSave.TabIndex = 28;
            this.btnSave.Text = "&Save";
            this.btnSave.UseVisualStyleBackColor = true;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // btnClear
            // 
            this.btnClear.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnClear.Location = new System.Drawing.Point(340, 11);
            this.btnClear.Name = "btnClear";
            this.btnClear.Size = new System.Drawing.Size(105, 31);
            this.btnClear.TabIndex = 28;
            this.btnClear.Text = "&Clear";
            this.btnClear.UseVisualStyleBackColor = true;
            this.btnClear.Click += new System.EventHandler(this.btnClear_Click);
            // 
            // groupBoxSugarBags
            // 
            this.groupBoxSugarBags.Controls.Add(this.txtSugarbagGrandTotal);
            this.groupBoxSugarBags.Controls.Add(this.label9);
            this.groupBoxSugarBags.Controls.Add(this.label17);
            this.groupBoxSugarBags.Controls.Add(this.label16);
            this.groupBoxSugarBags.Controls.Add(this.label15);
            this.groupBoxSugarBags.Controls.Add(this.txtSugarBagSTotal);
            this.groupBoxSugarBags.Controls.Add(this.txtSugarBagMTotal);
            this.groupBoxSugarBags.Controls.Add(this.txtSugarBagLTotal);
            this.groupBoxSugarBags.Controls.Add(this.txtSugarBagsS30);
            this.groupBoxSugarBags.Controls.Add(this.label12);
            this.groupBoxSugarBags.Controls.Add(this.txtSugarBagsS31);
            this.groupBoxSugarBags.Controls.Add(this.label14);
            this.groupBoxSugarBags.Controls.Add(this.txtSugarBagsBiss);
            this.groupBoxSugarBags.Controls.Add(this.label13);
            this.groupBoxSugarBags.Controls.Add(this.txtSugarBagsM30);
            this.groupBoxSugarBags.Controls.Add(this.label7);
            this.groupBoxSugarBags.Controls.Add(this.txtSugarBagsM31);
            this.groupBoxSugarBags.Controls.Add(this.label11);
            this.groupBoxSugarBags.Controls.Add(this.txtSugarBagsL30);
            this.groupBoxSugarBags.Controls.Add(this.label10);
            this.groupBoxSugarBags.Controls.Add(this.txtSugarBagsL31);
            this.groupBoxSugarBags.Controls.Add(this.label8);
            this.groupBoxSugarBags.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.groupBoxSugarBags.Location = new System.Drawing.Point(15, 234);
            this.groupBoxSugarBags.Name = "groupBoxSugarBags";
            this.groupBoxSugarBags.Size = new System.Drawing.Size(762, 114);
            this.groupBoxSugarBags.TabIndex = 2;
            this.groupBoxSugarBags.TabStop = false;
            this.groupBoxSugarBags.Text = "Sugar Bags";
            // 
            // txtSugarbagGrandTotal
            // 
            this.txtSugarbagGrandTotal.Enabled = false;
            this.txtSugarbagGrandTotal.Location = new System.Drawing.Point(640, 77);
            this.txtSugarbagGrandTotal.Name = "txtSugarbagGrandTotal";
            this.txtSugarbagGrandTotal.Size = new System.Drawing.Size(100, 22);
            this.txtSugarbagGrandTotal.TabIndex = 99;
            this.txtSugarbagGrandTotal.Text = "0";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(575, 82);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(59, 17);
            this.label9.TabIndex = 25;
            this.label9.Text = "G. Total";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(410, 83);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(40, 17);
            this.label17.TabIndex = 24;
            this.label17.Text = "Total";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(253, 82);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(40, 17);
            this.label16.TabIndex = 23;
            this.label16.Text = "Total";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(75, 81);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(40, 17);
            this.label15.TabIndex = 22;
            this.label15.Text = "Total";
            // 
            // txtSugarBagSTotal
            // 
            this.txtSugarBagSTotal.Enabled = false;
            this.txtSugarBagSTotal.Location = new System.Drawing.Point(469, 79);
            this.txtSugarBagSTotal.Name = "txtSugarBagSTotal";
            this.txtSugarBagSTotal.Size = new System.Drawing.Size(100, 22);
            this.txtSugarBagSTotal.TabIndex = 21;
            this.txtSugarBagSTotal.Text = "0";
            // 
            // txtSugarBagMTotal
            // 
            this.txtSugarBagMTotal.Enabled = false;
            this.txtSugarBagMTotal.Location = new System.Drawing.Point(304, 76);
            this.txtSugarBagMTotal.Name = "txtSugarBagMTotal";
            this.txtSugarBagMTotal.Size = new System.Drawing.Size(100, 22);
            this.txtSugarBagMTotal.TabIndex = 20;
            this.txtSugarBagMTotal.Text = "0";
            // 
            // txtSugarBagLTotal
            // 
            this.txtSugarBagLTotal.Enabled = false;
            this.txtSugarBagLTotal.Location = new System.Drawing.Point(121, 78);
            this.txtSugarBagLTotal.Name = "txtSugarBagLTotal";
            this.txtSugarBagLTotal.Size = new System.Drawing.Size(100, 22);
            this.txtSugarBagLTotal.TabIndex = 19;
            this.txtSugarBagLTotal.Text = "0";
            // 
            // txtSugarBagsS30
            // 
            this.txtSugarBagsS30.Location = new System.Drawing.Point(469, 49);
            this.txtSugarBagsS30.Name = "txtSugarBagsS30";
            this.txtSugarBagsS30.Size = new System.Drawing.Size(100, 22);
            this.txtSugarBagsS30.TabIndex = 11;
            this.txtSugarBagsS30.Text = "0";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(417, 51);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(33, 17);
            this.label12.TabIndex = 17;
            this.label12.Text = "S30";
            // 
            // txtSugarBagsS31
            // 
            this.txtSugarBagsS31.Location = new System.Drawing.Point(469, 21);
            this.txtSugarBagsS31.Name = "txtSugarBagsS31";
            this.txtSugarBagsS31.Size = new System.Drawing.Size(100, 22);
            this.txtSugarBagsS31.TabIndex = 8;
            this.txtSugarBagsS31.Text = "0";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(417, 23);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(33, 17);
            this.label14.TabIndex = 15;
            this.label14.Text = "S31";
            // 
            // txtSugarBagsBiss
            // 
            this.txtSugarBagsBiss.Location = new System.Drawing.Point(640, 23);
            this.txtSugarBagsBiss.Name = "txtSugarBagsBiss";
            this.txtSugarBagsBiss.Size = new System.Drawing.Size(100, 22);
            this.txtSugarBagsBiss.TabIndex = 12;
            this.txtSugarBagsBiss.Text = "0";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(574, 23);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(38, 17);
            this.label13.TabIndex = 13;
            this.label13.Text = "BISS";
            // 
            // txtSugarBagsM30
            // 
            this.txtSugarBagsM30.Location = new System.Drawing.Point(304, 46);
            this.txtSugarBagsM30.Name = "txtSugarBagsM30";
            this.txtSugarBagsM30.Size = new System.Drawing.Size(100, 22);
            this.txtSugarBagsM30.TabIndex = 10;
            this.txtSugarBagsM30.Text = "0";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(258, 51);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(35, 17);
            this.label7.TabIndex = 11;
            this.label7.Text = "M30";
            // 
            // txtSugarBagsM31
            // 
            this.txtSugarBagsM31.Location = new System.Drawing.Point(304, 18);
            this.txtSugarBagsM31.Name = "txtSugarBagsM31";
            this.txtSugarBagsM31.Size = new System.Drawing.Size(100, 22);
            this.txtSugarBagsM31.TabIndex = 7;
            this.txtSugarBagsM31.Text = "0";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(258, 23);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(35, 17);
            this.label11.TabIndex = 9;
            this.label11.Text = "M31";
            // 
            // txtSugarBagsL30
            // 
            this.txtSugarBagsL30.Location = new System.Drawing.Point(121, 49);
            this.txtSugarBagsL30.Name = "txtSugarBagsL30";
            this.txtSugarBagsL30.Size = new System.Drawing.Size(100, 22);
            this.txtSugarBagsL30.TabIndex = 9;
            this.txtSugarBagsL30.Text = "0";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(83, 51);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(32, 17);
            this.label10.TabIndex = 7;
            this.label10.Text = "L30";
            // 
            // txtSugarBagsL31
            // 
            this.txtSugarBagsL31.Location = new System.Drawing.Point(121, 23);
            this.txtSugarBagsL31.Name = "txtSugarBagsL31";
            this.txtSugarBagsL31.Size = new System.Drawing.Size(100, 22);
            this.txtSugarBagsL31.TabIndex = 6;
            this.txtSugarBagsL31.Text = "0";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(83, 23);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(32, 17);
            this.label8.TabIndex = 2;
            this.label8.Text = "L31";
            // 
            // groupBoxWater
            // 
            this.groupBoxWater.Controls.Add(this.label4);
            this.groupBoxWater.Controls.Add(this.txtWaterTotal);
            this.groupBoxWater.Controls.Add(this.txtWaterNewMill);
            this.groupBoxWater.Controls.Add(this.label5);
            this.groupBoxWater.Controls.Add(this.txtWaterOldMill);
            this.groupBoxWater.Controls.Add(this.label6);
            this.groupBoxWater.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.groupBoxWater.Location = new System.Drawing.Point(15, 152);
            this.groupBoxWater.Name = "groupBoxWater";
            this.groupBoxWater.Size = new System.Drawing.Size(762, 76);
            this.groupBoxWater.TabIndex = 1;
            this.groupBoxWater.TabStop = false;
            this.groupBoxWater.Text = "Water Flow Flow";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(410, 30);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(54, 17);
            this.label4.TabIndex = 15;
            this.label4.Text = "TOTAL";
            // 
            // txtWaterTotal
            // 
            this.txtWaterTotal.Enabled = false;
            this.txtWaterTotal.Location = new System.Drawing.Point(469, 27);
            this.txtWaterTotal.Name = "txtWaterTotal";
            this.txtWaterTotal.Size = new System.Drawing.Size(100, 22);
            this.txtWaterTotal.TabIndex = 7;
            this.txtWaterTotal.Text = "0";
            // 
            // txtWaterNewMill
            // 
            this.txtWaterNewMill.Location = new System.Drawing.Point(121, 30);
            this.txtWaterNewMill.Name = "txtWaterNewMill";
            this.txtWaterNewMill.Size = new System.Drawing.Size(100, 22);
            this.txtWaterNewMill.TabIndex = 4;
            this.txtWaterNewMill.Text = "0";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(41, 30);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(74, 17);
            this.label5.TabIndex = 12;
            this.label5.Text = "NEW MILL";
            // 
            // txtWaterOldMill
            // 
            this.txtWaterOldMill.Location = new System.Drawing.Point(304, 30);
            this.txtWaterOldMill.Name = "txtWaterOldMill";
            this.txtWaterOldMill.Size = new System.Drawing.Size(100, 22);
            this.txtWaterOldMill.TabIndex = 5;
            this.txtWaterOldMill.Text = "0";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(227, 30);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(71, 17);
            this.label6.TabIndex = 10;
            this.label6.Text = "OLD MILL";
            // 
            // groupBoxJuice
            // 
            this.groupBoxJuice.Controls.Add(this.label18);
            this.groupBoxJuice.Controls.Add(this.txtJuiceTotal);
            this.groupBoxJuice.Controls.Add(this.txtjuiceNewMill);
            this.groupBoxJuice.Controls.Add(this.label3);
            this.groupBoxJuice.Controls.Add(this.txtjuiceOldMill);
            this.groupBoxJuice.Controls.Add(this.label2);
            this.groupBoxJuice.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.groupBoxJuice.Location = new System.Drawing.Point(11, 78);
            this.groupBoxJuice.Name = "groupBoxJuice";
            this.groupBoxJuice.Size = new System.Drawing.Size(766, 68);
            this.groupBoxJuice.TabIndex = 0;
            this.groupBoxJuice.TabStop = false;
            this.groupBoxJuice.Text = "Juice Flow";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(414, 28);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(54, 17);
            this.label18.TabIndex = 7;
            this.label18.Text = "TOTAL";
            // 
            // txtJuiceTotal
            // 
            this.txtJuiceTotal.Enabled = false;
            this.txtJuiceTotal.Location = new System.Drawing.Point(473, 25);
            this.txtJuiceTotal.Name = "txtJuiceTotal";
            this.txtJuiceTotal.Size = new System.Drawing.Size(100, 22);
            this.txtJuiceTotal.TabIndex = 100;
            this.txtJuiceTotal.Text = "0";
            // 
            // txtjuiceNewMill
            // 
            this.txtjuiceNewMill.Location = new System.Drawing.Point(125, 25);
            this.txtjuiceNewMill.Name = "txtjuiceNewMill";
            this.txtjuiceNewMill.Size = new System.Drawing.Size(100, 22);
            this.txtjuiceNewMill.TabIndex = 2;
            this.txtjuiceNewMill.Text = "0";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(45, 28);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(74, 17);
            this.label3.TabIndex = 4;
            this.label3.Text = "NEW MILL";
            // 
            // txtjuiceOldMill
            // 
            this.txtjuiceOldMill.Location = new System.Drawing.Point(308, 25);
            this.txtjuiceOldMill.Name = "txtjuiceOldMill";
            this.txtjuiceOldMill.Size = new System.Drawing.Size(100, 22);
            this.txtjuiceOldMill.TabIndex = 3;
            this.txtjuiceOldMill.Text = "0";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(231, 28);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(71, 17);
            this.label2.TabIndex = 2;
            this.label2.Text = "OLD MILL";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.txtTime);
            this.groupBox2.Controls.Add(this.lblDate);
            this.groupBox2.Controls.Add(this.label1);
            this.groupBox2.Controls.Add(this.dateTimeTranDate);
            this.groupBox2.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.groupBox2.Location = new System.Drawing.Point(11, 26);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(766, 46);
            this.groupBox2.TabIndex = 13;
            this.groupBox2.TabStop = false;
            // 
            // txtTime
            // 
            this.txtTime.Location = new System.Drawing.Point(308, 14);
            this.txtTime.Name = "txtTime";
            this.txtTime.Size = new System.Drawing.Size(100, 22);
            this.txtTime.TabIndex = 98;
            // 
            // lblDate
            // 
            this.lblDate.AutoSize = true;
            this.lblDate.Location = new System.Drawing.Point(23, 15);
            this.lblDate.Name = "lblDate";
            this.lblDate.Size = new System.Drawing.Size(96, 17);
            this.lblDate.TabIndex = 7;
            this.lblDate.Text = "ENTRY DATE";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(257, 17);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(40, 17);
            this.label1.TabIndex = 6;
            this.label1.Text = "TIME";
            // 
            // dateTimeTranDate
            // 
            this.dateTimeTranDate.CustomFormat = "yyyy-MM-dd";
            this.dateTimeTranDate.Enabled = false;
            this.dateTimeTranDate.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dateTimeTranDate.Location = new System.Drawing.Point(135, 15);
            this.dateTimeTranDate.Name = "dateTimeTranDate";
            this.dateTimeTranDate.Size = new System.Drawing.Size(100, 22);
            this.dateTimeTranDate.TabIndex = 97;
            // 
            // frm_hourly_transactions
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(800, 645);
            this.Controls.Add(this.groupBox1);
            this.Name = "frm_hourly_transactions";
            this.Text = "Hourly Transactions";
            this.groupBox1.ResumeLayout(false);
            this.groupBoxCaneStatus.ResumeLayout(false);
            this.groupBoxCaneStatus.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.groupBox6.ResumeLayout(false);
            this.groupBoxSugarBags.ResumeLayout(false);
            this.groupBoxSugarBags.PerformLayout();
            this.groupBoxWater.ResumeLayout(false);
            this.groupBoxWater.PerformLayout();
            this.groupBoxJuice.ResumeLayout(false);
            this.groupBoxJuice.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.GroupBox groupBoxSugarBags;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.TextBox txtSugarBagSTotal;
        private System.Windows.Forms.TextBox txtSugarBagMTotal;
        private System.Windows.Forms.TextBox txtSugarBagLTotal;
        private System.Windows.Forms.TextBox txtSugarBagsS30;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox txtSugarBagsS31;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.TextBox txtSugarBagsBiss;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.TextBox txtSugarBagsM30;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox txtSugarBagsM31;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox txtSugarBagsL30;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox txtSugarBagsL31;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.GroupBox groupBoxWater;
        private System.Windows.Forms.GroupBox groupBoxJuice;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.TextBox txtJuiceTotal;
        private System.Windows.Forms.TextBox txtjuiceNewMill;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtjuiceOldMill;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txtWaterTotal;
        private System.Windows.Forms.TextBox txtWaterNewMill;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txtWaterOldMill;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label lblDate;
        private System.Windows.Forms.DateTimePicker dateTimeTranDate;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.TextBox txtSugarbagGrandTotal;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox txtTime;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.TextBox txtCoolingPh;
        private System.Windows.Forms.TextBox txtCoolingPol;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.GroupBox groupBox6;
        private System.Windows.Forms.Button btnModify;
        private System.Windows.Forms.Button btnNewRecord;
        private System.Windows.Forms.Button btnSave;
        private System.Windows.Forms.Button btnClear;
        private System.Windows.Forms.ComboBox comboCoolingTowerTraces;
        private System.Windows.Forms.GroupBox groupBoxCaneStatus;
        private System.Windows.Forms.TextBox txtCaneCrushed;
        private System.Windows.Forms.Label label49;
        private System.Windows.Forms.TextBox txtUncrushedCane;
        private System.Windows.Forms.Label label48;
        private System.Windows.Forms.TextBox txtStandingCarts;
        private System.Windows.Forms.Label label47;
        private System.Windows.Forms.TextBox txtStandingTripplers;
        private System.Windows.Forms.Label label46;
        private System.Windows.Forms.TextBox txtStandingTrolleys;
        private System.Windows.Forms.Label label39;
        private System.Windows.Forms.TextBox txtStandingTrucks;
        private System.Windows.Forms.Label label38;

    }
}