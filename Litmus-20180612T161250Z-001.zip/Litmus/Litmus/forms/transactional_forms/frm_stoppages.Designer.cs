﻿namespace Litmus.forms.transactional_forms
{
    partial class frm_stoppages
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.txtDuration = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.radioOldMill = new System.Windows.Forms.RadioButton();
            this.radioNewMill = new System.Windows.Forms.RadioButton();
            this.label6 = new System.Windows.Forms.Label();
            this.groupBox6 = new System.Windows.Forms.GroupBox();
            this.btnModify = new System.Windows.Forms.Button();
            this.btnNewRecord = new System.Windows.Forms.Button();
            this.btnSave = new System.Windows.Forms.Button();
            this.btnClear = new System.Windows.Forms.Button();
            this.label5 = new System.Windows.Forms.Label();
            this.txtEndTime = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.txtComments = new System.Windows.Forms.TextBox();
            this.ddlStoppageSubHead = new System.Windows.Forms.ComboBox();
            this.ddlStoppageHead = new System.Windows.Forms.ComboBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.txtStartTime = new System.Windows.Forms.TextBox();
            this.lblDate = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.dateTimeTranDate = new System.Windows.Forms.DateTimePicker();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.dataGridViewPendingStoppages = new System.Windows.Forms.DataGridView();
            this.groupBox1.SuspendLayout();
            this.panel1.SuspendLayout();
            this.groupBox6.SuspendLayout();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewPendingStoppages)).BeginInit();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.txtDuration);
            this.groupBox1.Controls.Add(this.label7);
            this.groupBox1.Controls.Add(this.panel1);
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Controls.Add(this.groupBox6);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.txtEndTime);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.txtComments);
            this.groupBox1.Controls.Add(this.ddlStoppageSubHead);
            this.groupBox1.Controls.Add(this.ddlStoppageHead);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.txtStartTime);
            this.groupBox1.Controls.Add(this.lblDate);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.dateTimeTranDate);
            this.groupBox1.Location = new System.Drawing.Point(12, 12);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(795, 318);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            // 
            // txtDuration
            // 
            this.txtDuration.Location = new System.Drawing.Point(657, 73);
            this.txtDuration.Name = "txtDuration";
            this.txtDuration.ReadOnly = true;
            this.txtDuration.Size = new System.Drawing.Size(100, 22);
            this.txtDuration.TabIndex = 113;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(561, 76);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(80, 17);
            this.label7.TabIndex = 114;
            this.label7.Text = "DURATION";
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.radioOldMill);
            this.panel1.Controls.Add(this.radioNewMill);
            this.panel1.Location = new System.Drawing.Point(111, 68);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(210, 38);
            this.panel1.TabIndex = 3;
            // 
            // radioOldMill
            // 
            this.radioOldMill.AutoSize = true;
            this.radioOldMill.Location = new System.Drawing.Point(111, 6);
            this.radioOldMill.Name = "radioOldMill";
            this.radioOldMill.Size = new System.Drawing.Size(51, 21);
            this.radioOldMill.TabIndex = 115;
            this.radioOldMill.TabStop = true;
            this.radioOldMill.Text = "Old";
            this.radioOldMill.UseVisualStyleBackColor = true;
            // 
            // radioNewMill
            // 
            this.radioNewMill.AutoSize = true;
            this.radioNewMill.Location = new System.Drawing.Point(12, 6);
            this.radioNewMill.Name = "radioNewMill";
            this.radioNewMill.Size = new System.Drawing.Size(56, 21);
            this.radioNewMill.TabIndex = 3;
            this.radioNewMill.TabStop = true;
            this.radioNewMill.Text = "New";
            this.radioNewMill.UseVisualStyleBackColor = true;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(65, 74);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(28, 17);
            this.label6.TabIndex = 112;
            this.label6.Text = "Mill";
            // 
            // groupBox6
            // 
            this.groupBox6.Controls.Add(this.btnModify);
            this.groupBox6.Controls.Add(this.btnNewRecord);
            this.groupBox6.Controls.Add(this.btnSave);
            this.groupBox6.Controls.Add(this.btnClear);
            this.groupBox6.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.groupBox6.Location = new System.Drawing.Point(164, 250);
            this.groupBox6.Name = "groupBox6";
            this.groupBox6.Size = new System.Drawing.Size(453, 48);
            this.groupBox6.TabIndex = 7;
            this.groupBox6.TabStop = false;
            // 
            // btnModify
            // 
            this.btnModify.Enabled = false;
            this.btnModify.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnModify.Location = new System.Drawing.Point(118, 11);
            this.btnModify.Name = "btnModify";
            this.btnModify.Size = new System.Drawing.Size(105, 31);
            this.btnModify.TabIndex = 8;
            this.btnModify.Text = "MODIFY";
            this.btnModify.UseVisualStyleBackColor = true;
            this.btnModify.Click += new System.EventHandler(this.btnModify_Click);
            // 
            // btnNewRecord
            // 
            this.btnNewRecord.Enabled = false;
            this.btnNewRecord.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnNewRecord.Location = new System.Drawing.Point(9, 11);
            this.btnNewRecord.Name = "btnNewRecord";
            this.btnNewRecord.Size = new System.Drawing.Size(105, 31);
            this.btnNewRecord.TabIndex = 8;
            this.btnNewRecord.Text = "&New Record";
            this.btnNewRecord.UseVisualStyleBackColor = true;
            this.btnNewRecord.Click += new System.EventHandler(this.btnNewRecord_Click);
            // 
            // btnSave
            // 
            this.btnSave.Enabled = false;
            this.btnSave.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnSave.Location = new System.Drawing.Point(229, 11);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(105, 31);
            this.btnSave.TabIndex = 7;
            this.btnSave.Text = "&Save";
            this.btnSave.UseVisualStyleBackColor = true;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // btnClear
            // 
            this.btnClear.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnClear.Location = new System.Drawing.Point(340, 11);
            this.btnClear.Name = "btnClear";
            this.btnClear.Size = new System.Drawing.Size(105, 31);
            this.btnClear.TabIndex = 9;
            this.btnClear.Text = "&Clear";
            this.btnClear.UseVisualStyleBackColor = true;
            this.btnClear.Click += new System.EventHandler(this.btnClear_Click);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(6, 201);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(87, 17);
            this.label5.TabIndex = 110;
            this.label5.Text = "COMMENTS";
            // 
            // txtEndTime
            // 
            this.txtEndTime.Location = new System.Drawing.Point(657, 28);
            this.txtEndTime.Name = "txtEndTime";
            this.txtEndTime.Size = new System.Drawing.Size(100, 22);
            this.txtEndTime.TabIndex = 2;
            this.txtEndTime.TextChanged += new System.EventHandler(this.txtEndTime_TextChanged);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(561, 31);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(73, 17);
            this.label4.TabIndex = 108;
            this.label4.Text = "END TIME";
            // 
            // txtComments
            // 
            this.txtComments.Location = new System.Drawing.Point(111, 180);
            this.txtComments.Multiline = true;
            this.txtComments.Name = "txtComments";
            this.txtComments.Size = new System.Drawing.Size(312, 66);
            this.txtComments.TabIndex = 6;
            // 
            // ddlStoppageSubHead
            // 
            this.ddlStoppageSubHead.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.ddlStoppageSubHead.FormattingEnabled = true;
            this.ddlStoppageSubHead.Location = new System.Drawing.Point(111, 150);
            this.ddlStoppageSubHead.Name = "ddlStoppageSubHead";
            this.ddlStoppageSubHead.Size = new System.Drawing.Size(210, 24);
            this.ddlStoppageSubHead.TabIndex = 5;
            // 
            // ddlStoppageHead
            // 
            this.ddlStoppageHead.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.ddlStoppageHead.FormattingEnabled = true;
            this.ddlStoppageHead.Location = new System.Drawing.Point(111, 112);
            this.ddlStoppageHead.Name = "ddlStoppageHead";
            this.ddlStoppageHead.Size = new System.Drawing.Size(210, 24);
            this.ddlStoppageHead.TabIndex = 4;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(15, 153);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(78, 17);
            this.label3.TabIndex = 104;
            this.label3.Text = "SUB HEAD";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(47, 119);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(46, 17);
            this.label2.TabIndex = 103;
            this.label2.Text = "HEAD";
            // 
            // txtStartTime
            // 
            this.txtStartTime.Location = new System.Drawing.Point(429, 27);
            this.txtStartTime.Name = "txtStartTime";
            this.txtStartTime.Size = new System.Drawing.Size(100, 22);
            this.txtStartTime.TabIndex = 1;
            // 
            // lblDate
            // 
            this.lblDate.AutoSize = true;
            this.lblDate.Location = new System.Drawing.Point(47, 31);
            this.lblDate.Name = "lblDate";
            this.lblDate.Size = new System.Drawing.Size(45, 17);
            this.lblDate.TabIndex = 100;
            this.lblDate.Text = "DATE";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(333, 30);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(90, 17);
            this.label1.TabIndex = 99;
            this.label1.Text = "START TIME";
            // 
            // dateTimeTranDate
            // 
            this.dateTimeTranDate.CustomFormat = "yyyy-MM-dd";
            this.dateTimeTranDate.Enabled = false;
            this.dateTimeTranDate.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dateTimeTranDate.Location = new System.Drawing.Point(111, 26);
            this.dateTimeTranDate.Name = "dateTimeTranDate";
            this.dateTimeTranDate.Size = new System.Drawing.Size(100, 22);
            this.dateTimeTranDate.TabIndex = 101;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.dataGridViewPendingStoppages);
            this.groupBox2.Location = new System.Drawing.Point(12, 336);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(795, 298);
            this.groupBox2.TabIndex = 1;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "PENDING STOPPAGES";
            // 
            // dataGridViewPendingStoppages
            // 
            this.dataGridViewPendingStoppages.AllowUserToAddRows = false;
            this.dataGridViewPendingStoppages.AllowUserToDeleteRows = false;
            this.dataGridViewPendingStoppages.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewPendingStoppages.Location = new System.Drawing.Point(8, 21);
            this.dataGridViewPendingStoppages.Name = "dataGridViewPendingStoppages";
            this.dataGridViewPendingStoppages.ReadOnly = true;
            this.dataGridViewPendingStoppages.RowTemplate.Height = 24;
            this.dataGridViewPendingStoppages.Size = new System.Drawing.Size(781, 271);
            this.dataGridViewPendingStoppages.TabIndex = 0;
            // 
            // frm_stoppages
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(819, 646);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Name = "frm_stoppages";
            this.Text = "Stoppages";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.groupBox6.ResumeLayout(false);
            this.groupBox2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewPendingStoppages)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TextBox txtStartTime;
        private System.Windows.Forms.Label lblDate;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.DateTimePicker dateTimeTranDate;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txtEndTime;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txtComments;
        private System.Windows.Forms.ComboBox ddlStoppageSubHead;
        private System.Windows.Forms.ComboBox ddlStoppageHead;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.DataGridView dataGridViewPendingStoppages;
        private System.Windows.Forms.GroupBox groupBox6;
        private System.Windows.Forms.Button btnModify;
        private System.Windows.Forms.Button btnNewRecord;
        private System.Windows.Forms.Button btnSave;
        private System.Windows.Forms.Button btnClear;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.RadioButton radioOldMill;
        private System.Windows.Forms.RadioButton radioNewMill;
        private System.Windows.Forms.TextBox txtDuration;
        private System.Windows.Forms.Label label7;
    }
}