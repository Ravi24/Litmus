﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Litmus.forms.transactional_forms
{
    
    public partial class frm_day_analysis : Form
    {
        classes.generalFunctions genFunc = new classes.generalFunctions();
        classes.master_parameter_logic masterParam = new classes.master_parameter_logic();
        classes.day_analysis_logic dayAnalysisLogic = new classes.day_analysis_logic();
        classes.ExceptionHelper expHelper = new classes.ExceptionHelper();
        private string trans_Date, trans_time, crtd_by= null, updtby = null, updt_dt;
        private string actionType = "";
        bool recordsExistsForTheDay = false; // variable to hold existance status of records in database for selected date. 
        
        private float cane_early, cane_general, cane_rejected, cane_gate, cane_centre, cane_farm, cane_crushed, total_juice, sp_gravity, total_water,
                    press_cake, molasses_sent_out, biss_sugar, biss_molasses, scrap_sugar, scrap_molasses, moist_sugar, moist_molasses,
                    raw_sugar, raw_molasses, other_sugar, other_molasses, unknown_losses, dirt_correction, 
                    total_operating_tubewell, exhaust_condensate_recovery, no_of_80t_massecuite_pan,
                    store_sulpher, store_phosphoric, store_lime, store_viscosity,
                    store_bioside, store_color_reducer, store_megnafloe, store_lub_oil, store_lub_grease, store_boiler_chemical, icumsa_l31, icumsa_l30,
                    icumsa_m31, icumsa_m30, icumsa_s31, icumsa_s30,
                    foreign_matter_l31, foreign_matter_l30, foreign_matter_m31, foreign_matter_m30,
                    foreign_matter_s31, foreign_matter_s30, retention_l31, retention_l30,
                    retention_m31, retention_m30, retention_s31, retention_s30, etp_ph, etp_tss , etp_cod, etp_bod, etp_waterFlow,
                    calcium_mixed_juice, calcium_clear_juice, phosphate_mixed_juice,
                    phosphate_clear_juice, ph_injection_inlet, ph_injection_outlet,
                    average_vaccume_pan, average_vaccume_evap, Exhaust_steam_press_lp, Exhaust_steam_press_hp,
                    boiler_steam_press_lp, boiler_steam_hp, ph_boiler_feed_water, boiler_water, 
                    bagasse_baed, power_from_uppcb, power_export_uppcb, filter_water,
                    pan_water, cf_water, bagasse_sold, bagasse_stock,
                    nm_p_index, nm_pry_ext, om_p_index, om_pry_ext, trs_percentage, rs_percentage,
                    temp_max, temp_min, humidity, rain_fall,
                    iu_primary_juice, iu_mixed_juice, iu_clear_juice, ph_primary_juice,
                    ph_mixed_juice, live_steam_generation, live_steam_consumption, power_turbines,
                    bleeding_in_process, bleeding_acf, ata_cogen, drain_pipe_loss,
                    exhaust_steam_generation, exhaust_steam_consumption, steam_percent_cane, d_sulpher_heating, turbine_25,
                    turbine_3_New, turbine_3_Old, turbine_1, dg_set, power_import_cogen, total_power;
        private float steam_per_ton_cane, steam_per_qtl_sugar, power_per_ton_cane, power_per_qtl_sugar, total_sugar_bags
            ,steam_per_cane;
        public frm_day_analysis()
        {
            InitializeComponent();
            txtTransDate.Text = masterParam.entryDate;
            recordsExistsForTheDay = dayAnalysisLogic.entryExistsForTheDay(masterParam.entryDate);
            if (recordsExistsForTheDay == true)
            {
                actionType = "update";
            }
            else
            {
                actionType="insert";
            }
            txtTransTime.Text = DateTime.Now.ToString("hh:mm");

            onFormLoadDayData(masterParam.entryDate);

            btnSave.GotFocus += new EventHandler(btnSaveGotFocus);
            txtTransDate.LostFocus += new EventHandler(get_data_for_date);
        }
        private void btnSaveGotFocus(object sender, EventArgs e)
        {
            valueAssignment("update");
        }

        private void btnNewRecord_Click(object sender, EventArgs e)
        {
            genFunc.enableFieldsInControl(tabControl1);
            btnSave.Enabled = true;
            btnNewRecord.Enabled = false;
        }
        private void btnSave_Click(object sender, EventArgs e)
        {
            //genFunc.disableFieldsInControl(tabControl1);
            //btnSave.Enabled = false;
            
            btnNewRecord.Enabled = true;
            
          DialogResult confirm =  MessageBox.Show("Are you sure to make changes?","Sure to proceed?",MessageBoxButtons.YesNo,MessageBoxIcon.Question);
            if(confirm == DialogResult.Yes)
            {
                btnSaveOperations();
            }
             
        }
        private void valueAssignment(string actionType)
        {
            trans_Date = txtTransDate.Text;
            trans_time = txtTransTime.Text;
            cane_early = float.Parse(txtEarly.Text);
            cane_general = float.Parse(txtGeneral.Text);
            cane_rejected = float.Parse(txtReject.Text);
            cane_gate = float.Parse(txtCaneGate.Text);
            cane_centre = float.Parse(txtCaneCentre.Text);
            cane_crushed = float.Parse(txtCaneCrushed.Text);
            total_juice = float.Parse(txtJuice.Text);
            sp_gravity = float.Parse(txtSpGrvity.Text);
            total_water = float.Parse(txtWater.Text);
            press_cake = float.Parse(txtPressCake.Text);
            molasses_sent_out = float.Parse(txtMolassesSentOut.Text);
            biss_sugar = float.Parse(txtBissSugar.Text);
            biss_molasses = float.Parse(txtBissMolasses.Text);
            scrap_sugar = float.Parse(txtScrapSugar.Text);
            scrap_molasses = float.Parse(txtScrapMolasses.Text);
            moist_sugar = float.Parse(txtMoistSugar.Text);
            moist_molasses = float.Parse(txtMoistMolasses.Text);
            raw_sugar = float.Parse(txtRawSugar.Text);
            raw_molasses = float.Parse(txtRawMolasses.Text);
            other_sugar = float.Parse(txtOtherSugar.Text);
            other_molasses = float.Parse(txtOtherMolasses.Text);
            store_sulpher = float.Parse(txtStoreSulpher.Text);
            store_phosphoric = float.Parse(txtStorePhosphoric.Text);
            store_lime = float.Parse(txtStoreLime.Text);
            store_viscosity = float.Parse(txtStoreViscocty.Text);
            store_bioside = float.Parse(txtStoreBioeide.Text);
            store_color_reducer = float.Parse(txtStoreColorReducer.Text);
            store_megnafloe = float.Parse(txtStoreMegnafloe.Text);
            store_lub_oil = float.Parse(txtStoreLubOil.Text);
            store_lub_grease = float.Parse(txtStoreLubGreece.Text);
            store_boiler_chemical = float.Parse(txtStoreBoilerChemical.Text);
            icumsa_l31 = float.Parse(txtIcumsaL31.Text);
            icumsa_l30 = float.Parse(txtIcumsaL30.Text);
            icumsa_m31 = float.Parse(txtIcumsaM31.Text);
            icumsa_m30 = float.Parse(txtIcumsaM30.Text);
            icumsa_s31 = float.Parse(txtIcumsaS31.Text);
            icumsa_s30 = float.Parse(txtIcumsaS30.Text);
            foreign_matter_l31 = float.Parse(txtForeIgnL31.Text);
            foreign_matter_l30 = float.Parse(txtForeignL30.Text);
            foreign_matter_m31 = float.Parse(txtForeignM31.Text);
            foreign_matter_m30 = float.Parse(txtForeignM30.Text);
            foreign_matter_s31 = float.Parse(txtForeignS31.Text);
            foreign_matter_s30 = float.Parse(txtForeignS30.Text);
            retention_l31 = float.Parse(txtRetentionL31.Text);
            retention_l30 = float.Parse(txtRetentionL30.Text);
            retention_m31 = float.Parse(txtRetentionM31.Text);
            retention_m30 = float.Parse(txtRetentionM30.Text);
            retention_s31 = float.Parse(txtRetentionS31.Text);
            retention_s30 = float.Parse(txtRetentionS30.Text);
            etp_ph = float.Parse(txtEtpPh.Text);
            etp_tss = float.Parse(txtEtpTss.Text);
            etp_cod = float.Parse(txtEtpCod.Text);
            etp_bod = float.Parse(txtEtpBod.Text);
            etp_waterFlow = float.Parse(txtEtpWaterFlow.Text);
            calcium_mixed_juice = float.Parse(txtCalciumMixedJuice.Text);
            calcium_clear_juice = float.Parse(txtCalciumClearJuice.Text);
            phosphate_mixed_juice = float.Parse(txtPhosphateMixedJuice.Text);
            phosphate_clear_juice = float.Parse(txtPhosphateClearJuice.Text);
            unknown_losses = float.Parse(txtUnknownLosses.Text);
            dirt_correction = float.Parse(txtDirtCorrection.Text);
            total_operating_tubewell = float.Parse(txtTotalOperatingTubeWell.Text);
            exhaust_condensate_recovery = float.Parse(txtExhaustCondensateRecovery.Text);
            no_of_80t_massecuite_pan = float.Parse(txt80tCMassecuitePan.Text);

            ph_injection_inlet = float.Parse(txtInjectionInlet.Text);
            ph_injection_outlet = float.Parse(txtInjectionOutlet.Text);
            average_vaccume_pan = float.Parse(txtVaccumeOnPan.Text);
            average_vaccume_evap = float.Parse(txtVaccumeOnEvap.Text);
            Exhaust_steam_press_lp = float.Parse(txtExhaustSteamPressLp.Text);
            Exhaust_steam_press_hp = float.Parse(txtExhaustSteamPressHp.Text);
            boiler_steam_press_lp = float.Parse(txtBoilerSteamPressLp.Text);
            boiler_steam_hp = float.Parse(txtBoilerSteamPressHp.Text);
            ph_boiler_feed_water = float.Parse(txtBoilerFeedWater.Text);
            boiler_water = float.Parse(txtBoilerWater.Text);
            bagasse_baed = float.Parse(txtBaggasseBaed.Text);
            power_from_uppcb = float.Parse(txtPowerFromUppcb.Text);
            power_export_uppcb = float.Parse(txtPowerExportUppcb.Text);
            filter_water = float.Parse(txtFilterWater.Text);
            pan_water = float.Parse(txtPanWater.Text);
            cf_water = float.Parse(txtCfWater.Text);
            bagasse_sold = float.Parse(txtBagasseSold.Text);
            bagasse_stock = float.Parse(txtBagasseStock.Text);
            nm_p_index = float.Parse(txtNmPIndex.Text);
            nm_pry_ext = float.Parse(txtNmPryExt.Text);
            om_p_index = float.Parse(txtOmPIndex.Text);
            om_pry_ext = float.Parse(txtOmPryExt.Text);
            trs_percentage = float.Parse(txtTrsPercentage.Text);
            rs_percentage = float.Parse(TxtRsPercentage.Text);
            temp_max = float.Parse(txtTempMax.Text);
            temp_min = float.Parse(txtTempMin.Text);
            humidity = float.Parse(txtHumidity.Text);
            rain_fall = float.Parse(txtRainFall.Text);
            iu_primary_juice = float.Parse(txtIuPrimaryJuice.Text);
            iu_mixed_juice = float.Parse(txtIuMixedJuice.Text);
            iu_clear_juice = float.Parse(txtIuClearJuice.Text);
            ph_primary_juice = float.Parse(txtPhPrimaryJuice.Text);
            ph_mixed_juice = float.Parse(txtPhMixedJuice.Text);
            live_steam_generation = float.Parse(txtLiveStamGeneration.Text);
            live_steam_consumption = float.Parse(txtLiveSteamConsumption.Text);
            power_turbines = float.Parse(txtPowerTurbines.Text);
            bleeding_in_process = float.Parse(txtBleedingProcess.Text);
            bleeding_acf = float.Parse(txtBleedingAcf.Text);
            ata_cogen = float.Parse(txtAtaFromCogen.Text);
            d_sulpher_heating = float.Parse(txtD_sulpher_heating.Text);
            drain_pipe_loss = float.Parse(txtDrainPipeLoss.Text);
            exhaust_steam_generation = float.Parse(txtExhaustSteamGeneration.Text);
            exhaust_steam_consumption = float.Parse(txtExhaustStamConsumption.Text);
            steam_per_cane = float.Parse(txtSteamPercentCane.Text);
            turbine_25 = float.Parse(txtPowerGen25Turbine.Text);
            turbine_3_New = float.Parse(txtPowerGen3NewTurbine.Text);
            turbine_3_Old = float.Parse(txtPowerGen3OldTurbine.Text);
            turbine_1 = float.Parse(txtPowerGen1Turbine.Text);
            dg_set = float.Parse(txtPowerGenDg.Text);
            power_import_cogen = float.Parse(txtPowerGenImportFromCogen.Text);
            cane_farm = float.Parse(txtCaneFarm.Text);
            

            /// formulae
            total_power = turbine_3_New + turbine_3_Old + turbine_1 + dg_set + power_import_cogen;
            total_sugar_bags = dayAnalysisLogic.totalSugarBagsforTheDay(trans_Date);
            //----- exhaust_steam_consumption is Total Steam 
            // bleeding_in_process = 3ATA & bleeding_acf = 9ATA
            exhaust_steam_consumption = bleeding_in_process + d_sulpher_heating  + bleeding_acf + ata_cogen  + exhaust_steam_generation;
            
            
            if (cane_crushed > 0)
            {
                steam_per_ton_cane = (exhaust_steam_consumption / (cane_crushed / 10));
                power_per_ton_cane = (total_power / (cane_crushed / 10));
            }
            else
            {
                steam_per_ton_cane = 0;
                power_per_ton_cane = 0;
            }
            if (total_sugar_bags > 0)
            {
                steam_per_qtl_sugar = exhaust_steam_consumption / (total_sugar_bags);
                power_per_qtl_sugar = (total_power / total_sugar_bags);
            }
            else
            {
                steam_per_qtl_sugar = 0;
                power_per_ton_cane = 0;
            }
            if (cane_crushed > 0)
            {
                steam_percent_cane = (exhaust_steam_consumption / cane_crushed)*100;
            }
            else
            {
                steam_percent_cane = 0;
            }
            
            txTotalPower.Text = total_power.ToString();
            txtExhaustStamConsumption.Text = exhaust_steam_consumption.ToString();
            txtPowerPerTonOfCane.Text = power_per_ton_cane.ToString();
            txtPowerPerQtlOfSugar.Text = power_per_qtl_sugar.ToString();
            txtSteamPerTonOfCane.Text = steam_per_ton_cane.ToString();
            txtSteamPerQtlOfSugar.Text = steam_per_qtl_sugar.ToString();
            txtSteamPercentCane.Text = steam_percent_cane.ToString();

            switch (actionType)
            {
                case"insert":
                    crtd_by = genFunc.userCode;
                    break;
                case "update":
                    updtby = genFunc.userCode;
                    updt_dt = DateTime.Now.ToString("yyyy-MM-dd hh:mm:ss");
                    break;
                default:
                    crtd_by = genFunc.userCode;
                    break;
            }    
        }

        private void get_data_for_date(object sender, EventArgs e)
        {
            string selected_date = txtTransDate.Text;
            onFormLoadDayData(selected_date);
        }
        private void onFormLoadDayData(string trans_date)
        {
            try
            {
                DataTable dt = dayAnalysisLogic.getDailyAnalysisDataForTheDay(trans_date);
                if (dt.Rows.Count > 0)
                {
                    txtTransDate.Text = dt.Rows[0]["trans_date"].ToString();
                    txtEarly.Text = dt.Rows[0]["cane_early"].ToString();
                    txtGeneral.Text = dt.Rows[0]["cane_general"].ToString();
                    txtReject.Text = dt.Rows[0]["cane_rejected"].ToString();
                    txtCaneCentre.Text = dt.Rows[0]["cane_centre"].ToString();
                    txtCaneGate.Text = dt.Rows[0]["cane_gate"].ToString();
                    txtCaneFarm.Text = dt.Rows[0]["cane_farm"].ToString();
                    txtCaneCrushed.Text = dt.Rows[0]["cane_crushed"].ToString();
                    txtJuice.Text = dt.Rows[0]["total_juice"].ToString();
                    txtSpGrvity.Text = dt.Rows[0]["sp_gravity"].ToString();
                    txtWater.Text = dt.Rows[0]["total_water"].ToString();
                    txtPressCake.Text = dt.Rows[0]["press_cake"].ToString();
                    txtMolassesSentOut.Text = dt.Rows[0]["molasses_sent_out"].ToString();
                    txtBissSugar.Text = dt.Rows[0]["biss_sugar"].ToString();
                    txtBissMolasses.Text = dt.Rows[0]["biss_molasses"].ToString();
                    txtScrapSugar.Text = dt.Rows[0]["scrap_sugar"].ToString();
                    txtScrapMolasses.Text = dt.Rows[0]["scrap_molasses"].ToString();
                    txtMoistSugar.Text = dt.Rows[0]["moist_sugar"].ToString();
                    txtMoistMolasses.Text = dt.Rows[0]["moist_molasses"].ToString();
                    txtRawSugar.Text = dt.Rows[0]["raw_sugar"].ToString();
                    txtRawMolasses.Text = dt.Rows[0]["raw_molasses"].ToString();
                    txtOtherSugar.Text = dt.Rows[0]["other_sugar"].ToString();
                    txtOtherMolasses.Text = dt.Rows[0]["other_molasses"].ToString();

                    txtStoreSulpher.Text = dt.Rows[0]["store_sulpher"].ToString();
                    txtStorePhosphoric.Text = dt.Rows[0]["store_phosphoric"].ToString();
                    txtStoreLime.Text = dt.Rows[0]["store_lime"].ToString();
                    txtStoreViscocty.Text = dt.Rows[0]["store_viscosity_reducer"].ToString();
                    txtStoreBioeide.Text = dt.Rows[0]["store_biocide"].ToString();
                    txtStoreColorReducer.Text = dt.Rows[0]["store_color_reducer"].ToString();
                    txtStoreMegnafloe.Text = dt.Rows[0]["store_megnafloe"].ToString();
                    txtStoreLubOil.Text = dt.Rows[0]["store_lub_oil"].ToString();
                    txtStoreLubGreece.Text = dt.Rows[0]["store_lub_grease"].ToString();
                    txtStoreBoilerChemical.Text = dt.Rows[0]["store_boiler_chemical"].ToString();
                    txtIcumsaL31.Text = dt.Rows[0]["icumsa_l31"].ToString();
                    txtIcumsaL30.Text = dt.Rows[0]["icumsa_l30"].ToString();
                    txtIcumsaM31.Text = dt.Rows[0]["icumsa_m31"].ToString();
                    txtIcumsaM30.Text = dt.Rows[0]["icumsa_m30"].ToString();
                    txtIcumsaS31.Text = dt.Rows[0]["icumsa_s31"].ToString();
                    txtIcumsaS30.Text = dt.Rows[0]["icumsa_s30"].ToString();
                    txtForeIgnL31.Text = dt.Rows[0]["foreign_matter_l31"].ToString();
                    txtForeignL30.Text = dt.Rows[0]["foreign_matter_l30"].ToString();
                    txtForeignM31.Text = dt.Rows[0]["foreign_matter_m31"].ToString();
                    txtForeignM30.Text = dt.Rows[0]["foreign_matter_m30"].ToString();
                    txtForeignS31.Text = dt.Rows[0]["foreign_matter_s31"].ToString();
                    txtForeignS30.Text = dt.Rows[0]["foreign_matter_s30"].ToString();
                    txtRetentionL31.Text = dt.Rows[0]["retention_l31"].ToString();
                    txtRetentionL30.Text = dt.Rows[0]["retention_l30"].ToString();
                    txtRetentionM31.Text = dt.Rows[0]["retention_m31"].ToString();
                    txtRetentionM30.Text = dt.Rows[0]["retention_m30"].ToString();
                    txtRetentionS31.Text = dt.Rows[0]["retention_s31"].ToString();
                    txtRetentionS30.Text = dt.Rows[0]["retention_s30"].ToString();

                    txtCalciumMixedJuice.Text = dt.Rows[0]["calcium_mixed_juice"].ToString();
                    txtCalciumClearJuice.Text = dt.Rows[0]["calcium_clear_juice"].ToString();
                    txtPhosphateMixedJuice.Text = dt.Rows[0]["phosphate_mixed_juice"].ToString();
                    txtPhosphateClearJuice.Text = dt.Rows[0]["phosphate_clear_juice"].ToString();
                    txtEtpTss.Text = dt.Rows[0]["etp_water_flow"].ToString();
                    txtInjectionInlet.Text = dt.Rows[0]["ph_injection_inlet"].ToString();
                    txtInjectionOutlet.Text = dt.Rows[0]["ph_injection_outlet"].ToString();
                    txtVaccumeOnPan.Text = dt.Rows[0]["average_vaccume_pan"].ToString();
                    txtVaccumeOnEvap.Text = dt.Rows[0]["average_vaccume_evap"].ToString();
                    txtExhaustSteamPressLp.Text = dt.Rows[0]["Exhaust_steam_press_lp"].ToString();
                    txtExhaustSteamPressHp.Text = dt.Rows[0]["Exhaust_steam_press_hp"].ToString();
                    txtBoilerSteamPressLp.Text = dt.Rows[0]["boiler_steam_press_lp"].ToString();
                    txtBoilerSteamPressHp.Text = dt.Rows[0]["boiler_steam_press_hp"].ToString();
                    txtBoilerFeedWater.Text = dt.Rows[0]["ph_boiler_feed_water"].ToString();

                    txtEtpPh.Text = dt.Rows[0]["etp_ph"].ToString();
                    txtEtpTss.Text = dt.Rows[0]["etp_tss"].ToString();
                    txtEtpCod.Text = dt.Rows[0]["etp_cod"].ToString();
                    txtEtpBod.Text = dt.Rows[0]["etp_bod"].ToString();
                    txtEtpWaterFlow.Text = dt.Rows[0]["etp_water_flow"].ToString();

                    txtCalciumMixedJuice.Text = dt.Rows[0]["calcium_mixed_juice"].ToString();
                    txtCalciumClearJuice.Text = dt.Rows[0]["calcium_clear_juice"].ToString();
                    txtPhosphateMixedJuice.Text = dt.Rows[0]["phosphate_mixed_juice"].ToString();
                    txtPhosphateClearJuice.Text = dt.Rows[0]["phosphate_clear_juice"].ToString();
                    txtUnknownLosses.Text = dt.Rows[0]["unknown_losses"].ToString(); //unknow losses
                    txtDirtCorrection.Text = dt.Rows[0]["dirt_correction"].ToString(); //dirt correction

                    txtTotalOperatingTubeWell.Text = dt.Rows[0]["total_operating_tube_well"].ToString();
                    txtExhaustCondensateRecovery.Text = dt.Rows[0]["exhaust_condensate_recovery"].ToString();
                    txt80tCMassecuitePan.Text = dt.Rows[0]["t_c_massecuite_pan"].ToString();
                    txtInjectionInlet.Text = dt.Rows[0]["ph_injection_inlet"].ToString();
                    txtInjectionOutlet.Text = dt.Rows[0]["ph_injection_outlet"].ToString();
                    txtVaccumeOnPan.Text = dt.Rows[0]["average_vaccume_pan"].ToString();
                    txtVaccumeOnEvap.Text = dt.Rows[0]["average_vaccume_evap"].ToString();
                    txtExhaustSteamPressLp.Text = dt.Rows[0]["exhaust_steam_press_lp"].ToString();
                    txtExhaustSteamPressHp.Text = dt.Rows[0]["exhaust_steam_press_hp"].ToString();
                    txtBoilerSteamPressLp.Text = dt.Rows[0]["boiler_steam_press_lp"].ToString();
                    txtBoilerSteamPressHp.Text = dt.Rows[0]["boiler_steam_press_hp"].ToString();
                    txtBoilerFeedWater.Text = dt.Rows[0]["ph_boiler_feed_water"].ToString();
                    txtBoilerWater.Text = dt.Rows[0]["boiler_water"].ToString();
                    txtBaggasseBaed.Text = dt.Rows[0]["bagasse_baed"].ToString(); ;
                    txtPowerFromUppcb.Text = dt.Rows[0]["power_from_uppcb"].ToString();
                    txtPowerExportUppcb.Text = dt.Rows[0]["power_export_uppcb"].ToString();
                    txtFilterWater.Text = dt.Rows[0]["filter_water"].ToString();
                    txtPanWater.Text = dt.Rows[0]["pan_water"].ToString();
                    txtCfWater.Text = dt.Rows[0]["cf_water"].ToString();
                    txtBagasseSold.Text = dt.Rows[0]["bagasse_sold"].ToString();
                    txtBagasseStock.Text = dt.Rows[0]["bagasse_stock"].ToString();
                    txtNmPIndex.Text = dt.Rows[0]["nm_p_index"].ToString();
                    txtNmPryExt.Text = dt.Rows[0]["nm_pry_ext"].ToString();
                    txtOmPIndex.Text = dt.Rows[0]["om_p_index"].ToString();
                    txtOmPryExt.Text = dt.Rows[0]["om_pry_ext"].ToString();
                    txtTrsPercentage.Text = dt.Rows[0]["trs_percentage"].ToString();
                    TxtRsPercentage.Text = dt.Rows[0]["rs_percentage"].ToString();
                    txtTempMax.Text = dt.Rows[0]["temp_max"].ToString();
                    txtTempMin.Text = dt.Rows[0]["temp_min"].ToString();
                    txtHumidity.Text = dt.Rows[0]["humidity"].ToString();
                    txtRainFall.Text = dt.Rows[0]["rain_fall"].ToString();
                    txtIuPrimaryJuice.Text = dt.Rows[0]["iu_primary_juice"].ToString();
                    txtIuMixedJuice.Text = dt.Rows[0]["iu_mixed_juice"].ToString();
                    txtIuClearJuice.Text = dt.Rows[0]["iu_clear_juice"].ToString();
                    txtPhPrimaryJuice.Text = dt.Rows[0]["ph_primary_juice"].ToString();
                    txtPhMixedJuice.Text = dt.Rows[0]["ph_mixed_juice"].ToString();
                    txtLiveStamGeneration.Text = dt.Rows[0]["live_steam_generation"].ToString();
                    txtLiveSteamConsumption.Text = dt.Rows[0]["live_steam_consumption"].ToString();
                    txtPowerTurbines.Text = dt.Rows[0]["power_turbines"].ToString();
                    txtBleedingProcess.Text = dt.Rows[0]["bleeding_in_process"].ToString();
                    txtBleedingAcf.Text = dt.Rows[0]["bleeding_acf"].ToString();
                    txtAtaFromCogen.Text = dt.Rows[0]["ata3_cogen"].ToString();
                    txtD_sulpher_heating.Text = dt.Rows[0]["d_sulpher_heating"].ToString();
                    txtDrainPipeLoss.Text = dt.Rows[0]["drain_pipe_loss"].ToString();
                    txtExhaustSteamGeneration.Text = dt.Rows[0]["exhaust_steam_generation"].ToString();
                    txtExhaustStamConsumption.Text = dt.Rows[0]["exhaust_steam_consumption"].ToString();
                    txtSteamPercentCane.Text = dt.Rows[0]["steam_percent_cane"].ToString();
                    txtSteamPerTonOfCane.Text = dt.Rows[0]["steam_per_ton_cane"].ToString();
                    txtSteamPerQtlOfSugar.Text = dt.Rows[0]["steam_per_qtl_sugar"].ToString();
                    txtPowerGen25Turbine.Text = dt.Rows[0]["turbine_25_mw"].ToString();
                    txtPowerGen3NewTurbine.Text = dt.Rows[0]["turbine_three_mw_new"].ToString();
                    txtPowerGen3OldTurbine.Text = dt.Rows[0]["turbine_three_mw_old"].ToString();
                    txtPowerGen1Turbine.Text = dt.Rows[0]["turbine_1_mw"].ToString();
                    txtPowerGenDg.Text = dt.Rows[0]["dg_set"].ToString();
                    txtPowerGenImportFromCogen.Text = dt.Rows[0]["power_import_cogen"].ToString();
                    txTotalPower.Text = dt.Rows[0]["total_power"].ToString();
                    txtPowerPerTonOfCane.Text = dt.Rows[0]["power_per_ton_cane"].ToString();
                    txtPowerPerQtlOfSugar.Text = dt.Rows[0]["power_per_qtl_sugar"].ToString();
                    btnSave.Enabled = true;
                    btnNewRecord.Enabled = false;
                }
                else
                {
                    genFunc.disableFieldsInControl(tabControl1);
                    MessageBox.Show("No data exists for selected date.\nClick on 'New Record' button to proceed", "No data to Show", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
            catch (Exception ex)
            {

                MessageBox.Show("Exception - \n" + ex.Message + "\n for more details please check error log", "Exception!", MessageBoxButtons.OK, MessageBoxIcon.Error);
                expHelper.statusMsg = "Exception - \n" + ex.Message + "\n Stack Trace-  " + ex.StackTrace;
            }
        }

        private void txtLiveStamGeneration_TextChanged(object sender, EventArgs e)
        {
            txtExhaustSteamGeneration.Text = txtLiveStamGeneration.Text;
        }

        private void btnSaveOperations()
        {
            switch (actionType)
            {
                case "update":
                    valueAssignment(actionType);
                    dayAnalysisLogic.updateDailyAnalysis(trans_Date, trans_time, cane_early, cane_general, cane_rejected, cane_gate, cane_centre, cane_crushed, total_juice, sp_gravity, total_water, press_cake,
                        molasses_sent_out, biss_sugar, biss_molasses, scrap_sugar, scrap_molasses, moist_sugar, moist_molasses, raw_sugar, raw_molasses, other_sugar, other_molasses, unknown_losses,
                        dirt_correction, store_sulpher, store_phosphoric, store_lime, store_viscosity, store_bioside, store_color_reducer, store_megnafloe, store_lub_oil, store_lub_grease, store_boiler_chemical,
                        icumsa_l31, icumsa_l30, icumsa_m31, icumsa_m30, icumsa_s31, icumsa_s30, foreign_matter_l31, foreign_matter_l30, foreign_matter_m31, foreign_matter_m30,
                        foreign_matter_s31, foreign_matter_s30, retention_l31, retention_l30, retention_m31, retention_m30, retention_s31, retention_s30, etp_ph, etp_tss, etp_cod, etp_bod, etp_waterFlow, calcium_mixed_juice, calcium_clear_juice, phosphate_mixed_juice, phosphate_clear_juice, total_operating_tubewell, exhaust_condensate_recovery,
                        no_of_80t_massecuite_pan, ph_injection_inlet, ph_injection_outlet, average_vaccume_pan, average_vaccume_evap, Exhaust_steam_press_lp, Exhaust_steam_press_hp, boiler_steam_press_lp,
                        boiler_steam_hp, ph_boiler_feed_water, boiler_water, bagasse_baed, power_from_uppcb, power_export_uppcb, filter_water, pan_water, cf_water, bagasse_sold, bagasse_stock, nm_p_index, nm_pry_ext, om_p_index, om_pry_ext, trs_percentage,
                        rs_percentage, temp_max, temp_min, humidity, rain_fall, iu_primary_juice, iu_mixed_juice, iu_clear_juice, ph_primary_juice, ph_mixed_juice, live_steam_generation, live_steam_consumption,
                        power_turbines, bleeding_in_process, bleeding_acf, ata_cogen, d_sulpher_heating, drain_pipe_loss, exhaust_steam_generation, exhaust_steam_consumption, steam_per_ton_cane,
                        steam_per_qtl_sugar, turbine_25, turbine_3_New, turbine_3_Old, turbine_1, dg_set, power_import_cogen, total_power, power_per_ton_cane, power_per_qtl_sugar, updt_dt, updtby, steam_per_cane, cane_farm);
                    break;
                case "insert":
                    valueAssignment(actionType);

                    dayAnalysisLogic.insertDailyAnalysis(trans_Date, trans_time, cane_early, cane_general, cane_rejected, cane_gate, cane_centre, cane_crushed, total_juice, sp_gravity, total_water,
                        press_cake, molasses_sent_out, biss_sugar, biss_molasses, scrap_sugar, scrap_molasses, moist_sugar, moist_molasses, raw_sugar, raw_molasses, other_sugar, other_molasses,
                        unknown_losses, dirt_correction, store_sulpher, store_phosphoric, store_lime, store_viscosity, store_bioside, store_color_reducer, store_megnafloe, store_lub_oil,
                        store_lub_grease, store_boiler_chemical, icumsa_l31, icumsa_l30, icumsa_m31, icumsa_m30, icumsa_s31, icumsa_s30, foreign_matter_l31, foreign_matter_l30,
                        foreign_matter_m31, foreign_matter_m30, foreign_matter_s31, foreign_matter_s30, retention_l31, retention_l30, retention_m31, retention_m30, retention_s31,
                        retention_s30, etp_ph, etp_tss, etp_cod, etp_bod, etp_waterFlow, calcium_mixed_juice, calcium_clear_juice, phosphate_mixed_juice, phosphate_clear_juice,
                        total_operating_tubewell, exhaust_condensate_recovery, no_of_80t_massecuite_pan, ph_injection_inlet, ph_injection_outlet, average_vaccume_pan,
                        average_vaccume_evap, Exhaust_steam_press_lp, Exhaust_steam_press_hp, boiler_steam_press_lp, boiler_steam_hp, ph_boiler_feed_water, boiler_water, bagasse_baed,
                        power_from_uppcb, power_export_uppcb, filter_water, pan_water, cf_water, bagasse_sold, bagasse_stock, nm_p_index, nm_pry_ext, om_p_index, om_pry_ext, trs_percentage, rs_percentage,
                        temp_max, temp_min, humidity, rain_fall, iu_primary_juice, iu_mixed_juice, iu_clear_juice, ph_primary_juice, ph_mixed_juice, live_steam_generation,
                        live_steam_consumption, power_turbines, bleeding_in_process, bleeding_acf, ata_cogen, d_sulpher_heating, drain_pipe_loss, exhaust_steam_generation,
                        exhaust_steam_consumption, steam_per_ton_cane, steam_per_qtl_sugar, turbine_25, turbine_3_New, turbine_3_Old, turbine_1, dg_set, power_import_cogen,
                        total_power, power_per_ton_cane, power_per_qtl_sugar, crtd_by, steam_per_cane, cane_farm);
                    break;
                default:
                    break;
            }
        }

       
    }
}
