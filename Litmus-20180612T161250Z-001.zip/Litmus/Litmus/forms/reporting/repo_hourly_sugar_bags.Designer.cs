﻿namespace Litmus.forms.reporting
{
    partial class repo_hourly_sugar_bags
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.groupBox6 = new System.Windows.Forms.GroupBox();
            this.panel28 = new System.Windows.Forms.Panel();
            this.button108 = new System.Windows.Forms.Button();
            this.button107 = new System.Windows.Forms.Button();
            this.button106 = new System.Windows.Forms.Button();
            this.button105 = new System.Windows.Forms.Button();
            this.panel32 = new System.Windows.Forms.Panel();
            this.button124 = new System.Windows.Forms.Button();
            this.button123 = new System.Windows.Forms.Button();
            this.button122 = new System.Windows.Forms.Button();
            this.button121 = new System.Windows.Forms.Button();
            this.panel24 = new System.Windows.Forms.Panel();
            this.button92 = new System.Windows.Forms.Button();
            this.button91 = new System.Windows.Forms.Button();
            this.button90 = new System.Windows.Forms.Button();
            this.button89 = new System.Windows.Forms.Button();
            this.panel20 = new System.Windows.Forms.Panel();
            this.button76 = new System.Windows.Forms.Button();
            this.button75 = new System.Windows.Forms.Button();
            this.button74 = new System.Windows.Forms.Button();
            this.button73 = new System.Windows.Forms.Button();
            this.panel16 = new System.Windows.Forms.Panel();
            this.button60 = new System.Windows.Forms.Button();
            this.button59 = new System.Windows.Forms.Button();
            this.button58 = new System.Windows.Forms.Button();
            this.button57 = new System.Windows.Forms.Button();
            this.panel11 = new System.Windows.Forms.Panel();
            this.button44 = new System.Windows.Forms.Button();
            this.button43 = new System.Windows.Forms.Button();
            this.button42 = new System.Windows.Forms.Button();
            this.button41 = new System.Windows.Forms.Button();
            this.panel7 = new System.Windows.Forms.Panel();
            this.button28 = new System.Windows.Forms.Button();
            this.button27 = new System.Windows.Forms.Button();
            this.button26 = new System.Windows.Forms.Button();
            this.button25 = new System.Windows.Forms.Button();
            this.panel3 = new System.Windows.Forms.Panel();
            this.button12 = new System.Windows.Forms.Button();
            this.button11 = new System.Windows.Forms.Button();
            this.button10 = new System.Windows.Forms.Button();
            this.button9 = new System.Windows.Forms.Button();
            this.btnSCumlativeShiftA = new System.Windows.Forms.Button();
            this.btnSTotalShiftA = new System.Windows.Forms.Button();
            this.btnS30ShiftA = new System.Windows.Forms.Button();
            this.btnS31ShiftA = new System.Windows.Forms.Button();
            this.btnSSugarShifA = new System.Windows.Forms.Button();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.panel10 = new System.Windows.Forms.Panel();
            this.button40 = new System.Windows.Forms.Button();
            this.button39 = new System.Windows.Forms.Button();
            this.button38 = new System.Windows.Forms.Button();
            this.button37 = new System.Windows.Forms.Button();
            this.panel31 = new System.Windows.Forms.Panel();
            this.button120 = new System.Windows.Forms.Button();
            this.button119 = new System.Windows.Forms.Button();
            this.button118 = new System.Windows.Forms.Button();
            this.button117 = new System.Windows.Forms.Button();
            this.panel27 = new System.Windows.Forms.Panel();
            this.button104 = new System.Windows.Forms.Button();
            this.button103 = new System.Windows.Forms.Button();
            this.button102 = new System.Windows.Forms.Button();
            this.button101 = new System.Windows.Forms.Button();
            this.panel23 = new System.Windows.Forms.Panel();
            this.button88 = new System.Windows.Forms.Button();
            this.button87 = new System.Windows.Forms.Button();
            this.button86 = new System.Windows.Forms.Button();
            this.button85 = new System.Windows.Forms.Button();
            this.panel19 = new System.Windows.Forms.Panel();
            this.button72 = new System.Windows.Forms.Button();
            this.button71 = new System.Windows.Forms.Button();
            this.button70 = new System.Windows.Forms.Button();
            this.button69 = new System.Windows.Forms.Button();
            this.panel15 = new System.Windows.Forms.Panel();
            this.button56 = new System.Windows.Forms.Button();
            this.button55 = new System.Windows.Forms.Button();
            this.button54 = new System.Windows.Forms.Button();
            this.button53 = new System.Windows.Forms.Button();
            this.panel6 = new System.Windows.Forms.Panel();
            this.button24 = new System.Windows.Forms.Button();
            this.button23 = new System.Windows.Forms.Button();
            this.button22 = new System.Windows.Forms.Button();
            this.button21 = new System.Windows.Forms.Button();
            this.panel2 = new System.Windows.Forms.Panel();
            this.button8 = new System.Windows.Forms.Button();
            this.button7 = new System.Windows.Forms.Button();
            this.button6 = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            this.btnMCumlativeShiftA = new System.Windows.Forms.Button();
            this.btnMTotalShiftA = new System.Windows.Forms.Button();
            this.btnM30ShiftA = new System.Windows.Forms.Button();
            this.btnM31ShiftA = new System.Windows.Forms.Button();
            this.btnMSugarShiftA = new System.Windows.Forms.Button();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.panel30 = new System.Windows.Forms.Panel();
            this.button116 = new System.Windows.Forms.Button();
            this.button115 = new System.Windows.Forms.Button();
            this.button114 = new System.Windows.Forms.Button();
            this.button113 = new System.Windows.Forms.Button();
            this.panel26 = new System.Windows.Forms.Panel();
            this.button100 = new System.Windows.Forms.Button();
            this.button99 = new System.Windows.Forms.Button();
            this.button98 = new System.Windows.Forms.Button();
            this.button97 = new System.Windows.Forms.Button();
            this.panel22 = new System.Windows.Forms.Panel();
            this.button84 = new System.Windows.Forms.Button();
            this.button83 = new System.Windows.Forms.Button();
            this.button82 = new System.Windows.Forms.Button();
            this.button81 = new System.Windows.Forms.Button();
            this.panel18 = new System.Windows.Forms.Panel();
            this.button68 = new System.Windows.Forms.Button();
            this.button67 = new System.Windows.Forms.Button();
            this.button66 = new System.Windows.Forms.Button();
            this.button65 = new System.Windows.Forms.Button();
            this.panel14 = new System.Windows.Forms.Panel();
            this.button52 = new System.Windows.Forms.Button();
            this.button51 = new System.Windows.Forms.Button();
            this.button50 = new System.Windows.Forms.Button();
            this.button49 = new System.Windows.Forms.Button();
            this.panel9 = new System.Windows.Forms.Panel();
            this.button36 = new System.Windows.Forms.Button();
            this.button35 = new System.Windows.Forms.Button();
            this.button34 = new System.Windows.Forms.Button();
            this.button33 = new System.Windows.Forms.Button();
            this.panel5 = new System.Windows.Forms.Panel();
            this.button20 = new System.Windows.Forms.Button();
            this.button19 = new System.Windows.Forms.Button();
            this.button18 = new System.Windows.Forms.Button();
            this.button17 = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.button4 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.btnLCumlativeShiftA = new System.Windows.Forms.Button();
            this.btnLTotalShiftA = new System.Windows.Forms.Button();
            this.btnL30ShiftA = new System.Windows.Forms.Button();
            this.btnL31ShiftA = new System.Windows.Forms.Button();
            this.btnLargeSugarShiftA = new System.Windows.Forms.Button();
            this.groupBox19 = new System.Windows.Forms.GroupBox();
            this.button128 = new System.Windows.Forms.Button();
            this.button112 = new System.Windows.Forms.Button();
            this.button96 = new System.Windows.Forms.Button();
            this.button80 = new System.Windows.Forms.Button();
            this.button64 = new System.Windows.Forms.Button();
            this.button48 = new System.Windows.Forms.Button();
            this.button32 = new System.Windows.Forms.Button();
            this.button16 = new System.Windows.Forms.Button();
            this.btnHourTotalShiftA = new System.Windows.Forms.Button();
            this.groupBox7 = new System.Windows.Forms.GroupBox();
            this.panel12 = new System.Windows.Forms.Panel();
            this.button31 = new System.Windows.Forms.Button();
            this.button30 = new System.Windows.Forms.Button();
            this.button29 = new System.Windows.Forms.Button();
            this.panel34 = new System.Windows.Forms.Panel();
            this.button127 = new System.Windows.Forms.Button();
            this.button126 = new System.Windows.Forms.Button();
            this.button125 = new System.Windows.Forms.Button();
            this.panel29 = new System.Windows.Forms.Panel();
            this.button111 = new System.Windows.Forms.Button();
            this.button110 = new System.Windows.Forms.Button();
            this.button109 = new System.Windows.Forms.Button();
            this.panel25 = new System.Windows.Forms.Panel();
            this.button95 = new System.Windows.Forms.Button();
            this.button94 = new System.Windows.Forms.Button();
            this.button93 = new System.Windows.Forms.Button();
            this.panel21 = new System.Windows.Forms.Panel();
            this.button79 = new System.Windows.Forms.Button();
            this.button78 = new System.Windows.Forms.Button();
            this.button77 = new System.Windows.Forms.Button();
            this.panel17 = new System.Windows.Forms.Panel();
            this.button63 = new System.Windows.Forms.Button();
            this.button62 = new System.Windows.Forms.Button();
            this.button61 = new System.Windows.Forms.Button();
            this.panel13 = new System.Windows.Forms.Panel();
            this.button47 = new System.Windows.Forms.Button();
            this.button46 = new System.Windows.Forms.Button();
            this.button45 = new System.Windows.Forms.Button();
            this.panel4 = new System.Windows.Forms.Panel();
            this.button15 = new System.Windows.Forms.Button();
            this.button14 = new System.Windows.Forms.Button();
            this.button13 = new System.Windows.Forms.Button();
            this.btnBissCumlativeShiftA = new System.Windows.Forms.Button();
            this.btnBissTotalShiftA = new System.Windows.Forms.Button();
            this.btnBissShiftA = new System.Windows.Forms.Button();
            this.btnBissSugarShifA = new System.Windows.Forms.Button();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.btnTime9 = new System.Windows.Forms.Button();
            this.btnTime16 = new System.Windows.Forms.Button();
            this.btnTime15 = new System.Windows.Forms.Button();
            this.btnTime14 = new System.Windows.Forms.Button();
            this.btnTime13 = new System.Windows.Forms.Button();
            this.btnTime12 = new System.Windows.Forms.Button();
            this.btnTime11 = new System.Windows.Forms.Button();
            this.btnTime10 = new System.Windows.Forms.Button();
            this.headerTime = new System.Windows.Forms.Button();
            this.btnShiftA = new System.Windows.Forms.Button();
            this.panel33 = new System.Windows.Forms.Panel();
            this.groupBox13 = new System.Windows.Forms.GroupBox();
            this.groupBox21 = new System.Windows.Forms.GroupBox();
            this.button352 = new System.Windows.Forms.Button();
            this.button336 = new System.Windows.Forms.Button();
            this.button320 = new System.Windows.Forms.Button();
            this.button304 = new System.Windows.Forms.Button();
            this.button288 = new System.Windows.Forms.Button();
            this.button272 = new System.Windows.Forms.Button();
            this.btnTotalShiftC = new System.Windows.Forms.Button();
            this.groupBox14 = new System.Windows.Forms.GroupBox();
            this.panel98 = new System.Windows.Forms.Panel();
            this.panel94 = new System.Windows.Forms.Panel();
            this.panel90 = new System.Windows.Forms.Panel();
            this.button351 = new System.Windows.Forms.Button();
            this.button350 = new System.Windows.Forms.Button();
            this.button349 = new System.Windows.Forms.Button();
            this.panel86 = new System.Windows.Forms.Panel();
            this.button335 = new System.Windows.Forms.Button();
            this.button334 = new System.Windows.Forms.Button();
            this.button333 = new System.Windows.Forms.Button();
            this.panel82 = new System.Windows.Forms.Panel();
            this.button319 = new System.Windows.Forms.Button();
            this.button318 = new System.Windows.Forms.Button();
            this.button317 = new System.Windows.Forms.Button();
            this.panel78 = new System.Windows.Forms.Panel();
            this.button303 = new System.Windows.Forms.Button();
            this.button302 = new System.Windows.Forms.Button();
            this.button301 = new System.Windows.Forms.Button();
            this.panel74 = new System.Windows.Forms.Panel();
            this.button287 = new System.Windows.Forms.Button();
            this.button286 = new System.Windows.Forms.Button();
            this.button285 = new System.Windows.Forms.Button();
            this.panel70 = new System.Windows.Forms.Panel();
            this.button271 = new System.Windows.Forms.Button();
            this.button270 = new System.Windows.Forms.Button();
            this.button269 = new System.Windows.Forms.Button();
            this.btnBissCumlativeShiftC = new System.Windows.Forms.Button();
            this.btnBissTotalShiftC = new System.Windows.Forms.Button();
            this.btnBissShiftC = new System.Windows.Forms.Button();
            this.btnBissSugarShiftC = new System.Windows.Forms.Button();
            this.groupBox15 = new System.Windows.Forms.GroupBox();
            this.panel97 = new System.Windows.Forms.Panel();
            this.panel93 = new System.Windows.Forms.Panel();
            this.panel89 = new System.Windows.Forms.Panel();
            this.button348 = new System.Windows.Forms.Button();
            this.button347 = new System.Windows.Forms.Button();
            this.button346 = new System.Windows.Forms.Button();
            this.button345 = new System.Windows.Forms.Button();
            this.panel85 = new System.Windows.Forms.Panel();
            this.button332 = new System.Windows.Forms.Button();
            this.button331 = new System.Windows.Forms.Button();
            this.button330 = new System.Windows.Forms.Button();
            this.button329 = new System.Windows.Forms.Button();
            this.panel81 = new System.Windows.Forms.Panel();
            this.button316 = new System.Windows.Forms.Button();
            this.button315 = new System.Windows.Forms.Button();
            this.button314 = new System.Windows.Forms.Button();
            this.button313 = new System.Windows.Forms.Button();
            this.panel77 = new System.Windows.Forms.Panel();
            this.button300 = new System.Windows.Forms.Button();
            this.button299 = new System.Windows.Forms.Button();
            this.button298 = new System.Windows.Forms.Button();
            this.button297 = new System.Windows.Forms.Button();
            this.panel73 = new System.Windows.Forms.Panel();
            this.button284 = new System.Windows.Forms.Button();
            this.button283 = new System.Windows.Forms.Button();
            this.button282 = new System.Windows.Forms.Button();
            this.button281 = new System.Windows.Forms.Button();
            this.panel69 = new System.Windows.Forms.Panel();
            this.button268 = new System.Windows.Forms.Button();
            this.button267 = new System.Windows.Forms.Button();
            this.button266 = new System.Windows.Forms.Button();
            this.button265 = new System.Windows.Forms.Button();
            this.btnSCumlativeShiftC = new System.Windows.Forms.Button();
            this.btnSTotalShiftC = new System.Windows.Forms.Button();
            this.btnS30ShiftC = new System.Windows.Forms.Button();
            this.btnS31ShiftC = new System.Windows.Forms.Button();
            this.btnSSugarShiftC = new System.Windows.Forms.Button();
            this.groupBox16 = new System.Windows.Forms.GroupBox();
            this.panel96 = new System.Windows.Forms.Panel();
            this.panel92 = new System.Windows.Forms.Panel();
            this.panel88 = new System.Windows.Forms.Panel();
            this.button344 = new System.Windows.Forms.Button();
            this.button343 = new System.Windows.Forms.Button();
            this.button342 = new System.Windows.Forms.Button();
            this.button341 = new System.Windows.Forms.Button();
            this.panel84 = new System.Windows.Forms.Panel();
            this.button328 = new System.Windows.Forms.Button();
            this.button327 = new System.Windows.Forms.Button();
            this.button326 = new System.Windows.Forms.Button();
            this.button325 = new System.Windows.Forms.Button();
            this.panel80 = new System.Windows.Forms.Panel();
            this.button312 = new System.Windows.Forms.Button();
            this.button311 = new System.Windows.Forms.Button();
            this.button310 = new System.Windows.Forms.Button();
            this.button309 = new System.Windows.Forms.Button();
            this.panel76 = new System.Windows.Forms.Panel();
            this.button296 = new System.Windows.Forms.Button();
            this.button295 = new System.Windows.Forms.Button();
            this.button294 = new System.Windows.Forms.Button();
            this.button293 = new System.Windows.Forms.Button();
            this.panel72 = new System.Windows.Forms.Panel();
            this.button280 = new System.Windows.Forms.Button();
            this.button279 = new System.Windows.Forms.Button();
            this.button278 = new System.Windows.Forms.Button();
            this.button277 = new System.Windows.Forms.Button();
            this.panel68 = new System.Windows.Forms.Panel();
            this.button264 = new System.Windows.Forms.Button();
            this.button263 = new System.Windows.Forms.Button();
            this.button262 = new System.Windows.Forms.Button();
            this.button261 = new System.Windows.Forms.Button();
            this.btnMCumlativeShiftC = new System.Windows.Forms.Button();
            this.btnMTotalShiftC = new System.Windows.Forms.Button();
            this.btnM30ShiftC = new System.Windows.Forms.Button();
            this.btnM31ShiftC = new System.Windows.Forms.Button();
            this.btnMSugarShiftC = new System.Windows.Forms.Button();
            this.groupBox17 = new System.Windows.Forms.GroupBox();
            this.btnTime1 = new System.Windows.Forms.Button();
            this.btnTime8 = new System.Windows.Forms.Button();
            this.btnTime7 = new System.Windows.Forms.Button();
            this.btnTime6 = new System.Windows.Forms.Button();
            this.btnTime5 = new System.Windows.Forms.Button();
            this.btnTime4 = new System.Windows.Forms.Button();
            this.btnTime3 = new System.Windows.Forms.Button();
            this.btnTime2 = new System.Windows.Forms.Button();
            this.btnHeaderTimeShiftC = new System.Windows.Forms.Button();
            this.groupBox18 = new System.Windows.Forms.GroupBox();
            this.panel95 = new System.Windows.Forms.Panel();
            this.panel91 = new System.Windows.Forms.Panel();
            this.button357 = new System.Windows.Forms.Button();
            this.button356 = new System.Windows.Forms.Button();
            this.button355 = new System.Windows.Forms.Button();
            this.button354 = new System.Windows.Forms.Button();
            this.button353 = new System.Windows.Forms.Button();
            this.panel87 = new System.Windows.Forms.Panel();
            this.button340 = new System.Windows.Forms.Button();
            this.button339 = new System.Windows.Forms.Button();
            this.button338 = new System.Windows.Forms.Button();
            this.button337 = new System.Windows.Forms.Button();
            this.panel83 = new System.Windows.Forms.Panel();
            this.button324 = new System.Windows.Forms.Button();
            this.button323 = new System.Windows.Forms.Button();
            this.button322 = new System.Windows.Forms.Button();
            this.button321 = new System.Windows.Forms.Button();
            this.panel79 = new System.Windows.Forms.Panel();
            this.button308 = new System.Windows.Forms.Button();
            this.button307 = new System.Windows.Forms.Button();
            this.button306 = new System.Windows.Forms.Button();
            this.button305 = new System.Windows.Forms.Button();
            this.panel75 = new System.Windows.Forms.Panel();
            this.button292 = new System.Windows.Forms.Button();
            this.button291 = new System.Windows.Forms.Button();
            this.button290 = new System.Windows.Forms.Button();
            this.button289 = new System.Windows.Forms.Button();
            this.panel71 = new System.Windows.Forms.Panel();
            this.button276 = new System.Windows.Forms.Button();
            this.button275 = new System.Windows.Forms.Button();
            this.button274 = new System.Windows.Forms.Button();
            this.button273 = new System.Windows.Forms.Button();
            this.panel67 = new System.Windows.Forms.Panel();
            this.button260 = new System.Windows.Forms.Button();
            this.button259 = new System.Windows.Forms.Button();
            this.button258 = new System.Windows.Forms.Button();
            this.button257 = new System.Windows.Forms.Button();
            this.btnLCumlativeShiftC = new System.Windows.Forms.Button();
            this.btnLTotalShiftC = new System.Windows.Forms.Button();
            this.btnL30ShiftC = new System.Windows.Forms.Button();
            this.btnL31ShiftC = new System.Windows.Forms.Button();
            this.btnLargeSugarShiftC = new System.Windows.Forms.Button();
            this.btnShiftC = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.groupBox20 = new System.Windows.Forms.GroupBox();
            this.button256 = new System.Windows.Forms.Button();
            this.button240 = new System.Windows.Forms.Button();
            this.button224 = new System.Windows.Forms.Button();
            this.button208 = new System.Windows.Forms.Button();
            this.button192 = new System.Windows.Forms.Button();
            this.button176 = new System.Windows.Forms.Button();
            this.button160 = new System.Windows.Forms.Button();
            this.button144 = new System.Windows.Forms.Button();
            this.btnTotalShiftB = new System.Windows.Forms.Button();
            this.groupBox8 = new System.Windows.Forms.GroupBox();
            this.panel66 = new System.Windows.Forms.Panel();
            this.button255 = new System.Windows.Forms.Button();
            this.button254 = new System.Windows.Forms.Button();
            this.button253 = new System.Windows.Forms.Button();
            this.panel62 = new System.Windows.Forms.Panel();
            this.button239 = new System.Windows.Forms.Button();
            this.button238 = new System.Windows.Forms.Button();
            this.button237 = new System.Windows.Forms.Button();
            this.panel58 = new System.Windows.Forms.Panel();
            this.button223 = new System.Windows.Forms.Button();
            this.button222 = new System.Windows.Forms.Button();
            this.button221 = new System.Windows.Forms.Button();
            this.panel54 = new System.Windows.Forms.Panel();
            this.button207 = new System.Windows.Forms.Button();
            this.button206 = new System.Windows.Forms.Button();
            this.button205 = new System.Windows.Forms.Button();
            this.panel50 = new System.Windows.Forms.Panel();
            this.button191 = new System.Windows.Forms.Button();
            this.button190 = new System.Windows.Forms.Button();
            this.button189 = new System.Windows.Forms.Button();
            this.panel46 = new System.Windows.Forms.Panel();
            this.button175 = new System.Windows.Forms.Button();
            this.button174 = new System.Windows.Forms.Button();
            this.button173 = new System.Windows.Forms.Button();
            this.panel42 = new System.Windows.Forms.Panel();
            this.button159 = new System.Windows.Forms.Button();
            this.button158 = new System.Windows.Forms.Button();
            this.button157 = new System.Windows.Forms.Button();
            this.panel38 = new System.Windows.Forms.Panel();
            this.button143 = new System.Windows.Forms.Button();
            this.button142 = new System.Windows.Forms.Button();
            this.button141 = new System.Windows.Forms.Button();
            this.btnBissCumlativeShiftB = new System.Windows.Forms.Button();
            this.btnBissTotalShiftB = new System.Windows.Forms.Button();
            this.btnBissShiftB = new System.Windows.Forms.Button();
            this.btnBissSugarShifB = new System.Windows.Forms.Button();
            this.groupBox9 = new System.Windows.Forms.GroupBox();
            this.panel65 = new System.Windows.Forms.Panel();
            this.button252 = new System.Windows.Forms.Button();
            this.button251 = new System.Windows.Forms.Button();
            this.button250 = new System.Windows.Forms.Button();
            this.button249 = new System.Windows.Forms.Button();
            this.panel61 = new System.Windows.Forms.Panel();
            this.button236 = new System.Windows.Forms.Button();
            this.button235 = new System.Windows.Forms.Button();
            this.button234 = new System.Windows.Forms.Button();
            this.button233 = new System.Windows.Forms.Button();
            this.panel57 = new System.Windows.Forms.Panel();
            this.button220 = new System.Windows.Forms.Button();
            this.button219 = new System.Windows.Forms.Button();
            this.button218 = new System.Windows.Forms.Button();
            this.button217 = new System.Windows.Forms.Button();
            this.panel53 = new System.Windows.Forms.Panel();
            this.button204 = new System.Windows.Forms.Button();
            this.button203 = new System.Windows.Forms.Button();
            this.button202 = new System.Windows.Forms.Button();
            this.button201 = new System.Windows.Forms.Button();
            this.panel49 = new System.Windows.Forms.Panel();
            this.button188 = new System.Windows.Forms.Button();
            this.button187 = new System.Windows.Forms.Button();
            this.button186 = new System.Windows.Forms.Button();
            this.button185 = new System.Windows.Forms.Button();
            this.panel45 = new System.Windows.Forms.Panel();
            this.button172 = new System.Windows.Forms.Button();
            this.button171 = new System.Windows.Forms.Button();
            this.button170 = new System.Windows.Forms.Button();
            this.button169 = new System.Windows.Forms.Button();
            this.panel41 = new System.Windows.Forms.Panel();
            this.button156 = new System.Windows.Forms.Button();
            this.button155 = new System.Windows.Forms.Button();
            this.button154 = new System.Windows.Forms.Button();
            this.button153 = new System.Windows.Forms.Button();
            this.panel37 = new System.Windows.Forms.Panel();
            this.button140 = new System.Windows.Forms.Button();
            this.button139 = new System.Windows.Forms.Button();
            this.button138 = new System.Windows.Forms.Button();
            this.button137 = new System.Windows.Forms.Button();
            this.btnSCumlativeShiftB = new System.Windows.Forms.Button();
            this.btnSTotalShiftB = new System.Windows.Forms.Button();
            this.btnS30ShiftB = new System.Windows.Forms.Button();
            this.btnS31ShiftB = new System.Windows.Forms.Button();
            this.btnSSugarShifB = new System.Windows.Forms.Button();
            this.groupBox10 = new System.Windows.Forms.GroupBox();
            this.panel64 = new System.Windows.Forms.Panel();
            this.button248 = new System.Windows.Forms.Button();
            this.button247 = new System.Windows.Forms.Button();
            this.button246 = new System.Windows.Forms.Button();
            this.button245 = new System.Windows.Forms.Button();
            this.panel60 = new System.Windows.Forms.Panel();
            this.button232 = new System.Windows.Forms.Button();
            this.button231 = new System.Windows.Forms.Button();
            this.button230 = new System.Windows.Forms.Button();
            this.button229 = new System.Windows.Forms.Button();
            this.panel56 = new System.Windows.Forms.Panel();
            this.button216 = new System.Windows.Forms.Button();
            this.button215 = new System.Windows.Forms.Button();
            this.button214 = new System.Windows.Forms.Button();
            this.button213 = new System.Windows.Forms.Button();
            this.panel52 = new System.Windows.Forms.Panel();
            this.button200 = new System.Windows.Forms.Button();
            this.button199 = new System.Windows.Forms.Button();
            this.button198 = new System.Windows.Forms.Button();
            this.button197 = new System.Windows.Forms.Button();
            this.panel48 = new System.Windows.Forms.Panel();
            this.button184 = new System.Windows.Forms.Button();
            this.button183 = new System.Windows.Forms.Button();
            this.button182 = new System.Windows.Forms.Button();
            this.button181 = new System.Windows.Forms.Button();
            this.panel44 = new System.Windows.Forms.Panel();
            this.button168 = new System.Windows.Forms.Button();
            this.button167 = new System.Windows.Forms.Button();
            this.button166 = new System.Windows.Forms.Button();
            this.button165 = new System.Windows.Forms.Button();
            this.panel40 = new System.Windows.Forms.Panel();
            this.button152 = new System.Windows.Forms.Button();
            this.button151 = new System.Windows.Forms.Button();
            this.button150 = new System.Windows.Forms.Button();
            this.button149 = new System.Windows.Forms.Button();
            this.panel36 = new System.Windows.Forms.Panel();
            this.button136 = new System.Windows.Forms.Button();
            this.button135 = new System.Windows.Forms.Button();
            this.button134 = new System.Windows.Forms.Button();
            this.button133 = new System.Windows.Forms.Button();
            this.btnMCumlativeShiftB = new System.Windows.Forms.Button();
            this.btnMTotalShiftB = new System.Windows.Forms.Button();
            this.btnM30ShiftB = new System.Windows.Forms.Button();
            this.btnM31ShiftB = new System.Windows.Forms.Button();
            this.btnMSugarShifB = new System.Windows.Forms.Button();
            this.groupBox11 = new System.Windows.Forms.GroupBox();
            this.btnTime17 = new System.Windows.Forms.Button();
            this.btnTime24 = new System.Windows.Forms.Button();
            this.btnTime23 = new System.Windows.Forms.Button();
            this.btnTime22 = new System.Windows.Forms.Button();
            this.btnTime21 = new System.Windows.Forms.Button();
            this.btnTime20 = new System.Windows.Forms.Button();
            this.btnTime19 = new System.Windows.Forms.Button();
            this.btnTime18 = new System.Windows.Forms.Button();
            this.btnHeaderTimeShiftB = new System.Windows.Forms.Button();
            this.groupBox12 = new System.Windows.Forms.GroupBox();
            this.panel63 = new System.Windows.Forms.Panel();
            this.button244 = new System.Windows.Forms.Button();
            this.button243 = new System.Windows.Forms.Button();
            this.button242 = new System.Windows.Forms.Button();
            this.button241 = new System.Windows.Forms.Button();
            this.panel59 = new System.Windows.Forms.Panel();
            this.button228 = new System.Windows.Forms.Button();
            this.button227 = new System.Windows.Forms.Button();
            this.button226 = new System.Windows.Forms.Button();
            this.button225 = new System.Windows.Forms.Button();
            this.panel55 = new System.Windows.Forms.Panel();
            this.button212 = new System.Windows.Forms.Button();
            this.button211 = new System.Windows.Forms.Button();
            this.button210 = new System.Windows.Forms.Button();
            this.button209 = new System.Windows.Forms.Button();
            this.panel51 = new System.Windows.Forms.Panel();
            this.button196 = new System.Windows.Forms.Button();
            this.button195 = new System.Windows.Forms.Button();
            this.button194 = new System.Windows.Forms.Button();
            this.button193 = new System.Windows.Forms.Button();
            this.panel47 = new System.Windows.Forms.Panel();
            this.button180 = new System.Windows.Forms.Button();
            this.button179 = new System.Windows.Forms.Button();
            this.button178 = new System.Windows.Forms.Button();
            this.button177 = new System.Windows.Forms.Button();
            this.panel43 = new System.Windows.Forms.Panel();
            this.button164 = new System.Windows.Forms.Button();
            this.button163 = new System.Windows.Forms.Button();
            this.button162 = new System.Windows.Forms.Button();
            this.button161 = new System.Windows.Forms.Button();
            this.panel39 = new System.Windows.Forms.Panel();
            this.button148 = new System.Windows.Forms.Button();
            this.button147 = new System.Windows.Forms.Button();
            this.button146 = new System.Windows.Forms.Button();
            this.button145 = new System.Windows.Forms.Button();
            this.panel35 = new System.Windows.Forms.Panel();
            this.button132 = new System.Windows.Forms.Button();
            this.button131 = new System.Windows.Forms.Button();
            this.button130 = new System.Windows.Forms.Button();
            this.button129 = new System.Windows.Forms.Button();
            this.btnLCumlativeShiftB = new System.Windows.Forms.Button();
            this.btnLTotalShiftB = new System.Windows.Forms.Button();
            this.btnL30ShiftB = new System.Windows.Forms.Button();
            this.btnL31ShiftB = new System.Windows.Forms.Button();
            this.btnLargeSugarShiftB = new System.Windows.Forms.Button();
            this.btnShiftB = new System.Windows.Forms.Button();
            this.button358 = new System.Windows.Forms.Button();
            this.button359 = new System.Windows.Forms.Button();
            this.button360 = new System.Windows.Forms.Button();
            this.button361 = new System.Windows.Forms.Button();
            this.button362 = new System.Windows.Forms.Button();
            this.button363 = new System.Windows.Forms.Button();
            this.button364 = new System.Windows.Forms.Button();
            this.button365 = new System.Windows.Forms.Button();
            this.button366 = new System.Windows.Forms.Button();
            this.button367 = new System.Windows.Forms.Button();
            this.button368 = new System.Windows.Forms.Button();
            this.button369 = new System.Windows.Forms.Button();
            this.button370 = new System.Windows.Forms.Button();
            this.button371 = new System.Windows.Forms.Button();
            this.button372 = new System.Windows.Forms.Button();
            this.button373 = new System.Windows.Forms.Button();
            this.button374 = new System.Windows.Forms.Button();
            this.button375 = new System.Windows.Forms.Button();
            this.button376 = new System.Windows.Forms.Button();
            this.button377 = new System.Windows.Forms.Button();
            this.button378 = new System.Windows.Forms.Button();
            this.button379 = new System.Windows.Forms.Button();
            this.button380 = new System.Windows.Forms.Button();
            this.button381 = new System.Windows.Forms.Button();
            this.button382 = new System.Windows.Forms.Button();
            this.button383 = new System.Windows.Forms.Button();
            this.button384 = new System.Windows.Forms.Button();
            this.button385 = new System.Windows.Forms.Button();
            this.groupBox4.SuspendLayout();
            this.groupBox6.SuspendLayout();
            this.panel28.SuspendLayout();
            this.panel32.SuspendLayout();
            this.panel24.SuspendLayout();
            this.panel20.SuspendLayout();
            this.panel16.SuspendLayout();
            this.panel11.SuspendLayout();
            this.panel7.SuspendLayout();
            this.panel3.SuspendLayout();
            this.groupBox5.SuspendLayout();
            this.panel10.SuspendLayout();
            this.panel31.SuspendLayout();
            this.panel27.SuspendLayout();
            this.panel23.SuspendLayout();
            this.panel19.SuspendLayout();
            this.panel15.SuspendLayout();
            this.panel6.SuspendLayout();
            this.panel2.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.panel30.SuspendLayout();
            this.panel26.SuspendLayout();
            this.panel22.SuspendLayout();
            this.panel18.SuspendLayout();
            this.panel14.SuspendLayout();
            this.panel9.SuspendLayout();
            this.panel5.SuspendLayout();
            this.panel1.SuspendLayout();
            this.groupBox19.SuspendLayout();
            this.groupBox7.SuspendLayout();
            this.panel12.SuspendLayout();
            this.panel34.SuspendLayout();
            this.panel29.SuspendLayout();
            this.panel25.SuspendLayout();
            this.panel21.SuspendLayout();
            this.panel17.SuspendLayout();
            this.panel13.SuspendLayout();
            this.panel4.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.panel33.SuspendLayout();
            this.groupBox13.SuspendLayout();
            this.groupBox21.SuspendLayout();
            this.groupBox14.SuspendLayout();
            this.panel98.SuspendLayout();
            this.panel94.SuspendLayout();
            this.panel90.SuspendLayout();
            this.panel86.SuspendLayout();
            this.panel82.SuspendLayout();
            this.panel78.SuspendLayout();
            this.panel74.SuspendLayout();
            this.panel70.SuspendLayout();
            this.groupBox15.SuspendLayout();
            this.panel97.SuspendLayout();
            this.panel93.SuspendLayout();
            this.panel89.SuspendLayout();
            this.panel85.SuspendLayout();
            this.panel81.SuspendLayout();
            this.panel77.SuspendLayout();
            this.panel73.SuspendLayout();
            this.panel69.SuspendLayout();
            this.groupBox16.SuspendLayout();
            this.panel96.SuspendLayout();
            this.panel92.SuspendLayout();
            this.panel88.SuspendLayout();
            this.panel84.SuspendLayout();
            this.panel80.SuspendLayout();
            this.panel76.SuspendLayout();
            this.panel72.SuspendLayout();
            this.panel68.SuspendLayout();
            this.groupBox17.SuspendLayout();
            this.groupBox18.SuspendLayout();
            this.panel95.SuspendLayout();
            this.panel91.SuspendLayout();
            this.panel87.SuspendLayout();
            this.panel83.SuspendLayout();
            this.panel79.SuspendLayout();
            this.panel75.SuspendLayout();
            this.panel71.SuspendLayout();
            this.panel67.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.groupBox20.SuspendLayout();
            this.groupBox8.SuspendLayout();
            this.panel66.SuspendLayout();
            this.panel62.SuspendLayout();
            this.panel58.SuspendLayout();
            this.panel54.SuspendLayout();
            this.panel50.SuspendLayout();
            this.panel46.SuspendLayout();
            this.panel42.SuspendLayout();
            this.panel38.SuspendLayout();
            this.groupBox9.SuspendLayout();
            this.panel65.SuspendLayout();
            this.panel61.SuspendLayout();
            this.panel57.SuspendLayout();
            this.panel53.SuspendLayout();
            this.panel49.SuspendLayout();
            this.panel45.SuspendLayout();
            this.panel41.SuspendLayout();
            this.panel37.SuspendLayout();
            this.groupBox10.SuspendLayout();
            this.panel64.SuspendLayout();
            this.panel60.SuspendLayout();
            this.panel56.SuspendLayout();
            this.panel52.SuspendLayout();
            this.panel48.SuspendLayout();
            this.panel44.SuspendLayout();
            this.panel40.SuspendLayout();
            this.panel36.SuspendLayout();
            this.groupBox11.SuspendLayout();
            this.groupBox12.SuspendLayout();
            this.panel63.SuspendLayout();
            this.panel59.SuspendLayout();
            this.panel55.SuspendLayout();
            this.panel51.SuspendLayout();
            this.panel47.SuspendLayout();
            this.panel43.SuspendLayout();
            this.panel39.SuspendLayout();
            this.panel35.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.groupBox6);
            this.groupBox4.Controls.Add(this.groupBox5);
            this.groupBox4.Controls.Add(this.groupBox2);
            this.groupBox4.Controls.Add(this.groupBox19);
            this.groupBox4.Controls.Add(this.groupBox7);
            this.groupBox4.Controls.Add(this.groupBox3);
            this.groupBox4.Controls.Add(this.btnShiftA);
            this.groupBox4.Location = new System.Drawing.Point(3, 6);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(1679, 483);
            this.groupBox4.TabIndex = 7;
            this.groupBox4.TabStop = false;
            // 
            // groupBox6
            // 
            this.groupBox6.Controls.Add(this.panel28);
            this.groupBox6.Controls.Add(this.panel32);
            this.groupBox6.Controls.Add(this.panel24);
            this.groupBox6.Controls.Add(this.panel20);
            this.groupBox6.Controls.Add(this.panel16);
            this.groupBox6.Controls.Add(this.panel11);
            this.groupBox6.Controls.Add(this.panel7);
            this.groupBox6.Controls.Add(this.panel3);
            this.groupBox6.Controls.Add(this.btnSCumlativeShiftA);
            this.groupBox6.Controls.Add(this.btnSTotalShiftA);
            this.groupBox6.Controls.Add(this.btnS30ShiftA);
            this.groupBox6.Controls.Add(this.button385);
            this.groupBox6.Controls.Add(this.btnS31ShiftA);
            this.groupBox6.Controls.Add(this.btnSSugarShifA);
            this.groupBox6.Location = new System.Drawing.Point(873, 52);
            this.groupBox6.Name = "groupBox6";
            this.groupBox6.Size = new System.Drawing.Size(368, 425);
            this.groupBox6.TabIndex = 8;
            this.groupBox6.TabStop = false;
            // 
            // panel28
            // 
            this.panel28.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel28.Controls.Add(this.button108);
            this.panel28.Controls.Add(this.button107);
            this.panel28.Controls.Add(this.button106);
            this.panel28.Controls.Add(this.button105);
            this.panel28.Location = new System.Drawing.Point(6, 332);
            this.panel28.Name = "panel28";
            this.panel28.Size = new System.Drawing.Size(360, 35);
            this.panel28.TabIndex = 15;
            // 
            // button108
            // 
            this.button108.BackColor = System.Drawing.Color.Aqua;
            this.button108.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button108.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button108.Location = new System.Drawing.Point(271, 3);
            this.button108.Name = "button108";
            this.button108.Size = new System.Drawing.Size(82, 26);
            this.button108.TabIndex = 40;
            this.button108.Text = "button108";
            this.button108.UseVisualStyleBackColor = false;
            // 
            // button107
            // 
            this.button107.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.button107.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button107.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button107.Location = new System.Drawing.Point(181, 3);
            this.button107.Name = "button107";
            this.button107.Size = new System.Drawing.Size(82, 26);
            this.button107.TabIndex = 50;
            this.button107.Text = "button107";
            this.button107.UseVisualStyleBackColor = false;
            // 
            // button106
            // 
            this.button106.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button106.Location = new System.Drawing.Point(92, 3);
            this.button106.Name = "button106";
            this.button106.Size = new System.Drawing.Size(82, 26);
            this.button106.TabIndex = 49;
            this.button106.Text = "button106";
            this.button106.UseVisualStyleBackColor = true;
            // 
            // button105
            // 
            this.button105.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button105.Location = new System.Drawing.Point(5, 3);
            this.button105.Name = "button105";
            this.button105.Size = new System.Drawing.Size(82, 26);
            this.button105.TabIndex = 48;
            this.button105.Text = "button105";
            this.button105.UseVisualStyleBackColor = true;
            // 
            // panel32
            // 
            this.panel32.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel32.Controls.Add(this.button124);
            this.panel32.Controls.Add(this.button123);
            this.panel32.Controls.Add(this.button122);
            this.panel32.Controls.Add(this.button121);
            this.panel32.Location = new System.Drawing.Point(6, 373);
            this.panel32.Name = "panel32";
            this.panel32.Size = new System.Drawing.Size(360, 35);
            this.panel32.TabIndex = 16;
            // 
            // button124
            // 
            this.button124.BackColor = System.Drawing.Color.Aqua;
            this.button124.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button124.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button124.Location = new System.Drawing.Point(271, 3);
            this.button124.Name = "button124";
            this.button124.Size = new System.Drawing.Size(82, 26);
            this.button124.TabIndex = 65;
            this.button124.Text = "button124";
            this.button124.UseVisualStyleBackColor = false;
            // 
            // button123
            // 
            this.button123.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.button123.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button123.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button123.Location = new System.Drawing.Point(181, 3);
            this.button123.Name = "button123";
            this.button123.Size = new System.Drawing.Size(82, 26);
            this.button123.TabIndex = 64;
            this.button123.Text = "button123";
            this.button123.UseVisualStyleBackColor = false;
            // 
            // button122
            // 
            this.button122.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button122.Location = new System.Drawing.Point(92, 3);
            this.button122.Name = "button122";
            this.button122.Size = new System.Drawing.Size(82, 26);
            this.button122.TabIndex = 63;
            this.button122.Text = "button122";
            this.button122.UseVisualStyleBackColor = true;
            // 
            // button121
            // 
            this.button121.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button121.Location = new System.Drawing.Point(5, 3);
            this.button121.Name = "button121";
            this.button121.Size = new System.Drawing.Size(82, 26);
            this.button121.TabIndex = 62;
            this.button121.Text = "button121";
            this.button121.UseVisualStyleBackColor = true;
            // 
            // panel24
            // 
            this.panel24.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel24.Controls.Add(this.button92);
            this.panel24.Controls.Add(this.button91);
            this.panel24.Controls.Add(this.button90);
            this.panel24.Controls.Add(this.button89);
            this.panel24.Location = new System.Drawing.Point(6, 291);
            this.panel24.Name = "panel24";
            this.panel24.Size = new System.Drawing.Size(360, 35);
            this.panel24.TabIndex = 14;
            // 
            // button92
            // 
            this.button92.BackColor = System.Drawing.Color.Aqua;
            this.button92.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button92.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button92.Location = new System.Drawing.Point(271, 3);
            this.button92.Name = "button92";
            this.button92.Size = new System.Drawing.Size(82, 26);
            this.button92.TabIndex = 48;
            this.button92.Text = "button92";
            this.button92.UseVisualStyleBackColor = false;
            // 
            // button91
            // 
            this.button91.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.button91.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button91.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button91.Location = new System.Drawing.Point(181, 3);
            this.button91.Name = "button91";
            this.button91.Size = new System.Drawing.Size(82, 26);
            this.button91.TabIndex = 47;
            this.button91.Text = "button91";
            this.button91.UseVisualStyleBackColor = false;
            // 
            // button90
            // 
            this.button90.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button90.Location = new System.Drawing.Point(92, 3);
            this.button90.Name = "button90";
            this.button90.Size = new System.Drawing.Size(82, 26);
            this.button90.TabIndex = 46;
            this.button90.Text = "button90";
            this.button90.UseVisualStyleBackColor = true;
            // 
            // button89
            // 
            this.button89.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button89.Location = new System.Drawing.Point(5, 3);
            this.button89.Name = "button89";
            this.button89.Size = new System.Drawing.Size(82, 26);
            this.button89.TabIndex = 45;
            this.button89.Text = "button89";
            this.button89.UseVisualStyleBackColor = true;
            // 
            // panel20
            // 
            this.panel20.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel20.Controls.Add(this.button76);
            this.panel20.Controls.Add(this.button75);
            this.panel20.Controls.Add(this.button74);
            this.panel20.Controls.Add(this.button73);
            this.panel20.Location = new System.Drawing.Point(6, 250);
            this.panel20.Name = "panel20";
            this.panel20.Size = new System.Drawing.Size(360, 35);
            this.panel20.TabIndex = 13;
            // 
            // button76
            // 
            this.button76.BackColor = System.Drawing.Color.Aqua;
            this.button76.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button76.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button76.Location = new System.Drawing.Point(271, 3);
            this.button76.Name = "button76";
            this.button76.Size = new System.Drawing.Size(82, 26);
            this.button76.TabIndex = 37;
            this.button76.Text = "button76";
            this.button76.UseVisualStyleBackColor = false;
            // 
            // button75
            // 
            this.button75.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.button75.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button75.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button75.Location = new System.Drawing.Point(181, 3);
            this.button75.Name = "button75";
            this.button75.Size = new System.Drawing.Size(82, 26);
            this.button75.TabIndex = 36;
            this.button75.Text = "button75";
            this.button75.UseVisualStyleBackColor = false;
            // 
            // button74
            // 
            this.button74.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button74.Location = new System.Drawing.Point(92, 3);
            this.button74.Name = "button74";
            this.button74.Size = new System.Drawing.Size(82, 26);
            this.button74.TabIndex = 35;
            this.button74.Text = "button74";
            this.button74.UseVisualStyleBackColor = true;
            // 
            // button73
            // 
            this.button73.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button73.Location = new System.Drawing.Point(5, 3);
            this.button73.Name = "button73";
            this.button73.Size = new System.Drawing.Size(82, 26);
            this.button73.TabIndex = 34;
            this.button73.Text = "button73";
            this.button73.UseVisualStyleBackColor = true;
            // 
            // panel16
            // 
            this.panel16.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel16.Controls.Add(this.button60);
            this.panel16.Controls.Add(this.button59);
            this.panel16.Controls.Add(this.button58);
            this.panel16.Controls.Add(this.button57);
            this.panel16.Location = new System.Drawing.Point(6, 209);
            this.panel16.Name = "panel16";
            this.panel16.Size = new System.Drawing.Size(360, 35);
            this.panel16.TabIndex = 12;
            // 
            // button60
            // 
            this.button60.BackColor = System.Drawing.Color.Aqua;
            this.button60.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button60.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button60.Location = new System.Drawing.Point(271, 3);
            this.button60.Name = "button60";
            this.button60.Size = new System.Drawing.Size(82, 26);
            this.button60.TabIndex = 30;
            this.button60.Text = "button60";
            this.button60.UseVisualStyleBackColor = false;
            // 
            // button59
            // 
            this.button59.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.button59.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button59.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button59.Location = new System.Drawing.Point(181, 3);
            this.button59.Name = "button59";
            this.button59.Size = new System.Drawing.Size(82, 26);
            this.button59.TabIndex = 29;
            this.button59.Text = "button59";
            this.button59.UseVisualStyleBackColor = false;
            // 
            // button58
            // 
            this.button58.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button58.Location = new System.Drawing.Point(92, 3);
            this.button58.Name = "button58";
            this.button58.Size = new System.Drawing.Size(82, 26);
            this.button58.TabIndex = 28;
            this.button58.Text = "button58";
            this.button58.UseVisualStyleBackColor = true;
            // 
            // button57
            // 
            this.button57.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button57.Location = new System.Drawing.Point(5, 3);
            this.button57.Name = "button57";
            this.button57.Size = new System.Drawing.Size(82, 26);
            this.button57.TabIndex = 27;
            this.button57.Text = "button57";
            this.button57.UseVisualStyleBackColor = true;
            // 
            // panel11
            // 
            this.panel11.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel11.Controls.Add(this.button44);
            this.panel11.Controls.Add(this.button43);
            this.panel11.Controls.Add(this.button42);
            this.panel11.Controls.Add(this.button41);
            this.panel11.Location = new System.Drawing.Point(6, 168);
            this.panel11.Name = "panel11";
            this.panel11.Size = new System.Drawing.Size(360, 35);
            this.panel11.TabIndex = 11;
            // 
            // button44
            // 
            this.button44.BackColor = System.Drawing.Color.Aqua;
            this.button44.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button44.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button44.Location = new System.Drawing.Point(271, 3);
            this.button44.Name = "button44";
            this.button44.Size = new System.Drawing.Size(82, 26);
            this.button44.TabIndex = 23;
            this.button44.Text = "button44";
            this.button44.UseVisualStyleBackColor = false;
            // 
            // button43
            // 
            this.button43.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.button43.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button43.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button43.Location = new System.Drawing.Point(181, 4);
            this.button43.Name = "button43";
            this.button43.Size = new System.Drawing.Size(82, 26);
            this.button43.TabIndex = 22;
            this.button43.Text = "button43";
            this.button43.UseVisualStyleBackColor = false;
            // 
            // button42
            // 
            this.button42.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button42.Location = new System.Drawing.Point(92, 3);
            this.button42.Name = "button42";
            this.button42.Size = new System.Drawing.Size(82, 26);
            this.button42.TabIndex = 21;
            this.button42.Text = "button42";
            this.button42.UseVisualStyleBackColor = true;
            // 
            // button41
            // 
            this.button41.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button41.Location = new System.Drawing.Point(5, 4);
            this.button41.Name = "button41";
            this.button41.Size = new System.Drawing.Size(82, 26);
            this.button41.TabIndex = 20;
            this.button41.Text = "button41";
            this.button41.UseVisualStyleBackColor = true;
            // 
            // panel7
            // 
            this.panel7.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel7.Controls.Add(this.button28);
            this.panel7.Controls.Add(this.button27);
            this.panel7.Controls.Add(this.button26);
            this.panel7.Controls.Add(this.button25);
            this.panel7.Location = new System.Drawing.Point(6, 127);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(360, 35);
            this.panel7.TabIndex = 10;
            // 
            // button28
            // 
            this.button28.BackColor = System.Drawing.Color.Aqua;
            this.button28.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button28.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button28.Location = new System.Drawing.Point(271, 3);
            this.button28.Name = "button28";
            this.button28.Size = new System.Drawing.Size(82, 26);
            this.button28.TabIndex = 16;
            this.button28.Text = "button28";
            this.button28.UseVisualStyleBackColor = false;
            // 
            // button27
            // 
            this.button27.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.button27.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button27.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button27.Location = new System.Drawing.Point(181, 3);
            this.button27.Name = "button27";
            this.button27.Size = new System.Drawing.Size(82, 26);
            this.button27.TabIndex = 15;
            this.button27.Text = "button27";
            this.button27.UseVisualStyleBackColor = false;
            // 
            // button26
            // 
            this.button26.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button26.Location = new System.Drawing.Point(92, 3);
            this.button26.Name = "button26";
            this.button26.Size = new System.Drawing.Size(82, 26);
            this.button26.TabIndex = 14;
            this.button26.Text = "button26";
            this.button26.UseVisualStyleBackColor = true;
            // 
            // button25
            // 
            this.button25.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button25.Location = new System.Drawing.Point(5, 3);
            this.button25.Name = "button25";
            this.button25.Size = new System.Drawing.Size(82, 26);
            this.button25.TabIndex = 13;
            this.button25.Text = "button25";
            this.button25.UseVisualStyleBackColor = true;
            // 
            // panel3
            // 
            this.panel3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel3.Controls.Add(this.button12);
            this.panel3.Controls.Add(this.button11);
            this.panel3.Controls.Add(this.button10);
            this.panel3.Controls.Add(this.button9);
            this.panel3.Location = new System.Drawing.Point(4, 84);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(360, 35);
            this.panel3.TabIndex = 7;
            // 
            // button12
            // 
            this.button12.BackColor = System.Drawing.Color.Aqua;
            this.button12.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button12.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button12.Location = new System.Drawing.Point(271, 4);
            this.button12.Name = "button12";
            this.button12.Size = new System.Drawing.Size(82, 26);
            this.button12.TabIndex = 15;
            this.button12.Text = "button12";
            this.button12.UseVisualStyleBackColor = false;
            // 
            // button11
            // 
            this.button11.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.button11.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button11.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button11.Location = new System.Drawing.Point(181, 4);
            this.button11.Name = "button11";
            this.button11.Size = new System.Drawing.Size(82, 26);
            this.button11.TabIndex = 14;
            this.button11.Text = "button11";
            this.button11.UseVisualStyleBackColor = false;
            // 
            // button10
            // 
            this.button10.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button10.Location = new System.Drawing.Point(92, 3);
            this.button10.Name = "button10";
            this.button10.Size = new System.Drawing.Size(82, 26);
            this.button10.TabIndex = 13;
            this.button10.Text = "button10";
            this.button10.UseVisualStyleBackColor = true;
            // 
            // button9
            // 
            this.button9.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button9.Location = new System.Drawing.Point(5, 4);
            this.button9.Name = "button9";
            this.button9.Size = new System.Drawing.Size(82, 26);
            this.button9.TabIndex = 9;
            this.button9.Text = "button9";
            this.button9.UseVisualStyleBackColor = true;
            // 
            // btnSCumlativeShiftA
            // 
            this.btnSCumlativeShiftA.BackColor = System.Drawing.Color.Black;
            this.btnSCumlativeShiftA.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSCumlativeShiftA.ForeColor = System.Drawing.Color.White;
            this.btnSCumlativeShiftA.Location = new System.Drawing.Point(274, 50);
            this.btnSCumlativeShiftA.Name = "btnSCumlativeShiftA";
            this.btnSCumlativeShiftA.Size = new System.Drawing.Size(83, 30);
            this.btnSCumlativeShiftA.TabIndex = 4;
            this.btnSCumlativeShiftA.Text = "H..";
            this.btnSCumlativeShiftA.UseVisualStyleBackColor = false;
            // 
            // btnSTotalShiftA
            // 
            this.btnSTotalShiftA.BackColor = System.Drawing.Color.Black;
            this.btnSTotalShiftA.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSTotalShiftA.ForeColor = System.Drawing.Color.White;
            this.btnSTotalShiftA.Location = new System.Drawing.Point(185, 50);
            this.btnSTotalShiftA.Name = "btnSTotalShiftA";
            this.btnSTotalShiftA.Size = new System.Drawing.Size(83, 30);
            this.btnSTotalShiftA.TabIndex = 3;
            this.btnSTotalShiftA.Text = "TOTAL";
            this.btnSTotalShiftA.UseVisualStyleBackColor = false;
            // 
            // btnS30ShiftA
            // 
            this.btnS30ShiftA.BackColor = System.Drawing.Color.Black;
            this.btnS30ShiftA.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnS30ShiftA.ForeColor = System.Drawing.Color.White;
            this.btnS30ShiftA.Location = new System.Drawing.Point(96, 50);
            this.btnS30ShiftA.Name = "btnS30ShiftA";
            this.btnS30ShiftA.Size = new System.Drawing.Size(83, 30);
            this.btnS30ShiftA.TabIndex = 2;
            this.btnS30ShiftA.Text = "S-30";
            this.btnS30ShiftA.UseVisualStyleBackColor = false;
            // 
            // btnS31ShiftA
            // 
            this.btnS31ShiftA.BackColor = System.Drawing.Color.Black;
            this.btnS31ShiftA.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnS31ShiftA.ForeColor = System.Drawing.Color.White;
            this.btnS31ShiftA.Location = new System.Drawing.Point(6, 50);
            this.btnS31ShiftA.Name = "btnS31ShiftA";
            this.btnS31ShiftA.Size = new System.Drawing.Size(83, 30);
            this.btnS31ShiftA.TabIndex = 1;
            this.btnS31ShiftA.Text = "S-31";
            this.btnS31ShiftA.UseVisualStyleBackColor = false;
            // 
            // btnSSugarShifA
            // 
            this.btnSSugarShifA.BackColor = System.Drawing.Color.Black;
            this.btnSSugarShifA.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSSugarShifA.ForeColor = System.Drawing.Color.White;
            this.btnSSugarShifA.Location = new System.Drawing.Point(4, 10);
            this.btnSSugarShifA.Name = "btnSSugarShifA";
            this.btnSSugarShifA.Size = new System.Drawing.Size(357, 34);
            this.btnSSugarShifA.TabIndex = 0;
            this.btnSSugarShifA.Text = "SMALL SUGAR";
            this.btnSSugarShifA.UseVisualStyleBackColor = false;
            // 
            // groupBox5
            // 
            this.groupBox5.Controls.Add(this.panel10);
            this.groupBox5.Controls.Add(this.panel31);
            this.groupBox5.Controls.Add(this.panel27);
            this.groupBox5.Controls.Add(this.panel23);
            this.groupBox5.Controls.Add(this.panel19);
            this.groupBox5.Controls.Add(this.panel15);
            this.groupBox5.Controls.Add(this.panel6);
            this.groupBox5.Controls.Add(this.panel2);
            this.groupBox5.Controls.Add(this.btnMCumlativeShiftA);
            this.groupBox5.Controls.Add(this.btnMTotalShiftA);
            this.groupBox5.Controls.Add(this.btnM30ShiftA);
            this.groupBox5.Controls.Add(this.btnM31ShiftA);
            this.groupBox5.Controls.Add(this.btnMSugarShiftA);
            this.groupBox5.Location = new System.Drawing.Point(484, 52);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(368, 425);
            this.groupBox5.TabIndex = 7;
            this.groupBox5.TabStop = false;
            // 
            // panel10
            // 
            this.panel10.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel10.Controls.Add(this.button40);
            this.panel10.Controls.Add(this.button39);
            this.panel10.Controls.Add(this.button38);
            this.panel10.Controls.Add(this.button37);
            this.panel10.Location = new System.Drawing.Point(0, 168);
            this.panel10.Name = "panel10";
            this.panel10.Size = new System.Drawing.Size(360, 35);
            this.panel10.TabIndex = 10;
            // 
            // button40
            // 
            this.button40.BackColor = System.Drawing.Color.Aqua;
            this.button40.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button40.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button40.Location = new System.Drawing.Point(273, 4);
            this.button40.Name = "button40";
            this.button40.Size = new System.Drawing.Size(82, 26);
            this.button40.TabIndex = 19;
            this.button40.Text = "button40";
            this.button40.UseVisualStyleBackColor = false;
            // 
            // button39
            // 
            this.button39.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.button39.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button39.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button39.Location = new System.Drawing.Point(185, 3);
            this.button39.Name = "button39";
            this.button39.Size = new System.Drawing.Size(82, 26);
            this.button39.TabIndex = 18;
            this.button39.Text = "button39";
            this.button39.UseVisualStyleBackColor = false;
            // 
            // button38
            // 
            this.button38.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button38.Location = new System.Drawing.Point(93, 3);
            this.button38.Name = "button38";
            this.button38.Size = new System.Drawing.Size(82, 26);
            this.button38.TabIndex = 17;
            this.button38.Text = "button38";
            this.button38.UseVisualStyleBackColor = true;
            // 
            // button37
            // 
            this.button37.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button37.Location = new System.Drawing.Point(3, 4);
            this.button37.Name = "button37";
            this.button37.Size = new System.Drawing.Size(82, 26);
            this.button37.TabIndex = 16;
            this.button37.Text = "button37";
            this.button37.UseVisualStyleBackColor = true;
            // 
            // panel31
            // 
            this.panel31.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel31.Controls.Add(this.button120);
            this.panel31.Controls.Add(this.button119);
            this.panel31.Controls.Add(this.button118);
            this.panel31.Controls.Add(this.button117);
            this.panel31.Location = new System.Drawing.Point(0, 373);
            this.panel31.Name = "panel31";
            this.panel31.Size = new System.Drawing.Size(360, 35);
            this.panel31.TabIndex = 15;
            // 
            // button120
            // 
            this.button120.BackColor = System.Drawing.Color.Aqua;
            this.button120.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button120.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button120.Location = new System.Drawing.Point(273, 3);
            this.button120.Name = "button120";
            this.button120.Size = new System.Drawing.Size(82, 26);
            this.button120.TabIndex = 61;
            this.button120.Text = "button120";
            this.button120.UseVisualStyleBackColor = false;
            // 
            // button119
            // 
            this.button119.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.button119.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button119.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button119.Location = new System.Drawing.Point(185, 3);
            this.button119.Name = "button119";
            this.button119.Size = new System.Drawing.Size(82, 26);
            this.button119.TabIndex = 60;
            this.button119.Text = "button119";
            this.button119.UseVisualStyleBackColor = false;
            // 
            // button118
            // 
            this.button118.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button118.Location = new System.Drawing.Point(93, 3);
            this.button118.Name = "button118";
            this.button118.Size = new System.Drawing.Size(82, 26);
            this.button118.TabIndex = 59;
            this.button118.Text = "button118";
            this.button118.UseVisualStyleBackColor = true;
            // 
            // button117
            // 
            this.button117.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button117.Location = new System.Drawing.Point(3, 3);
            this.button117.Name = "button117";
            this.button117.Size = new System.Drawing.Size(82, 26);
            this.button117.TabIndex = 58;
            this.button117.Text = "button117";
            this.button117.UseVisualStyleBackColor = true;
            // 
            // panel27
            // 
            this.panel27.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel27.Controls.Add(this.button104);
            this.panel27.Controls.Add(this.button103);
            this.panel27.Controls.Add(this.button102);
            this.panel27.Controls.Add(this.button101);
            this.panel27.Location = new System.Drawing.Point(0, 332);
            this.panel27.Name = "panel27";
            this.panel27.Size = new System.Drawing.Size(360, 35);
            this.panel27.TabIndex = 14;
            // 
            // button104
            // 
            this.button104.BackColor = System.Drawing.Color.Aqua;
            this.button104.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button104.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button104.Location = new System.Drawing.Point(273, 3);
            this.button104.Name = "button104";
            this.button104.Size = new System.Drawing.Size(82, 26);
            this.button104.TabIndex = 47;
            this.button104.Text = "button104";
            this.button104.UseVisualStyleBackColor = false;
            // 
            // button103
            // 
            this.button103.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.button103.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button103.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button103.Location = new System.Drawing.Point(185, 3);
            this.button103.Name = "button103";
            this.button103.Size = new System.Drawing.Size(82, 26);
            this.button103.TabIndex = 46;
            this.button103.Text = "button103";
            this.button103.UseVisualStyleBackColor = false;
            // 
            // button102
            // 
            this.button102.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button102.Location = new System.Drawing.Point(93, 3);
            this.button102.Name = "button102";
            this.button102.Size = new System.Drawing.Size(82, 26);
            this.button102.TabIndex = 45;
            this.button102.Text = "button102";
            this.button102.UseVisualStyleBackColor = true;
            // 
            // button101
            // 
            this.button101.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button101.Location = new System.Drawing.Point(3, 3);
            this.button101.Name = "button101";
            this.button101.Size = new System.Drawing.Size(82, 26);
            this.button101.TabIndex = 44;
            this.button101.Text = "button101";
            this.button101.UseVisualStyleBackColor = true;
            // 
            // panel23
            // 
            this.panel23.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel23.Controls.Add(this.button88);
            this.panel23.Controls.Add(this.button87);
            this.panel23.Controls.Add(this.button86);
            this.panel23.Controls.Add(this.button85);
            this.panel23.Location = new System.Drawing.Point(0, 291);
            this.panel23.Name = "panel23";
            this.panel23.Size = new System.Drawing.Size(360, 35);
            this.panel23.TabIndex = 13;
            // 
            // button88
            // 
            this.button88.BackColor = System.Drawing.Color.Aqua;
            this.button88.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button88.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button88.Location = new System.Drawing.Point(273, 3);
            this.button88.Name = "button88";
            this.button88.Size = new System.Drawing.Size(82, 26);
            this.button88.TabIndex = 44;
            this.button88.Text = "button88";
            this.button88.UseVisualStyleBackColor = false;
            // 
            // button87
            // 
            this.button87.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.button87.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button87.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button87.Location = new System.Drawing.Point(185, 3);
            this.button87.Name = "button87";
            this.button87.Size = new System.Drawing.Size(82, 26);
            this.button87.TabIndex = 43;
            this.button87.Text = "button87";
            this.button87.UseVisualStyleBackColor = false;
            // 
            // button86
            // 
            this.button86.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button86.Location = new System.Drawing.Point(93, 3);
            this.button86.Name = "button86";
            this.button86.Size = new System.Drawing.Size(82, 26);
            this.button86.TabIndex = 42;
            this.button86.Text = "button86";
            this.button86.UseVisualStyleBackColor = true;
            // 
            // button85
            // 
            this.button85.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button85.Location = new System.Drawing.Point(3, 3);
            this.button85.Name = "button85";
            this.button85.Size = new System.Drawing.Size(82, 26);
            this.button85.TabIndex = 41;
            this.button85.Text = "button85";
            this.button85.UseVisualStyleBackColor = true;
            // 
            // panel19
            // 
            this.panel19.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel19.Controls.Add(this.button72);
            this.panel19.Controls.Add(this.button71);
            this.panel19.Controls.Add(this.button70);
            this.panel19.Controls.Add(this.button69);
            this.panel19.Location = new System.Drawing.Point(0, 250);
            this.panel19.Name = "panel19";
            this.panel19.Size = new System.Drawing.Size(360, 35);
            this.panel19.TabIndex = 12;
            // 
            // button72
            // 
            this.button72.BackColor = System.Drawing.Color.Aqua;
            this.button72.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button72.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button72.Location = new System.Drawing.Point(273, 3);
            this.button72.Name = "button72";
            this.button72.Size = new System.Drawing.Size(82, 26);
            this.button72.TabIndex = 37;
            this.button72.Text = "button72";
            this.button72.UseVisualStyleBackColor = false;
            // 
            // button71
            // 
            this.button71.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.button71.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button71.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button71.Location = new System.Drawing.Point(185, 3);
            this.button71.Name = "button71";
            this.button71.Size = new System.Drawing.Size(82, 26);
            this.button71.TabIndex = 36;
            this.button71.Text = "button71";
            this.button71.UseVisualStyleBackColor = false;
            // 
            // button70
            // 
            this.button70.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button70.Location = new System.Drawing.Point(93, 3);
            this.button70.Name = "button70";
            this.button70.Size = new System.Drawing.Size(82, 26);
            this.button70.TabIndex = 35;
            this.button70.Text = "button70";
            this.button70.UseVisualStyleBackColor = true;
            // 
            // button69
            // 
            this.button69.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button69.Location = new System.Drawing.Point(3, 3);
            this.button69.Name = "button69";
            this.button69.Size = new System.Drawing.Size(82, 26);
            this.button69.TabIndex = 34;
            this.button69.Text = "button69";
            this.button69.UseVisualStyleBackColor = true;
            // 
            // panel15
            // 
            this.panel15.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel15.Controls.Add(this.button56);
            this.panel15.Controls.Add(this.button55);
            this.panel15.Controls.Add(this.button54);
            this.panel15.Controls.Add(this.button53);
            this.panel15.Location = new System.Drawing.Point(0, 209);
            this.panel15.Name = "panel15";
            this.panel15.Size = new System.Drawing.Size(360, 35);
            this.panel15.TabIndex = 10;
            // 
            // button56
            // 
            this.button56.BackColor = System.Drawing.Color.Aqua;
            this.button56.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button56.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button56.Location = new System.Drawing.Point(273, 3);
            this.button56.Name = "button56";
            this.button56.Size = new System.Drawing.Size(82, 26);
            this.button56.TabIndex = 30;
            this.button56.Text = "button56";
            this.button56.UseVisualStyleBackColor = false;
            // 
            // button55
            // 
            this.button55.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.button55.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button55.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button55.Location = new System.Drawing.Point(185, 3);
            this.button55.Name = "button55";
            this.button55.Size = new System.Drawing.Size(82, 26);
            this.button55.TabIndex = 29;
            this.button55.Text = "button55";
            this.button55.UseVisualStyleBackColor = false;
            // 
            // button54
            // 
            this.button54.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button54.Location = new System.Drawing.Point(93, 3);
            this.button54.Name = "button54";
            this.button54.Size = new System.Drawing.Size(82, 26);
            this.button54.TabIndex = 28;
            this.button54.Text = "button54";
            this.button54.UseVisualStyleBackColor = true;
            // 
            // button53
            // 
            this.button53.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button53.Location = new System.Drawing.Point(3, 3);
            this.button53.Name = "button53";
            this.button53.Size = new System.Drawing.Size(82, 26);
            this.button53.TabIndex = 27;
            this.button53.Text = "button53";
            this.button53.UseVisualStyleBackColor = true;
            // 
            // panel6
            // 
            this.panel6.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel6.Controls.Add(this.button24);
            this.panel6.Controls.Add(this.button23);
            this.panel6.Controls.Add(this.button22);
            this.panel6.Controls.Add(this.button21);
            this.panel6.Location = new System.Drawing.Point(0, 127);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(360, 35);
            this.panel6.TabIndex = 9;
            // 
            // button24
            // 
            this.button24.BackColor = System.Drawing.Color.Aqua;
            this.button24.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button24.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button24.Location = new System.Drawing.Point(273, 3);
            this.button24.Name = "button24";
            this.button24.Size = new System.Drawing.Size(82, 26);
            this.button24.TabIndex = 16;
            this.button24.Text = "button24";
            this.button24.UseVisualStyleBackColor = false;
            // 
            // button23
            // 
            this.button23.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.button23.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button23.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button23.Location = new System.Drawing.Point(185, 3);
            this.button23.Name = "button23";
            this.button23.Size = new System.Drawing.Size(82, 26);
            this.button23.TabIndex = 15;
            this.button23.Text = "button23";
            this.button23.UseVisualStyleBackColor = false;
            // 
            // button22
            // 
            this.button22.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button22.Location = new System.Drawing.Point(93, 3);
            this.button22.Name = "button22";
            this.button22.Size = new System.Drawing.Size(82, 26);
            this.button22.TabIndex = 14;
            this.button22.Text = "button22";
            this.button22.UseVisualStyleBackColor = true;
            // 
            // button21
            // 
            this.button21.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button21.Location = new System.Drawing.Point(3, 3);
            this.button21.Name = "button21";
            this.button21.Size = new System.Drawing.Size(82, 26);
            this.button21.TabIndex = 13;
            this.button21.Text = "button21";
            this.button21.UseVisualStyleBackColor = true;
            // 
            // panel2
            // 
            this.panel2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel2.Controls.Add(this.button8);
            this.panel2.Controls.Add(this.button7);
            this.panel2.Controls.Add(this.button6);
            this.panel2.Controls.Add(this.button5);
            this.panel2.Location = new System.Drawing.Point(0, 84);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(360, 35);
            this.panel2.TabIndex = 6;
            // 
            // button8
            // 
            this.button8.BackColor = System.Drawing.Color.Aqua;
            this.button8.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button8.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button8.Location = new System.Drawing.Point(273, 3);
            this.button8.Name = "button8";
            this.button8.Size = new System.Drawing.Size(82, 26);
            this.button8.TabIndex = 9;
            this.button8.Text = "button8";
            this.button8.UseVisualStyleBackColor = false;
            // 
            // button7
            // 
            this.button7.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.button7.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button7.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button7.Location = new System.Drawing.Point(185, 3);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(82, 26);
            this.button7.TabIndex = 9;
            this.button7.Text = "button7";
            this.button7.UseVisualStyleBackColor = false;
            // 
            // button6
            // 
            this.button6.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button6.Location = new System.Drawing.Point(93, 3);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(82, 26);
            this.button6.TabIndex = 9;
            this.button6.Text = "button6";
            this.button6.UseVisualStyleBackColor = true;
            // 
            // button5
            // 
            this.button5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button5.Location = new System.Drawing.Point(3, 3);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(82, 26);
            this.button5.TabIndex = 8;
            this.button5.Text = "button5";
            this.button5.UseVisualStyleBackColor = true;
            // 
            // btnMCumlativeShiftA
            // 
            this.btnMCumlativeShiftA.BackColor = System.Drawing.Color.Black;
            this.btnMCumlativeShiftA.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnMCumlativeShiftA.ForeColor = System.Drawing.Color.White;
            this.btnMCumlativeShiftA.Location = new System.Drawing.Point(273, 51);
            this.btnMCumlativeShiftA.Name = "btnMCumlativeShiftA";
            this.btnMCumlativeShiftA.Size = new System.Drawing.Size(83, 30);
            this.btnMCumlativeShiftA.TabIndex = 4;
            this.btnMCumlativeShiftA.Text = "H..";
            this.btnMCumlativeShiftA.UseVisualStyleBackColor = false;
            // 
            // btnMTotalShiftA
            // 
            this.btnMTotalShiftA.BackColor = System.Drawing.Color.Black;
            this.btnMTotalShiftA.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnMTotalShiftA.ForeColor = System.Drawing.Color.White;
            this.btnMTotalShiftA.Location = new System.Drawing.Point(184, 51);
            this.btnMTotalShiftA.Name = "btnMTotalShiftA";
            this.btnMTotalShiftA.Size = new System.Drawing.Size(83, 30);
            this.btnMTotalShiftA.TabIndex = 3;
            this.btnMTotalShiftA.Text = "TOTAL";
            this.btnMTotalShiftA.UseVisualStyleBackColor = false;
            // 
            // btnM30ShiftA
            // 
            this.btnM30ShiftA.BackColor = System.Drawing.Color.Black;
            this.btnM30ShiftA.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnM30ShiftA.ForeColor = System.Drawing.Color.White;
            this.btnM30ShiftA.Location = new System.Drawing.Point(95, 51);
            this.btnM30ShiftA.Name = "btnM30ShiftA";
            this.btnM30ShiftA.Size = new System.Drawing.Size(83, 30);
            this.btnM30ShiftA.TabIndex = 2;
            this.btnM30ShiftA.Text = "M-30";
            this.btnM30ShiftA.UseVisualStyleBackColor = false;
            // 
            // btnM31ShiftA
            // 
            this.btnM31ShiftA.BackColor = System.Drawing.Color.Black;
            this.btnM31ShiftA.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnM31ShiftA.ForeColor = System.Drawing.Color.White;
            this.btnM31ShiftA.Location = new System.Drawing.Point(6, 50);
            this.btnM31ShiftA.Name = "btnM31ShiftA";
            this.btnM31ShiftA.Size = new System.Drawing.Size(83, 30);
            this.btnM31ShiftA.TabIndex = 1;
            this.btnM31ShiftA.Text = "M-31";
            this.btnM31ShiftA.UseVisualStyleBackColor = false;
            // 
            // btnMSugarShiftA
            // 
            this.btnMSugarShiftA.BackColor = System.Drawing.Color.Black;
            this.btnMSugarShiftA.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnMSugarShiftA.ForeColor = System.Drawing.Color.White;
            this.btnMSugarShiftA.Location = new System.Drawing.Point(4, 10);
            this.btnMSugarShiftA.Name = "btnMSugarShiftA";
            this.btnMSugarShiftA.Size = new System.Drawing.Size(357, 34);
            this.btnMSugarShiftA.TabIndex = 0;
            this.btnMSugarShiftA.Text = "MEDIUM SUGAR";
            this.btnMSugarShiftA.UseVisualStyleBackColor = false;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.panel30);
            this.groupBox2.Controls.Add(this.panel26);
            this.groupBox2.Controls.Add(this.panel22);
            this.groupBox2.Controls.Add(this.panel18);
            this.groupBox2.Controls.Add(this.panel14);
            this.groupBox2.Controls.Add(this.panel9);
            this.groupBox2.Controls.Add(this.panel5);
            this.groupBox2.Controls.Add(this.panel1);
            this.groupBox2.Controls.Add(this.btnLCumlativeShiftA);
            this.groupBox2.Controls.Add(this.btnLTotalShiftA);
            this.groupBox2.Controls.Add(this.btnL30ShiftA);
            this.groupBox2.Controls.Add(this.btnL31ShiftA);
            this.groupBox2.Controls.Add(this.btnLargeSugarShiftA);
            this.groupBox2.Location = new System.Drawing.Point(95, 52);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(368, 425);
            this.groupBox2.TabIndex = 4;
            this.groupBox2.TabStop = false;
            // 
            // panel30
            // 
            this.panel30.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel30.Controls.Add(this.button116);
            this.panel30.Controls.Add(this.button115);
            this.panel30.Controls.Add(this.button114);
            this.panel30.Controls.Add(this.button113);
            this.panel30.Location = new System.Drawing.Point(3, 373);
            this.panel30.Name = "panel30";
            this.panel30.Size = new System.Drawing.Size(360, 35);
            this.panel30.TabIndex = 14;
            // 
            // button116
            // 
            this.button116.BackColor = System.Drawing.Color.Aqua;
            this.button116.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button116.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button116.Location = new System.Drawing.Point(272, 3);
            this.button116.Name = "button116";
            this.button116.Size = new System.Drawing.Size(82, 26);
            this.button116.TabIndex = 57;
            this.button116.Text = "button116";
            this.button116.UseVisualStyleBackColor = false;
            // 
            // button115
            // 
            this.button115.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.button115.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button115.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button115.Location = new System.Drawing.Point(181, 3);
            this.button115.Name = "button115";
            this.button115.Size = new System.Drawing.Size(82, 26);
            this.button115.TabIndex = 56;
            this.button115.Text = "button115";
            this.button115.UseVisualStyleBackColor = false;
            // 
            // button114
            // 
            this.button114.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button114.Location = new System.Drawing.Point(95, 3);
            this.button114.Name = "button114";
            this.button114.Size = new System.Drawing.Size(82, 26);
            this.button114.TabIndex = 55;
            this.button114.Text = "button114";
            this.button114.UseVisualStyleBackColor = true;
            // 
            // button113
            // 
            this.button113.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button113.Location = new System.Drawing.Point(5, 3);
            this.button113.Name = "button113";
            this.button113.Size = new System.Drawing.Size(82, 26);
            this.button113.TabIndex = 54;
            this.button113.Text = "button113";
            this.button113.UseVisualStyleBackColor = true;
            // 
            // panel26
            // 
            this.panel26.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel26.Controls.Add(this.button100);
            this.panel26.Controls.Add(this.button99);
            this.panel26.Controls.Add(this.button98);
            this.panel26.Controls.Add(this.button97);
            this.panel26.Location = new System.Drawing.Point(3, 332);
            this.panel26.Name = "panel26";
            this.panel26.Size = new System.Drawing.Size(360, 35);
            this.panel26.TabIndex = 13;
            // 
            // button100
            // 
            this.button100.BackColor = System.Drawing.Color.Aqua;
            this.button100.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button100.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button100.Location = new System.Drawing.Point(272, 3);
            this.button100.Name = "button100";
            this.button100.Size = new System.Drawing.Size(82, 26);
            this.button100.TabIndex = 43;
            this.button100.Text = "button100";
            this.button100.UseVisualStyleBackColor = false;
            // 
            // button99
            // 
            this.button99.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.button99.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button99.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button99.Location = new System.Drawing.Point(181, 3);
            this.button99.Name = "button99";
            this.button99.Size = new System.Drawing.Size(82, 26);
            this.button99.TabIndex = 42;
            this.button99.Text = "button99";
            this.button99.UseVisualStyleBackColor = false;
            // 
            // button98
            // 
            this.button98.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button98.Location = new System.Drawing.Point(95, 3);
            this.button98.Name = "button98";
            this.button98.Size = new System.Drawing.Size(82, 26);
            this.button98.TabIndex = 41;
            this.button98.Text = "button98";
            this.button98.UseVisualStyleBackColor = true;
            // 
            // button97
            // 
            this.button97.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button97.Location = new System.Drawing.Point(7, 3);
            this.button97.Name = "button97";
            this.button97.Size = new System.Drawing.Size(82, 26);
            this.button97.TabIndex = 40;
            this.button97.Text = "button97";
            this.button97.UseVisualStyleBackColor = true;
            // 
            // panel22
            // 
            this.panel22.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel22.Controls.Add(this.button84);
            this.panel22.Controls.Add(this.button83);
            this.panel22.Controls.Add(this.button82);
            this.panel22.Controls.Add(this.button81);
            this.panel22.Location = new System.Drawing.Point(3, 291);
            this.panel22.Name = "panel22";
            this.panel22.Size = new System.Drawing.Size(360, 35);
            this.panel22.TabIndex = 12;
            // 
            // button84
            // 
            this.button84.BackColor = System.Drawing.Color.Aqua;
            this.button84.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button84.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button84.Location = new System.Drawing.Point(272, 3);
            this.button84.Name = "button84";
            this.button84.Size = new System.Drawing.Size(82, 26);
            this.button84.TabIndex = 40;
            this.button84.Text = "button84";
            this.button84.UseVisualStyleBackColor = false;
            // 
            // button83
            // 
            this.button83.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.button83.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button83.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button83.Location = new System.Drawing.Point(181, 3);
            this.button83.Name = "button83";
            this.button83.Size = new System.Drawing.Size(82, 26);
            this.button83.TabIndex = 39;
            this.button83.Text = "button83";
            this.button83.UseVisualStyleBackColor = false;
            // 
            // button82
            // 
            this.button82.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button82.Location = new System.Drawing.Point(95, 3);
            this.button82.Name = "button82";
            this.button82.Size = new System.Drawing.Size(82, 26);
            this.button82.TabIndex = 38;
            this.button82.Text = "button82";
            this.button82.UseVisualStyleBackColor = true;
            // 
            // button81
            // 
            this.button81.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button81.Location = new System.Drawing.Point(5, 3);
            this.button81.Name = "button81";
            this.button81.Size = new System.Drawing.Size(82, 26);
            this.button81.TabIndex = 37;
            this.button81.Text = "button81";
            this.button81.UseVisualStyleBackColor = true;
            // 
            // panel18
            // 
            this.panel18.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel18.Controls.Add(this.button68);
            this.panel18.Controls.Add(this.button67);
            this.panel18.Controls.Add(this.button66);
            this.panel18.Controls.Add(this.button65);
            this.panel18.Location = new System.Drawing.Point(3, 250);
            this.panel18.Name = "panel18";
            this.panel18.Size = new System.Drawing.Size(360, 35);
            this.panel18.TabIndex = 11;
            // 
            // button68
            // 
            this.button68.BackColor = System.Drawing.Color.Aqua;
            this.button68.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button68.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button68.Location = new System.Drawing.Point(272, 3);
            this.button68.Name = "button68";
            this.button68.Size = new System.Drawing.Size(82, 26);
            this.button68.TabIndex = 37;
            this.button68.Text = "button68";
            this.button68.UseVisualStyleBackColor = false;
            // 
            // button67
            // 
            this.button67.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.button67.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button67.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button67.Location = new System.Drawing.Point(181, 3);
            this.button67.Name = "button67";
            this.button67.Size = new System.Drawing.Size(82, 26);
            this.button67.TabIndex = 36;
            this.button67.Text = "button67";
            this.button67.UseVisualStyleBackColor = false;
            // 
            // button66
            // 
            this.button66.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button66.Location = new System.Drawing.Point(95, 3);
            this.button66.Name = "button66";
            this.button66.Size = new System.Drawing.Size(82, 26);
            this.button66.TabIndex = 35;
            this.button66.Text = "button66";
            this.button66.UseVisualStyleBackColor = true;
            // 
            // button65
            // 
            this.button65.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button65.Location = new System.Drawing.Point(5, 3);
            this.button65.Name = "button65";
            this.button65.Size = new System.Drawing.Size(82, 26);
            this.button65.TabIndex = 34;
            this.button65.Text = "button65";
            this.button65.UseVisualStyleBackColor = true;
            // 
            // panel14
            // 
            this.panel14.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel14.Controls.Add(this.button52);
            this.panel14.Controls.Add(this.button51);
            this.panel14.Controls.Add(this.button50);
            this.panel14.Controls.Add(this.button49);
            this.panel14.Location = new System.Drawing.Point(3, 209);
            this.panel14.Name = "panel14";
            this.panel14.Size = new System.Drawing.Size(360, 35);
            this.panel14.TabIndex = 10;
            // 
            // button52
            // 
            this.button52.BackColor = System.Drawing.Color.Aqua;
            this.button52.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button52.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button52.Location = new System.Drawing.Point(272, 3);
            this.button52.Name = "button52";
            this.button52.Size = new System.Drawing.Size(82, 26);
            this.button52.TabIndex = 30;
            this.button52.Text = "button52";
            this.button52.UseVisualStyleBackColor = false;
            // 
            // button51
            // 
            this.button51.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.button51.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button51.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button51.Location = new System.Drawing.Point(181, 3);
            this.button51.Name = "button51";
            this.button51.Size = new System.Drawing.Size(82, 26);
            this.button51.TabIndex = 29;
            this.button51.Text = "button51";
            this.button51.UseVisualStyleBackColor = false;
            // 
            // button50
            // 
            this.button50.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button50.Location = new System.Drawing.Point(95, 3);
            this.button50.Name = "button50";
            this.button50.Size = new System.Drawing.Size(82, 26);
            this.button50.TabIndex = 28;
            this.button50.Text = "button50";
            this.button50.UseVisualStyleBackColor = true;
            // 
            // button49
            // 
            this.button49.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button49.Location = new System.Drawing.Point(5, 3);
            this.button49.Name = "button49";
            this.button49.Size = new System.Drawing.Size(82, 26);
            this.button49.TabIndex = 27;
            this.button49.Text = "button49";
            this.button49.UseVisualStyleBackColor = true;
            // 
            // panel9
            // 
            this.panel9.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel9.Controls.Add(this.button36);
            this.panel9.Controls.Add(this.button35);
            this.panel9.Controls.Add(this.button34);
            this.panel9.Controls.Add(this.button33);
            this.panel9.Location = new System.Drawing.Point(3, 168);
            this.panel9.Name = "panel9";
            this.panel9.Size = new System.Drawing.Size(360, 35);
            this.panel9.TabIndex = 9;
            // 
            // button36
            // 
            this.button36.BackColor = System.Drawing.Color.Aqua;
            this.button36.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button36.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button36.Location = new System.Drawing.Point(272, 3);
            this.button36.Name = "button36";
            this.button36.Size = new System.Drawing.Size(82, 26);
            this.button36.TabIndex = 19;
            this.button36.Text = "button36";
            this.button36.UseVisualStyleBackColor = false;
            // 
            // button35
            // 
            this.button35.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.button35.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button35.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button35.Location = new System.Drawing.Point(181, 3);
            this.button35.Name = "button35";
            this.button35.Size = new System.Drawing.Size(82, 26);
            this.button35.TabIndex = 18;
            this.button35.Text = "button35";
            this.button35.UseVisualStyleBackColor = false;
            // 
            // button34
            // 
            this.button34.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button34.Location = new System.Drawing.Point(95, 3);
            this.button34.Name = "button34";
            this.button34.Size = new System.Drawing.Size(82, 26);
            this.button34.TabIndex = 17;
            this.button34.Text = "button34";
            this.button34.UseVisualStyleBackColor = true;
            // 
            // button33
            // 
            this.button33.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button33.Location = new System.Drawing.Point(5, 3);
            this.button33.Name = "button33";
            this.button33.Size = new System.Drawing.Size(82, 26);
            this.button33.TabIndex = 16;
            this.button33.Text = "button33";
            this.button33.UseVisualStyleBackColor = true;
            // 
            // panel5
            // 
            this.panel5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel5.Controls.Add(this.button20);
            this.panel5.Controls.Add(this.button19);
            this.panel5.Controls.Add(this.button18);
            this.panel5.Controls.Add(this.button17);
            this.panel5.Location = new System.Drawing.Point(3, 127);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(360, 35);
            this.panel5.TabIndex = 8;
            // 
            // button20
            // 
            this.button20.BackColor = System.Drawing.Color.Aqua;
            this.button20.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button20.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button20.Location = new System.Drawing.Point(272, 3);
            this.button20.Name = "button20";
            this.button20.Size = new System.Drawing.Size(82, 26);
            this.button20.TabIndex = 16;
            this.button20.Text = "button20";
            this.button20.UseVisualStyleBackColor = false;
            // 
            // button19
            // 
            this.button19.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.button19.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button19.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button19.Location = new System.Drawing.Point(181, 3);
            this.button19.Name = "button19";
            this.button19.Size = new System.Drawing.Size(82, 26);
            this.button19.TabIndex = 15;
            this.button19.Text = "button19";
            this.button19.UseVisualStyleBackColor = false;
            // 
            // button18
            // 
            this.button18.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button18.Location = new System.Drawing.Point(95, 3);
            this.button18.Name = "button18";
            this.button18.Size = new System.Drawing.Size(82, 26);
            this.button18.TabIndex = 14;
            this.button18.Text = "button18";
            this.button18.UseVisualStyleBackColor = true;
            // 
            // button17
            // 
            this.button17.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button17.Location = new System.Drawing.Point(5, 3);
            this.button17.Name = "button17";
            this.button17.Size = new System.Drawing.Size(82, 26);
            this.button17.TabIndex = 13;
            this.button17.Text = "button17";
            this.button17.UseVisualStyleBackColor = true;
            // 
            // panel1
            // 
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel1.Controls.Add(this.button4);
            this.panel1.Controls.Add(this.button3);
            this.panel1.Controls.Add(this.button2);
            this.panel1.Controls.Add(this.button1);
            this.panel1.Location = new System.Drawing.Point(3, 84);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(360, 35);
            this.panel1.TabIndex = 5;
            // 
            // button4
            // 
            this.button4.BackColor = System.Drawing.Color.Aqua;
            this.button4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button4.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button4.Location = new System.Drawing.Point(272, 3);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(82, 26);
            this.button4.TabIndex = 8;
            this.button4.Text = "button4";
            this.button4.UseVisualStyleBackColor = false;
            // 
            // button3
            // 
            this.button3.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.button3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button3.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button3.Location = new System.Drawing.Point(181, 3);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(82, 26);
            this.button3.TabIndex = 7;
            this.button3.Text = "button3";
            this.button3.UseVisualStyleBackColor = false;
            // 
            // button2
            // 
            this.button2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button2.Location = new System.Drawing.Point(95, 3);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(82, 26);
            this.button2.TabIndex = 6;
            this.button2.Text = "button2";
            this.button2.UseVisualStyleBackColor = true;
            // 
            // button1
            // 
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.Location = new System.Drawing.Point(5, 3);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(82, 26);
            this.button1.TabIndex = 5;
            this.button1.Text = "button1";
            this.button1.UseVisualStyleBackColor = true;
            // 
            // btnLCumlativeShiftA
            // 
            this.btnLCumlativeShiftA.BackColor = System.Drawing.Color.Black;
            this.btnLCumlativeShiftA.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLCumlativeShiftA.ForeColor = System.Drawing.Color.White;
            this.btnLCumlativeShiftA.Location = new System.Drawing.Point(276, 47);
            this.btnLCumlativeShiftA.Name = "btnLCumlativeShiftA";
            this.btnLCumlativeShiftA.Size = new System.Drawing.Size(83, 30);
            this.btnLCumlativeShiftA.TabIndex = 4;
            this.btnLCumlativeShiftA.Text = "H..";
            this.btnLCumlativeShiftA.UseVisualStyleBackColor = false;
            // 
            // btnLTotalShiftA
            // 
            this.btnLTotalShiftA.BackColor = System.Drawing.Color.Black;
            this.btnLTotalShiftA.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLTotalShiftA.ForeColor = System.Drawing.Color.White;
            this.btnLTotalShiftA.Location = new System.Drawing.Point(185, 47);
            this.btnLTotalShiftA.Name = "btnLTotalShiftA";
            this.btnLTotalShiftA.Size = new System.Drawing.Size(83, 30);
            this.btnLTotalShiftA.TabIndex = 3;
            this.btnLTotalShiftA.Text = "TOTAL";
            this.btnLTotalShiftA.UseVisualStyleBackColor = false;
            // 
            // btnL30ShiftA
            // 
            this.btnL30ShiftA.BackColor = System.Drawing.Color.Black;
            this.btnL30ShiftA.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnL30ShiftA.ForeColor = System.Drawing.Color.White;
            this.btnL30ShiftA.Location = new System.Drawing.Point(99, 47);
            this.btnL30ShiftA.Name = "btnL30ShiftA";
            this.btnL30ShiftA.Size = new System.Drawing.Size(83, 30);
            this.btnL30ShiftA.TabIndex = 2;
            this.btnL30ShiftA.Text = "L-30";
            this.btnL30ShiftA.UseVisualStyleBackColor = false;
            // 
            // btnL31ShiftA
            // 
            this.btnL31ShiftA.BackColor = System.Drawing.Color.Black;
            this.btnL31ShiftA.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnL31ShiftA.ForeColor = System.Drawing.Color.White;
            this.btnL31ShiftA.Location = new System.Drawing.Point(5, 47);
            this.btnL31ShiftA.Name = "btnL31ShiftA";
            this.btnL31ShiftA.Size = new System.Drawing.Size(83, 30);
            this.btnL31ShiftA.TabIndex = 1;
            this.btnL31ShiftA.Text = "L-31";
            this.btnL31ShiftA.UseVisualStyleBackColor = false;
            // 
            // btnLargeSugarShiftA
            // 
            this.btnLargeSugarShiftA.BackColor = System.Drawing.Color.Black;
            this.btnLargeSugarShiftA.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLargeSugarShiftA.ForeColor = System.Drawing.Color.White;
            this.btnLargeSugarShiftA.Location = new System.Drawing.Point(4, 10);
            this.btnLargeSugarShiftA.Name = "btnLargeSugarShiftA";
            this.btnLargeSugarShiftA.Size = new System.Drawing.Size(357, 34);
            this.btnLargeSugarShiftA.TabIndex = 0;
            this.btnLargeSugarShiftA.Text = "LARGE SUGAR";
            this.btnLargeSugarShiftA.UseVisualStyleBackColor = false;
            // 
            // groupBox19
            // 
            this.groupBox19.Controls.Add(this.button128);
            this.groupBox19.Controls.Add(this.button112);
            this.groupBox19.Controls.Add(this.button96);
            this.groupBox19.Controls.Add(this.button80);
            this.groupBox19.Controls.Add(this.button64);
            this.groupBox19.Controls.Add(this.button48);
            this.groupBox19.Controls.Add(this.button32);
            this.groupBox19.Controls.Add(this.button16);
            this.groupBox19.Controls.Add(this.btnHourTotalShiftA);
            this.groupBox19.Location = new System.Drawing.Point(1581, 52);
            this.groupBox19.Name = "groupBox19";
            this.groupBox19.Size = new System.Drawing.Size(84, 425);
            this.groupBox19.TabIndex = 10;
            this.groupBox19.TabStop = false;
            // 
            // button128
            // 
            this.button128.Location = new System.Drawing.Point(3, 373);
            this.button128.Name = "button128";
            this.button128.Size = new System.Drawing.Size(78, 35);
            this.button128.TabIndex = 13;
            this.button128.Text = "9";
            this.button128.UseVisualStyleBackColor = true;
            // 
            // button112
            // 
            this.button112.Location = new System.Drawing.Point(3, 332);
            this.button112.Name = "button112";
            this.button112.Size = new System.Drawing.Size(78, 35);
            this.button112.TabIndex = 12;
            this.button112.Text = "9";
            this.button112.UseVisualStyleBackColor = true;
            // 
            // button96
            // 
            this.button96.Location = new System.Drawing.Point(3, 295);
            this.button96.Name = "button96";
            this.button96.Size = new System.Drawing.Size(78, 35);
            this.button96.TabIndex = 11;
            this.button96.Text = "9";
            this.button96.UseVisualStyleBackColor = true;
            // 
            // button80
            // 
            this.button80.Location = new System.Drawing.Point(3, 254);
            this.button80.Name = "button80";
            this.button80.Size = new System.Drawing.Size(78, 35);
            this.button80.TabIndex = 10;
            this.button80.Text = "9";
            this.button80.UseVisualStyleBackColor = true;
            // 
            // button64
            // 
            this.button64.Location = new System.Drawing.Point(3, 208);
            this.button64.Name = "button64";
            this.button64.Size = new System.Drawing.Size(78, 35);
            this.button64.TabIndex = 9;
            this.button64.Text = "9";
            this.button64.UseVisualStyleBackColor = true;
            // 
            // button48
            // 
            this.button48.Location = new System.Drawing.Point(3, 167);
            this.button48.Name = "button48";
            this.button48.Size = new System.Drawing.Size(78, 35);
            this.button48.TabIndex = 8;
            this.button48.Text = "9";
            this.button48.UseVisualStyleBackColor = true;
            // 
            // button32
            // 
            this.button32.Location = new System.Drawing.Point(3, 126);
            this.button32.Name = "button32";
            this.button32.Size = new System.Drawing.Size(78, 35);
            this.button32.TabIndex = 7;
            this.button32.Text = "9";
            this.button32.UseVisualStyleBackColor = true;
            // 
            // button16
            // 
            this.button16.Location = new System.Drawing.Point(3, 85);
            this.button16.Name = "button16";
            this.button16.Size = new System.Drawing.Size(78, 35);
            this.button16.TabIndex = 6;
            this.button16.Text = "9";
            this.button16.UseVisualStyleBackColor = true;
            // 
            // btnHourTotalShiftA
            // 
            this.btnHourTotalShiftA.BackColor = System.Drawing.Color.Black;
            this.btnHourTotalShiftA.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnHourTotalShiftA.ForeColor = System.Drawing.Color.White;
            this.btnHourTotalShiftA.Location = new System.Drawing.Point(3, 10);
            this.btnHourTotalShiftA.Name = "btnHourTotalShiftA";
            this.btnHourTotalShiftA.Size = new System.Drawing.Size(78, 60);
            this.btnHourTotalShiftA.TabIndex = 5;
            this.btnHourTotalShiftA.Text = "TOTAL";
            this.btnHourTotalShiftA.UseVisualStyleBackColor = false;
            // 
            // groupBox7
            // 
            this.groupBox7.Controls.Add(this.panel12);
            this.groupBox7.Controls.Add(this.panel34);
            this.groupBox7.Controls.Add(this.panel29);
            this.groupBox7.Controls.Add(this.panel25);
            this.groupBox7.Controls.Add(this.panel21);
            this.groupBox7.Controls.Add(this.panel17);
            this.groupBox7.Controls.Add(this.panel13);
            this.groupBox7.Controls.Add(this.panel4);
            this.groupBox7.Controls.Add(this.btnBissCumlativeShiftA);
            this.groupBox7.Controls.Add(this.btnBissTotalShiftA);
            this.groupBox7.Controls.Add(this.btnBissShiftA);
            this.groupBox7.Controls.Add(this.btnBissSugarShifA);
            this.groupBox7.Location = new System.Drawing.Point(1262, 52);
            this.groupBox7.Name = "groupBox7";
            this.groupBox7.Size = new System.Drawing.Size(291, 425);
            this.groupBox7.TabIndex = 9;
            this.groupBox7.TabStop = false;
            // 
            // panel12
            // 
            this.panel12.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel12.Controls.Add(this.button31);
            this.panel12.Controls.Add(this.button30);
            this.panel12.Controls.Add(this.button29);
            this.panel12.Location = new System.Drawing.Point(6, 127);
            this.panel12.Name = "panel12";
            this.panel12.Size = new System.Drawing.Size(265, 35);
            this.panel12.TabIndex = 10;
            // 
            // button31
            // 
            this.button31.BackColor = System.Drawing.Color.Aqua;
            this.button31.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button31.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button31.Location = new System.Drawing.Point(178, 3);
            this.button31.Name = "button31";
            this.button31.Size = new System.Drawing.Size(82, 26);
            this.button31.TabIndex = 15;
            this.button31.Text = "button31";
            this.button31.UseVisualStyleBackColor = false;
            // 
            // button30
            // 
            this.button30.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.button30.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button30.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button30.Location = new System.Drawing.Point(90, 3);
            this.button30.Name = "button30";
            this.button30.Size = new System.Drawing.Size(82, 26);
            this.button30.TabIndex = 14;
            this.button30.Text = "button30";
            this.button30.UseVisualStyleBackColor = false;
            // 
            // button29
            // 
            this.button29.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button29.Location = new System.Drawing.Point(3, 3);
            this.button29.Name = "button29";
            this.button29.Size = new System.Drawing.Size(82, 26);
            this.button29.TabIndex = 13;
            this.button29.Text = "button29";
            this.button29.UseVisualStyleBackColor = true;
            // 
            // panel34
            // 
            this.panel34.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel34.Controls.Add(this.button127);
            this.panel34.Controls.Add(this.button126);
            this.panel34.Controls.Add(this.button125);
            this.panel34.Location = new System.Drawing.Point(6, 373);
            this.panel34.Name = "panel34";
            this.panel34.Size = new System.Drawing.Size(265, 35);
            this.panel34.TabIndex = 15;
            // 
            // button127
            // 
            this.button127.BackColor = System.Drawing.Color.Aqua;
            this.button127.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button127.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button127.Location = new System.Drawing.Point(180, 3);
            this.button127.Name = "button127";
            this.button127.Size = new System.Drawing.Size(82, 26);
            this.button127.TabIndex = 68;
            this.button127.Text = "button127";
            this.button127.UseVisualStyleBackColor = false;
            // 
            // button126
            // 
            this.button126.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.button126.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button126.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button126.Location = new System.Drawing.Point(91, 3);
            this.button126.Name = "button126";
            this.button126.Size = new System.Drawing.Size(82, 26);
            this.button126.TabIndex = 67;
            this.button126.Text = "button126";
            this.button126.UseVisualStyleBackColor = false;
            // 
            // button125
            // 
            this.button125.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button125.Location = new System.Drawing.Point(3, 3);
            this.button125.Name = "button125";
            this.button125.Size = new System.Drawing.Size(82, 26);
            this.button125.TabIndex = 66;
            this.button125.Text = "button125";
            this.button125.UseVisualStyleBackColor = true;
            // 
            // panel29
            // 
            this.panel29.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel29.Controls.Add(this.button111);
            this.panel29.Controls.Add(this.button110);
            this.panel29.Controls.Add(this.button109);
            this.panel29.Location = new System.Drawing.Point(6, 332);
            this.panel29.Name = "panel29";
            this.panel29.Size = new System.Drawing.Size(265, 35);
            this.panel29.TabIndex = 14;
            // 
            // button111
            // 
            this.button111.BackColor = System.Drawing.Color.Aqua;
            this.button111.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button111.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button111.Location = new System.Drawing.Point(178, 3);
            this.button111.Name = "button111";
            this.button111.Size = new System.Drawing.Size(82, 26);
            this.button111.TabIndex = 53;
            this.button111.Text = "button111";
            this.button111.UseVisualStyleBackColor = false;
            // 
            // button110
            // 
            this.button110.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.button110.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button110.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button110.Location = new System.Drawing.Point(91, 3);
            this.button110.Name = "button110";
            this.button110.Size = new System.Drawing.Size(82, 26);
            this.button110.TabIndex = 52;
            this.button110.Text = "button110";
            this.button110.UseVisualStyleBackColor = false;
            // 
            // button109
            // 
            this.button109.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button109.Location = new System.Drawing.Point(3, 3);
            this.button109.Name = "button109";
            this.button109.Size = new System.Drawing.Size(82, 26);
            this.button109.TabIndex = 51;
            this.button109.Text = "button109";
            this.button109.UseVisualStyleBackColor = true;
            // 
            // panel25
            // 
            this.panel25.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel25.Controls.Add(this.button95);
            this.panel25.Controls.Add(this.button94);
            this.panel25.Controls.Add(this.button93);
            this.panel25.Location = new System.Drawing.Point(6, 291);
            this.panel25.Name = "panel25";
            this.panel25.Size = new System.Drawing.Size(265, 35);
            this.panel25.TabIndex = 13;
            // 
            // button95
            // 
            this.button95.BackColor = System.Drawing.Color.Aqua;
            this.button95.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button95.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button95.Location = new System.Drawing.Point(178, 3);
            this.button95.Name = "button95";
            this.button95.Size = new System.Drawing.Size(82, 26);
            this.button95.TabIndex = 39;
            this.button95.Text = "button95";
            this.button95.UseVisualStyleBackColor = false;
            // 
            // button94
            // 
            this.button94.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.button94.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button94.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button94.Location = new System.Drawing.Point(90, 3);
            this.button94.Name = "button94";
            this.button94.Size = new System.Drawing.Size(82, 26);
            this.button94.TabIndex = 38;
            this.button94.Text = "button94";
            this.button94.UseVisualStyleBackColor = false;
            // 
            // button93
            // 
            this.button93.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button93.Location = new System.Drawing.Point(3, 3);
            this.button93.Name = "button93";
            this.button93.Size = new System.Drawing.Size(82, 26);
            this.button93.TabIndex = 37;
            this.button93.Text = "button93";
            this.button93.UseVisualStyleBackColor = true;
            // 
            // panel21
            // 
            this.panel21.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel21.Controls.Add(this.button79);
            this.panel21.Controls.Add(this.button78);
            this.panel21.Controls.Add(this.button77);
            this.panel21.Location = new System.Drawing.Point(6, 250);
            this.panel21.Name = "panel21";
            this.panel21.Size = new System.Drawing.Size(265, 35);
            this.panel21.TabIndex = 12;
            // 
            // button79
            // 
            this.button79.BackColor = System.Drawing.Color.Aqua;
            this.button79.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button79.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button79.Location = new System.Drawing.Point(178, 3);
            this.button79.Name = "button79";
            this.button79.Size = new System.Drawing.Size(82, 26);
            this.button79.TabIndex = 36;
            this.button79.Text = "button79";
            this.button79.UseVisualStyleBackColor = false;
            // 
            // button78
            // 
            this.button78.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.button78.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button78.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button78.Location = new System.Drawing.Point(90, 3);
            this.button78.Name = "button78";
            this.button78.Size = new System.Drawing.Size(82, 26);
            this.button78.TabIndex = 35;
            this.button78.Text = "button78";
            this.button78.UseVisualStyleBackColor = false;
            // 
            // button77
            // 
            this.button77.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button77.Location = new System.Drawing.Point(3, 3);
            this.button77.Name = "button77";
            this.button77.Size = new System.Drawing.Size(82, 26);
            this.button77.TabIndex = 34;
            this.button77.Text = "button77";
            this.button77.UseVisualStyleBackColor = true;
            // 
            // panel17
            // 
            this.panel17.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel17.Controls.Add(this.button63);
            this.panel17.Controls.Add(this.button62);
            this.panel17.Controls.Add(this.button61);
            this.panel17.Location = new System.Drawing.Point(4, 209);
            this.panel17.Name = "panel17";
            this.panel17.Size = new System.Drawing.Size(265, 35);
            this.panel17.TabIndex = 11;
            // 
            // button63
            // 
            this.button63.BackColor = System.Drawing.Color.Aqua;
            this.button63.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button63.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button63.Location = new System.Drawing.Point(178, 3);
            this.button63.Name = "button63";
            this.button63.Size = new System.Drawing.Size(82, 26);
            this.button63.TabIndex = 33;
            this.button63.Text = "button63";
            this.button63.UseVisualStyleBackColor = false;
            // 
            // button62
            // 
            this.button62.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.button62.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button62.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button62.Location = new System.Drawing.Point(90, 3);
            this.button62.Name = "button62";
            this.button62.Size = new System.Drawing.Size(82, 26);
            this.button62.TabIndex = 32;
            this.button62.Text = "button62";
            this.button62.UseVisualStyleBackColor = false;
            // 
            // button61
            // 
            this.button61.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button61.Location = new System.Drawing.Point(3, 3);
            this.button61.Name = "button61";
            this.button61.Size = new System.Drawing.Size(82, 26);
            this.button61.TabIndex = 31;
            this.button61.Text = "button61";
            this.button61.UseVisualStyleBackColor = true;
            // 
            // panel13
            // 
            this.panel13.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel13.Controls.Add(this.button47);
            this.panel13.Controls.Add(this.button46);
            this.panel13.Controls.Add(this.button45);
            this.panel13.Location = new System.Drawing.Point(6, 168);
            this.panel13.Name = "panel13";
            this.panel13.Size = new System.Drawing.Size(265, 35);
            this.panel13.TabIndex = 10;
            // 
            // button47
            // 
            this.button47.BackColor = System.Drawing.Color.Aqua;
            this.button47.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button47.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button47.Location = new System.Drawing.Point(178, 3);
            this.button47.Name = "button47";
            this.button47.Size = new System.Drawing.Size(82, 26);
            this.button47.TabIndex = 26;
            this.button47.Text = "button47";
            this.button47.UseVisualStyleBackColor = false;
            // 
            // button46
            // 
            this.button46.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.button46.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button46.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button46.Location = new System.Drawing.Point(90, 5);
            this.button46.Name = "button46";
            this.button46.Size = new System.Drawing.Size(82, 26);
            this.button46.TabIndex = 25;
            this.button46.Text = "button46";
            this.button46.UseVisualStyleBackColor = false;
            // 
            // button45
            // 
            this.button45.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button45.Location = new System.Drawing.Point(3, 3);
            this.button45.Name = "button45";
            this.button45.Size = new System.Drawing.Size(82, 26);
            this.button45.TabIndex = 24;
            this.button45.Text = "button45";
            this.button45.UseVisualStyleBackColor = true;
            // 
            // panel4
            // 
            this.panel4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel4.Controls.Add(this.button15);
            this.panel4.Controls.Add(this.button14);
            this.panel4.Controls.Add(this.button13);
            this.panel4.Location = new System.Drawing.Point(4, 84);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(265, 35);
            this.panel4.TabIndex = 8;
            // 
            // button15
            // 
            this.button15.BackColor = System.Drawing.Color.Aqua;
            this.button15.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button15.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button15.Location = new System.Drawing.Point(178, 3);
            this.button15.Name = "button15";
            this.button15.Size = new System.Drawing.Size(82, 26);
            this.button15.TabIndex = 12;
            this.button15.Text = "button15";
            this.button15.UseVisualStyleBackColor = false;
            // 
            // button14
            // 
            this.button14.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.button14.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button14.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button14.Location = new System.Drawing.Point(90, 3);
            this.button14.Name = "button14";
            this.button14.Size = new System.Drawing.Size(82, 26);
            this.button14.TabIndex = 11;
            this.button14.Text = "button14";
            this.button14.UseVisualStyleBackColor = false;
            // 
            // button13
            // 
            this.button13.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button13.Location = new System.Drawing.Point(3, 4);
            this.button13.Name = "button13";
            this.button13.Size = new System.Drawing.Size(82, 26);
            this.button13.TabIndex = 10;
            this.button13.Text = "button13";
            this.button13.UseVisualStyleBackColor = true;
            // 
            // btnBissCumlativeShiftA
            // 
            this.btnBissCumlativeShiftA.BackColor = System.Drawing.Color.Black;
            this.btnBissCumlativeShiftA.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnBissCumlativeShiftA.ForeColor = System.Drawing.Color.White;
            this.btnBissCumlativeShiftA.Location = new System.Drawing.Point(186, 51);
            this.btnBissCumlativeShiftA.Name = "btnBissCumlativeShiftA";
            this.btnBissCumlativeShiftA.Size = new System.Drawing.Size(83, 30);
            this.btnBissCumlativeShiftA.TabIndex = 4;
            this.btnBissCumlativeShiftA.Text = "H..";
            this.btnBissCumlativeShiftA.UseVisualStyleBackColor = false;
            // 
            // btnBissTotalShiftA
            // 
            this.btnBissTotalShiftA.BackColor = System.Drawing.Color.Black;
            this.btnBissTotalShiftA.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnBissTotalShiftA.ForeColor = System.Drawing.Color.White;
            this.btnBissTotalShiftA.Location = new System.Drawing.Point(97, 50);
            this.btnBissTotalShiftA.Name = "btnBissTotalShiftA";
            this.btnBissTotalShiftA.Size = new System.Drawing.Size(83, 30);
            this.btnBissTotalShiftA.TabIndex = 3;
            this.btnBissTotalShiftA.Text = "TOTAL";
            this.btnBissTotalShiftA.UseVisualStyleBackColor = false;
            // 
            // btnBissShiftA
            // 
            this.btnBissShiftA.BackColor = System.Drawing.Color.Black;
            this.btnBissShiftA.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnBissShiftA.ForeColor = System.Drawing.Color.White;
            this.btnBissShiftA.Location = new System.Drawing.Point(6, 50);
            this.btnBissShiftA.Name = "btnBissShiftA";
            this.btnBissShiftA.Size = new System.Drawing.Size(83, 30);
            this.btnBissShiftA.TabIndex = 1;
            this.btnBissShiftA.Text = "BISS";
            this.btnBissShiftA.UseVisualStyleBackColor = false;
            // 
            // btnBissSugarShifA
            // 
            this.btnBissSugarShifA.BackColor = System.Drawing.Color.Black;
            this.btnBissSugarShifA.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnBissSugarShifA.ForeColor = System.Drawing.Color.White;
            this.btnBissSugarShifA.Location = new System.Drawing.Point(4, 10);
            this.btnBissSugarShifA.Name = "btnBissSugarShifA";
            this.btnBissSugarShifA.Size = new System.Drawing.Size(273, 34);
            this.btnBissSugarShifA.TabIndex = 0;
            this.btnBissSugarShifA.Text = "BISS SUGAR";
            this.btnBissSugarShifA.UseVisualStyleBackColor = false;
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.btnTime9);
            this.groupBox3.Controls.Add(this.btnTime16);
            this.groupBox3.Controls.Add(this.btnTime15);
            this.groupBox3.Controls.Add(this.btnTime14);
            this.groupBox3.Controls.Add(this.btnTime13);
            this.groupBox3.Controls.Add(this.btnTime12);
            this.groupBox3.Controls.Add(this.btnTime11);
            this.groupBox3.Controls.Add(this.btnTime10);
            this.groupBox3.Controls.Add(this.headerTime);
            this.groupBox3.Location = new System.Drawing.Point(16, 47);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(73, 425);
            this.groupBox3.TabIndex = 6;
            this.groupBox3.TabStop = false;
            // 
            // btnTime9
            // 
            this.btnTime9.Location = new System.Drawing.Point(6, 86);
            this.btnTime9.Name = "btnTime9";
            this.btnTime9.Size = new System.Drawing.Size(61, 35);
            this.btnTime9.TabIndex = 5;
            this.btnTime9.Text = "9";
            this.btnTime9.UseVisualStyleBackColor = true;
            // 
            // btnTime16
            // 
            this.btnTime16.Location = new System.Drawing.Point(6, 373);
            this.btnTime16.Name = "btnTime16";
            this.btnTime16.Size = new System.Drawing.Size(61, 35);
            this.btnTime16.TabIndex = 10;
            this.btnTime16.Text = "16";
            this.btnTime16.UseVisualStyleBackColor = true;
            // 
            // btnTime15
            // 
            this.btnTime15.Location = new System.Drawing.Point(6, 332);
            this.btnTime15.Name = "btnTime15";
            this.btnTime15.Size = new System.Drawing.Size(61, 35);
            this.btnTime15.TabIndex = 6;
            this.btnTime15.Text = "15";
            this.btnTime15.UseVisualStyleBackColor = true;
            // 
            // btnTime14
            // 
            this.btnTime14.Location = new System.Drawing.Point(6, 291);
            this.btnTime14.Name = "btnTime14";
            this.btnTime14.Size = new System.Drawing.Size(61, 35);
            this.btnTime14.TabIndex = 9;
            this.btnTime14.Text = "14";
            this.btnTime14.UseVisualStyleBackColor = true;
            // 
            // btnTime13
            // 
            this.btnTime13.Location = new System.Drawing.Point(6, 250);
            this.btnTime13.Name = "btnTime13";
            this.btnTime13.Size = new System.Drawing.Size(61, 35);
            this.btnTime13.TabIndex = 8;
            this.btnTime13.Text = "13";
            this.btnTime13.UseVisualStyleBackColor = true;
            // 
            // btnTime12
            // 
            this.btnTime12.Location = new System.Drawing.Point(6, 209);
            this.btnTime12.Name = "btnTime12";
            this.btnTime12.Size = new System.Drawing.Size(61, 35);
            this.btnTime12.TabIndex = 7;
            this.btnTime12.Text = "12";
            this.btnTime12.UseVisualStyleBackColor = true;
            // 
            // btnTime11
            // 
            this.btnTime11.Location = new System.Drawing.Point(6, 168);
            this.btnTime11.Name = "btnTime11";
            this.btnTime11.Size = new System.Drawing.Size(61, 35);
            this.btnTime11.TabIndex = 6;
            this.btnTime11.Text = "11";
            this.btnTime11.UseVisualStyleBackColor = true;
            // 
            // btnTime10
            // 
            this.btnTime10.Location = new System.Drawing.Point(6, 127);
            this.btnTime10.Name = "btnTime10";
            this.btnTime10.Size = new System.Drawing.Size(61, 35);
            this.btnTime10.TabIndex = 6;
            this.btnTime10.Text = "10";
            this.btnTime10.UseVisualStyleBackColor = true;
            // 
            // headerTime
            // 
            this.headerTime.Location = new System.Drawing.Point(6, 10);
            this.headerTime.Name = "headerTime";
            this.headerTime.Size = new System.Drawing.Size(61, 70);
            this.headerTime.TabIndex = 5;
            this.headerTime.Text = "TIME";
            this.headerTime.UseVisualStyleBackColor = true;
            // 
            // btnShiftA
            // 
            this.btnShiftA.Location = new System.Drawing.Point(16, 18);
            this.btnShiftA.Name = "btnShiftA";
            this.btnShiftA.Size = new System.Drawing.Size(1649, 23);
            this.btnShiftA.TabIndex = 0;
            this.btnShiftA.Text = "SHIFT-A";
            this.btnShiftA.UseVisualStyleBackColor = true;
            // 
            // panel33
            // 
            this.panel33.AutoScroll = true;
            this.panel33.Controls.Add(this.groupBox13);
            this.panel33.Controls.Add(this.groupBox1);
            this.panel33.Controls.Add(this.groupBox4);
            this.panel33.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel33.Location = new System.Drawing.Point(0, 0);
            this.panel33.Name = "panel33";
            this.panel33.Size = new System.Drawing.Size(1713, 810);
            this.panel33.TabIndex = 8;
            // 
            // groupBox13
            // 
            this.groupBox13.Controls.Add(this.groupBox21);
            this.groupBox13.Controls.Add(this.groupBox14);
            this.groupBox13.Controls.Add(this.groupBox15);
            this.groupBox13.Controls.Add(this.groupBox16);
            this.groupBox13.Controls.Add(this.groupBox17);
            this.groupBox13.Controls.Add(this.groupBox18);
            this.groupBox13.Controls.Add(this.btnShiftC);
            this.groupBox13.Location = new System.Drawing.Point(3, 981);
            this.groupBox13.Name = "groupBox13";
            this.groupBox13.Size = new System.Drawing.Size(1679, 483);
            this.groupBox13.TabIndex = 9;
            this.groupBox13.TabStop = false;
            // 
            // groupBox21
            // 
            this.groupBox21.Controls.Add(this.button384);
            this.groupBox21.Controls.Add(this.button368);
            this.groupBox21.Controls.Add(this.button352);
            this.groupBox21.Controls.Add(this.button336);
            this.groupBox21.Controls.Add(this.button320);
            this.groupBox21.Controls.Add(this.button304);
            this.groupBox21.Controls.Add(this.button288);
            this.groupBox21.Controls.Add(this.button272);
            this.groupBox21.Controls.Add(this.btnTotalShiftC);
            this.groupBox21.Location = new System.Drawing.Point(1581, 47);
            this.groupBox21.Name = "groupBox21";
            this.groupBox21.Size = new System.Drawing.Size(84, 425);
            this.groupBox21.TabIndex = 12;
            this.groupBox21.TabStop = false;
            // 
            // button352
            // 
            this.button352.Location = new System.Drawing.Point(6, 291);
            this.button352.Name = "button352";
            this.button352.Size = new System.Drawing.Size(78, 35);
            this.button352.TabIndex = 27;
            this.button352.Text = "9";
            this.button352.UseVisualStyleBackColor = true;
            // 
            // button336
            // 
            this.button336.Location = new System.Drawing.Point(6, 250);
            this.button336.Name = "button336";
            this.button336.Size = new System.Drawing.Size(78, 35);
            this.button336.TabIndex = 26;
            this.button336.Text = "9";
            this.button336.UseVisualStyleBackColor = true;
            // 
            // button320
            // 
            this.button320.Location = new System.Drawing.Point(6, 209);
            this.button320.Name = "button320";
            this.button320.Size = new System.Drawing.Size(78, 35);
            this.button320.TabIndex = 25;
            this.button320.Text = "9";
            this.button320.UseVisualStyleBackColor = true;
            // 
            // button304
            // 
            this.button304.Location = new System.Drawing.Point(3, 168);
            this.button304.Name = "button304";
            this.button304.Size = new System.Drawing.Size(78, 35);
            this.button304.TabIndex = 24;
            this.button304.Text = "9";
            this.button304.UseVisualStyleBackColor = true;
            // 
            // button288
            // 
            this.button288.Location = new System.Drawing.Point(6, 128);
            this.button288.Name = "button288";
            this.button288.Size = new System.Drawing.Size(78, 35);
            this.button288.TabIndex = 23;
            this.button288.Text = "9";
            this.button288.UseVisualStyleBackColor = true;
            // 
            // button272
            // 
            this.button272.Location = new System.Drawing.Point(6, 86);
            this.button272.Name = "button272";
            this.button272.Size = new System.Drawing.Size(78, 35);
            this.button272.TabIndex = 22;
            this.button272.Text = "9";
            this.button272.UseVisualStyleBackColor = true;
            // 
            // btnTotalShiftC
            // 
            this.btnTotalShiftC.BackColor = System.Drawing.Color.Black;
            this.btnTotalShiftC.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnTotalShiftC.ForeColor = System.Drawing.Color.White;
            this.btnTotalShiftC.Location = new System.Drawing.Point(6, 10);
            this.btnTotalShiftC.Name = "btnTotalShiftC";
            this.btnTotalShiftC.Size = new System.Drawing.Size(78, 60);
            this.btnTotalShiftC.TabIndex = 5;
            this.btnTotalShiftC.Text = "TOTAL";
            this.btnTotalShiftC.UseVisualStyleBackColor = false;
            // 
            // groupBox14
            // 
            this.groupBox14.Controls.Add(this.panel98);
            this.groupBox14.Controls.Add(this.panel94);
            this.groupBox14.Controls.Add(this.panel90);
            this.groupBox14.Controls.Add(this.panel86);
            this.groupBox14.Controls.Add(this.panel82);
            this.groupBox14.Controls.Add(this.panel78);
            this.groupBox14.Controls.Add(this.panel74);
            this.groupBox14.Controls.Add(this.panel70);
            this.groupBox14.Controls.Add(this.btnBissCumlativeShiftC);
            this.groupBox14.Controls.Add(this.btnBissTotalShiftC);
            this.groupBox14.Controls.Add(this.btnBissShiftC);
            this.groupBox14.Controls.Add(this.btnBissSugarShiftC);
            this.groupBox14.Location = new System.Drawing.Point(1272, 47);
            this.groupBox14.Name = "groupBox14";
            this.groupBox14.Size = new System.Drawing.Size(291, 425);
            this.groupBox14.TabIndex = 9;
            this.groupBox14.TabStop = false;
            // 
            // panel98
            // 
            this.panel98.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel98.Controls.Add(this.button383);
            this.panel98.Controls.Add(this.button382);
            this.panel98.Controls.Add(this.button381);
            this.panel98.Location = new System.Drawing.Point(6, 373);
            this.panel98.Name = "panel98";
            this.panel98.Size = new System.Drawing.Size(265, 35);
            this.panel98.TabIndex = 31;
            // 
            // panel94
            // 
            this.panel94.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel94.Controls.Add(this.button367);
            this.panel94.Controls.Add(this.button366);
            this.panel94.Controls.Add(this.button365);
            this.panel94.Location = new System.Drawing.Point(6, 332);
            this.panel94.Name = "panel94";
            this.panel94.Size = new System.Drawing.Size(265, 35);
            this.panel94.TabIndex = 30;
            // 
            // panel90
            // 
            this.panel90.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel90.Controls.Add(this.button351);
            this.panel90.Controls.Add(this.button350);
            this.panel90.Controls.Add(this.button349);
            this.panel90.Location = new System.Drawing.Point(6, 291);
            this.panel90.Name = "panel90";
            this.panel90.Size = new System.Drawing.Size(265, 35);
            this.panel90.TabIndex = 29;
            // 
            // button351
            // 
            this.button351.BackColor = System.Drawing.Color.Aqua;
            this.button351.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button351.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button351.Location = new System.Drawing.Point(179, 3);
            this.button351.Name = "button351";
            this.button351.Size = new System.Drawing.Size(82, 26);
            this.button351.TabIndex = 107;
            this.button351.Text = "button351";
            this.button351.UseVisualStyleBackColor = false;
            // 
            // button350
            // 
            this.button350.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.button350.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button350.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button350.Location = new System.Drawing.Point(91, 3);
            this.button350.Name = "button350";
            this.button350.Size = new System.Drawing.Size(82, 26);
            this.button350.TabIndex = 106;
            this.button350.Text = "button350";
            this.button350.UseVisualStyleBackColor = false;
            // 
            // button349
            // 
            this.button349.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button349.Location = new System.Drawing.Point(3, 3);
            this.button349.Name = "button349";
            this.button349.Size = new System.Drawing.Size(82, 26);
            this.button349.TabIndex = 105;
            this.button349.Text = "button349";
            this.button349.UseVisualStyleBackColor = true;
            // 
            // panel86
            // 
            this.panel86.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel86.Controls.Add(this.button335);
            this.panel86.Controls.Add(this.button334);
            this.panel86.Controls.Add(this.button333);
            this.panel86.Location = new System.Drawing.Point(6, 250);
            this.panel86.Name = "panel86";
            this.panel86.Size = new System.Drawing.Size(265, 35);
            this.panel86.TabIndex = 28;
            // 
            // button335
            // 
            this.button335.BackColor = System.Drawing.Color.Aqua;
            this.button335.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button335.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button335.Location = new System.Drawing.Point(179, 4);
            this.button335.Name = "button335";
            this.button335.Size = new System.Drawing.Size(82, 26);
            this.button335.TabIndex = 102;
            this.button335.Text = "button335";
            this.button335.UseVisualStyleBackColor = false;
            // 
            // button334
            // 
            this.button334.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.button334.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button334.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button334.Location = new System.Drawing.Point(91, 4);
            this.button334.Name = "button334";
            this.button334.Size = new System.Drawing.Size(82, 26);
            this.button334.TabIndex = 101;
            this.button334.Text = "button334";
            this.button334.UseVisualStyleBackColor = false;
            // 
            // button333
            // 
            this.button333.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button333.Location = new System.Drawing.Point(3, 4);
            this.button333.Name = "button333";
            this.button333.Size = new System.Drawing.Size(82, 26);
            this.button333.TabIndex = 100;
            this.button333.Text = "button333";
            this.button333.UseVisualStyleBackColor = true;
            // 
            // panel82
            // 
            this.panel82.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel82.Controls.Add(this.button319);
            this.panel82.Controls.Add(this.button318);
            this.panel82.Controls.Add(this.button317);
            this.panel82.Location = new System.Drawing.Point(6, 209);
            this.panel82.Name = "panel82";
            this.panel82.Size = new System.Drawing.Size(265, 35);
            this.panel82.TabIndex = 27;
            // 
            // button319
            // 
            this.button319.BackColor = System.Drawing.Color.Aqua;
            this.button319.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button319.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button319.Location = new System.Drawing.Point(179, 3);
            this.button319.Name = "button319";
            this.button319.Size = new System.Drawing.Size(82, 26);
            this.button319.TabIndex = 94;
            this.button319.Text = "button319";
            this.button319.UseVisualStyleBackColor = false;
            // 
            // button318
            // 
            this.button318.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.button318.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button318.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button318.Location = new System.Drawing.Point(91, 3);
            this.button318.Name = "button318";
            this.button318.Size = new System.Drawing.Size(82, 26);
            this.button318.TabIndex = 93;
            this.button318.Text = "button318";
            this.button318.UseVisualStyleBackColor = false;
            // 
            // button317
            // 
            this.button317.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button317.Location = new System.Drawing.Point(3, 3);
            this.button317.Name = "button317";
            this.button317.Size = new System.Drawing.Size(82, 26);
            this.button317.TabIndex = 92;
            this.button317.Text = "button317";
            this.button317.UseVisualStyleBackColor = true;
            // 
            // panel78
            // 
            this.panel78.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel78.Controls.Add(this.button303);
            this.panel78.Controls.Add(this.button302);
            this.panel78.Controls.Add(this.button301);
            this.panel78.Location = new System.Drawing.Point(6, 168);
            this.panel78.Name = "panel78";
            this.panel78.Size = new System.Drawing.Size(265, 35);
            this.panel78.TabIndex = 26;
            // 
            // button303
            // 
            this.button303.BackColor = System.Drawing.Color.Aqua;
            this.button303.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button303.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button303.Location = new System.Drawing.Point(179, 3);
            this.button303.Name = "button303";
            this.button303.Size = new System.Drawing.Size(82, 26);
            this.button303.TabIndex = 102;
            this.button303.Text = "button303";
            this.button303.UseVisualStyleBackColor = false;
            // 
            // button302
            // 
            this.button302.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.button302.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button302.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button302.Location = new System.Drawing.Point(91, 3);
            this.button302.Name = "button302";
            this.button302.Size = new System.Drawing.Size(82, 26);
            this.button302.TabIndex = 101;
            this.button302.Text = "button302";
            this.button302.UseVisualStyleBackColor = false;
            // 
            // button301
            // 
            this.button301.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button301.Location = new System.Drawing.Point(3, 3);
            this.button301.Name = "button301";
            this.button301.Size = new System.Drawing.Size(82, 26);
            this.button301.TabIndex = 100;
            this.button301.Text = "button301";
            this.button301.UseVisualStyleBackColor = true;
            // 
            // panel74
            // 
            this.panel74.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel74.Controls.Add(this.button287);
            this.panel74.Controls.Add(this.button286);
            this.panel74.Controls.Add(this.button285);
            this.panel74.Location = new System.Drawing.Point(6, 127);
            this.panel74.Name = "panel74";
            this.panel74.Size = new System.Drawing.Size(265, 35);
            this.panel74.TabIndex = 25;
            // 
            // button287
            // 
            this.button287.BackColor = System.Drawing.Color.Aqua;
            this.button287.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button287.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button287.Location = new System.Drawing.Point(179, 4);
            this.button287.Name = "button287";
            this.button287.Size = new System.Drawing.Size(82, 26);
            this.button287.TabIndex = 98;
            this.button287.Text = "button287";
            this.button287.UseVisualStyleBackColor = false;
            // 
            // button286
            // 
            this.button286.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.button286.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button286.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button286.Location = new System.Drawing.Point(91, 4);
            this.button286.Name = "button286";
            this.button286.Size = new System.Drawing.Size(82, 26);
            this.button286.TabIndex = 97;
            this.button286.Text = "button286";
            this.button286.UseVisualStyleBackColor = false;
            // 
            // button285
            // 
            this.button285.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button285.Location = new System.Drawing.Point(3, 4);
            this.button285.Name = "button285";
            this.button285.Size = new System.Drawing.Size(82, 26);
            this.button285.TabIndex = 96;
            this.button285.Text = "button285";
            this.button285.UseVisualStyleBackColor = true;
            // 
            // panel70
            // 
            this.panel70.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel70.Controls.Add(this.button271);
            this.panel70.Controls.Add(this.button270);
            this.panel70.Controls.Add(this.button269);
            this.panel70.Location = new System.Drawing.Point(6, 86);
            this.panel70.Name = "panel70";
            this.panel70.Size = new System.Drawing.Size(265, 35);
            this.panel70.TabIndex = 24;
            // 
            // button271
            // 
            this.button271.BackColor = System.Drawing.Color.Aqua;
            this.button271.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button271.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button271.Location = new System.Drawing.Point(179, 3);
            this.button271.Name = "button271";
            this.button271.Size = new System.Drawing.Size(82, 26);
            this.button271.TabIndex = 94;
            this.button271.Text = "button271";
            this.button271.UseVisualStyleBackColor = false;
            // 
            // button270
            // 
            this.button270.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.button270.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button270.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button270.Location = new System.Drawing.Point(91, 3);
            this.button270.Name = "button270";
            this.button270.Size = new System.Drawing.Size(82, 26);
            this.button270.TabIndex = 93;
            this.button270.Text = "button270";
            this.button270.UseVisualStyleBackColor = false;
            // 
            // button269
            // 
            this.button269.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button269.Location = new System.Drawing.Point(3, 3);
            this.button269.Name = "button269";
            this.button269.Size = new System.Drawing.Size(82, 26);
            this.button269.TabIndex = 92;
            this.button269.Text = "button269";
            this.button269.UseVisualStyleBackColor = true;
            // 
            // btnBissCumlativeShiftC
            // 
            this.btnBissCumlativeShiftC.BackColor = System.Drawing.Color.Black;
            this.btnBissCumlativeShiftC.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnBissCumlativeShiftC.ForeColor = System.Drawing.Color.White;
            this.btnBissCumlativeShiftC.Location = new System.Drawing.Point(196, 50);
            this.btnBissCumlativeShiftC.Name = "btnBissCumlativeShiftC";
            this.btnBissCumlativeShiftC.Size = new System.Drawing.Size(83, 30);
            this.btnBissCumlativeShiftC.TabIndex = 4;
            this.btnBissCumlativeShiftC.Text = "H..";
            this.btnBissCumlativeShiftC.UseVisualStyleBackColor = false;
            // 
            // btnBissTotalShiftC
            // 
            this.btnBissTotalShiftC.BackColor = System.Drawing.Color.Black;
            this.btnBissTotalShiftC.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnBissTotalShiftC.ForeColor = System.Drawing.Color.White;
            this.btnBissTotalShiftC.Location = new System.Drawing.Point(107, 50);
            this.btnBissTotalShiftC.Name = "btnBissTotalShiftC";
            this.btnBissTotalShiftC.Size = new System.Drawing.Size(83, 30);
            this.btnBissTotalShiftC.TabIndex = 3;
            this.btnBissTotalShiftC.Text = "TOTAL";
            this.btnBissTotalShiftC.UseVisualStyleBackColor = false;
            // 
            // btnBissShiftC
            // 
            this.btnBissShiftC.BackColor = System.Drawing.Color.Black;
            this.btnBissShiftC.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnBissShiftC.ForeColor = System.Drawing.Color.White;
            this.btnBissShiftC.Location = new System.Drawing.Point(6, 50);
            this.btnBissShiftC.Name = "btnBissShiftC";
            this.btnBissShiftC.Size = new System.Drawing.Size(83, 30);
            this.btnBissShiftC.TabIndex = 1;
            this.btnBissShiftC.Text = "BISS";
            this.btnBissShiftC.UseVisualStyleBackColor = false;
            // 
            // btnBissSugarShiftC
            // 
            this.btnBissSugarShiftC.BackColor = System.Drawing.Color.Black;
            this.btnBissSugarShiftC.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnBissSugarShiftC.ForeColor = System.Drawing.Color.White;
            this.btnBissSugarShiftC.Location = new System.Drawing.Point(4, 10);
            this.btnBissSugarShiftC.Name = "btnBissSugarShiftC";
            this.btnBissSugarShiftC.Size = new System.Drawing.Size(273, 34);
            this.btnBissSugarShiftC.TabIndex = 0;
            this.btnBissSugarShiftC.Text = "BISS SUGAR";
            this.btnBissSugarShiftC.UseVisualStyleBackColor = false;
            // 
            // groupBox15
            // 
            this.groupBox15.Controls.Add(this.panel97);
            this.groupBox15.Controls.Add(this.panel93);
            this.groupBox15.Controls.Add(this.panel89);
            this.groupBox15.Controls.Add(this.panel85);
            this.groupBox15.Controls.Add(this.panel81);
            this.groupBox15.Controls.Add(this.panel77);
            this.groupBox15.Controls.Add(this.panel73);
            this.groupBox15.Controls.Add(this.panel69);
            this.groupBox15.Controls.Add(this.btnSCumlativeShiftC);
            this.groupBox15.Controls.Add(this.btnSTotalShiftC);
            this.groupBox15.Controls.Add(this.btnS30ShiftC);
            this.groupBox15.Controls.Add(this.btnS31ShiftC);
            this.groupBox15.Controls.Add(this.btnSSugarShiftC);
            this.groupBox15.Location = new System.Drawing.Point(867, 52);
            this.groupBox15.Name = "groupBox15";
            this.groupBox15.Size = new System.Drawing.Size(383, 425);
            this.groupBox15.TabIndex = 8;
            this.groupBox15.TabStop = false;
            // 
            // panel97
            // 
            this.panel97.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel97.Controls.Add(this.button380);
            this.panel97.Controls.Add(this.button379);
            this.panel97.Controls.Add(this.button378);
            this.panel97.Controls.Add(this.button377);
            this.panel97.Location = new System.Drawing.Point(6, 373);
            this.panel97.Name = "panel97";
            this.panel97.Size = new System.Drawing.Size(360, 35);
            this.panel97.TabIndex = 33;
            // 
            // panel93
            // 
            this.panel93.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel93.Controls.Add(this.button364);
            this.panel93.Controls.Add(this.button363);
            this.panel93.Controls.Add(this.button362);
            this.panel93.Controls.Add(this.button361);
            this.panel93.Location = new System.Drawing.Point(6, 332);
            this.panel93.Name = "panel93";
            this.panel93.Size = new System.Drawing.Size(360, 35);
            this.panel93.TabIndex = 32;
            // 
            // panel89
            // 
            this.panel89.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel89.Controls.Add(this.button348);
            this.panel89.Controls.Add(this.button347);
            this.panel89.Controls.Add(this.button346);
            this.panel89.Controls.Add(this.button345);
            this.panel89.Location = new System.Drawing.Point(6, 291);
            this.panel89.Name = "panel89";
            this.panel89.Size = new System.Drawing.Size(360, 35);
            this.panel89.TabIndex = 31;
            // 
            // button348
            // 
            this.button348.BackColor = System.Drawing.Color.Aqua;
            this.button348.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button348.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button348.Location = new System.Drawing.Point(271, 3);
            this.button348.Name = "button348";
            this.button348.Size = new System.Drawing.Size(82, 26);
            this.button348.TabIndex = 104;
            this.button348.Text = "button348";
            this.button348.UseVisualStyleBackColor = false;
            // 
            // button347
            // 
            this.button347.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.button347.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button347.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button347.Location = new System.Drawing.Point(181, 3);
            this.button347.Name = "button347";
            this.button347.Size = new System.Drawing.Size(82, 26);
            this.button347.TabIndex = 103;
            this.button347.Text = "button347";
            this.button347.UseVisualStyleBackColor = false;
            // 
            // button346
            // 
            this.button346.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button346.Location = new System.Drawing.Point(93, 3);
            this.button346.Name = "button346";
            this.button346.Size = new System.Drawing.Size(82, 26);
            this.button346.TabIndex = 102;
            this.button346.Text = "button346";
            this.button346.UseVisualStyleBackColor = true;
            // 
            // button345
            // 
            this.button345.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button345.Location = new System.Drawing.Point(5, 3);
            this.button345.Name = "button345";
            this.button345.Size = new System.Drawing.Size(82, 26);
            this.button345.TabIndex = 101;
            this.button345.Text = "button345";
            this.button345.UseVisualStyleBackColor = true;
            // 
            // panel85
            // 
            this.panel85.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel85.Controls.Add(this.button332);
            this.panel85.Controls.Add(this.button331);
            this.panel85.Controls.Add(this.button330);
            this.panel85.Controls.Add(this.button329);
            this.panel85.Location = new System.Drawing.Point(6, 250);
            this.panel85.Name = "panel85";
            this.panel85.Size = new System.Drawing.Size(360, 35);
            this.panel85.TabIndex = 30;
            // 
            // button332
            // 
            this.button332.BackColor = System.Drawing.Color.Aqua;
            this.button332.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button332.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button332.Location = new System.Drawing.Point(271, 4);
            this.button332.Name = "button332";
            this.button332.Size = new System.Drawing.Size(82, 26);
            this.button332.TabIndex = 99;
            this.button332.Text = "button332";
            this.button332.UseVisualStyleBackColor = false;
            // 
            // button331
            // 
            this.button331.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.button331.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button331.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button331.Location = new System.Drawing.Point(181, 4);
            this.button331.Name = "button331";
            this.button331.Size = new System.Drawing.Size(82, 26);
            this.button331.TabIndex = 98;
            this.button331.Text = "button331";
            this.button331.UseVisualStyleBackColor = false;
            // 
            // button330
            // 
            this.button330.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button330.Location = new System.Drawing.Point(93, 4);
            this.button330.Name = "button330";
            this.button330.Size = new System.Drawing.Size(82, 26);
            this.button330.TabIndex = 97;
            this.button330.Text = "button330";
            this.button330.UseVisualStyleBackColor = true;
            // 
            // button329
            // 
            this.button329.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button329.Location = new System.Drawing.Point(5, 4);
            this.button329.Name = "button329";
            this.button329.Size = new System.Drawing.Size(82, 26);
            this.button329.TabIndex = 96;
            this.button329.Text = "button329";
            this.button329.UseVisualStyleBackColor = true;
            // 
            // panel81
            // 
            this.panel81.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel81.Controls.Add(this.button316);
            this.panel81.Controls.Add(this.button315);
            this.panel81.Controls.Add(this.button314);
            this.panel81.Controls.Add(this.button313);
            this.panel81.Location = new System.Drawing.Point(6, 209);
            this.panel81.Name = "panel81";
            this.panel81.Size = new System.Drawing.Size(360, 35);
            this.panel81.TabIndex = 29;
            // 
            // button316
            // 
            this.button316.BackColor = System.Drawing.Color.Aqua;
            this.button316.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button316.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button316.Location = new System.Drawing.Point(271, 3);
            this.button316.Name = "button316";
            this.button316.Size = new System.Drawing.Size(82, 26);
            this.button316.TabIndex = 99;
            this.button316.Text = "button316";
            this.button316.UseVisualStyleBackColor = false;
            // 
            // button315
            // 
            this.button315.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.button315.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button315.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button315.Location = new System.Drawing.Point(181, 3);
            this.button315.Name = "button315";
            this.button315.Size = new System.Drawing.Size(82, 26);
            this.button315.TabIndex = 98;
            this.button315.Text = "button315";
            this.button315.UseVisualStyleBackColor = false;
            // 
            // button314
            // 
            this.button314.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button314.Location = new System.Drawing.Point(93, 3);
            this.button314.Name = "button314";
            this.button314.Size = new System.Drawing.Size(82, 26);
            this.button314.TabIndex = 97;
            this.button314.Text = "button314";
            this.button314.UseVisualStyleBackColor = true;
            // 
            // button313
            // 
            this.button313.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button313.Location = new System.Drawing.Point(5, 3);
            this.button313.Name = "button313";
            this.button313.Size = new System.Drawing.Size(82, 26);
            this.button313.TabIndex = 96;
            this.button313.Text = "button313";
            this.button313.UseVisualStyleBackColor = true;
            // 
            // panel77
            // 
            this.panel77.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel77.Controls.Add(this.button300);
            this.panel77.Controls.Add(this.button299);
            this.panel77.Controls.Add(this.button298);
            this.panel77.Controls.Add(this.button297);
            this.panel77.Location = new System.Drawing.Point(6, 168);
            this.panel77.Name = "panel77";
            this.panel77.Size = new System.Drawing.Size(360, 35);
            this.panel77.TabIndex = 28;
            // 
            // button300
            // 
            this.button300.BackColor = System.Drawing.Color.Aqua;
            this.button300.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button300.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button300.Location = new System.Drawing.Point(271, 3);
            this.button300.Name = "button300";
            this.button300.Size = new System.Drawing.Size(82, 26);
            this.button300.TabIndex = 99;
            this.button300.Text = "button300";
            this.button300.UseVisualStyleBackColor = false;
            // 
            // button299
            // 
            this.button299.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.button299.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button299.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button299.Location = new System.Drawing.Point(181, 3);
            this.button299.Name = "button299";
            this.button299.Size = new System.Drawing.Size(82, 26);
            this.button299.TabIndex = 98;
            this.button299.Text = "button299";
            this.button299.UseVisualStyleBackColor = false;
            // 
            // button298
            // 
            this.button298.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button298.Location = new System.Drawing.Point(93, 3);
            this.button298.Name = "button298";
            this.button298.Size = new System.Drawing.Size(82, 26);
            this.button298.TabIndex = 97;
            this.button298.Text = "button298";
            this.button298.UseVisualStyleBackColor = true;
            // 
            // button297
            // 
            this.button297.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button297.Location = new System.Drawing.Point(5, 3);
            this.button297.Name = "button297";
            this.button297.Size = new System.Drawing.Size(82, 26);
            this.button297.TabIndex = 96;
            this.button297.Text = "button297";
            this.button297.UseVisualStyleBackColor = true;
            // 
            // panel73
            // 
            this.panel73.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel73.Controls.Add(this.button284);
            this.panel73.Controls.Add(this.button283);
            this.panel73.Controls.Add(this.button282);
            this.panel73.Controls.Add(this.button281);
            this.panel73.Location = new System.Drawing.Point(6, 127);
            this.panel73.Name = "panel73";
            this.panel73.Size = new System.Drawing.Size(360, 35);
            this.panel73.TabIndex = 27;
            // 
            // button284
            // 
            this.button284.BackColor = System.Drawing.Color.Aqua;
            this.button284.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button284.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button284.Location = new System.Drawing.Point(271, 4);
            this.button284.Name = "button284";
            this.button284.Size = new System.Drawing.Size(82, 26);
            this.button284.TabIndex = 95;
            this.button284.Text = "button284";
            this.button284.UseVisualStyleBackColor = false;
            // 
            // button283
            // 
            this.button283.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.button283.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button283.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button283.Location = new System.Drawing.Point(181, 4);
            this.button283.Name = "button283";
            this.button283.Size = new System.Drawing.Size(82, 26);
            this.button283.TabIndex = 94;
            this.button283.Text = "button283";
            this.button283.UseVisualStyleBackColor = false;
            // 
            // button282
            // 
            this.button282.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button282.Location = new System.Drawing.Point(93, 4);
            this.button282.Name = "button282";
            this.button282.Size = new System.Drawing.Size(82, 26);
            this.button282.TabIndex = 93;
            this.button282.Text = "button282";
            this.button282.UseVisualStyleBackColor = true;
            // 
            // button281
            // 
            this.button281.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button281.Location = new System.Drawing.Point(5, 4);
            this.button281.Name = "button281";
            this.button281.Size = new System.Drawing.Size(82, 26);
            this.button281.TabIndex = 92;
            this.button281.Text = "button281";
            this.button281.UseVisualStyleBackColor = true;
            // 
            // panel69
            // 
            this.panel69.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel69.Controls.Add(this.button268);
            this.panel69.Controls.Add(this.button267);
            this.panel69.Controls.Add(this.button266);
            this.panel69.Controls.Add(this.button265);
            this.panel69.Location = new System.Drawing.Point(6, 86);
            this.panel69.Name = "panel69";
            this.panel69.Size = new System.Drawing.Size(360, 35);
            this.panel69.TabIndex = 26;
            // 
            // button268
            // 
            this.button268.BackColor = System.Drawing.Color.Aqua;
            this.button268.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button268.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button268.Location = new System.Drawing.Point(271, 3);
            this.button268.Name = "button268";
            this.button268.Size = new System.Drawing.Size(82, 26);
            this.button268.TabIndex = 91;
            this.button268.Text = "button268";
            this.button268.UseVisualStyleBackColor = false;
            // 
            // button267
            // 
            this.button267.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.button267.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button267.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button267.Location = new System.Drawing.Point(181, 3);
            this.button267.Name = "button267";
            this.button267.Size = new System.Drawing.Size(82, 26);
            this.button267.TabIndex = 90;
            this.button267.Text = "button267";
            this.button267.UseVisualStyleBackColor = false;
            // 
            // button266
            // 
            this.button266.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button266.Location = new System.Drawing.Point(93, 3);
            this.button266.Name = "button266";
            this.button266.Size = new System.Drawing.Size(82, 26);
            this.button266.TabIndex = 89;
            this.button266.Text = "button266";
            this.button266.UseVisualStyleBackColor = true;
            // 
            // button265
            // 
            this.button265.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button265.Location = new System.Drawing.Point(5, 3);
            this.button265.Name = "button265";
            this.button265.Size = new System.Drawing.Size(82, 26);
            this.button265.TabIndex = 88;
            this.button265.Text = "button265";
            this.button265.UseVisualStyleBackColor = true;
            // 
            // btnSCumlativeShiftC
            // 
            this.btnSCumlativeShiftC.BackColor = System.Drawing.Color.Black;
            this.btnSCumlativeShiftC.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSCumlativeShiftC.ForeColor = System.Drawing.Color.White;
            this.btnSCumlativeShiftC.Location = new System.Drawing.Point(281, 50);
            this.btnSCumlativeShiftC.Name = "btnSCumlativeShiftC";
            this.btnSCumlativeShiftC.Size = new System.Drawing.Size(83, 30);
            this.btnSCumlativeShiftC.TabIndex = 4;
            this.btnSCumlativeShiftC.Text = "H..";
            this.btnSCumlativeShiftC.UseVisualStyleBackColor = false;
            // 
            // btnSTotalShiftC
            // 
            this.btnSTotalShiftC.BackColor = System.Drawing.Color.Black;
            this.btnSTotalShiftC.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSTotalShiftC.ForeColor = System.Drawing.Color.White;
            this.btnSTotalShiftC.Location = new System.Drawing.Point(191, 50);
            this.btnSTotalShiftC.Name = "btnSTotalShiftC";
            this.btnSTotalShiftC.Size = new System.Drawing.Size(83, 30);
            this.btnSTotalShiftC.TabIndex = 3;
            this.btnSTotalShiftC.Text = "TOTAL";
            this.btnSTotalShiftC.UseVisualStyleBackColor = false;
            // 
            // btnS30ShiftC
            // 
            this.btnS30ShiftC.BackColor = System.Drawing.Color.Black;
            this.btnS30ShiftC.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnS30ShiftC.ForeColor = System.Drawing.Color.White;
            this.btnS30ShiftC.Location = new System.Drawing.Point(102, 50);
            this.btnS30ShiftC.Name = "btnS30ShiftC";
            this.btnS30ShiftC.Size = new System.Drawing.Size(83, 30);
            this.btnS30ShiftC.TabIndex = 2;
            this.btnS30ShiftC.Text = "S-30";
            this.btnS30ShiftC.UseVisualStyleBackColor = false;
            // 
            // btnS31ShiftC
            // 
            this.btnS31ShiftC.BackColor = System.Drawing.Color.Black;
            this.btnS31ShiftC.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnS31ShiftC.ForeColor = System.Drawing.Color.White;
            this.btnS31ShiftC.Location = new System.Drawing.Point(6, 50);
            this.btnS31ShiftC.Name = "btnS31ShiftC";
            this.btnS31ShiftC.Size = new System.Drawing.Size(83, 30);
            this.btnS31ShiftC.TabIndex = 1;
            this.btnS31ShiftC.Text = "S-31";
            this.btnS31ShiftC.UseVisualStyleBackColor = false;
            // 
            // btnSSugarShiftC
            // 
            this.btnSSugarShiftC.BackColor = System.Drawing.Color.Black;
            this.btnSSugarShiftC.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSSugarShiftC.ForeColor = System.Drawing.Color.White;
            this.btnSSugarShiftC.Location = new System.Drawing.Point(4, 10);
            this.btnSSugarShiftC.Name = "btnSSugarShiftC";
            this.btnSSugarShiftC.Size = new System.Drawing.Size(357, 34);
            this.btnSSugarShiftC.TabIndex = 0;
            this.btnSSugarShiftC.Text = "SMALL SUGAR";
            this.btnSSugarShiftC.UseVisualStyleBackColor = false;
            // 
            // groupBox16
            // 
            this.groupBox16.Controls.Add(this.panel96);
            this.groupBox16.Controls.Add(this.panel92);
            this.groupBox16.Controls.Add(this.panel88);
            this.groupBox16.Controls.Add(this.panel84);
            this.groupBox16.Controls.Add(this.panel80);
            this.groupBox16.Controls.Add(this.panel76);
            this.groupBox16.Controls.Add(this.panel72);
            this.groupBox16.Controls.Add(this.panel68);
            this.groupBox16.Controls.Add(this.btnMCumlativeShiftC);
            this.groupBox16.Controls.Add(this.btnMTotalShiftC);
            this.groupBox16.Controls.Add(this.btnM30ShiftC);
            this.groupBox16.Controls.Add(this.btnM31ShiftC);
            this.groupBox16.Controls.Add(this.btnMSugarShiftC);
            this.groupBox16.Location = new System.Drawing.Point(484, 52);
            this.groupBox16.Name = "groupBox16";
            this.groupBox16.Size = new System.Drawing.Size(383, 425);
            this.groupBox16.TabIndex = 7;
            this.groupBox16.TabStop = false;
            // 
            // panel96
            // 
            this.panel96.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel96.Controls.Add(this.button376);
            this.panel96.Controls.Add(this.button375);
            this.panel96.Controls.Add(this.button374);
            this.panel96.Controls.Add(this.button373);
            this.panel96.Location = new System.Drawing.Point(7, 371);
            this.panel96.Name = "panel96";
            this.panel96.Size = new System.Drawing.Size(360, 35);
            this.panel96.TabIndex = 33;
            // 
            // panel92
            // 
            this.panel92.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel92.Controls.Add(this.button360);
            this.panel92.Controls.Add(this.button359);
            this.panel92.Controls.Add(this.button358);
            this.panel92.Controls.Add(this.button357);
            this.panel92.Location = new System.Drawing.Point(7, 332);
            this.panel92.Name = "panel92";
            this.panel92.Size = new System.Drawing.Size(360, 35);
            this.panel92.TabIndex = 32;
            // 
            // panel88
            // 
            this.panel88.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel88.Controls.Add(this.button344);
            this.panel88.Controls.Add(this.button343);
            this.panel88.Controls.Add(this.button342);
            this.panel88.Controls.Add(this.button341);
            this.panel88.Location = new System.Drawing.Point(7, 291);
            this.panel88.Name = "panel88";
            this.panel88.Size = new System.Drawing.Size(360, 35);
            this.panel88.TabIndex = 31;
            // 
            // button344
            // 
            this.button344.BackColor = System.Drawing.Color.Aqua;
            this.button344.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button344.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button344.Location = new System.Drawing.Point(273, 3);
            this.button344.Name = "button344";
            this.button344.Size = new System.Drawing.Size(82, 26);
            this.button344.TabIndex = 100;
            this.button344.Text = "button344";
            this.button344.UseVisualStyleBackColor = false;
            // 
            // button343
            // 
            this.button343.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.button343.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button343.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button343.Location = new System.Drawing.Point(185, 3);
            this.button343.Name = "button343";
            this.button343.Size = new System.Drawing.Size(82, 26);
            this.button343.TabIndex = 99;
            this.button343.Text = "button343";
            this.button343.UseVisualStyleBackColor = false;
            // 
            // button342
            // 
            this.button342.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button342.Location = new System.Drawing.Point(93, 3);
            this.button342.Name = "button342";
            this.button342.Size = new System.Drawing.Size(82, 26);
            this.button342.TabIndex = 98;
            this.button342.Text = "button342";
            this.button342.UseVisualStyleBackColor = true;
            // 
            // button341
            // 
            this.button341.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button341.Location = new System.Drawing.Point(3, 3);
            this.button341.Name = "button341";
            this.button341.Size = new System.Drawing.Size(82, 26);
            this.button341.TabIndex = 97;
            this.button341.Text = "button341";
            this.button341.UseVisualStyleBackColor = true;
            // 
            // panel84
            // 
            this.panel84.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel84.Controls.Add(this.button328);
            this.panel84.Controls.Add(this.button327);
            this.panel84.Controls.Add(this.button326);
            this.panel84.Controls.Add(this.button325);
            this.panel84.Location = new System.Drawing.Point(7, 249);
            this.panel84.Name = "panel84";
            this.panel84.Size = new System.Drawing.Size(360, 35);
            this.panel84.TabIndex = 30;
            // 
            // button328
            // 
            this.button328.BackColor = System.Drawing.Color.Aqua;
            this.button328.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button328.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button328.Location = new System.Drawing.Point(273, 4);
            this.button328.Name = "button328";
            this.button328.Size = new System.Drawing.Size(82, 26);
            this.button328.TabIndex = 103;
            this.button328.Text = "button328";
            this.button328.UseVisualStyleBackColor = false;
            // 
            // button327
            // 
            this.button327.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.button327.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button327.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button327.Location = new System.Drawing.Point(185, 4);
            this.button327.Name = "button327";
            this.button327.Size = new System.Drawing.Size(82, 26);
            this.button327.TabIndex = 102;
            this.button327.Text = "button327";
            this.button327.UseVisualStyleBackColor = false;
            // 
            // button326
            // 
            this.button326.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button326.Location = new System.Drawing.Point(93, 4);
            this.button326.Name = "button326";
            this.button326.Size = new System.Drawing.Size(82, 26);
            this.button326.TabIndex = 101;
            this.button326.Text = "button326";
            this.button326.UseVisualStyleBackColor = true;
            // 
            // button325
            // 
            this.button325.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button325.Location = new System.Drawing.Point(3, 4);
            this.button325.Name = "button325";
            this.button325.Size = new System.Drawing.Size(82, 26);
            this.button325.TabIndex = 100;
            this.button325.Text = "button325";
            this.button325.UseVisualStyleBackColor = true;
            // 
            // panel80
            // 
            this.panel80.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel80.Controls.Add(this.button312);
            this.panel80.Controls.Add(this.button311);
            this.panel80.Controls.Add(this.button310);
            this.panel80.Controls.Add(this.button309);
            this.panel80.Location = new System.Drawing.Point(7, 209);
            this.panel80.Name = "panel80";
            this.panel80.Size = new System.Drawing.Size(360, 35);
            this.panel80.TabIndex = 29;
            // 
            // button312
            // 
            this.button312.BackColor = System.Drawing.Color.Aqua;
            this.button312.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button312.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button312.Location = new System.Drawing.Point(273, 3);
            this.button312.Name = "button312";
            this.button312.Size = new System.Drawing.Size(82, 26);
            this.button312.TabIndex = 95;
            this.button312.Text = "button312";
            this.button312.UseVisualStyleBackColor = false;
            // 
            // button311
            // 
            this.button311.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.button311.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button311.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button311.Location = new System.Drawing.Point(185, 3);
            this.button311.Name = "button311";
            this.button311.Size = new System.Drawing.Size(82, 26);
            this.button311.TabIndex = 94;
            this.button311.Text = "button311";
            this.button311.UseVisualStyleBackColor = false;
            // 
            // button310
            // 
            this.button310.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button310.Location = new System.Drawing.Point(93, 3);
            this.button310.Name = "button310";
            this.button310.Size = new System.Drawing.Size(82, 26);
            this.button310.TabIndex = 93;
            this.button310.Text = "button310";
            this.button310.UseVisualStyleBackColor = true;
            // 
            // button309
            // 
            this.button309.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button309.Location = new System.Drawing.Point(3, 3);
            this.button309.Name = "button309";
            this.button309.Size = new System.Drawing.Size(82, 26);
            this.button309.TabIndex = 92;
            this.button309.Text = "button309";
            this.button309.UseVisualStyleBackColor = true;
            // 
            // panel76
            // 
            this.panel76.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel76.Controls.Add(this.button296);
            this.panel76.Controls.Add(this.button295);
            this.panel76.Controls.Add(this.button294);
            this.panel76.Controls.Add(this.button293);
            this.panel76.Location = new System.Drawing.Point(7, 168);
            this.panel76.Name = "panel76";
            this.panel76.Size = new System.Drawing.Size(360, 35);
            this.panel76.TabIndex = 28;
            // 
            // button296
            // 
            this.button296.BackColor = System.Drawing.Color.Aqua;
            this.button296.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button296.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button296.Location = new System.Drawing.Point(273, 3);
            this.button296.Name = "button296";
            this.button296.Size = new System.Drawing.Size(82, 26);
            this.button296.TabIndex = 95;
            this.button296.Text = "button296";
            this.button296.UseVisualStyleBackColor = false;
            // 
            // button295
            // 
            this.button295.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.button295.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button295.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button295.Location = new System.Drawing.Point(185, 3);
            this.button295.Name = "button295";
            this.button295.Size = new System.Drawing.Size(82, 26);
            this.button295.TabIndex = 94;
            this.button295.Text = "button295";
            this.button295.UseVisualStyleBackColor = false;
            // 
            // button294
            // 
            this.button294.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button294.Location = new System.Drawing.Point(93, 3);
            this.button294.Name = "button294";
            this.button294.Size = new System.Drawing.Size(82, 26);
            this.button294.TabIndex = 93;
            this.button294.Text = "button294";
            this.button294.UseVisualStyleBackColor = true;
            // 
            // button293
            // 
            this.button293.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button293.Location = new System.Drawing.Point(3, 3);
            this.button293.Name = "button293";
            this.button293.Size = new System.Drawing.Size(82, 26);
            this.button293.TabIndex = 92;
            this.button293.Text = "button293";
            this.button293.UseVisualStyleBackColor = true;
            // 
            // panel72
            // 
            this.panel72.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel72.Controls.Add(this.button280);
            this.panel72.Controls.Add(this.button279);
            this.panel72.Controls.Add(this.button278);
            this.panel72.Controls.Add(this.button277);
            this.panel72.Location = new System.Drawing.Point(7, 127);
            this.panel72.Name = "panel72";
            this.panel72.Size = new System.Drawing.Size(360, 35);
            this.panel72.TabIndex = 27;
            // 
            // button280
            // 
            this.button280.BackColor = System.Drawing.Color.Aqua;
            this.button280.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button280.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button280.Location = new System.Drawing.Point(273, 4);
            this.button280.Name = "button280";
            this.button280.Size = new System.Drawing.Size(82, 26);
            this.button280.TabIndex = 91;
            this.button280.Text = "button280";
            this.button280.UseVisualStyleBackColor = false;
            // 
            // button279
            // 
            this.button279.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.button279.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button279.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button279.Location = new System.Drawing.Point(185, 4);
            this.button279.Name = "button279";
            this.button279.Size = new System.Drawing.Size(82, 26);
            this.button279.TabIndex = 90;
            this.button279.Text = "button279";
            this.button279.UseVisualStyleBackColor = false;
            // 
            // button278
            // 
            this.button278.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button278.Location = new System.Drawing.Point(93, 4);
            this.button278.Name = "button278";
            this.button278.Size = new System.Drawing.Size(82, 26);
            this.button278.TabIndex = 89;
            this.button278.Text = "button278";
            this.button278.UseVisualStyleBackColor = true;
            // 
            // button277
            // 
            this.button277.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button277.Location = new System.Drawing.Point(3, 4);
            this.button277.Name = "button277";
            this.button277.Size = new System.Drawing.Size(82, 26);
            this.button277.TabIndex = 88;
            this.button277.Text = "button277";
            this.button277.UseVisualStyleBackColor = true;
            // 
            // panel68
            // 
            this.panel68.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel68.Controls.Add(this.button264);
            this.panel68.Controls.Add(this.button263);
            this.panel68.Controls.Add(this.button262);
            this.panel68.Controls.Add(this.button261);
            this.panel68.Location = new System.Drawing.Point(7, 86);
            this.panel68.Name = "panel68";
            this.panel68.Size = new System.Drawing.Size(360, 35);
            this.panel68.TabIndex = 25;
            // 
            // button264
            // 
            this.button264.BackColor = System.Drawing.Color.Aqua;
            this.button264.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button264.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button264.Location = new System.Drawing.Point(273, 3);
            this.button264.Name = "button264";
            this.button264.Size = new System.Drawing.Size(82, 26);
            this.button264.TabIndex = 87;
            this.button264.Text = "button264";
            this.button264.UseVisualStyleBackColor = false;
            // 
            // button263
            // 
            this.button263.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.button263.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button263.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button263.Location = new System.Drawing.Point(185, 3);
            this.button263.Name = "button263";
            this.button263.Size = new System.Drawing.Size(82, 26);
            this.button263.TabIndex = 86;
            this.button263.Text = "button263";
            this.button263.UseVisualStyleBackColor = false;
            // 
            // button262
            // 
            this.button262.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button262.Location = new System.Drawing.Point(93, 3);
            this.button262.Name = "button262";
            this.button262.Size = new System.Drawing.Size(82, 26);
            this.button262.TabIndex = 85;
            this.button262.Text = "button262";
            this.button262.UseVisualStyleBackColor = true;
            // 
            // button261
            // 
            this.button261.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button261.Location = new System.Drawing.Point(3, 3);
            this.button261.Name = "button261";
            this.button261.Size = new System.Drawing.Size(82, 26);
            this.button261.TabIndex = 84;
            this.button261.Text = "button261";
            this.button261.UseVisualStyleBackColor = true;
            // 
            // btnMCumlativeShiftC
            // 
            this.btnMCumlativeShiftC.BackColor = System.Drawing.Color.Black;
            this.btnMCumlativeShiftC.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnMCumlativeShiftC.ForeColor = System.Drawing.Color.White;
            this.btnMCumlativeShiftC.Location = new System.Drawing.Point(278, 50);
            this.btnMCumlativeShiftC.Name = "btnMCumlativeShiftC";
            this.btnMCumlativeShiftC.Size = new System.Drawing.Size(83, 30);
            this.btnMCumlativeShiftC.TabIndex = 4;
            this.btnMCumlativeShiftC.Text = "H..";
            this.btnMCumlativeShiftC.UseVisualStyleBackColor = false;
            // 
            // btnMTotalShiftC
            // 
            this.btnMTotalShiftC.BackColor = System.Drawing.Color.Black;
            this.btnMTotalShiftC.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnMTotalShiftC.ForeColor = System.Drawing.Color.White;
            this.btnMTotalShiftC.Location = new System.Drawing.Point(185, 50);
            this.btnMTotalShiftC.Name = "btnMTotalShiftC";
            this.btnMTotalShiftC.Size = new System.Drawing.Size(83, 30);
            this.btnMTotalShiftC.TabIndex = 3;
            this.btnMTotalShiftC.Text = "TOTAL";
            this.btnMTotalShiftC.UseVisualStyleBackColor = false;
            // 
            // btnM30ShiftC
            // 
            this.btnM30ShiftC.BackColor = System.Drawing.Color.Black;
            this.btnM30ShiftC.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnM30ShiftC.ForeColor = System.Drawing.Color.White;
            this.btnM30ShiftC.Location = new System.Drawing.Point(99, 50);
            this.btnM30ShiftC.Name = "btnM30ShiftC";
            this.btnM30ShiftC.Size = new System.Drawing.Size(83, 30);
            this.btnM30ShiftC.TabIndex = 2;
            this.btnM30ShiftC.Text = "M-30";
            this.btnM30ShiftC.UseVisualStyleBackColor = false;
            // 
            // btnM31ShiftC
            // 
            this.btnM31ShiftC.BackColor = System.Drawing.Color.Black;
            this.btnM31ShiftC.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnM31ShiftC.ForeColor = System.Drawing.Color.White;
            this.btnM31ShiftC.Location = new System.Drawing.Point(6, 50);
            this.btnM31ShiftC.Name = "btnM31ShiftC";
            this.btnM31ShiftC.Size = new System.Drawing.Size(83, 30);
            this.btnM31ShiftC.TabIndex = 1;
            this.btnM31ShiftC.Text = "M-31";
            this.btnM31ShiftC.UseVisualStyleBackColor = false;
            // 
            // btnMSugarShiftC
            // 
            this.btnMSugarShiftC.BackColor = System.Drawing.Color.Black;
            this.btnMSugarShiftC.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnMSugarShiftC.ForeColor = System.Drawing.Color.White;
            this.btnMSugarShiftC.Location = new System.Drawing.Point(4, 10);
            this.btnMSugarShiftC.Name = "btnMSugarShiftC";
            this.btnMSugarShiftC.Size = new System.Drawing.Size(357, 34);
            this.btnMSugarShiftC.TabIndex = 0;
            this.btnMSugarShiftC.Text = "MEDIUM SUGAR";
            this.btnMSugarShiftC.UseVisualStyleBackColor = false;
            // 
            // groupBox17
            // 
            this.groupBox17.Controls.Add(this.btnTime1);
            this.groupBox17.Controls.Add(this.btnTime8);
            this.groupBox17.Controls.Add(this.btnTime7);
            this.groupBox17.Controls.Add(this.btnTime6);
            this.groupBox17.Controls.Add(this.btnTime5);
            this.groupBox17.Controls.Add(this.btnTime4);
            this.groupBox17.Controls.Add(this.btnTime3);
            this.groupBox17.Controls.Add(this.btnTime2);
            this.groupBox17.Controls.Add(this.btnHeaderTimeShiftC);
            this.groupBox17.Location = new System.Drawing.Point(16, 47);
            this.groupBox17.Name = "groupBox17";
            this.groupBox17.Size = new System.Drawing.Size(58, 425);
            this.groupBox17.TabIndex = 6;
            this.groupBox17.TabStop = false;
            // 
            // btnTime1
            // 
            this.btnTime1.Location = new System.Drawing.Point(4, 86);
            this.btnTime1.Name = "btnTime1";
            this.btnTime1.Size = new System.Drawing.Size(48, 35);
            this.btnTime1.TabIndex = 5;
            this.btnTime1.Text = "1";
            this.btnTime1.UseVisualStyleBackColor = true;
            // 
            // btnTime8
            // 
            this.btnTime8.Location = new System.Drawing.Point(5, 373);
            this.btnTime8.Name = "btnTime8";
            this.btnTime8.Size = new System.Drawing.Size(48, 35);
            this.btnTime8.TabIndex = 10;
            this.btnTime8.Text = "8";
            this.btnTime8.UseVisualStyleBackColor = true;
            // 
            // btnTime7
            // 
            this.btnTime7.Location = new System.Drawing.Point(6, 332);
            this.btnTime7.Name = "btnTime7";
            this.btnTime7.Size = new System.Drawing.Size(48, 35);
            this.btnTime7.TabIndex = 6;
            this.btnTime7.Text = "7";
            this.btnTime7.UseVisualStyleBackColor = true;
            // 
            // btnTime6
            // 
            this.btnTime6.Location = new System.Drawing.Point(4, 291);
            this.btnTime6.Name = "btnTime6";
            this.btnTime6.Size = new System.Drawing.Size(48, 35);
            this.btnTime6.TabIndex = 9;
            this.btnTime6.Text = "6";
            this.btnTime6.UseVisualStyleBackColor = true;
            // 
            // btnTime5
            // 
            this.btnTime5.Location = new System.Drawing.Point(6, 250);
            this.btnTime5.Name = "btnTime5";
            this.btnTime5.Size = new System.Drawing.Size(48, 35);
            this.btnTime5.TabIndex = 8;
            this.btnTime5.Text = "5";
            this.btnTime5.UseVisualStyleBackColor = true;
            // 
            // btnTime4
            // 
            this.btnTime4.Location = new System.Drawing.Point(5, 209);
            this.btnTime4.Name = "btnTime4";
            this.btnTime4.Size = new System.Drawing.Size(48, 35);
            this.btnTime4.TabIndex = 7;
            this.btnTime4.Text = "4";
            this.btnTime4.UseVisualStyleBackColor = true;
            // 
            // btnTime3
            // 
            this.btnTime3.Location = new System.Drawing.Point(6, 168);
            this.btnTime3.Name = "btnTime3";
            this.btnTime3.Size = new System.Drawing.Size(48, 35);
            this.btnTime3.TabIndex = 6;
            this.btnTime3.Text = "3";
            this.btnTime3.UseVisualStyleBackColor = true;
            // 
            // btnTime2
            // 
            this.btnTime2.Location = new System.Drawing.Point(4, 127);
            this.btnTime2.Name = "btnTime2";
            this.btnTime2.Size = new System.Drawing.Size(48, 35);
            this.btnTime2.TabIndex = 6;
            this.btnTime2.Text = "2";
            this.btnTime2.UseVisualStyleBackColor = true;
            // 
            // btnHeaderTimeShiftC
            // 
            this.btnHeaderTimeShiftC.Location = new System.Drawing.Point(6, 10);
            this.btnHeaderTimeShiftC.Name = "btnHeaderTimeShiftC";
            this.btnHeaderTimeShiftC.Size = new System.Drawing.Size(48, 70);
            this.btnHeaderTimeShiftC.TabIndex = 5;
            this.btnHeaderTimeShiftC.Text = "TIME";
            this.btnHeaderTimeShiftC.UseVisualStyleBackColor = true;
            // 
            // groupBox18
            // 
            this.groupBox18.Controls.Add(this.panel95);
            this.groupBox18.Controls.Add(this.panel91);
            this.groupBox18.Controls.Add(this.panel87);
            this.groupBox18.Controls.Add(this.panel83);
            this.groupBox18.Controls.Add(this.panel79);
            this.groupBox18.Controls.Add(this.panel75);
            this.groupBox18.Controls.Add(this.panel71);
            this.groupBox18.Controls.Add(this.panel67);
            this.groupBox18.Controls.Add(this.btnLCumlativeShiftC);
            this.groupBox18.Controls.Add(this.btnLTotalShiftC);
            this.groupBox18.Controls.Add(this.btnL30ShiftC);
            this.groupBox18.Controls.Add(this.btnL31ShiftC);
            this.groupBox18.Controls.Add(this.btnLargeSugarShiftC);
            this.groupBox18.Location = new System.Drawing.Point(80, 47);
            this.groupBox18.Name = "groupBox18";
            this.groupBox18.Size = new System.Drawing.Size(383, 425);
            this.groupBox18.TabIndex = 4;
            this.groupBox18.TabStop = false;
            // 
            // panel95
            // 
            this.panel95.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel95.Controls.Add(this.button372);
            this.panel95.Controls.Add(this.button371);
            this.panel95.Controls.Add(this.button370);
            this.panel95.Controls.Add(this.button369);
            this.panel95.Location = new System.Drawing.Point(6, 373);
            this.panel95.Name = "panel95";
            this.panel95.Size = new System.Drawing.Size(360, 35);
            this.panel95.TabIndex = 32;
            // 
            // panel91
            // 
            this.panel91.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel91.Controls.Add(this.button355);
            this.panel91.Controls.Add(this.button356);
            this.panel91.Controls.Add(this.button354);
            this.panel91.Controls.Add(this.button353);
            this.panel91.Location = new System.Drawing.Point(6, 332);
            this.panel91.Name = "panel91";
            this.panel91.Size = new System.Drawing.Size(360, 35);
            this.panel91.TabIndex = 31;
            // 
            // button357
            // 
            this.button357.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button357.Location = new System.Drawing.Point(3, 3);
            this.button357.Name = "button357";
            this.button357.Size = new System.Drawing.Size(82, 26);
            this.button357.TabIndex = 102;
            this.button357.Text = "button357";
            this.button357.UseVisualStyleBackColor = true;
            // 
            // button356
            // 
            this.button356.BackColor = System.Drawing.Color.Aqua;
            this.button356.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button356.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button356.Location = new System.Drawing.Point(272, 3);
            this.button356.Name = "button356";
            this.button356.Size = new System.Drawing.Size(82, 26);
            this.button356.TabIndex = 101;
            this.button356.Text = "button356";
            this.button356.UseVisualStyleBackColor = false;
            // 
            // button355
            // 
            this.button355.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.button355.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button355.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button355.Location = new System.Drawing.Point(181, 3);
            this.button355.Name = "button355";
            this.button355.Size = new System.Drawing.Size(82, 26);
            this.button355.TabIndex = 100;
            this.button355.Text = "button355";
            this.button355.UseVisualStyleBackColor = false;
            // 
            // button354
            // 
            this.button354.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button354.Location = new System.Drawing.Point(95, 3);
            this.button354.Name = "button354";
            this.button354.Size = new System.Drawing.Size(82, 26);
            this.button354.TabIndex = 99;
            this.button354.Text = "button354";
            this.button354.UseVisualStyleBackColor = true;
            // 
            // button353
            // 
            this.button353.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button353.Location = new System.Drawing.Point(5, 3);
            this.button353.Name = "button353";
            this.button353.Size = new System.Drawing.Size(82, 26);
            this.button353.TabIndex = 98;
            this.button353.Text = "button353";
            this.button353.UseVisualStyleBackColor = true;
            // 
            // panel87
            // 
            this.panel87.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel87.Controls.Add(this.button340);
            this.panel87.Controls.Add(this.button339);
            this.panel87.Controls.Add(this.button338);
            this.panel87.Controls.Add(this.button337);
            this.panel87.Location = new System.Drawing.Point(6, 291);
            this.panel87.Name = "panel87";
            this.panel87.Size = new System.Drawing.Size(360, 35);
            this.panel87.TabIndex = 30;
            // 
            // button340
            // 
            this.button340.BackColor = System.Drawing.Color.Aqua;
            this.button340.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button340.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button340.Location = new System.Drawing.Point(272, 3);
            this.button340.Name = "button340";
            this.button340.Size = new System.Drawing.Size(82, 26);
            this.button340.TabIndex = 100;
            this.button340.Text = "button340";
            this.button340.UseVisualStyleBackColor = false;
            // 
            // button339
            // 
            this.button339.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.button339.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button339.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button339.Location = new System.Drawing.Point(181, 3);
            this.button339.Name = "button339";
            this.button339.Size = new System.Drawing.Size(82, 26);
            this.button339.TabIndex = 99;
            this.button339.Text = "button339";
            this.button339.UseVisualStyleBackColor = false;
            // 
            // button338
            // 
            this.button338.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button338.Location = new System.Drawing.Point(95, 3);
            this.button338.Name = "button338";
            this.button338.Size = new System.Drawing.Size(82, 26);
            this.button338.TabIndex = 98;
            this.button338.Text = "button338";
            this.button338.UseVisualStyleBackColor = true;
            // 
            // button337
            // 
            this.button337.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button337.Location = new System.Drawing.Point(5, 3);
            this.button337.Name = "button337";
            this.button337.Size = new System.Drawing.Size(82, 26);
            this.button337.TabIndex = 97;
            this.button337.Text = "button337";
            this.button337.UseVisualStyleBackColor = true;
            // 
            // panel83
            // 
            this.panel83.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel83.Controls.Add(this.button324);
            this.panel83.Controls.Add(this.button323);
            this.panel83.Controls.Add(this.button322);
            this.panel83.Controls.Add(this.button321);
            this.panel83.Location = new System.Drawing.Point(6, 250);
            this.panel83.Name = "panel83";
            this.panel83.Size = new System.Drawing.Size(360, 35);
            this.panel83.TabIndex = 29;
            // 
            // button324
            // 
            this.button324.BackColor = System.Drawing.Color.Aqua;
            this.button324.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button324.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button324.Location = new System.Drawing.Point(272, 4);
            this.button324.Name = "button324";
            this.button324.Size = new System.Drawing.Size(82, 26);
            this.button324.TabIndex = 99;
            this.button324.Text = "button324";
            this.button324.UseVisualStyleBackColor = false;
            // 
            // button323
            // 
            this.button323.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.button323.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button323.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button323.Location = new System.Drawing.Point(181, 4);
            this.button323.Name = "button323";
            this.button323.Size = new System.Drawing.Size(82, 26);
            this.button323.TabIndex = 98;
            this.button323.Text = "button323";
            this.button323.UseVisualStyleBackColor = false;
            // 
            // button322
            // 
            this.button322.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button322.Location = new System.Drawing.Point(95, 4);
            this.button322.Name = "button322";
            this.button322.Size = new System.Drawing.Size(82, 26);
            this.button322.TabIndex = 97;
            this.button322.Text = "button322";
            this.button322.UseVisualStyleBackColor = true;
            // 
            // button321
            // 
            this.button321.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button321.Location = new System.Drawing.Point(5, 4);
            this.button321.Name = "button321";
            this.button321.Size = new System.Drawing.Size(82, 26);
            this.button321.TabIndex = 96;
            this.button321.Text = "button321";
            this.button321.UseVisualStyleBackColor = true;
            // 
            // panel79
            // 
            this.panel79.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel79.Controls.Add(this.button308);
            this.panel79.Controls.Add(this.button307);
            this.panel79.Controls.Add(this.button306);
            this.panel79.Controls.Add(this.button305);
            this.panel79.Location = new System.Drawing.Point(6, 209);
            this.panel79.Name = "panel79";
            this.panel79.Size = new System.Drawing.Size(360, 35);
            this.panel79.TabIndex = 28;
            // 
            // button308
            // 
            this.button308.BackColor = System.Drawing.Color.Aqua;
            this.button308.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button308.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button308.Location = new System.Drawing.Point(272, 3);
            this.button308.Name = "button308";
            this.button308.Size = new System.Drawing.Size(82, 26);
            this.button308.TabIndex = 95;
            this.button308.Text = "button308";
            this.button308.UseVisualStyleBackColor = false;
            // 
            // button307
            // 
            this.button307.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.button307.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button307.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button307.Location = new System.Drawing.Point(181, 3);
            this.button307.Name = "button307";
            this.button307.Size = new System.Drawing.Size(82, 26);
            this.button307.TabIndex = 94;
            this.button307.Text = "button307";
            this.button307.UseVisualStyleBackColor = false;
            // 
            // button306
            // 
            this.button306.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button306.Location = new System.Drawing.Point(95, 3);
            this.button306.Name = "button306";
            this.button306.Size = new System.Drawing.Size(82, 26);
            this.button306.TabIndex = 93;
            this.button306.Text = "button306";
            this.button306.UseVisualStyleBackColor = true;
            // 
            // button305
            // 
            this.button305.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button305.Location = new System.Drawing.Point(5, 3);
            this.button305.Name = "button305";
            this.button305.Size = new System.Drawing.Size(82, 26);
            this.button305.TabIndex = 92;
            this.button305.Text = "button305";
            this.button305.UseVisualStyleBackColor = true;
            // 
            // panel75
            // 
            this.panel75.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel75.Controls.Add(this.button292);
            this.panel75.Controls.Add(this.button291);
            this.panel75.Controls.Add(this.button290);
            this.panel75.Controls.Add(this.button289);
            this.panel75.Location = new System.Drawing.Point(6, 168);
            this.panel75.Name = "panel75";
            this.panel75.Size = new System.Drawing.Size(360, 35);
            this.panel75.TabIndex = 27;
            // 
            // button292
            // 
            this.button292.BackColor = System.Drawing.Color.Aqua;
            this.button292.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button292.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button292.Location = new System.Drawing.Point(272, 3);
            this.button292.Name = "button292";
            this.button292.Size = new System.Drawing.Size(82, 26);
            this.button292.TabIndex = 91;
            this.button292.Text = "button292";
            this.button292.UseVisualStyleBackColor = false;
            // 
            // button291
            // 
            this.button291.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.button291.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button291.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button291.Location = new System.Drawing.Point(181, 3);
            this.button291.Name = "button291";
            this.button291.Size = new System.Drawing.Size(82, 26);
            this.button291.TabIndex = 90;
            this.button291.Text = "button291";
            this.button291.UseVisualStyleBackColor = false;
            // 
            // button290
            // 
            this.button290.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button290.Location = new System.Drawing.Point(95, 3);
            this.button290.Name = "button290";
            this.button290.Size = new System.Drawing.Size(82, 26);
            this.button290.TabIndex = 89;
            this.button290.Text = "button290";
            this.button290.UseVisualStyleBackColor = true;
            // 
            // button289
            // 
            this.button289.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button289.Location = new System.Drawing.Point(5, 3);
            this.button289.Name = "button289";
            this.button289.Size = new System.Drawing.Size(82, 26);
            this.button289.TabIndex = 88;
            this.button289.Text = "button289";
            this.button289.UseVisualStyleBackColor = true;
            // 
            // panel71
            // 
            this.panel71.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel71.Controls.Add(this.button276);
            this.panel71.Controls.Add(this.button275);
            this.panel71.Controls.Add(this.button274);
            this.panel71.Controls.Add(this.button273);
            this.panel71.Location = new System.Drawing.Point(6, 127);
            this.panel71.Name = "panel71";
            this.panel71.Size = new System.Drawing.Size(360, 35);
            this.panel71.TabIndex = 26;
            // 
            // button276
            // 
            this.button276.BackColor = System.Drawing.Color.Aqua;
            this.button276.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button276.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button276.Location = new System.Drawing.Point(272, 4);
            this.button276.Name = "button276";
            this.button276.Size = new System.Drawing.Size(82, 26);
            this.button276.TabIndex = 87;
            this.button276.Text = "button276";
            this.button276.UseVisualStyleBackColor = false;
            // 
            // button275
            // 
            this.button275.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.button275.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button275.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button275.Location = new System.Drawing.Point(181, 4);
            this.button275.Name = "button275";
            this.button275.Size = new System.Drawing.Size(82, 26);
            this.button275.TabIndex = 86;
            this.button275.Text = "button275";
            this.button275.UseVisualStyleBackColor = false;
            // 
            // button274
            // 
            this.button274.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button274.Location = new System.Drawing.Point(95, 4);
            this.button274.Name = "button274";
            this.button274.Size = new System.Drawing.Size(82, 26);
            this.button274.TabIndex = 85;
            this.button274.Text = "button274";
            this.button274.UseVisualStyleBackColor = true;
            // 
            // button273
            // 
            this.button273.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button273.Location = new System.Drawing.Point(5, 4);
            this.button273.Name = "button273";
            this.button273.Size = new System.Drawing.Size(82, 26);
            this.button273.TabIndex = 84;
            this.button273.Text = "button273";
            this.button273.UseVisualStyleBackColor = true;
            // 
            // panel67
            // 
            this.panel67.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel67.Controls.Add(this.button260);
            this.panel67.Controls.Add(this.button259);
            this.panel67.Controls.Add(this.button258);
            this.panel67.Controls.Add(this.button257);
            this.panel67.Location = new System.Drawing.Point(6, 86);
            this.panel67.Name = "panel67";
            this.panel67.Size = new System.Drawing.Size(360, 35);
            this.panel67.TabIndex = 25;
            // 
            // button260
            // 
            this.button260.BackColor = System.Drawing.Color.Aqua;
            this.button260.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button260.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button260.Location = new System.Drawing.Point(272, 3);
            this.button260.Name = "button260";
            this.button260.Size = new System.Drawing.Size(82, 26);
            this.button260.TabIndex = 83;
            this.button260.Text = "button260";
            this.button260.UseVisualStyleBackColor = false;
            // 
            // button259
            // 
            this.button259.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.button259.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button259.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button259.Location = new System.Drawing.Point(181, 3);
            this.button259.Name = "button259";
            this.button259.Size = new System.Drawing.Size(82, 26);
            this.button259.TabIndex = 82;
            this.button259.Text = "button259";
            this.button259.UseVisualStyleBackColor = false;
            // 
            // button258
            // 
            this.button258.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button258.Location = new System.Drawing.Point(95, 3);
            this.button258.Name = "button258";
            this.button258.Size = new System.Drawing.Size(82, 26);
            this.button258.TabIndex = 81;
            this.button258.Text = "button258";
            this.button258.UseVisualStyleBackColor = true;
            // 
            // button257
            // 
            this.button257.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button257.Location = new System.Drawing.Point(5, 3);
            this.button257.Name = "button257";
            this.button257.Size = new System.Drawing.Size(82, 26);
            this.button257.TabIndex = 80;
            this.button257.Text = "button257";
            this.button257.UseVisualStyleBackColor = true;
            // 
            // btnLCumlativeShiftC
            // 
            this.btnLCumlativeShiftC.BackColor = System.Drawing.Color.Black;
            this.btnLCumlativeShiftC.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLCumlativeShiftC.ForeColor = System.Drawing.Color.White;
            this.btnLCumlativeShiftC.Location = new System.Drawing.Point(279, 50);
            this.btnLCumlativeShiftC.Name = "btnLCumlativeShiftC";
            this.btnLCumlativeShiftC.Size = new System.Drawing.Size(83, 30);
            this.btnLCumlativeShiftC.TabIndex = 4;
            this.btnLCumlativeShiftC.Text = "H..";
            this.btnLCumlativeShiftC.UseVisualStyleBackColor = false;
            // 
            // btnLTotalShiftC
            // 
            this.btnLTotalShiftC.BackColor = System.Drawing.Color.Black;
            this.btnLTotalShiftC.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLTotalShiftC.ForeColor = System.Drawing.Color.White;
            this.btnLTotalShiftC.Location = new System.Drawing.Point(186, 50);
            this.btnLTotalShiftC.Name = "btnLTotalShiftC";
            this.btnLTotalShiftC.Size = new System.Drawing.Size(83, 30);
            this.btnLTotalShiftC.TabIndex = 3;
            this.btnLTotalShiftC.Text = "TOTAL";
            this.btnLTotalShiftC.UseVisualStyleBackColor = false;
            // 
            // btnL30ShiftC
            // 
            this.btnL30ShiftC.BackColor = System.Drawing.Color.Black;
            this.btnL30ShiftC.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnL30ShiftC.ForeColor = System.Drawing.Color.White;
            this.btnL30ShiftC.Location = new System.Drawing.Point(99, 50);
            this.btnL30ShiftC.Name = "btnL30ShiftC";
            this.btnL30ShiftC.Size = new System.Drawing.Size(83, 30);
            this.btnL30ShiftC.TabIndex = 2;
            this.btnL30ShiftC.Text = "L-30";
            this.btnL30ShiftC.UseVisualStyleBackColor = false;
            // 
            // btnL31ShiftC
            // 
            this.btnL31ShiftC.BackColor = System.Drawing.Color.Black;
            this.btnL31ShiftC.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnL31ShiftC.ForeColor = System.Drawing.Color.White;
            this.btnL31ShiftC.Location = new System.Drawing.Point(6, 50);
            this.btnL31ShiftC.Name = "btnL31ShiftC";
            this.btnL31ShiftC.Size = new System.Drawing.Size(83, 30);
            this.btnL31ShiftC.TabIndex = 1;
            this.btnL31ShiftC.Text = "L-31";
            this.btnL31ShiftC.UseVisualStyleBackColor = false;
            // 
            // btnLargeSugarShiftC
            // 
            this.btnLargeSugarShiftC.BackColor = System.Drawing.Color.Black;
            this.btnLargeSugarShiftC.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLargeSugarShiftC.ForeColor = System.Drawing.Color.White;
            this.btnLargeSugarShiftC.Location = new System.Drawing.Point(4, 10);
            this.btnLargeSugarShiftC.Name = "btnLargeSugarShiftC";
            this.btnLargeSugarShiftC.Size = new System.Drawing.Size(357, 34);
            this.btnLargeSugarShiftC.TabIndex = 0;
            this.btnLargeSugarShiftC.Text = "LARGE SUGAR";
            this.btnLargeSugarShiftC.UseVisualStyleBackColor = false;
            // 
            // btnShiftC
            // 
            this.btnShiftC.Location = new System.Drawing.Point(16, 18);
            this.btnShiftC.Name = "btnShiftC";
            this.btnShiftC.Size = new System.Drawing.Size(1639, 23);
            this.btnShiftC.TabIndex = 0;
            this.btnShiftC.Text = "SHIFT-C";
            this.btnShiftC.UseVisualStyleBackColor = true;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.groupBox20);
            this.groupBox1.Controls.Add(this.groupBox8);
            this.groupBox1.Controls.Add(this.groupBox9);
            this.groupBox1.Controls.Add(this.groupBox10);
            this.groupBox1.Controls.Add(this.groupBox11);
            this.groupBox1.Controls.Add(this.groupBox12);
            this.groupBox1.Controls.Add(this.btnShiftB);
            this.groupBox1.Location = new System.Drawing.Point(3, 492);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(1679, 483);
            this.groupBox1.TabIndex = 8;
            this.groupBox1.TabStop = false;
            // 
            // groupBox20
            // 
            this.groupBox20.Controls.Add(this.button256);
            this.groupBox20.Controls.Add(this.button240);
            this.groupBox20.Controls.Add(this.button224);
            this.groupBox20.Controls.Add(this.button208);
            this.groupBox20.Controls.Add(this.button192);
            this.groupBox20.Controls.Add(this.button176);
            this.groupBox20.Controls.Add(this.button160);
            this.groupBox20.Controls.Add(this.button144);
            this.groupBox20.Controls.Add(this.btnTotalShiftB);
            this.groupBox20.Location = new System.Drawing.Point(1581, 47);
            this.groupBox20.Name = "groupBox20";
            this.groupBox20.Size = new System.Drawing.Size(84, 425);
            this.groupBox20.TabIndex = 11;
            this.groupBox20.TabStop = false;
            // 
            // button256
            // 
            this.button256.Location = new System.Drawing.Point(6, 373);
            this.button256.Name = "button256";
            this.button256.Size = new System.Drawing.Size(78, 35);
            this.button256.TabIndex = 21;
            this.button256.Text = "9";
            this.button256.UseVisualStyleBackColor = true;
            // 
            // button240
            // 
            this.button240.Location = new System.Drawing.Point(6, 332);
            this.button240.Name = "button240";
            this.button240.Size = new System.Drawing.Size(78, 35);
            this.button240.TabIndex = 20;
            this.button240.Text = "9";
            this.button240.UseVisualStyleBackColor = true;
            // 
            // button224
            // 
            this.button224.Location = new System.Drawing.Point(6, 292);
            this.button224.Name = "button224";
            this.button224.Size = new System.Drawing.Size(78, 35);
            this.button224.TabIndex = 19;
            this.button224.Text = "9";
            this.button224.UseVisualStyleBackColor = true;
            // 
            // button208
            // 
            this.button208.Location = new System.Drawing.Point(6, 250);
            this.button208.Name = "button208";
            this.button208.Size = new System.Drawing.Size(78, 35);
            this.button208.TabIndex = 18;
            this.button208.Text = "9";
            this.button208.UseVisualStyleBackColor = true;
            // 
            // button192
            // 
            this.button192.Location = new System.Drawing.Point(6, 210);
            this.button192.Name = "button192";
            this.button192.Size = new System.Drawing.Size(78, 35);
            this.button192.TabIndex = 17;
            this.button192.Text = "9";
            this.button192.UseVisualStyleBackColor = true;
            // 
            // button176
            // 
            this.button176.Location = new System.Drawing.Point(6, 169);
            this.button176.Name = "button176";
            this.button176.Size = new System.Drawing.Size(78, 35);
            this.button176.TabIndex = 16;
            this.button176.Text = "9";
            this.button176.UseVisualStyleBackColor = true;
            // 
            // button160
            // 
            this.button160.Location = new System.Drawing.Point(6, 128);
            this.button160.Name = "button160";
            this.button160.Size = new System.Drawing.Size(78, 35);
            this.button160.TabIndex = 15;
            this.button160.Text = "9";
            this.button160.UseVisualStyleBackColor = true;
            // 
            // button144
            // 
            this.button144.Location = new System.Drawing.Point(6, 87);
            this.button144.Name = "button144";
            this.button144.Size = new System.Drawing.Size(78, 35);
            this.button144.TabIndex = 14;
            this.button144.Text = "9";
            this.button144.UseVisualStyleBackColor = true;
            // 
            // btnTotalShiftB
            // 
            this.btnTotalShiftB.BackColor = System.Drawing.Color.Black;
            this.btnTotalShiftB.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnTotalShiftB.ForeColor = System.Drawing.Color.White;
            this.btnTotalShiftB.Location = new System.Drawing.Point(6, 10);
            this.btnTotalShiftB.Name = "btnTotalShiftB";
            this.btnTotalShiftB.Size = new System.Drawing.Size(78, 60);
            this.btnTotalShiftB.TabIndex = 5;
            this.btnTotalShiftB.Text = "TOTAL";
            this.btnTotalShiftB.UseVisualStyleBackColor = false;
            // 
            // groupBox8
            // 
            this.groupBox8.Controls.Add(this.panel66);
            this.groupBox8.Controls.Add(this.panel62);
            this.groupBox8.Controls.Add(this.panel58);
            this.groupBox8.Controls.Add(this.panel54);
            this.groupBox8.Controls.Add(this.panel50);
            this.groupBox8.Controls.Add(this.panel46);
            this.groupBox8.Controls.Add(this.panel42);
            this.groupBox8.Controls.Add(this.panel38);
            this.groupBox8.Controls.Add(this.btnBissCumlativeShiftB);
            this.groupBox8.Controls.Add(this.btnBissTotalShiftB);
            this.groupBox8.Controls.Add(this.btnBissShiftB);
            this.groupBox8.Controls.Add(this.btnBissSugarShifB);
            this.groupBox8.Location = new System.Drawing.Point(1272, 47);
            this.groupBox8.Name = "groupBox8";
            this.groupBox8.Size = new System.Drawing.Size(291, 425);
            this.groupBox8.TabIndex = 9;
            this.groupBox8.TabStop = false;
            // 
            // panel66
            // 
            this.panel66.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel66.Controls.Add(this.button255);
            this.panel66.Controls.Add(this.button254);
            this.panel66.Controls.Add(this.button253);
            this.panel66.Location = new System.Drawing.Point(6, 373);
            this.panel66.Name = "panel66";
            this.panel66.Size = new System.Drawing.Size(265, 35);
            this.panel66.TabIndex = 23;
            // 
            // button255
            // 
            this.button255.BackColor = System.Drawing.Color.Aqua;
            this.button255.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button255.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button255.Location = new System.Drawing.Point(179, 3);
            this.button255.Name = "button255";
            this.button255.Size = new System.Drawing.Size(82, 26);
            this.button255.TabIndex = 78;
            this.button255.Text = "button255";
            this.button255.UseVisualStyleBackColor = false;
            // 
            // button254
            // 
            this.button254.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.button254.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button254.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button254.Location = new System.Drawing.Point(91, 3);
            this.button254.Name = "button254";
            this.button254.Size = new System.Drawing.Size(82, 26);
            this.button254.TabIndex = 77;
            this.button254.Text = "button254";
            this.button254.UseVisualStyleBackColor = false;
            // 
            // button253
            // 
            this.button253.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button253.Location = new System.Drawing.Point(3, 3);
            this.button253.Name = "button253";
            this.button253.Size = new System.Drawing.Size(82, 26);
            this.button253.TabIndex = 76;
            this.button253.Text = "button253";
            this.button253.UseVisualStyleBackColor = true;
            // 
            // panel62
            // 
            this.panel62.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel62.Controls.Add(this.button239);
            this.panel62.Controls.Add(this.button238);
            this.panel62.Controls.Add(this.button237);
            this.panel62.Location = new System.Drawing.Point(6, 332);
            this.panel62.Name = "panel62";
            this.panel62.Size = new System.Drawing.Size(265, 35);
            this.panel62.TabIndex = 22;
            // 
            // button239
            // 
            this.button239.BackColor = System.Drawing.Color.Aqua;
            this.button239.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button239.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button239.Location = new System.Drawing.Point(179, 3);
            this.button239.Name = "button239";
            this.button239.Size = new System.Drawing.Size(82, 26);
            this.button239.TabIndex = 89;
            this.button239.Text = "button239";
            this.button239.UseVisualStyleBackColor = false;
            // 
            // button238
            // 
            this.button238.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.button238.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button238.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button238.Location = new System.Drawing.Point(91, 3);
            this.button238.Name = "button238";
            this.button238.Size = new System.Drawing.Size(82, 26);
            this.button238.TabIndex = 88;
            this.button238.Text = "button238";
            this.button238.UseVisualStyleBackColor = false;
            // 
            // button237
            // 
            this.button237.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button237.Location = new System.Drawing.Point(3, 3);
            this.button237.Name = "button237";
            this.button237.Size = new System.Drawing.Size(82, 26);
            this.button237.TabIndex = 87;
            this.button237.Text = "button237";
            this.button237.UseVisualStyleBackColor = true;
            // 
            // panel58
            // 
            this.panel58.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel58.Controls.Add(this.button223);
            this.panel58.Controls.Add(this.button222);
            this.panel58.Controls.Add(this.button221);
            this.panel58.Location = new System.Drawing.Point(6, 291);
            this.panel58.Name = "panel58";
            this.panel58.Size = new System.Drawing.Size(265, 35);
            this.panel58.TabIndex = 21;
            // 
            // button223
            // 
            this.button223.BackColor = System.Drawing.Color.Aqua;
            this.button223.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button223.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button223.Location = new System.Drawing.Point(179, 3);
            this.button223.Name = "button223";
            this.button223.Size = new System.Drawing.Size(82, 26);
            this.button223.TabIndex = 88;
            this.button223.Text = "button223";
            this.button223.UseVisualStyleBackColor = false;
            // 
            // button222
            // 
            this.button222.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.button222.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button222.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button222.Location = new System.Drawing.Point(91, 3);
            this.button222.Name = "button222";
            this.button222.Size = new System.Drawing.Size(82, 26);
            this.button222.TabIndex = 87;
            this.button222.Text = "button222";
            this.button222.UseVisualStyleBackColor = false;
            // 
            // button221
            // 
            this.button221.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button221.Location = new System.Drawing.Point(3, 3);
            this.button221.Name = "button221";
            this.button221.Size = new System.Drawing.Size(82, 26);
            this.button221.TabIndex = 86;
            this.button221.Text = "button221";
            this.button221.UseVisualStyleBackColor = true;
            // 
            // panel54
            // 
            this.panel54.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel54.Controls.Add(this.button207);
            this.panel54.Controls.Add(this.button206);
            this.panel54.Controls.Add(this.button205);
            this.panel54.Location = new System.Drawing.Point(6, 250);
            this.panel54.Name = "panel54";
            this.panel54.Size = new System.Drawing.Size(265, 35);
            this.panel54.TabIndex = 20;
            // 
            // button207
            // 
            this.button207.BackColor = System.Drawing.Color.Aqua;
            this.button207.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button207.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button207.Location = new System.Drawing.Point(179, 4);
            this.button207.Name = "button207";
            this.button207.Size = new System.Drawing.Size(82, 26);
            this.button207.TabIndex = 87;
            this.button207.Text = "button207";
            this.button207.UseVisualStyleBackColor = false;
            // 
            // button206
            // 
            this.button206.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.button206.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button206.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button206.Location = new System.Drawing.Point(91, 3);
            this.button206.Name = "button206";
            this.button206.Size = new System.Drawing.Size(82, 26);
            this.button206.TabIndex = 86;
            this.button206.Text = "button206";
            this.button206.UseVisualStyleBackColor = false;
            // 
            // button205
            // 
            this.button205.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button205.Location = new System.Drawing.Point(3, 3);
            this.button205.Name = "button205";
            this.button205.Size = new System.Drawing.Size(82, 26);
            this.button205.TabIndex = 85;
            this.button205.Text = "button205";
            this.button205.UseVisualStyleBackColor = true;
            // 
            // panel50
            // 
            this.panel50.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel50.Controls.Add(this.button191);
            this.panel50.Controls.Add(this.button190);
            this.panel50.Controls.Add(this.button189);
            this.panel50.Location = new System.Drawing.Point(6, 209);
            this.panel50.Name = "panel50";
            this.panel50.Size = new System.Drawing.Size(265, 35);
            this.panel50.TabIndex = 19;
            // 
            // button191
            // 
            this.button191.BackColor = System.Drawing.Color.Aqua;
            this.button191.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button191.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button191.Location = new System.Drawing.Point(180, 3);
            this.button191.Name = "button191";
            this.button191.Size = new System.Drawing.Size(82, 26);
            this.button191.TabIndex = 86;
            this.button191.Text = "button191";
            this.button191.UseVisualStyleBackColor = false;
            // 
            // button190
            // 
            this.button190.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.button190.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button190.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button190.Location = new System.Drawing.Point(91, 4);
            this.button190.Name = "button190";
            this.button190.Size = new System.Drawing.Size(82, 26);
            this.button190.TabIndex = 85;
            this.button190.Text = "button190";
            this.button190.UseVisualStyleBackColor = false;
            // 
            // button189
            // 
            this.button189.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button189.Location = new System.Drawing.Point(3, 3);
            this.button189.Name = "button189";
            this.button189.Size = new System.Drawing.Size(82, 26);
            this.button189.TabIndex = 84;
            this.button189.Text = "button189";
            this.button189.UseVisualStyleBackColor = true;
            // 
            // panel46
            // 
            this.panel46.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel46.Controls.Add(this.button175);
            this.panel46.Controls.Add(this.button174);
            this.panel46.Controls.Add(this.button173);
            this.panel46.Location = new System.Drawing.Point(6, 168);
            this.panel46.Name = "panel46";
            this.panel46.Size = new System.Drawing.Size(265, 35);
            this.panel46.TabIndex = 18;
            // 
            // button175
            // 
            this.button175.BackColor = System.Drawing.Color.Aqua;
            this.button175.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button175.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button175.Location = new System.Drawing.Point(179, 3);
            this.button175.Name = "button175";
            this.button175.Size = new System.Drawing.Size(82, 26);
            this.button175.TabIndex = 85;
            this.button175.Text = "button175";
            this.button175.UseVisualStyleBackColor = false;
            // 
            // button174
            // 
            this.button174.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.button174.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button174.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button174.Location = new System.Drawing.Point(91, 4);
            this.button174.Name = "button174";
            this.button174.Size = new System.Drawing.Size(82, 26);
            this.button174.TabIndex = 84;
            this.button174.Text = "button174";
            this.button174.UseVisualStyleBackColor = false;
            // 
            // button173
            // 
            this.button173.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button173.Location = new System.Drawing.Point(3, 4);
            this.button173.Name = "button173";
            this.button173.Size = new System.Drawing.Size(82, 26);
            this.button173.TabIndex = 83;
            this.button173.Text = "button173";
            this.button173.UseVisualStyleBackColor = true;
            // 
            // panel42
            // 
            this.panel42.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel42.Controls.Add(this.button159);
            this.panel42.Controls.Add(this.button158);
            this.panel42.Controls.Add(this.button157);
            this.panel42.Location = new System.Drawing.Point(6, 127);
            this.panel42.Name = "panel42";
            this.panel42.Size = new System.Drawing.Size(265, 35);
            this.panel42.TabIndex = 17;
            // 
            // button159
            // 
            this.button159.BackColor = System.Drawing.Color.Aqua;
            this.button159.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button159.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button159.Location = new System.Drawing.Point(180, 3);
            this.button159.Name = "button159";
            this.button159.Size = new System.Drawing.Size(82, 26);
            this.button159.TabIndex = 80;
            this.button159.Text = "button159";
            this.button159.UseVisualStyleBackColor = false;
            // 
            // button158
            // 
            this.button158.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.button158.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button158.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button158.Location = new System.Drawing.Point(91, 3);
            this.button158.Name = "button158";
            this.button158.Size = new System.Drawing.Size(82, 26);
            this.button158.TabIndex = 79;
            this.button158.Text = "button158";
            this.button158.UseVisualStyleBackColor = false;
            // 
            // button157
            // 
            this.button157.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button157.Location = new System.Drawing.Point(3, 3);
            this.button157.Name = "button157";
            this.button157.Size = new System.Drawing.Size(82, 26);
            this.button157.TabIndex = 78;
            this.button157.Text = "button157";
            this.button157.UseVisualStyleBackColor = true;
            // 
            // panel38
            // 
            this.panel38.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel38.Controls.Add(this.button143);
            this.panel38.Controls.Add(this.button142);
            this.panel38.Controls.Add(this.button141);
            this.panel38.Location = new System.Drawing.Point(6, 86);
            this.panel38.Name = "panel38";
            this.panel38.Size = new System.Drawing.Size(265, 35);
            this.panel38.TabIndex = 16;
            // 
            // button143
            // 
            this.button143.BackColor = System.Drawing.Color.Aqua;
            this.button143.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button143.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button143.Location = new System.Drawing.Point(178, 3);
            this.button143.Name = "button143";
            this.button143.Size = new System.Drawing.Size(82, 26);
            this.button143.TabIndex = 75;
            this.button143.Text = "button143";
            this.button143.UseVisualStyleBackColor = false;
            // 
            // button142
            // 
            this.button142.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.button142.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button142.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button142.Location = new System.Drawing.Point(90, 4);
            this.button142.Name = "button142";
            this.button142.Size = new System.Drawing.Size(82, 26);
            this.button142.TabIndex = 74;
            this.button142.Text = "button142";
            this.button142.UseVisualStyleBackColor = false;
            // 
            // button141
            // 
            this.button141.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button141.Location = new System.Drawing.Point(3, 3);
            this.button141.Name = "button141";
            this.button141.Size = new System.Drawing.Size(82, 26);
            this.button141.TabIndex = 73;
            this.button141.Text = "button141";
            this.button141.UseVisualStyleBackColor = true;
            // 
            // btnBissCumlativeShiftB
            // 
            this.btnBissCumlativeShiftB.BackColor = System.Drawing.Color.Black;
            this.btnBissCumlativeShiftB.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnBissCumlativeShiftB.ForeColor = System.Drawing.Color.White;
            this.btnBissCumlativeShiftB.Location = new System.Drawing.Point(186, 50);
            this.btnBissCumlativeShiftB.Name = "btnBissCumlativeShiftB";
            this.btnBissCumlativeShiftB.Size = new System.Drawing.Size(83, 30);
            this.btnBissCumlativeShiftB.TabIndex = 4;
            this.btnBissCumlativeShiftB.Text = "H..";
            this.btnBissCumlativeShiftB.UseVisualStyleBackColor = false;
            // 
            // btnBissTotalShiftB
            // 
            this.btnBissTotalShiftB.BackColor = System.Drawing.Color.Black;
            this.btnBissTotalShiftB.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnBissTotalShiftB.ForeColor = System.Drawing.Color.White;
            this.btnBissTotalShiftB.Location = new System.Drawing.Point(97, 50);
            this.btnBissTotalShiftB.Name = "btnBissTotalShiftB";
            this.btnBissTotalShiftB.Size = new System.Drawing.Size(83, 30);
            this.btnBissTotalShiftB.TabIndex = 3;
            this.btnBissTotalShiftB.Text = "TOTAL";
            this.btnBissTotalShiftB.UseVisualStyleBackColor = false;
            // 
            // btnBissShiftB
            // 
            this.btnBissShiftB.BackColor = System.Drawing.Color.Black;
            this.btnBissShiftB.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnBissShiftB.ForeColor = System.Drawing.Color.White;
            this.btnBissShiftB.Location = new System.Drawing.Point(6, 50);
            this.btnBissShiftB.Name = "btnBissShiftB";
            this.btnBissShiftB.Size = new System.Drawing.Size(83, 30);
            this.btnBissShiftB.TabIndex = 1;
            this.btnBissShiftB.Text = "BISS";
            this.btnBissShiftB.UseVisualStyleBackColor = false;
            // 
            // btnBissSugarShifB
            // 
            this.btnBissSugarShifB.BackColor = System.Drawing.Color.Black;
            this.btnBissSugarShifB.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnBissSugarShifB.ForeColor = System.Drawing.Color.White;
            this.btnBissSugarShifB.Location = new System.Drawing.Point(4, 10);
            this.btnBissSugarShifB.Name = "btnBissSugarShifB";
            this.btnBissSugarShifB.Size = new System.Drawing.Size(273, 34);
            this.btnBissSugarShifB.TabIndex = 0;
            this.btnBissSugarShifB.Text = "BISS SUGAR";
            this.btnBissSugarShifB.UseVisualStyleBackColor = false;
            // 
            // groupBox9
            // 
            this.groupBox9.Controls.Add(this.panel65);
            this.groupBox9.Controls.Add(this.panel61);
            this.groupBox9.Controls.Add(this.panel57);
            this.groupBox9.Controls.Add(this.panel53);
            this.groupBox9.Controls.Add(this.panel49);
            this.groupBox9.Controls.Add(this.panel45);
            this.groupBox9.Controls.Add(this.panel41);
            this.groupBox9.Controls.Add(this.panel37);
            this.groupBox9.Controls.Add(this.btnSCumlativeShiftB);
            this.groupBox9.Controls.Add(this.btnSTotalShiftB);
            this.groupBox9.Controls.Add(this.btnS30ShiftB);
            this.groupBox9.Controls.Add(this.btnS31ShiftB);
            this.groupBox9.Controls.Add(this.btnSSugarShifB);
            this.groupBox9.Location = new System.Drawing.Point(873, 47);
            this.groupBox9.Name = "groupBox9";
            this.groupBox9.Size = new System.Drawing.Size(383, 425);
            this.groupBox9.TabIndex = 8;
            this.groupBox9.TabStop = false;
            // 
            // panel65
            // 
            this.panel65.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel65.Controls.Add(this.button252);
            this.panel65.Controls.Add(this.button251);
            this.panel65.Controls.Add(this.button250);
            this.panel65.Controls.Add(this.button249);
            this.panel65.Location = new System.Drawing.Point(7, 373);
            this.panel65.Name = "panel65";
            this.panel65.Size = new System.Drawing.Size(360, 35);
            this.panel65.TabIndex = 26;
            // 
            // button252
            // 
            this.button252.BackColor = System.Drawing.Color.Aqua;
            this.button252.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button252.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button252.Location = new System.Drawing.Point(271, 3);
            this.button252.Name = "button252";
            this.button252.Size = new System.Drawing.Size(82, 26);
            this.button252.TabIndex = 87;
            this.button252.Text = "button252";
            this.button252.UseVisualStyleBackColor = false;
            // 
            // button251
            // 
            this.button251.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.button251.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button251.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button251.Location = new System.Drawing.Point(181, 3);
            this.button251.Name = "button251";
            this.button251.Size = new System.Drawing.Size(82, 26);
            this.button251.TabIndex = 86;
            this.button251.Text = "button251";
            this.button251.UseVisualStyleBackColor = false;
            // 
            // button250
            // 
            this.button250.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button250.Location = new System.Drawing.Point(93, 3);
            this.button250.Name = "button250";
            this.button250.Size = new System.Drawing.Size(82, 26);
            this.button250.TabIndex = 85;
            this.button250.Text = "button250";
            this.button250.UseVisualStyleBackColor = true;
            // 
            // button249
            // 
            this.button249.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button249.Location = new System.Drawing.Point(5, 3);
            this.button249.Name = "button249";
            this.button249.Size = new System.Drawing.Size(82, 26);
            this.button249.TabIndex = 84;
            this.button249.Text = "button249";
            this.button249.UseVisualStyleBackColor = true;
            // 
            // panel61
            // 
            this.panel61.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel61.Controls.Add(this.button236);
            this.panel61.Controls.Add(this.button235);
            this.panel61.Controls.Add(this.button234);
            this.panel61.Controls.Add(this.button233);
            this.panel61.Location = new System.Drawing.Point(6, 332);
            this.panel61.Name = "panel61";
            this.panel61.Size = new System.Drawing.Size(360, 35);
            this.panel61.TabIndex = 25;
            // 
            // button236
            // 
            this.button236.BackColor = System.Drawing.Color.Aqua;
            this.button236.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button236.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button236.Location = new System.Drawing.Point(271, 3);
            this.button236.Name = "button236";
            this.button236.Size = new System.Drawing.Size(82, 26);
            this.button236.TabIndex = 86;
            this.button236.Text = "button236";
            this.button236.UseVisualStyleBackColor = false;
            // 
            // button235
            // 
            this.button235.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.button235.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button235.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button235.Location = new System.Drawing.Point(181, 3);
            this.button235.Name = "button235";
            this.button235.Size = new System.Drawing.Size(82, 26);
            this.button235.TabIndex = 85;
            this.button235.Text = "button235";
            this.button235.UseVisualStyleBackColor = false;
            // 
            // button234
            // 
            this.button234.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button234.Location = new System.Drawing.Point(93, 3);
            this.button234.Name = "button234";
            this.button234.Size = new System.Drawing.Size(82, 26);
            this.button234.TabIndex = 84;
            this.button234.Text = "button234";
            this.button234.UseVisualStyleBackColor = true;
            // 
            // button233
            // 
            this.button233.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button233.Location = new System.Drawing.Point(5, 3);
            this.button233.Name = "button233";
            this.button233.Size = new System.Drawing.Size(82, 26);
            this.button233.TabIndex = 83;
            this.button233.Text = "button233";
            this.button233.UseVisualStyleBackColor = true;
            // 
            // panel57
            // 
            this.panel57.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel57.Controls.Add(this.button220);
            this.panel57.Controls.Add(this.button219);
            this.panel57.Controls.Add(this.button218);
            this.panel57.Controls.Add(this.button217);
            this.panel57.Location = new System.Drawing.Point(7, 291);
            this.panel57.Name = "panel57";
            this.panel57.Size = new System.Drawing.Size(360, 35);
            this.panel57.TabIndex = 24;
            // 
            // button220
            // 
            this.button220.BackColor = System.Drawing.Color.Aqua;
            this.button220.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button220.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button220.Location = new System.Drawing.Point(271, 3);
            this.button220.Name = "button220";
            this.button220.Size = new System.Drawing.Size(82, 26);
            this.button220.TabIndex = 85;
            this.button220.Text = "button220";
            this.button220.UseVisualStyleBackColor = false;
            // 
            // button219
            // 
            this.button219.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.button219.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button219.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button219.Location = new System.Drawing.Point(181, 3);
            this.button219.Name = "button219";
            this.button219.Size = new System.Drawing.Size(82, 26);
            this.button219.TabIndex = 84;
            this.button219.Text = "button219";
            this.button219.UseVisualStyleBackColor = false;
            // 
            // button218
            // 
            this.button218.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button218.Location = new System.Drawing.Point(93, 3);
            this.button218.Name = "button218";
            this.button218.Size = new System.Drawing.Size(82, 26);
            this.button218.TabIndex = 83;
            this.button218.Text = "button218";
            this.button218.UseVisualStyleBackColor = true;
            // 
            // button217
            // 
            this.button217.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button217.Location = new System.Drawing.Point(5, 3);
            this.button217.Name = "button217";
            this.button217.Size = new System.Drawing.Size(82, 26);
            this.button217.TabIndex = 82;
            this.button217.Text = "button217";
            this.button217.UseVisualStyleBackColor = true;
            // 
            // panel53
            // 
            this.panel53.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel53.Controls.Add(this.button204);
            this.panel53.Controls.Add(this.button203);
            this.panel53.Controls.Add(this.button202);
            this.panel53.Controls.Add(this.button201);
            this.panel53.Location = new System.Drawing.Point(6, 250);
            this.panel53.Name = "panel53";
            this.panel53.Size = new System.Drawing.Size(360, 35);
            this.panel53.TabIndex = 23;
            // 
            // button204
            // 
            this.button204.BackColor = System.Drawing.Color.Aqua;
            this.button204.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button204.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button204.Location = new System.Drawing.Point(271, 4);
            this.button204.Name = "button204";
            this.button204.Size = new System.Drawing.Size(82, 26);
            this.button204.TabIndex = 84;
            this.button204.Text = "button204";
            this.button204.UseVisualStyleBackColor = false;
            // 
            // button203
            // 
            this.button203.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.button203.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button203.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button203.Location = new System.Drawing.Point(181, 3);
            this.button203.Name = "button203";
            this.button203.Size = new System.Drawing.Size(82, 26);
            this.button203.TabIndex = 83;
            this.button203.Text = "button203";
            this.button203.UseVisualStyleBackColor = false;
            // 
            // button202
            // 
            this.button202.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button202.Location = new System.Drawing.Point(92, 4);
            this.button202.Name = "button202";
            this.button202.Size = new System.Drawing.Size(82, 26);
            this.button202.TabIndex = 82;
            this.button202.Text = "button202";
            this.button202.UseVisualStyleBackColor = true;
            // 
            // button201
            // 
            this.button201.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button201.Location = new System.Drawing.Point(5, 4);
            this.button201.Name = "button201";
            this.button201.Size = new System.Drawing.Size(82, 26);
            this.button201.TabIndex = 81;
            this.button201.Text = "button201";
            this.button201.UseVisualStyleBackColor = true;
            // 
            // panel49
            // 
            this.panel49.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel49.Controls.Add(this.button188);
            this.panel49.Controls.Add(this.button187);
            this.panel49.Controls.Add(this.button186);
            this.panel49.Controls.Add(this.button185);
            this.panel49.Location = new System.Drawing.Point(6, 209);
            this.panel49.Name = "panel49";
            this.panel49.Size = new System.Drawing.Size(360, 35);
            this.panel49.TabIndex = 22;
            // 
            // button188
            // 
            this.button188.BackColor = System.Drawing.Color.Aqua;
            this.button188.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button188.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button188.Location = new System.Drawing.Point(271, 3);
            this.button188.Name = "button188";
            this.button188.Size = new System.Drawing.Size(82, 26);
            this.button188.TabIndex = 83;
            this.button188.Text = "button188";
            this.button188.UseVisualStyleBackColor = false;
            // 
            // button187
            // 
            this.button187.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.button187.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button187.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button187.Location = new System.Drawing.Point(181, 4);
            this.button187.Name = "button187";
            this.button187.Size = new System.Drawing.Size(82, 26);
            this.button187.TabIndex = 82;
            this.button187.Text = "button187";
            this.button187.UseVisualStyleBackColor = false;
            // 
            // button186
            // 
            this.button186.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button186.Location = new System.Drawing.Point(92, 4);
            this.button186.Name = "button186";
            this.button186.Size = new System.Drawing.Size(82, 26);
            this.button186.TabIndex = 81;
            this.button186.Text = "button186";
            this.button186.UseVisualStyleBackColor = true;
            // 
            // button185
            // 
            this.button185.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button185.Location = new System.Drawing.Point(5, 4);
            this.button185.Name = "button185";
            this.button185.Size = new System.Drawing.Size(82, 26);
            this.button185.TabIndex = 80;
            this.button185.Text = "button185";
            this.button185.UseVisualStyleBackColor = true;
            // 
            // panel45
            // 
            this.panel45.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel45.Controls.Add(this.button172);
            this.panel45.Controls.Add(this.button171);
            this.panel45.Controls.Add(this.button170);
            this.panel45.Controls.Add(this.button169);
            this.panel45.Location = new System.Drawing.Point(7, 168);
            this.panel45.Name = "panel45";
            this.panel45.Size = new System.Drawing.Size(360, 35);
            this.panel45.TabIndex = 21;
            // 
            // button172
            // 
            this.button172.BackColor = System.Drawing.Color.Aqua;
            this.button172.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button172.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button172.Location = new System.Drawing.Point(271, 4);
            this.button172.Name = "button172";
            this.button172.Size = new System.Drawing.Size(82, 26);
            this.button172.TabIndex = 82;
            this.button172.Text = "button172";
            this.button172.UseVisualStyleBackColor = false;
            // 
            // button171
            // 
            this.button171.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.button171.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button171.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button171.Location = new System.Drawing.Point(181, 4);
            this.button171.Name = "button171";
            this.button171.Size = new System.Drawing.Size(82, 26);
            this.button171.TabIndex = 81;
            this.button171.Text = "button171";
            this.button171.UseVisualStyleBackColor = false;
            // 
            // button170
            // 
            this.button170.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button170.Location = new System.Drawing.Point(92, 4);
            this.button170.Name = "button170";
            this.button170.Size = new System.Drawing.Size(82, 26);
            this.button170.TabIndex = 80;
            this.button170.Text = "button170";
            this.button170.UseVisualStyleBackColor = true;
            // 
            // button169
            // 
            this.button169.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button169.Location = new System.Drawing.Point(5, 4);
            this.button169.Name = "button169";
            this.button169.Size = new System.Drawing.Size(82, 26);
            this.button169.TabIndex = 79;
            this.button169.Text = "button169";
            this.button169.UseVisualStyleBackColor = true;
            // 
            // panel41
            // 
            this.panel41.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel41.Controls.Add(this.button156);
            this.panel41.Controls.Add(this.button155);
            this.panel41.Controls.Add(this.button154);
            this.panel41.Controls.Add(this.button153);
            this.panel41.Location = new System.Drawing.Point(7, 127);
            this.panel41.Name = "panel41";
            this.panel41.Size = new System.Drawing.Size(360, 35);
            this.panel41.TabIndex = 20;
            // 
            // button156
            // 
            this.button156.BackColor = System.Drawing.Color.Aqua;
            this.button156.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button156.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button156.Location = new System.Drawing.Point(271, -1);
            this.button156.Name = "button156";
            this.button156.Size = new System.Drawing.Size(82, 26);
            this.button156.TabIndex = 77;
            this.button156.Text = "button156";
            this.button156.UseVisualStyleBackColor = false;
            // 
            // button155
            // 
            this.button155.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.button155.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button155.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button155.Location = new System.Drawing.Point(181, 4);
            this.button155.Name = "button155";
            this.button155.Size = new System.Drawing.Size(82, 26);
            this.button155.TabIndex = 76;
            this.button155.Text = "button155";
            this.button155.UseVisualStyleBackColor = false;
            // 
            // button154
            // 
            this.button154.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button154.Location = new System.Drawing.Point(92, 3);
            this.button154.Name = "button154";
            this.button154.Size = new System.Drawing.Size(82, 26);
            this.button154.TabIndex = 75;
            this.button154.Text = "button154";
            this.button154.UseVisualStyleBackColor = true;
            // 
            // button153
            // 
            this.button153.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button153.Location = new System.Drawing.Point(5, 4);
            this.button153.Name = "button153";
            this.button153.Size = new System.Drawing.Size(82, 26);
            this.button153.TabIndex = 74;
            this.button153.Text = "button153";
            this.button153.UseVisualStyleBackColor = true;
            // 
            // panel37
            // 
            this.panel37.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel37.Controls.Add(this.button140);
            this.panel37.Controls.Add(this.button139);
            this.panel37.Controls.Add(this.button138);
            this.panel37.Controls.Add(this.button137);
            this.panel37.Location = new System.Drawing.Point(7, 86);
            this.panel37.Name = "panel37";
            this.panel37.Size = new System.Drawing.Size(360, 35);
            this.panel37.TabIndex = 19;
            // 
            // button140
            // 
            this.button140.BackColor = System.Drawing.Color.Aqua;
            this.button140.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button140.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button140.Location = new System.Drawing.Point(271, 4);
            this.button140.Name = "button140";
            this.button140.Size = new System.Drawing.Size(82, 26);
            this.button140.TabIndex = 72;
            this.button140.Text = "button140";
            this.button140.UseVisualStyleBackColor = false;
            // 
            // button139
            // 
            this.button139.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.button139.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button139.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button139.Location = new System.Drawing.Point(181, 3);
            this.button139.Name = "button139";
            this.button139.Size = new System.Drawing.Size(82, 26);
            this.button139.TabIndex = 71;
            this.button139.Text = "button139";
            this.button139.UseVisualStyleBackColor = false;
            // 
            // button138
            // 
            this.button138.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button138.Location = new System.Drawing.Point(92, 3);
            this.button138.Name = "button138";
            this.button138.Size = new System.Drawing.Size(82, 26);
            this.button138.TabIndex = 70;
            this.button138.Text = "button138";
            this.button138.UseVisualStyleBackColor = true;
            // 
            // button137
            // 
            this.button137.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button137.Location = new System.Drawing.Point(5, 4);
            this.button137.Name = "button137";
            this.button137.Size = new System.Drawing.Size(82, 26);
            this.button137.TabIndex = 69;
            this.button137.Text = "button137";
            this.button137.UseVisualStyleBackColor = true;
            // 
            // btnSCumlativeShiftB
            // 
            this.btnSCumlativeShiftB.BackColor = System.Drawing.Color.Black;
            this.btnSCumlativeShiftB.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSCumlativeShiftB.ForeColor = System.Drawing.Color.White;
            this.btnSCumlativeShiftB.Location = new System.Drawing.Point(277, 50);
            this.btnSCumlativeShiftB.Name = "btnSCumlativeShiftB";
            this.btnSCumlativeShiftB.Size = new System.Drawing.Size(83, 30);
            this.btnSCumlativeShiftB.TabIndex = 4;
            this.btnSCumlativeShiftB.Text = "H..";
            this.btnSCumlativeShiftB.UseVisualStyleBackColor = false;
            // 
            // btnSTotalShiftB
            // 
            this.btnSTotalShiftB.BackColor = System.Drawing.Color.Black;
            this.btnSTotalShiftB.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSTotalShiftB.ForeColor = System.Drawing.Color.White;
            this.btnSTotalShiftB.Location = new System.Drawing.Point(185, 50);
            this.btnSTotalShiftB.Name = "btnSTotalShiftB";
            this.btnSTotalShiftB.Size = new System.Drawing.Size(83, 30);
            this.btnSTotalShiftB.TabIndex = 3;
            this.btnSTotalShiftB.Text = "TOTAL";
            this.btnSTotalShiftB.UseVisualStyleBackColor = false;
            // 
            // btnS30ShiftB
            // 
            this.btnS30ShiftB.BackColor = System.Drawing.Color.Black;
            this.btnS30ShiftB.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnS30ShiftB.ForeColor = System.Drawing.Color.White;
            this.btnS30ShiftB.Location = new System.Drawing.Point(96, 50);
            this.btnS30ShiftB.Name = "btnS30ShiftB";
            this.btnS30ShiftB.Size = new System.Drawing.Size(83, 30);
            this.btnS30ShiftB.TabIndex = 2;
            this.btnS30ShiftB.Text = "S-30";
            this.btnS30ShiftB.UseVisualStyleBackColor = false;
            // 
            // btnS31ShiftB
            // 
            this.btnS31ShiftB.BackColor = System.Drawing.Color.Black;
            this.btnS31ShiftB.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnS31ShiftB.ForeColor = System.Drawing.Color.White;
            this.btnS31ShiftB.Location = new System.Drawing.Point(6, 50);
            this.btnS31ShiftB.Name = "btnS31ShiftB";
            this.btnS31ShiftB.Size = new System.Drawing.Size(83, 30);
            this.btnS31ShiftB.TabIndex = 1;
            this.btnS31ShiftB.Text = "S-31";
            this.btnS31ShiftB.UseVisualStyleBackColor = false;
            // 
            // btnSSugarShifB
            // 
            this.btnSSugarShifB.BackColor = System.Drawing.Color.Black;
            this.btnSSugarShifB.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSSugarShifB.ForeColor = System.Drawing.Color.White;
            this.btnSSugarShifB.Location = new System.Drawing.Point(4, 10);
            this.btnSSugarShifB.Name = "btnSSugarShifB";
            this.btnSSugarShifB.Size = new System.Drawing.Size(357, 34);
            this.btnSSugarShifB.TabIndex = 0;
            this.btnSSugarShifB.Text = "SMALL SUGAR";
            this.btnSSugarShifB.UseVisualStyleBackColor = false;
            // 
            // groupBox10
            // 
            this.groupBox10.Controls.Add(this.panel64);
            this.groupBox10.Controls.Add(this.panel60);
            this.groupBox10.Controls.Add(this.panel56);
            this.groupBox10.Controls.Add(this.panel52);
            this.groupBox10.Controls.Add(this.panel48);
            this.groupBox10.Controls.Add(this.panel44);
            this.groupBox10.Controls.Add(this.panel40);
            this.groupBox10.Controls.Add(this.panel36);
            this.groupBox10.Controls.Add(this.btnMCumlativeShiftB);
            this.groupBox10.Controls.Add(this.btnMTotalShiftB);
            this.groupBox10.Controls.Add(this.btnM30ShiftB);
            this.groupBox10.Controls.Add(this.btnM31ShiftB);
            this.groupBox10.Controls.Add(this.btnMSugarShifB);
            this.groupBox10.Location = new System.Drawing.Point(484, 47);
            this.groupBox10.Name = "groupBox10";
            this.groupBox10.Size = new System.Drawing.Size(383, 425);
            this.groupBox10.TabIndex = 7;
            this.groupBox10.TabStop = false;
            // 
            // panel64
            // 
            this.panel64.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel64.Controls.Add(this.button248);
            this.panel64.Controls.Add(this.button247);
            this.panel64.Controls.Add(this.button246);
            this.panel64.Controls.Add(this.button245);
            this.panel64.Location = new System.Drawing.Point(7, 373);
            this.panel64.Name = "panel64";
            this.panel64.Size = new System.Drawing.Size(360, 35);
            this.panel64.TabIndex = 25;
            // 
            // button248
            // 
            this.button248.BackColor = System.Drawing.Color.Aqua;
            this.button248.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button248.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button248.Location = new System.Drawing.Point(273, 3);
            this.button248.Name = "button248";
            this.button248.Size = new System.Drawing.Size(82, 26);
            this.button248.TabIndex = 83;
            this.button248.Text = "button248";
            this.button248.UseVisualStyleBackColor = false;
            // 
            // button247
            // 
            this.button247.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.button247.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button247.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button247.Location = new System.Drawing.Point(185, 3);
            this.button247.Name = "button247";
            this.button247.Size = new System.Drawing.Size(82, 26);
            this.button247.TabIndex = 82;
            this.button247.Text = "button247";
            this.button247.UseVisualStyleBackColor = false;
            // 
            // button246
            // 
            this.button246.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button246.Location = new System.Drawing.Point(93, 3);
            this.button246.Name = "button246";
            this.button246.Size = new System.Drawing.Size(82, 26);
            this.button246.TabIndex = 81;
            this.button246.Text = "button246";
            this.button246.UseVisualStyleBackColor = true;
            // 
            // button245
            // 
            this.button245.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button245.Location = new System.Drawing.Point(3, 3);
            this.button245.Name = "button245";
            this.button245.Size = new System.Drawing.Size(82, 26);
            this.button245.TabIndex = 80;
            this.button245.Text = "button245";
            this.button245.UseVisualStyleBackColor = true;
            // 
            // panel60
            // 
            this.panel60.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel60.Controls.Add(this.button232);
            this.panel60.Controls.Add(this.button231);
            this.panel60.Controls.Add(this.button230);
            this.panel60.Controls.Add(this.button229);
            this.panel60.Location = new System.Drawing.Point(7, 332);
            this.panel60.Name = "panel60";
            this.panel60.Size = new System.Drawing.Size(360, 35);
            this.panel60.TabIndex = 24;
            // 
            // button232
            // 
            this.button232.BackColor = System.Drawing.Color.Aqua;
            this.button232.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button232.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button232.Location = new System.Drawing.Point(273, 3);
            this.button232.Name = "button232";
            this.button232.Size = new System.Drawing.Size(82, 26);
            this.button232.TabIndex = 82;
            this.button232.Text = "button232";
            this.button232.UseVisualStyleBackColor = false;
            // 
            // button231
            // 
            this.button231.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.button231.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button231.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button231.Location = new System.Drawing.Point(185, 3);
            this.button231.Name = "button231";
            this.button231.Size = new System.Drawing.Size(82, 26);
            this.button231.TabIndex = 81;
            this.button231.Text = "button231";
            this.button231.UseVisualStyleBackColor = false;
            // 
            // button230
            // 
            this.button230.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button230.Location = new System.Drawing.Point(93, 3);
            this.button230.Name = "button230";
            this.button230.Size = new System.Drawing.Size(82, 26);
            this.button230.TabIndex = 80;
            this.button230.Text = "button230";
            this.button230.UseVisualStyleBackColor = true;
            // 
            // button229
            // 
            this.button229.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button229.Location = new System.Drawing.Point(3, 3);
            this.button229.Name = "button229";
            this.button229.Size = new System.Drawing.Size(82, 26);
            this.button229.TabIndex = 79;
            this.button229.Text = "button229";
            this.button229.UseVisualStyleBackColor = true;
            // 
            // panel56
            // 
            this.panel56.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel56.Controls.Add(this.button216);
            this.panel56.Controls.Add(this.button215);
            this.panel56.Controls.Add(this.button214);
            this.panel56.Controls.Add(this.button213);
            this.panel56.Location = new System.Drawing.Point(7, 291);
            this.panel56.Name = "panel56";
            this.panel56.Size = new System.Drawing.Size(360, 35);
            this.panel56.TabIndex = 23;
            // 
            // button216
            // 
            this.button216.BackColor = System.Drawing.Color.Aqua;
            this.button216.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button216.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button216.Location = new System.Drawing.Point(273, 3);
            this.button216.Name = "button216";
            this.button216.Size = new System.Drawing.Size(82, 26);
            this.button216.TabIndex = 81;
            this.button216.Text = "button216";
            this.button216.UseVisualStyleBackColor = false;
            // 
            // button215
            // 
            this.button215.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.button215.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button215.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button215.Location = new System.Drawing.Point(185, 3);
            this.button215.Name = "button215";
            this.button215.Size = new System.Drawing.Size(82, 26);
            this.button215.TabIndex = 80;
            this.button215.Text = "button215";
            this.button215.UseVisualStyleBackColor = false;
            // 
            // button214
            // 
            this.button214.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button214.Location = new System.Drawing.Point(93, 3);
            this.button214.Name = "button214";
            this.button214.Size = new System.Drawing.Size(82, 26);
            this.button214.TabIndex = 79;
            this.button214.Text = "button214";
            this.button214.UseVisualStyleBackColor = true;
            // 
            // button213
            // 
            this.button213.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button213.Location = new System.Drawing.Point(3, 3);
            this.button213.Name = "button213";
            this.button213.Size = new System.Drawing.Size(82, 26);
            this.button213.TabIndex = 78;
            this.button213.Text = "button213";
            this.button213.UseVisualStyleBackColor = true;
            // 
            // panel52
            // 
            this.panel52.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel52.Controls.Add(this.button200);
            this.panel52.Controls.Add(this.button199);
            this.panel52.Controls.Add(this.button198);
            this.panel52.Controls.Add(this.button197);
            this.panel52.Location = new System.Drawing.Point(7, 250);
            this.panel52.Name = "panel52";
            this.panel52.Size = new System.Drawing.Size(360, 35);
            this.panel52.TabIndex = 22;
            // 
            // button200
            // 
            this.button200.BackColor = System.Drawing.Color.Aqua;
            this.button200.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button200.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button200.Location = new System.Drawing.Point(273, 4);
            this.button200.Name = "button200";
            this.button200.Size = new System.Drawing.Size(82, 26);
            this.button200.TabIndex = 80;
            this.button200.Text = "button200";
            this.button200.UseVisualStyleBackColor = false;
            // 
            // button199
            // 
            this.button199.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.button199.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button199.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button199.Location = new System.Drawing.Point(185, 4);
            this.button199.Name = "button199";
            this.button199.Size = new System.Drawing.Size(82, 26);
            this.button199.TabIndex = 79;
            this.button199.Text = "button199";
            this.button199.UseVisualStyleBackColor = false;
            // 
            // button198
            // 
            this.button198.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button198.Location = new System.Drawing.Point(93, 3);
            this.button198.Name = "button198";
            this.button198.Size = new System.Drawing.Size(82, 26);
            this.button198.TabIndex = 78;
            this.button198.Text = "button198";
            this.button198.UseVisualStyleBackColor = true;
            // 
            // button197
            // 
            this.button197.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button197.Location = new System.Drawing.Point(3, 3);
            this.button197.Name = "button197";
            this.button197.Size = new System.Drawing.Size(82, 26);
            this.button197.TabIndex = 77;
            this.button197.Text = "button197";
            this.button197.UseVisualStyleBackColor = true;
            // 
            // panel48
            // 
            this.panel48.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel48.Controls.Add(this.button184);
            this.panel48.Controls.Add(this.button183);
            this.panel48.Controls.Add(this.button182);
            this.panel48.Controls.Add(this.button181);
            this.panel48.Location = new System.Drawing.Point(7, 209);
            this.panel48.Name = "panel48";
            this.panel48.Size = new System.Drawing.Size(360, 35);
            this.panel48.TabIndex = 21;
            // 
            // button184
            // 
            this.button184.BackColor = System.Drawing.Color.Aqua;
            this.button184.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button184.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button184.Location = new System.Drawing.Point(273, 4);
            this.button184.Name = "button184";
            this.button184.Size = new System.Drawing.Size(82, 26);
            this.button184.TabIndex = 79;
            this.button184.Text = "button184";
            this.button184.UseVisualStyleBackColor = false;
            // 
            // button183
            // 
            this.button183.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.button183.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button183.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button183.Location = new System.Drawing.Point(185, 3);
            this.button183.Name = "button183";
            this.button183.Size = new System.Drawing.Size(82, 26);
            this.button183.TabIndex = 78;
            this.button183.Text = "button183";
            this.button183.UseVisualStyleBackColor = false;
            // 
            // button182
            // 
            this.button182.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button182.Location = new System.Drawing.Point(93, 4);
            this.button182.Name = "button182";
            this.button182.Size = new System.Drawing.Size(82, 26);
            this.button182.TabIndex = 77;
            this.button182.Text = "button182";
            this.button182.UseVisualStyleBackColor = true;
            // 
            // button181
            // 
            this.button181.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button181.Location = new System.Drawing.Point(3, 4);
            this.button181.Name = "button181";
            this.button181.Size = new System.Drawing.Size(82, 26);
            this.button181.TabIndex = 76;
            this.button181.Text = "button181";
            this.button181.UseVisualStyleBackColor = true;
            // 
            // panel44
            // 
            this.panel44.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel44.Controls.Add(this.button168);
            this.panel44.Controls.Add(this.button167);
            this.panel44.Controls.Add(this.button166);
            this.panel44.Controls.Add(this.button165);
            this.panel44.Location = new System.Drawing.Point(7, 168);
            this.panel44.Name = "panel44";
            this.panel44.Size = new System.Drawing.Size(360, 35);
            this.panel44.TabIndex = 20;
            // 
            // button168
            // 
            this.button168.BackColor = System.Drawing.Color.Aqua;
            this.button168.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button168.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button168.Location = new System.Drawing.Point(273, 4);
            this.button168.Name = "button168";
            this.button168.Size = new System.Drawing.Size(82, 26);
            this.button168.TabIndex = 78;
            this.button168.Text = "button168";
            this.button168.UseVisualStyleBackColor = false;
            // 
            // button167
            // 
            this.button167.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.button167.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button167.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button167.Location = new System.Drawing.Point(185, 4);
            this.button167.Name = "button167";
            this.button167.Size = new System.Drawing.Size(82, 26);
            this.button167.TabIndex = 77;
            this.button167.Text = "button167";
            this.button167.UseVisualStyleBackColor = false;
            // 
            // button166
            // 
            this.button166.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button166.Location = new System.Drawing.Point(93, 4);
            this.button166.Name = "button166";
            this.button166.Size = new System.Drawing.Size(82, 26);
            this.button166.TabIndex = 76;
            this.button166.Text = "button166";
            this.button166.UseVisualStyleBackColor = true;
            // 
            // button165
            // 
            this.button165.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button165.Location = new System.Drawing.Point(3, 4);
            this.button165.Name = "button165";
            this.button165.Size = new System.Drawing.Size(82, 26);
            this.button165.TabIndex = 75;
            this.button165.Text = "button165";
            this.button165.UseVisualStyleBackColor = true;
            // 
            // panel40
            // 
            this.panel40.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel40.Controls.Add(this.button152);
            this.panel40.Controls.Add(this.button151);
            this.panel40.Controls.Add(this.button150);
            this.panel40.Controls.Add(this.button149);
            this.panel40.Location = new System.Drawing.Point(7, 127);
            this.panel40.Name = "panel40";
            this.panel40.Size = new System.Drawing.Size(360, 35);
            this.panel40.TabIndex = 19;
            // 
            // button152
            // 
            this.button152.BackColor = System.Drawing.Color.Aqua;
            this.button152.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button152.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button152.Location = new System.Drawing.Point(273, 4);
            this.button152.Name = "button152";
            this.button152.Size = new System.Drawing.Size(82, 26);
            this.button152.TabIndex = 73;
            this.button152.Text = "button152";
            this.button152.UseVisualStyleBackColor = false;
            // 
            // button151
            // 
            this.button151.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.button151.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button151.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button151.Location = new System.Drawing.Point(185, 4);
            this.button151.Name = "button151";
            this.button151.Size = new System.Drawing.Size(82, 26);
            this.button151.TabIndex = 72;
            this.button151.Text = "button151";
            this.button151.UseVisualStyleBackColor = false;
            // 
            // button150
            // 
            this.button150.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button150.Location = new System.Drawing.Point(93, 4);
            this.button150.Name = "button150";
            this.button150.Size = new System.Drawing.Size(82, 26);
            this.button150.TabIndex = 71;
            this.button150.Text = "button150";
            this.button150.UseVisualStyleBackColor = true;
            // 
            // button149
            // 
            this.button149.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button149.Location = new System.Drawing.Point(3, 4);
            this.button149.Name = "button149";
            this.button149.Size = new System.Drawing.Size(82, 26);
            this.button149.TabIndex = 70;
            this.button149.Text = "button149";
            this.button149.UseVisualStyleBackColor = true;
            // 
            // panel36
            // 
            this.panel36.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel36.Controls.Add(this.button136);
            this.panel36.Controls.Add(this.button135);
            this.panel36.Controls.Add(this.button134);
            this.panel36.Controls.Add(this.button133);
            this.panel36.Location = new System.Drawing.Point(7, 86);
            this.panel36.Name = "panel36";
            this.panel36.Size = new System.Drawing.Size(360, 35);
            this.panel36.TabIndex = 18;
            // 
            // button136
            // 
            this.button136.BackColor = System.Drawing.Color.Aqua;
            this.button136.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button136.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button136.Location = new System.Drawing.Point(273, 4);
            this.button136.Name = "button136";
            this.button136.Size = new System.Drawing.Size(82, 26);
            this.button136.TabIndex = 72;
            this.button136.Text = "button136";
            this.button136.UseVisualStyleBackColor = false;
            // 
            // button135
            // 
            this.button135.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.button135.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button135.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button135.Location = new System.Drawing.Point(185, 3);
            this.button135.Name = "button135";
            this.button135.Size = new System.Drawing.Size(82, 26);
            this.button135.TabIndex = 71;
            this.button135.Text = "button135";
            this.button135.UseVisualStyleBackColor = false;
            // 
            // button134
            // 
            this.button134.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button134.Location = new System.Drawing.Point(93, 4);
            this.button134.Name = "button134";
            this.button134.Size = new System.Drawing.Size(82, 26);
            this.button134.TabIndex = 70;
            this.button134.Text = "button134";
            this.button134.UseVisualStyleBackColor = true;
            // 
            // button133
            // 
            this.button133.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button133.Location = new System.Drawing.Point(3, 4);
            this.button133.Name = "button133";
            this.button133.Size = new System.Drawing.Size(82, 26);
            this.button133.TabIndex = 69;
            this.button133.Text = "button133";
            this.button133.UseVisualStyleBackColor = true;
            // 
            // btnMCumlativeShiftB
            // 
            this.btnMCumlativeShiftB.BackColor = System.Drawing.Color.Black;
            this.btnMCumlativeShiftB.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnMCumlativeShiftB.ForeColor = System.Drawing.Color.White;
            this.btnMCumlativeShiftB.Location = new System.Drawing.Point(276, 50);
            this.btnMCumlativeShiftB.Name = "btnMCumlativeShiftB";
            this.btnMCumlativeShiftB.Size = new System.Drawing.Size(83, 30);
            this.btnMCumlativeShiftB.TabIndex = 4;
            this.btnMCumlativeShiftB.Text = "H..";
            this.btnMCumlativeShiftB.UseVisualStyleBackColor = false;
            // 
            // btnMTotalShiftB
            // 
            this.btnMTotalShiftB.BackColor = System.Drawing.Color.Black;
            this.btnMTotalShiftB.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnMTotalShiftB.ForeColor = System.Drawing.Color.White;
            this.btnMTotalShiftB.Location = new System.Drawing.Point(184, 50);
            this.btnMTotalShiftB.Name = "btnMTotalShiftB";
            this.btnMTotalShiftB.Size = new System.Drawing.Size(83, 30);
            this.btnMTotalShiftB.TabIndex = 3;
            this.btnMTotalShiftB.Text = "TOTAL";
            this.btnMTotalShiftB.UseVisualStyleBackColor = false;
            // 
            // btnM30ShiftB
            // 
            this.btnM30ShiftB.BackColor = System.Drawing.Color.Black;
            this.btnM30ShiftB.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnM30ShiftB.ForeColor = System.Drawing.Color.White;
            this.btnM30ShiftB.Location = new System.Drawing.Point(99, 50);
            this.btnM30ShiftB.Name = "btnM30ShiftB";
            this.btnM30ShiftB.Size = new System.Drawing.Size(83, 30);
            this.btnM30ShiftB.TabIndex = 2;
            this.btnM30ShiftB.Text = "M-30";
            this.btnM30ShiftB.UseVisualStyleBackColor = false;
            // 
            // btnM31ShiftB
            // 
            this.btnM31ShiftB.BackColor = System.Drawing.Color.Black;
            this.btnM31ShiftB.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnM31ShiftB.ForeColor = System.Drawing.Color.White;
            this.btnM31ShiftB.Location = new System.Drawing.Point(6, 50);
            this.btnM31ShiftB.Name = "btnM31ShiftB";
            this.btnM31ShiftB.Size = new System.Drawing.Size(83, 30);
            this.btnM31ShiftB.TabIndex = 1;
            this.btnM31ShiftB.Text = "M-31";
            this.btnM31ShiftB.UseVisualStyleBackColor = false;
            // 
            // btnMSugarShifB
            // 
            this.btnMSugarShifB.BackColor = System.Drawing.Color.Black;
            this.btnMSugarShifB.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnMSugarShifB.ForeColor = System.Drawing.Color.White;
            this.btnMSugarShifB.Location = new System.Drawing.Point(4, 10);
            this.btnMSugarShifB.Name = "btnMSugarShifB";
            this.btnMSugarShifB.Size = new System.Drawing.Size(357, 34);
            this.btnMSugarShifB.TabIndex = 0;
            this.btnMSugarShifB.Text = "MEDIUM SUGAR";
            this.btnMSugarShifB.UseVisualStyleBackColor = false;
            // 
            // groupBox11
            // 
            this.groupBox11.Controls.Add(this.btnTime17);
            this.groupBox11.Controls.Add(this.btnTime24);
            this.groupBox11.Controls.Add(this.btnTime23);
            this.groupBox11.Controls.Add(this.btnTime22);
            this.groupBox11.Controls.Add(this.btnTime21);
            this.groupBox11.Controls.Add(this.btnTime20);
            this.groupBox11.Controls.Add(this.btnTime19);
            this.groupBox11.Controls.Add(this.btnTime18);
            this.groupBox11.Controls.Add(this.btnHeaderTimeShiftB);
            this.groupBox11.Location = new System.Drawing.Point(16, 47);
            this.groupBox11.Name = "groupBox11";
            this.groupBox11.Size = new System.Drawing.Size(73, 425);
            this.groupBox11.TabIndex = 6;
            this.groupBox11.TabStop = false;
            // 
            // btnTime17
            // 
            this.btnTime17.Location = new System.Drawing.Point(4, 86);
            this.btnTime17.Name = "btnTime17";
            this.btnTime17.Size = new System.Drawing.Size(48, 35);
            this.btnTime17.TabIndex = 5;
            this.btnTime17.Text = "17";
            this.btnTime17.UseVisualStyleBackColor = true;
            // 
            // btnTime24
            // 
            this.btnTime24.Location = new System.Drawing.Point(5, 373);
            this.btnTime24.Name = "btnTime24";
            this.btnTime24.Size = new System.Drawing.Size(48, 35);
            this.btnTime24.TabIndex = 10;
            this.btnTime24.Text = "24";
            this.btnTime24.UseVisualStyleBackColor = true;
            // 
            // btnTime23
            // 
            this.btnTime23.Location = new System.Drawing.Point(6, 332);
            this.btnTime23.Name = "btnTime23";
            this.btnTime23.Size = new System.Drawing.Size(48, 35);
            this.btnTime23.TabIndex = 6;
            this.btnTime23.Text = "23";
            this.btnTime23.UseVisualStyleBackColor = true;
            // 
            // btnTime22
            // 
            this.btnTime22.Location = new System.Drawing.Point(4, 291);
            this.btnTime22.Name = "btnTime22";
            this.btnTime22.Size = new System.Drawing.Size(48, 35);
            this.btnTime22.TabIndex = 9;
            this.btnTime22.Text = "22";
            this.btnTime22.UseVisualStyleBackColor = true;
            // 
            // btnTime21
            // 
            this.btnTime21.Location = new System.Drawing.Point(6, 250);
            this.btnTime21.Name = "btnTime21";
            this.btnTime21.Size = new System.Drawing.Size(48, 35);
            this.btnTime21.TabIndex = 8;
            this.btnTime21.Text = "21";
            this.btnTime21.UseVisualStyleBackColor = true;
            // 
            // btnTime20
            // 
            this.btnTime20.Location = new System.Drawing.Point(5, 209);
            this.btnTime20.Name = "btnTime20";
            this.btnTime20.Size = new System.Drawing.Size(48, 35);
            this.btnTime20.TabIndex = 7;
            this.btnTime20.Text = "20";
            this.btnTime20.UseVisualStyleBackColor = true;
            // 
            // btnTime19
            // 
            this.btnTime19.Location = new System.Drawing.Point(6, 168);
            this.btnTime19.Name = "btnTime19";
            this.btnTime19.Size = new System.Drawing.Size(48, 35);
            this.btnTime19.TabIndex = 6;
            this.btnTime19.Text = "19";
            this.btnTime19.UseVisualStyleBackColor = true;
            // 
            // btnTime18
            // 
            this.btnTime18.Location = new System.Drawing.Point(4, 127);
            this.btnTime18.Name = "btnTime18";
            this.btnTime18.Size = new System.Drawing.Size(48, 35);
            this.btnTime18.TabIndex = 6;
            this.btnTime18.Text = "18";
            this.btnTime18.UseVisualStyleBackColor = true;
            // 
            // btnHeaderTimeShiftB
            // 
            this.btnHeaderTimeShiftB.Location = new System.Drawing.Point(6, 10);
            this.btnHeaderTimeShiftB.Name = "btnHeaderTimeShiftB";
            this.btnHeaderTimeShiftB.Size = new System.Drawing.Size(61, 70);
            this.btnHeaderTimeShiftB.TabIndex = 5;
            this.btnHeaderTimeShiftB.Text = "TIME";
            this.btnHeaderTimeShiftB.UseVisualStyleBackColor = true;
            // 
            // groupBox12
            // 
            this.groupBox12.Controls.Add(this.panel63);
            this.groupBox12.Controls.Add(this.panel59);
            this.groupBox12.Controls.Add(this.panel55);
            this.groupBox12.Controls.Add(this.panel51);
            this.groupBox12.Controls.Add(this.panel47);
            this.groupBox12.Controls.Add(this.panel43);
            this.groupBox12.Controls.Add(this.panel39);
            this.groupBox12.Controls.Add(this.panel35);
            this.groupBox12.Controls.Add(this.btnLCumlativeShiftB);
            this.groupBox12.Controls.Add(this.btnLTotalShiftB);
            this.groupBox12.Controls.Add(this.btnL30ShiftB);
            this.groupBox12.Controls.Add(this.btnL31ShiftB);
            this.groupBox12.Controls.Add(this.btnLargeSugarShiftB);
            this.groupBox12.Location = new System.Drawing.Point(95, 47);
            this.groupBox12.Name = "groupBox12";
            this.groupBox12.Size = new System.Drawing.Size(383, 425);
            this.groupBox12.TabIndex = 4;
            this.groupBox12.TabStop = false;
            // 
            // panel63
            // 
            this.panel63.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel63.Controls.Add(this.button244);
            this.panel63.Controls.Add(this.button243);
            this.panel63.Controls.Add(this.button242);
            this.panel63.Controls.Add(this.button241);
            this.panel63.Location = new System.Drawing.Point(4, 373);
            this.panel63.Name = "panel63";
            this.panel63.Size = new System.Drawing.Size(360, 35);
            this.panel63.TabIndex = 24;
            // 
            // button244
            // 
            this.button244.BackColor = System.Drawing.Color.Aqua;
            this.button244.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button244.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button244.Location = new System.Drawing.Point(272, 3);
            this.button244.Name = "button244";
            this.button244.Size = new System.Drawing.Size(82, 26);
            this.button244.TabIndex = 79;
            this.button244.Text = "button244";
            this.button244.UseVisualStyleBackColor = false;
            // 
            // button243
            // 
            this.button243.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.button243.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button243.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button243.Location = new System.Drawing.Point(181, 3);
            this.button243.Name = "button243";
            this.button243.Size = new System.Drawing.Size(82, 26);
            this.button243.TabIndex = 78;
            this.button243.Text = "button243";
            this.button243.UseVisualStyleBackColor = false;
            // 
            // button242
            // 
            this.button242.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button242.Location = new System.Drawing.Point(95, 3);
            this.button242.Name = "button242";
            this.button242.Size = new System.Drawing.Size(82, 26);
            this.button242.TabIndex = 77;
            this.button242.Text = "button242";
            this.button242.UseVisualStyleBackColor = true;
            // 
            // button241
            // 
            this.button241.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button241.Location = new System.Drawing.Point(5, 3);
            this.button241.Name = "button241";
            this.button241.Size = new System.Drawing.Size(82, 26);
            this.button241.TabIndex = 76;
            this.button241.Text = "button241";
            this.button241.UseVisualStyleBackColor = true;
            // 
            // panel59
            // 
            this.panel59.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel59.Controls.Add(this.button228);
            this.panel59.Controls.Add(this.button227);
            this.panel59.Controls.Add(this.button226);
            this.panel59.Controls.Add(this.button225);
            this.panel59.Location = new System.Drawing.Point(4, 332);
            this.panel59.Name = "panel59";
            this.panel59.Size = new System.Drawing.Size(360, 35);
            this.panel59.TabIndex = 23;
            // 
            // button228
            // 
            this.button228.BackColor = System.Drawing.Color.Aqua;
            this.button228.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button228.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button228.Location = new System.Drawing.Point(272, 3);
            this.button228.Name = "button228";
            this.button228.Size = new System.Drawing.Size(82, 26);
            this.button228.TabIndex = 78;
            this.button228.Text = "button228";
            this.button228.UseVisualStyleBackColor = false;
            // 
            // button227
            // 
            this.button227.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.button227.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button227.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button227.Location = new System.Drawing.Point(181, 3);
            this.button227.Name = "button227";
            this.button227.Size = new System.Drawing.Size(82, 26);
            this.button227.TabIndex = 77;
            this.button227.Text = "button227";
            this.button227.UseVisualStyleBackColor = false;
            // 
            // button226
            // 
            this.button226.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button226.Location = new System.Drawing.Point(95, 3);
            this.button226.Name = "button226";
            this.button226.Size = new System.Drawing.Size(82, 26);
            this.button226.TabIndex = 76;
            this.button226.Text = "button226";
            this.button226.UseVisualStyleBackColor = true;
            // 
            // button225
            // 
            this.button225.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button225.Location = new System.Drawing.Point(5, 3);
            this.button225.Name = "button225";
            this.button225.Size = new System.Drawing.Size(82, 26);
            this.button225.TabIndex = 75;
            this.button225.Text = "button225";
            this.button225.UseVisualStyleBackColor = true;
            // 
            // panel55
            // 
            this.panel55.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel55.Controls.Add(this.button212);
            this.panel55.Controls.Add(this.button211);
            this.panel55.Controls.Add(this.button210);
            this.panel55.Controls.Add(this.button209);
            this.panel55.Location = new System.Drawing.Point(6, 291);
            this.panel55.Name = "panel55";
            this.panel55.Size = new System.Drawing.Size(360, 35);
            this.panel55.TabIndex = 22;
            // 
            // button212
            // 
            this.button212.BackColor = System.Drawing.Color.Aqua;
            this.button212.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button212.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button212.Location = new System.Drawing.Point(272, 3);
            this.button212.Name = "button212";
            this.button212.Size = new System.Drawing.Size(82, 26);
            this.button212.TabIndex = 77;
            this.button212.Text = "button212";
            this.button212.UseVisualStyleBackColor = false;
            // 
            // button211
            // 
            this.button211.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.button211.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button211.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button211.Location = new System.Drawing.Point(181, 3);
            this.button211.Name = "button211";
            this.button211.Size = new System.Drawing.Size(82, 26);
            this.button211.TabIndex = 76;
            this.button211.Text = "button211";
            this.button211.UseVisualStyleBackColor = false;
            // 
            // button210
            // 
            this.button210.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button210.Location = new System.Drawing.Point(95, 3);
            this.button210.Name = "button210";
            this.button210.Size = new System.Drawing.Size(82, 26);
            this.button210.TabIndex = 75;
            this.button210.Text = "button210";
            this.button210.UseVisualStyleBackColor = true;
            // 
            // button209
            // 
            this.button209.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button209.Location = new System.Drawing.Point(5, 3);
            this.button209.Name = "button209";
            this.button209.Size = new System.Drawing.Size(82, 26);
            this.button209.TabIndex = 74;
            this.button209.Text = "button209";
            this.button209.UseVisualStyleBackColor = true;
            // 
            // panel51
            // 
            this.panel51.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel51.Controls.Add(this.button196);
            this.panel51.Controls.Add(this.button195);
            this.panel51.Controls.Add(this.button194);
            this.panel51.Controls.Add(this.button193);
            this.panel51.Location = new System.Drawing.Point(6, 250);
            this.panel51.Name = "panel51";
            this.panel51.Size = new System.Drawing.Size(360, 35);
            this.panel51.TabIndex = 21;
            // 
            // button196
            // 
            this.button196.BackColor = System.Drawing.Color.Aqua;
            this.button196.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button196.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button196.Location = new System.Drawing.Point(272, 3);
            this.button196.Name = "button196";
            this.button196.Size = new System.Drawing.Size(82, 26);
            this.button196.TabIndex = 76;
            this.button196.Text = "button196";
            this.button196.UseVisualStyleBackColor = false;
            // 
            // button195
            // 
            this.button195.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.button195.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button195.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button195.Location = new System.Drawing.Point(181, 3);
            this.button195.Name = "button195";
            this.button195.Size = new System.Drawing.Size(82, 26);
            this.button195.TabIndex = 75;
            this.button195.Text = "button195";
            this.button195.UseVisualStyleBackColor = false;
            // 
            // button194
            // 
            this.button194.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button194.Location = new System.Drawing.Point(95, 8);
            this.button194.Name = "button194";
            this.button194.Size = new System.Drawing.Size(82, 26);
            this.button194.TabIndex = 74;
            this.button194.Text = "button194";
            this.button194.UseVisualStyleBackColor = true;
            // 
            // button193
            // 
            this.button193.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button193.Location = new System.Drawing.Point(5, 4);
            this.button193.Name = "button193";
            this.button193.Size = new System.Drawing.Size(82, 26);
            this.button193.TabIndex = 73;
            this.button193.Text = "button193";
            this.button193.UseVisualStyleBackColor = true;
            // 
            // panel47
            // 
            this.panel47.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel47.Controls.Add(this.button180);
            this.panel47.Controls.Add(this.button179);
            this.panel47.Controls.Add(this.button178);
            this.panel47.Controls.Add(this.button177);
            this.panel47.Location = new System.Drawing.Point(7, 209);
            this.panel47.Name = "panel47";
            this.panel47.Size = new System.Drawing.Size(360, 35);
            this.panel47.TabIndex = 20;
            // 
            // button180
            // 
            this.button180.BackColor = System.Drawing.Color.Aqua;
            this.button180.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button180.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button180.Location = new System.Drawing.Point(272, 3);
            this.button180.Name = "button180";
            this.button180.Size = new System.Drawing.Size(82, 26);
            this.button180.TabIndex = 75;
            this.button180.Text = "button180";
            this.button180.UseVisualStyleBackColor = false;
            // 
            // button179
            // 
            this.button179.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.button179.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button179.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button179.Location = new System.Drawing.Point(181, 3);
            this.button179.Name = "button179";
            this.button179.Size = new System.Drawing.Size(82, 26);
            this.button179.TabIndex = 74;
            this.button179.Text = "button179";
            this.button179.UseVisualStyleBackColor = false;
            // 
            // button178
            // 
            this.button178.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button178.Location = new System.Drawing.Point(95, 3);
            this.button178.Name = "button178";
            this.button178.Size = new System.Drawing.Size(82, 26);
            this.button178.TabIndex = 73;
            this.button178.Text = "button178";
            this.button178.UseVisualStyleBackColor = true;
            // 
            // button177
            // 
            this.button177.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button177.Location = new System.Drawing.Point(5, 4);
            this.button177.Name = "button177";
            this.button177.Size = new System.Drawing.Size(82, 26);
            this.button177.TabIndex = 72;
            this.button177.Text = "button177";
            this.button177.UseVisualStyleBackColor = true;
            // 
            // panel43
            // 
            this.panel43.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel43.Controls.Add(this.button164);
            this.panel43.Controls.Add(this.button163);
            this.panel43.Controls.Add(this.button162);
            this.panel43.Controls.Add(this.button161);
            this.panel43.Location = new System.Drawing.Point(7, 168);
            this.panel43.Name = "panel43";
            this.panel43.Size = new System.Drawing.Size(360, 35);
            this.panel43.TabIndex = 19;
            // 
            // button164
            // 
            this.button164.BackColor = System.Drawing.Color.Aqua;
            this.button164.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button164.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button164.Location = new System.Drawing.Point(272, 4);
            this.button164.Name = "button164";
            this.button164.Size = new System.Drawing.Size(82, 26);
            this.button164.TabIndex = 74;
            this.button164.Text = "button164";
            this.button164.UseVisualStyleBackColor = false;
            // 
            // button163
            // 
            this.button163.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.button163.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button163.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button163.Location = new System.Drawing.Point(181, 3);
            this.button163.Name = "button163";
            this.button163.Size = new System.Drawing.Size(82, 26);
            this.button163.TabIndex = 73;
            this.button163.Text = "button163";
            this.button163.UseVisualStyleBackColor = false;
            // 
            // button162
            // 
            this.button162.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button162.Location = new System.Drawing.Point(95, 4);
            this.button162.Name = "button162";
            this.button162.Size = new System.Drawing.Size(82, 26);
            this.button162.TabIndex = 72;
            this.button162.Text = "button162";
            this.button162.UseVisualStyleBackColor = true;
            // 
            // button161
            // 
            this.button161.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button161.Location = new System.Drawing.Point(5, 4);
            this.button161.Name = "button161";
            this.button161.Size = new System.Drawing.Size(82, 26);
            this.button161.TabIndex = 71;
            this.button161.Text = "button161";
            this.button161.UseVisualStyleBackColor = true;
            // 
            // panel39
            // 
            this.panel39.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel39.Controls.Add(this.button148);
            this.panel39.Controls.Add(this.button147);
            this.panel39.Controls.Add(this.button146);
            this.panel39.Controls.Add(this.button145);
            this.panel39.Location = new System.Drawing.Point(6, 127);
            this.panel39.Name = "panel39";
            this.panel39.Size = new System.Drawing.Size(360, 35);
            this.panel39.TabIndex = 18;
            // 
            // button148
            // 
            this.button148.BackColor = System.Drawing.Color.Aqua;
            this.button148.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button148.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button148.Location = new System.Drawing.Point(272, 3);
            this.button148.Name = "button148";
            this.button148.Size = new System.Drawing.Size(82, 26);
            this.button148.TabIndex = 73;
            this.button148.Text = "button148";
            this.button148.UseVisualStyleBackColor = false;
            // 
            // button147
            // 
            this.button147.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.button147.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button147.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button147.Location = new System.Drawing.Point(181, 4);
            this.button147.Name = "button147";
            this.button147.Size = new System.Drawing.Size(82, 26);
            this.button147.TabIndex = 72;
            this.button147.Text = "button147";
            this.button147.UseVisualStyleBackColor = false;
            // 
            // button146
            // 
            this.button146.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button146.Location = new System.Drawing.Point(95, 3);
            this.button146.Name = "button146";
            this.button146.Size = new System.Drawing.Size(82, 26);
            this.button146.TabIndex = 71;
            this.button146.Text = "button146";
            this.button146.UseVisualStyleBackColor = true;
            // 
            // button145
            // 
            this.button145.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button145.Location = new System.Drawing.Point(5, 4);
            this.button145.Name = "button145";
            this.button145.Size = new System.Drawing.Size(82, 26);
            this.button145.TabIndex = 70;
            this.button145.Text = "button145";
            this.button145.UseVisualStyleBackColor = true;
            // 
            // panel35
            // 
            this.panel35.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel35.Controls.Add(this.button132);
            this.panel35.Controls.Add(this.button131);
            this.panel35.Controls.Add(this.button130);
            this.panel35.Controls.Add(this.button129);
            this.panel35.Location = new System.Drawing.Point(6, 86);
            this.panel35.Name = "panel35";
            this.panel35.Size = new System.Drawing.Size(360, 35);
            this.panel35.TabIndex = 17;
            // 
            // button132
            // 
            this.button132.BackColor = System.Drawing.Color.Aqua;
            this.button132.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button132.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button132.Location = new System.Drawing.Point(272, 4);
            this.button132.Name = "button132";
            this.button132.Size = new System.Drawing.Size(82, 26);
            this.button132.TabIndex = 72;
            this.button132.Text = "button132";
            this.button132.UseVisualStyleBackColor = false;
            // 
            // button131
            // 
            this.button131.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.button131.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button131.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button131.Location = new System.Drawing.Point(181, 4);
            this.button131.Name = "button131";
            this.button131.Size = new System.Drawing.Size(82, 26);
            this.button131.TabIndex = 71;
            this.button131.Text = "button131";
            this.button131.UseVisualStyleBackColor = false;
            // 
            // button130
            // 
            this.button130.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button130.Location = new System.Drawing.Point(95, 4);
            this.button130.Name = "button130";
            this.button130.Size = new System.Drawing.Size(82, 26);
            this.button130.TabIndex = 70;
            this.button130.Text = "button130";
            this.button130.UseVisualStyleBackColor = true;
            // 
            // button129
            // 
            this.button129.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button129.Location = new System.Drawing.Point(5, 4);
            this.button129.Name = "button129";
            this.button129.Size = new System.Drawing.Size(82, 26);
            this.button129.TabIndex = 69;
            this.button129.Text = "button129";
            this.button129.UseVisualStyleBackColor = true;
            // 
            // btnLCumlativeShiftB
            // 
            this.btnLCumlativeShiftB.BackColor = System.Drawing.Color.Black;
            this.btnLCumlativeShiftB.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLCumlativeShiftB.ForeColor = System.Drawing.Color.White;
            this.btnLCumlativeShiftB.Location = new System.Drawing.Point(279, 50);
            this.btnLCumlativeShiftB.Name = "btnLCumlativeShiftB";
            this.btnLCumlativeShiftB.Size = new System.Drawing.Size(83, 30);
            this.btnLCumlativeShiftB.TabIndex = 4;
            this.btnLCumlativeShiftB.Text = "H..";
            this.btnLCumlativeShiftB.UseVisualStyleBackColor = false;
            // 
            // btnLTotalShiftB
            // 
            this.btnLTotalShiftB.BackColor = System.Drawing.Color.Black;
            this.btnLTotalShiftB.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLTotalShiftB.ForeColor = System.Drawing.Color.White;
            this.btnLTotalShiftB.Location = new System.Drawing.Point(186, 50);
            this.btnLTotalShiftB.Name = "btnLTotalShiftB";
            this.btnLTotalShiftB.Size = new System.Drawing.Size(83, 30);
            this.btnLTotalShiftB.TabIndex = 3;
            this.btnLTotalShiftB.Text = "TOTAL";
            this.btnLTotalShiftB.UseVisualStyleBackColor = false;
            // 
            // btnL30ShiftB
            // 
            this.btnL30ShiftB.BackColor = System.Drawing.Color.Black;
            this.btnL30ShiftB.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnL30ShiftB.ForeColor = System.Drawing.Color.White;
            this.btnL30ShiftB.Location = new System.Drawing.Point(99, 50);
            this.btnL30ShiftB.Name = "btnL30ShiftB";
            this.btnL30ShiftB.Size = new System.Drawing.Size(83, 30);
            this.btnL30ShiftB.TabIndex = 2;
            this.btnL30ShiftB.Text = "L-30";
            this.btnL30ShiftB.UseVisualStyleBackColor = false;
            // 
            // btnL31ShiftB
            // 
            this.btnL31ShiftB.BackColor = System.Drawing.Color.Black;
            this.btnL31ShiftB.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnL31ShiftB.ForeColor = System.Drawing.Color.White;
            this.btnL31ShiftB.Location = new System.Drawing.Point(5, 50);
            this.btnL31ShiftB.Name = "btnL31ShiftB";
            this.btnL31ShiftB.Size = new System.Drawing.Size(83, 30);
            this.btnL31ShiftB.TabIndex = 1;
            this.btnL31ShiftB.Text = "L-31";
            this.btnL31ShiftB.UseVisualStyleBackColor = false;
            // 
            // btnLargeSugarShiftB
            // 
            this.btnLargeSugarShiftB.BackColor = System.Drawing.Color.Black;
            this.btnLargeSugarShiftB.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLargeSugarShiftB.ForeColor = System.Drawing.Color.White;
            this.btnLargeSugarShiftB.Location = new System.Drawing.Point(4, 10);
            this.btnLargeSugarShiftB.Name = "btnLargeSugarShiftB";
            this.btnLargeSugarShiftB.Size = new System.Drawing.Size(357, 34);
            this.btnLargeSugarShiftB.TabIndex = 0;
            this.btnLargeSugarShiftB.Text = "LARGE SUGAR";
            this.btnLargeSugarShiftB.UseVisualStyleBackColor = false;
            // 
            // btnShiftB
            // 
            this.btnShiftB.Location = new System.Drawing.Point(16, 18);
            this.btnShiftB.Name = "btnShiftB";
            this.btnShiftB.Size = new System.Drawing.Size(1649, 23);
            this.btnShiftB.TabIndex = 0;
            this.btnShiftB.Text = "SHIFT-B";
            this.btnShiftB.UseVisualStyleBackColor = true;
            // 
            // button358
            // 
            this.button358.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button358.Location = new System.Drawing.Point(93, 3);
            this.button358.Name = "button358";
            this.button358.Size = new System.Drawing.Size(82, 26);
            this.button358.TabIndex = 103;
            this.button358.Text = "button358";
            this.button358.UseVisualStyleBackColor = true;
            // 
            // button359
            // 
            this.button359.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.button359.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button359.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button359.Location = new System.Drawing.Point(185, 3);
            this.button359.Name = "button359";
            this.button359.Size = new System.Drawing.Size(82, 26);
            this.button359.TabIndex = 104;
            this.button359.Text = "button359";
            this.button359.UseVisualStyleBackColor = false;
            // 
            // button360
            // 
            this.button360.BackColor = System.Drawing.Color.Aqua;
            this.button360.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button360.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button360.Location = new System.Drawing.Point(273, 3);
            this.button360.Name = "button360";
            this.button360.Size = new System.Drawing.Size(82, 26);
            this.button360.TabIndex = 105;
            this.button360.Text = "button360";
            this.button360.UseVisualStyleBackColor = false;
            // 
            // button361
            // 
            this.button361.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button361.Location = new System.Drawing.Point(5, 3);
            this.button361.Name = "button361";
            this.button361.Size = new System.Drawing.Size(82, 26);
            this.button361.TabIndex = 106;
            this.button361.Text = "button361";
            this.button361.UseVisualStyleBackColor = true;
            // 
            // button362
            // 
            this.button362.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button362.Location = new System.Drawing.Point(93, 3);
            this.button362.Name = "button362";
            this.button362.Size = new System.Drawing.Size(82, 26);
            this.button362.TabIndex = 107;
            this.button362.Text = "button362";
            this.button362.UseVisualStyleBackColor = true;
            // 
            // button363
            // 
            this.button363.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.button363.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button363.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button363.Location = new System.Drawing.Point(181, 3);
            this.button363.Name = "button363";
            this.button363.Size = new System.Drawing.Size(82, 26);
            this.button363.TabIndex = 108;
            this.button363.Text = "button363";
            this.button363.UseVisualStyleBackColor = false;
            // 
            // button364
            // 
            this.button364.BackColor = System.Drawing.Color.Aqua;
            this.button364.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button364.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button364.Location = new System.Drawing.Point(271, 3);
            this.button364.Name = "button364";
            this.button364.Size = new System.Drawing.Size(82, 26);
            this.button364.TabIndex = 109;
            this.button364.Text = "button364";
            this.button364.UseVisualStyleBackColor = false;
            // 
            // button365
            // 
            this.button365.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button365.Location = new System.Drawing.Point(3, 3);
            this.button365.Name = "button365";
            this.button365.Size = new System.Drawing.Size(82, 26);
            this.button365.TabIndex = 98;
            this.button365.Text = "button365";
            this.button365.UseVisualStyleBackColor = true;
            // 
            // button366
            // 
            this.button366.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.button366.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button366.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button366.Location = new System.Drawing.Point(91, 3);
            this.button366.Name = "button366";
            this.button366.Size = new System.Drawing.Size(82, 26);
            this.button366.TabIndex = 99;
            this.button366.Text = "button366";
            this.button366.UseVisualStyleBackColor = false;
            // 
            // button367
            // 
            this.button367.BackColor = System.Drawing.Color.Aqua;
            this.button367.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button367.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button367.Location = new System.Drawing.Point(179, 3);
            this.button367.Name = "button367";
            this.button367.Size = new System.Drawing.Size(82, 26);
            this.button367.TabIndex = 100;
            this.button367.Text = "button367";
            this.button367.UseVisualStyleBackColor = false;
            // 
            // button368
            // 
            this.button368.Location = new System.Drawing.Point(6, 332);
            this.button368.Name = "button368";
            this.button368.Size = new System.Drawing.Size(78, 35);
            this.button368.TabIndex = 28;
            this.button368.Text = "9";
            this.button368.UseVisualStyleBackColor = true;
            // 
            // button369
            // 
            this.button369.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button369.Location = new System.Drawing.Point(5, 2);
            this.button369.Name = "button369";
            this.button369.Size = new System.Drawing.Size(82, 26);
            this.button369.TabIndex = 101;
            this.button369.Text = "button369";
            this.button369.UseVisualStyleBackColor = true;
            // 
            // button370
            // 
            this.button370.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button370.Location = new System.Drawing.Point(95, 2);
            this.button370.Name = "button370";
            this.button370.Size = new System.Drawing.Size(82, 26);
            this.button370.TabIndex = 102;
            this.button370.Text = "button370";
            this.button370.UseVisualStyleBackColor = true;
            // 
            // button371
            // 
            this.button371.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.button371.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button371.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button371.Location = new System.Drawing.Point(181, 2);
            this.button371.Name = "button371";
            this.button371.Size = new System.Drawing.Size(82, 26);
            this.button371.TabIndex = 103;
            this.button371.Text = "button371";
            this.button371.UseVisualStyleBackColor = false;
            // 
            // button372
            // 
            this.button372.BackColor = System.Drawing.Color.Aqua;
            this.button372.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button372.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button372.Location = new System.Drawing.Point(272, 2);
            this.button372.Name = "button372";
            this.button372.Size = new System.Drawing.Size(82, 26);
            this.button372.TabIndex = 104;
            this.button372.Text = "button372";
            this.button372.UseVisualStyleBackColor = false;
            // 
            // button373
            // 
            this.button373.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button373.Location = new System.Drawing.Point(3, 2);
            this.button373.Name = "button373";
            this.button373.Size = new System.Drawing.Size(82, 26);
            this.button373.TabIndex = 101;
            this.button373.Text = "button373";
            this.button373.UseVisualStyleBackColor = true;
            // 
            // button374
            // 
            this.button374.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button374.Location = new System.Drawing.Point(93, 2);
            this.button374.Name = "button374";
            this.button374.Size = new System.Drawing.Size(82, 26);
            this.button374.TabIndex = 102;
            this.button374.Text = "button374";
            this.button374.UseVisualStyleBackColor = true;
            // 
            // button375
            // 
            this.button375.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.button375.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button375.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button375.Location = new System.Drawing.Point(185, 2);
            this.button375.Name = "button375";
            this.button375.Size = new System.Drawing.Size(82, 26);
            this.button375.TabIndex = 103;
            this.button375.Text = "button375";
            this.button375.UseVisualStyleBackColor = false;
            // 
            // button376
            // 
            this.button376.BackColor = System.Drawing.Color.Aqua;
            this.button376.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button376.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button376.Location = new System.Drawing.Point(273, 2);
            this.button376.Name = "button376";
            this.button376.Size = new System.Drawing.Size(82, 26);
            this.button376.TabIndex = 104;
            this.button376.Text = "button376";
            this.button376.UseVisualStyleBackColor = false;
            // 
            // button377
            // 
            this.button377.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button377.Location = new System.Drawing.Point(5, 2);
            this.button377.Name = "button377";
            this.button377.Size = new System.Drawing.Size(82, 26);
            this.button377.TabIndex = 105;
            this.button377.Text = "button377";
            this.button377.UseVisualStyleBackColor = true;
            // 
            // button378
            // 
            this.button378.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button378.Location = new System.Drawing.Point(93, 2);
            this.button378.Name = "button378";
            this.button378.Size = new System.Drawing.Size(82, 26);
            this.button378.TabIndex = 106;
            this.button378.Text = "button378";
            this.button378.UseVisualStyleBackColor = true;
            // 
            // button379
            // 
            this.button379.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.button379.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button379.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button379.Location = new System.Drawing.Point(181, 2);
            this.button379.Name = "button379";
            this.button379.Size = new System.Drawing.Size(82, 26);
            this.button379.TabIndex = 107;
            this.button379.Text = "button379";
            this.button379.UseVisualStyleBackColor = false;
            // 
            // button380
            // 
            this.button380.BackColor = System.Drawing.Color.Aqua;
            this.button380.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button380.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button380.Location = new System.Drawing.Point(271, 2);
            this.button380.Name = "button380";
            this.button380.Size = new System.Drawing.Size(82, 26);
            this.button380.TabIndex = 108;
            this.button380.Text = "button380";
            this.button380.UseVisualStyleBackColor = false;
            // 
            // button381
            // 
            this.button381.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button381.Location = new System.Drawing.Point(3, 2);
            this.button381.Name = "button381";
            this.button381.Size = new System.Drawing.Size(82, 26);
            this.button381.TabIndex = 109;
            this.button381.Text = "button381";
            this.button381.UseVisualStyleBackColor = true;
            // 
            // button382
            // 
            this.button382.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.button382.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button382.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button382.Location = new System.Drawing.Point(91, 2);
            this.button382.Name = "button382";
            this.button382.Size = new System.Drawing.Size(82, 26);
            this.button382.TabIndex = 110;
            this.button382.Text = "button382";
            this.button382.UseVisualStyleBackColor = false;
            // 
            // button383
            // 
            this.button383.BackColor = System.Drawing.Color.Aqua;
            this.button383.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button383.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button383.Location = new System.Drawing.Point(179, 2);
            this.button383.Name = "button383";
            this.button383.Size = new System.Drawing.Size(82, 26);
            this.button383.TabIndex = 111;
            this.button383.Text = "button383";
            this.button383.UseVisualStyleBackColor = false;
            // 
            // button384
            // 
            this.button384.Location = new System.Drawing.Point(6, 372);
            this.button384.Name = "button384";
            this.button384.Size = new System.Drawing.Size(78, 35);
            this.button384.TabIndex = 29;
            this.button384.Text = "9";
            this.button384.UseVisualStyleBackColor = true;
            // 
            // button385
            // 
            this.button385.Location = new System.Drawing.Point(-694, 52);
            this.button385.Name = "button385";
            this.button385.Size = new System.Drawing.Size(83, 30);
            this.button385.TabIndex = 1;
            this.button385.Text = "L-31";
            this.button385.UseVisualStyleBackColor = true;
            // 
            // repo_hourly_sugar_bags
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Window;
            this.ClientSize = new System.Drawing.Size(1713, 810);
            this.Controls.Add(this.panel33);
            this.Name = "repo_hourly_sugar_bags";
            this.Text = "repo_hourly_sugar_bags";
            this.groupBox4.ResumeLayout(false);
            this.groupBox6.ResumeLayout(false);
            this.panel28.ResumeLayout(false);
            this.panel32.ResumeLayout(false);
            this.panel24.ResumeLayout(false);
            this.panel20.ResumeLayout(false);
            this.panel16.ResumeLayout(false);
            this.panel11.ResumeLayout(false);
            this.panel7.ResumeLayout(false);
            this.panel3.ResumeLayout(false);
            this.groupBox5.ResumeLayout(false);
            this.panel10.ResumeLayout(false);
            this.panel31.ResumeLayout(false);
            this.panel27.ResumeLayout(false);
            this.panel23.ResumeLayout(false);
            this.panel19.ResumeLayout(false);
            this.panel15.ResumeLayout(false);
            this.panel6.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.groupBox2.ResumeLayout(false);
            this.panel30.ResumeLayout(false);
            this.panel26.ResumeLayout(false);
            this.panel22.ResumeLayout(false);
            this.panel18.ResumeLayout(false);
            this.panel14.ResumeLayout(false);
            this.panel9.ResumeLayout(false);
            this.panel5.ResumeLayout(false);
            this.panel1.ResumeLayout(false);
            this.groupBox19.ResumeLayout(false);
            this.groupBox7.ResumeLayout(false);
            this.panel12.ResumeLayout(false);
            this.panel34.ResumeLayout(false);
            this.panel29.ResumeLayout(false);
            this.panel25.ResumeLayout(false);
            this.panel21.ResumeLayout(false);
            this.panel17.ResumeLayout(false);
            this.panel13.ResumeLayout(false);
            this.panel4.ResumeLayout(false);
            this.groupBox3.ResumeLayout(false);
            this.panel33.ResumeLayout(false);
            this.groupBox13.ResumeLayout(false);
            this.groupBox21.ResumeLayout(false);
            this.groupBox14.ResumeLayout(false);
            this.panel98.ResumeLayout(false);
            this.panel94.ResumeLayout(false);
            this.panel90.ResumeLayout(false);
            this.panel86.ResumeLayout(false);
            this.panel82.ResumeLayout(false);
            this.panel78.ResumeLayout(false);
            this.panel74.ResumeLayout(false);
            this.panel70.ResumeLayout(false);
            this.groupBox15.ResumeLayout(false);
            this.panel97.ResumeLayout(false);
            this.panel93.ResumeLayout(false);
            this.panel89.ResumeLayout(false);
            this.panel85.ResumeLayout(false);
            this.panel81.ResumeLayout(false);
            this.panel77.ResumeLayout(false);
            this.panel73.ResumeLayout(false);
            this.panel69.ResumeLayout(false);
            this.groupBox16.ResumeLayout(false);
            this.panel96.ResumeLayout(false);
            this.panel92.ResumeLayout(false);
            this.panel88.ResumeLayout(false);
            this.panel84.ResumeLayout(false);
            this.panel80.ResumeLayout(false);
            this.panel76.ResumeLayout(false);
            this.panel72.ResumeLayout(false);
            this.panel68.ResumeLayout(false);
            this.groupBox17.ResumeLayout(false);
            this.groupBox18.ResumeLayout(false);
            this.panel95.ResumeLayout(false);
            this.panel91.ResumeLayout(false);
            this.panel87.ResumeLayout(false);
            this.panel83.ResumeLayout(false);
            this.panel79.ResumeLayout(false);
            this.panel75.ResumeLayout(false);
            this.panel71.ResumeLayout(false);
            this.panel67.ResumeLayout(false);
            this.groupBox1.ResumeLayout(false);
            this.groupBox20.ResumeLayout(false);
            this.groupBox8.ResumeLayout(false);
            this.panel66.ResumeLayout(false);
            this.panel62.ResumeLayout(false);
            this.panel58.ResumeLayout(false);
            this.panel54.ResumeLayout(false);
            this.panel50.ResumeLayout(false);
            this.panel46.ResumeLayout(false);
            this.panel42.ResumeLayout(false);
            this.panel38.ResumeLayout(false);
            this.groupBox9.ResumeLayout(false);
            this.panel65.ResumeLayout(false);
            this.panel61.ResumeLayout(false);
            this.panel57.ResumeLayout(false);
            this.panel53.ResumeLayout(false);
            this.panel49.ResumeLayout(false);
            this.panel45.ResumeLayout(false);
            this.panel41.ResumeLayout(false);
            this.panel37.ResumeLayout(false);
            this.groupBox10.ResumeLayout(false);
            this.panel64.ResumeLayout(false);
            this.panel60.ResumeLayout(false);
            this.panel56.ResumeLayout(false);
            this.panel52.ResumeLayout(false);
            this.panel48.ResumeLayout(false);
            this.panel44.ResumeLayout(false);
            this.panel40.ResumeLayout(false);
            this.panel36.ResumeLayout(false);
            this.groupBox11.ResumeLayout(false);
            this.groupBox12.ResumeLayout(false);
            this.panel63.ResumeLayout(false);
            this.panel59.ResumeLayout(false);
            this.panel55.ResumeLayout(false);
            this.panel51.ResumeLayout(false);
            this.panel47.ResumeLayout(false);
            this.panel43.ResumeLayout(false);
            this.panel39.ResumeLayout(false);
            this.panel35.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Button headerTime;
        private System.Windows.Forms.Button btnTime9;
        private System.Windows.Forms.Button btnTime16;
        private System.Windows.Forms.Button btnTime15;
        private System.Windows.Forms.Button btnTime14;
        private System.Windows.Forms.Button btnTime13;
        private System.Windows.Forms.Button btnTime12;
        private System.Windows.Forms.Button btnTime11;
        private System.Windows.Forms.Button btnTime10;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Button btnLCumlativeShiftA;
        private System.Windows.Forms.Button btnLTotalShiftA;
        private System.Windows.Forms.Button btnL30ShiftA;
        private System.Windows.Forms.Button btnL31ShiftA;
        private System.Windows.Forms.Button btnLargeSugarShiftA;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.Button btnShiftA;
        private System.Windows.Forms.GroupBox groupBox7;
        private System.Windows.Forms.Button btnBissCumlativeShiftA;
        private System.Windows.Forms.Button btnBissTotalShiftA;
        private System.Windows.Forms.Button btnBissShiftA;
        private System.Windows.Forms.Button btnBissSugarShifA;
        private System.Windows.Forms.GroupBox groupBox6;
        private System.Windows.Forms.Button btnSCumlativeShiftA;
        private System.Windows.Forms.Button btnSTotalShiftA;
        private System.Windows.Forms.Button btnS30ShiftA;
        private System.Windows.Forms.Button btnS31ShiftA;
        private System.Windows.Forms.Button btnSSugarShifA;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.Button btnMCumlativeShiftA;
        private System.Windows.Forms.Button btnMTotalShiftA;
        private System.Windows.Forms.Button btnM30ShiftA;
        private System.Windows.Forms.Button btnM31ShiftA;
        private System.Windows.Forms.Button btnMSugarShiftA;
        private System.Windows.Forms.Panel panel33;
        private System.Windows.Forms.GroupBox groupBox13;
        private System.Windows.Forms.GroupBox groupBox14;
        private System.Windows.Forms.Button btnBissCumlativeShiftC;
        private System.Windows.Forms.Button btnBissTotalShiftC;
        private System.Windows.Forms.Button btnBissShiftC;
        private System.Windows.Forms.Button btnBissSugarShiftC;
        private System.Windows.Forms.GroupBox groupBox15;
        private System.Windows.Forms.Button btnSCumlativeShiftC;
        private System.Windows.Forms.Button btnSTotalShiftC;
        private System.Windows.Forms.Button btnS30ShiftC;
        private System.Windows.Forms.Button btnS31ShiftC;
        private System.Windows.Forms.Button btnSSugarShiftC;
        private System.Windows.Forms.GroupBox groupBox16;
        private System.Windows.Forms.Button btnMCumlativeShiftC;
        private System.Windows.Forms.Button btnMTotalShiftC;
        private System.Windows.Forms.Button btnM30ShiftC;
        private System.Windows.Forms.Button btnM31ShiftC;
        private System.Windows.Forms.Button btnMSugarShiftC;
        private System.Windows.Forms.GroupBox groupBox17;
        private System.Windows.Forms.Button btnTime1;
        private System.Windows.Forms.Button btnTime8;
        private System.Windows.Forms.Button btnTime7;
        private System.Windows.Forms.Button btnTime6;
        private System.Windows.Forms.Button btnTime5;
        private System.Windows.Forms.Button btnTime4;
        private System.Windows.Forms.Button btnTime3;
        private System.Windows.Forms.Button btnTime2;
        private System.Windows.Forms.Button btnHeaderTimeShiftC;
        private System.Windows.Forms.GroupBox groupBox18;
        private System.Windows.Forms.Button btnLCumlativeShiftC;
        private System.Windows.Forms.Button btnLTotalShiftC;
        private System.Windows.Forms.Button btnL30ShiftC;
        private System.Windows.Forms.Button btnL31ShiftC;
        private System.Windows.Forms.Button btnLargeSugarShiftC;
        private System.Windows.Forms.Button btnShiftC;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.GroupBox groupBox8;
        private System.Windows.Forms.Button btnBissCumlativeShiftB;
        private System.Windows.Forms.Button btnBissTotalShiftB;
        private System.Windows.Forms.Button btnBissShiftB;
        private System.Windows.Forms.Button btnBissSugarShifB;
        private System.Windows.Forms.GroupBox groupBox9;
        private System.Windows.Forms.Button btnSCumlativeShiftB;
        private System.Windows.Forms.Button btnSTotalShiftB;
        private System.Windows.Forms.Button btnS30ShiftB;
        private System.Windows.Forms.Button btnS31ShiftB;
        private System.Windows.Forms.Button btnSSugarShifB;
        private System.Windows.Forms.GroupBox groupBox10;
        private System.Windows.Forms.Button btnMCumlativeShiftB;
        private System.Windows.Forms.Button btnMTotalShiftB;
        private System.Windows.Forms.Button btnM30ShiftB;
        private System.Windows.Forms.Button btnM31ShiftB;
        private System.Windows.Forms.Button btnMSugarShifB;
        private System.Windows.Forms.GroupBox groupBox11;
        private System.Windows.Forms.Button btnTime17;
        private System.Windows.Forms.Button btnTime24;
        private System.Windows.Forms.Button btnTime23;
        private System.Windows.Forms.Button btnTime22;
        private System.Windows.Forms.Button btnTime21;
        private System.Windows.Forms.Button btnTime20;
        private System.Windows.Forms.Button btnTime19;
        private System.Windows.Forms.Button btnTime18;
        private System.Windows.Forms.Button btnHeaderTimeShiftB;
        private System.Windows.Forms.GroupBox groupBox12;
        private System.Windows.Forms.Button btnLCumlativeShiftB;
        private System.Windows.Forms.Button btnLTotalShiftB;
        private System.Windows.Forms.Button btnL30ShiftB;
        private System.Windows.Forms.Button btnL31ShiftB;
        private System.Windows.Forms.Button btnLargeSugarShiftB;
        private System.Windows.Forms.Button btnShiftB;
        private System.Windows.Forms.GroupBox groupBox19;
        private System.Windows.Forms.Button btnHourTotalShiftA;
        private System.Windows.Forms.GroupBox groupBox21;
        private System.Windows.Forms.Button btnTotalShiftC;
        private System.Windows.Forms.GroupBox groupBox20;
        private System.Windows.Forms.Button btnTotalShiftB;
        private System.Windows.Forms.Panel panel28;
        private System.Windows.Forms.Panel panel10;
        private System.Windows.Forms.Panel panel32;
        private System.Windows.Forms.Panel panel24;
        private System.Windows.Forms.Panel panel20;
        private System.Windows.Forms.Panel panel16;
        private System.Windows.Forms.Panel panel11;
        private System.Windows.Forms.Panel panel7;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Button button12;
        private System.Windows.Forms.Button button11;
        private System.Windows.Forms.Button button10;
        private System.Windows.Forms.Button button9;
        private System.Windows.Forms.Panel panel31;
        private System.Windows.Forms.Panel panel27;
        private System.Windows.Forms.Panel panel23;
        private System.Windows.Forms.Panel panel19;
        private System.Windows.Forms.Panel panel15;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Button button8;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Panel panel30;
        private System.Windows.Forms.Panel panel26;
        private System.Windows.Forms.Panel panel22;
        private System.Windows.Forms.Panel panel18;
        private System.Windows.Forms.Panel panel14;
        private System.Windows.Forms.Panel panel9;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Panel panel34;
        private System.Windows.Forms.Panel panel29;
        private System.Windows.Forms.Panel panel25;
        private System.Windows.Forms.Panel panel21;
        private System.Windows.Forms.Panel panel17;
        private System.Windows.Forms.Panel panel13;
        private System.Windows.Forms.Panel panel12;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Button button13;
        private System.Windows.Forms.Button button40;
        private System.Windows.Forms.Button button39;
        private System.Windows.Forms.Button button38;
        private System.Windows.Forms.Button button37;
        private System.Windows.Forms.Button button92;
        private System.Windows.Forms.Button button91;
        private System.Windows.Forms.Button button90;
        private System.Windows.Forms.Button button89;
        private System.Windows.Forms.Button button76;
        private System.Windows.Forms.Button button75;
        private System.Windows.Forms.Button button74;
        private System.Windows.Forms.Button button73;
        private System.Windows.Forms.Button button60;
        private System.Windows.Forms.Button button59;
        private System.Windows.Forms.Button button58;
        private System.Windows.Forms.Button button57;
        private System.Windows.Forms.Button button44;
        private System.Windows.Forms.Button button43;
        private System.Windows.Forms.Button button42;
        private System.Windows.Forms.Button button41;
        private System.Windows.Forms.Button button28;
        private System.Windows.Forms.Button button27;
        private System.Windows.Forms.Button button26;
        private System.Windows.Forms.Button button25;
        private System.Windows.Forms.Button button88;
        private System.Windows.Forms.Button button87;
        private System.Windows.Forms.Button button86;
        private System.Windows.Forms.Button button85;
        private System.Windows.Forms.Button button72;
        private System.Windows.Forms.Button button71;
        private System.Windows.Forms.Button button70;
        private System.Windows.Forms.Button button69;
        private System.Windows.Forms.Button button56;
        private System.Windows.Forms.Button button55;
        private System.Windows.Forms.Button button54;
        private System.Windows.Forms.Button button53;
        private System.Windows.Forms.Button button24;
        private System.Windows.Forms.Button button23;
        private System.Windows.Forms.Button button22;
        private System.Windows.Forms.Button button21;
        private System.Windows.Forms.Button button84;
        private System.Windows.Forms.Button button83;
        private System.Windows.Forms.Button button82;
        private System.Windows.Forms.Button button81;
        private System.Windows.Forms.Button button68;
        private System.Windows.Forms.Button button67;
        private System.Windows.Forms.Button button66;
        private System.Windows.Forms.Button button65;
        private System.Windows.Forms.Button button52;
        private System.Windows.Forms.Button button51;
        private System.Windows.Forms.Button button50;
        private System.Windows.Forms.Button button49;
        private System.Windows.Forms.Button button36;
        private System.Windows.Forms.Button button35;
        private System.Windows.Forms.Button button34;
        private System.Windows.Forms.Button button33;
        private System.Windows.Forms.Button button20;
        private System.Windows.Forms.Button button19;
        private System.Windows.Forms.Button button18;
        private System.Windows.Forms.Button button17;
        private System.Windows.Forms.Button button80;
        private System.Windows.Forms.Button button64;
        private System.Windows.Forms.Button button48;
        private System.Windows.Forms.Button button32;
        private System.Windows.Forms.Button button16;
        private System.Windows.Forms.Button button95;
        private System.Windows.Forms.Button button94;
        private System.Windows.Forms.Button button93;
        private System.Windows.Forms.Button button79;
        private System.Windows.Forms.Button button78;
        private System.Windows.Forms.Button button77;
        private System.Windows.Forms.Button button63;
        private System.Windows.Forms.Button button62;
        private System.Windows.Forms.Button button61;
        private System.Windows.Forms.Button button47;
        private System.Windows.Forms.Button button46;
        private System.Windows.Forms.Button button45;
        private System.Windows.Forms.Button button31;
        private System.Windows.Forms.Button button30;
        private System.Windows.Forms.Button button29;
        private System.Windows.Forms.Button button15;
        private System.Windows.Forms.Button button14;
        private System.Windows.Forms.Panel panel98;
        private System.Windows.Forms.Panel panel94;
        private System.Windows.Forms.Panel panel90;
        private System.Windows.Forms.Panel panel86;
        private System.Windows.Forms.Panel panel82;
        private System.Windows.Forms.Panel panel78;
        private System.Windows.Forms.Panel panel74;
        private System.Windows.Forms.Panel panel70;
        private System.Windows.Forms.Panel panel97;
        private System.Windows.Forms.Panel panel93;
        private System.Windows.Forms.Panel panel89;
        private System.Windows.Forms.Panel panel85;
        private System.Windows.Forms.Panel panel81;
        private System.Windows.Forms.Panel panel77;
        private System.Windows.Forms.Panel panel73;
        private System.Windows.Forms.Panel panel69;
        private System.Windows.Forms.Panel panel96;
        private System.Windows.Forms.Panel panel92;
        private System.Windows.Forms.Panel panel88;
        private System.Windows.Forms.Panel panel84;
        private System.Windows.Forms.Panel panel80;
        private System.Windows.Forms.Panel panel76;
        private System.Windows.Forms.Panel panel72;
        private System.Windows.Forms.Panel panel68;
        private System.Windows.Forms.Panel panel95;
        private System.Windows.Forms.Panel panel91;
        private System.Windows.Forms.Panel panel87;
        private System.Windows.Forms.Panel panel83;
        private System.Windows.Forms.Panel panel79;
        private System.Windows.Forms.Panel panel75;
        private System.Windows.Forms.Panel panel71;
        private System.Windows.Forms.Panel panel67;
        private System.Windows.Forms.Panel panel66;
        private System.Windows.Forms.Panel panel62;
        private System.Windows.Forms.Panel panel58;
        private System.Windows.Forms.Panel panel54;
        private System.Windows.Forms.Panel panel50;
        private System.Windows.Forms.Panel panel46;
        private System.Windows.Forms.Panel panel42;
        private System.Windows.Forms.Panel panel38;
        private System.Windows.Forms.Panel panel65;
        private System.Windows.Forms.Panel panel61;
        private System.Windows.Forms.Panel panel57;
        private System.Windows.Forms.Panel panel53;
        private System.Windows.Forms.Panel panel49;
        private System.Windows.Forms.Panel panel45;
        private System.Windows.Forms.Panel panel41;
        private System.Windows.Forms.Panel panel37;
        private System.Windows.Forms.Panel panel64;
        private System.Windows.Forms.Panel panel60;
        private System.Windows.Forms.Panel panel56;
        private System.Windows.Forms.Panel panel52;
        private System.Windows.Forms.Panel panel48;
        private System.Windows.Forms.Panel panel44;
        private System.Windows.Forms.Panel panel40;
        private System.Windows.Forms.Panel panel36;
        private System.Windows.Forms.Panel panel63;
        private System.Windows.Forms.Panel panel59;
        private System.Windows.Forms.Panel panel55;
        private System.Windows.Forms.Panel panel51;
        private System.Windows.Forms.Panel panel47;
        private System.Windows.Forms.Panel panel43;
        private System.Windows.Forms.Panel panel39;
        private System.Windows.Forms.Panel panel35;
        private System.Windows.Forms.Button button96;
        private System.Windows.Forms.Button button108;
        private System.Windows.Forms.Button button107;
        private System.Windows.Forms.Button button106;
        private System.Windows.Forms.Button button105;
        private System.Windows.Forms.Button button124;
        private System.Windows.Forms.Button button123;
        private System.Windows.Forms.Button button122;
        private System.Windows.Forms.Button button121;
        private System.Windows.Forms.Button button120;
        private System.Windows.Forms.Button button119;
        private System.Windows.Forms.Button button118;
        private System.Windows.Forms.Button button117;
        private System.Windows.Forms.Button button104;
        private System.Windows.Forms.Button button103;
        private System.Windows.Forms.Button button102;
        private System.Windows.Forms.Button button101;
        private System.Windows.Forms.Button button116;
        private System.Windows.Forms.Button button115;
        private System.Windows.Forms.Button button114;
        private System.Windows.Forms.Button button113;
        private System.Windows.Forms.Button button100;
        private System.Windows.Forms.Button button99;
        private System.Windows.Forms.Button button98;
        private System.Windows.Forms.Button button97;
        private System.Windows.Forms.Button button128;
        private System.Windows.Forms.Button button112;
        private System.Windows.Forms.Button button127;
        private System.Windows.Forms.Button button126;
        private System.Windows.Forms.Button button125;
        private System.Windows.Forms.Button button111;
        private System.Windows.Forms.Button button110;
        private System.Windows.Forms.Button button109;
        private System.Windows.Forms.Button button352;
        private System.Windows.Forms.Button button336;
        private System.Windows.Forms.Button button320;
        private System.Windows.Forms.Button button304;
        private System.Windows.Forms.Button button288;
        private System.Windows.Forms.Button button272;
        private System.Windows.Forms.Button button351;
        private System.Windows.Forms.Button button350;
        private System.Windows.Forms.Button button349;
        private System.Windows.Forms.Button button335;
        private System.Windows.Forms.Button button334;
        private System.Windows.Forms.Button button333;
        private System.Windows.Forms.Button button319;
        private System.Windows.Forms.Button button318;
        private System.Windows.Forms.Button button317;
        private System.Windows.Forms.Button button303;
        private System.Windows.Forms.Button button302;
        private System.Windows.Forms.Button button301;
        private System.Windows.Forms.Button button287;
        private System.Windows.Forms.Button button286;
        private System.Windows.Forms.Button button285;
        private System.Windows.Forms.Button button271;
        private System.Windows.Forms.Button button270;
        private System.Windows.Forms.Button button269;
        private System.Windows.Forms.Button button348;
        private System.Windows.Forms.Button button347;
        private System.Windows.Forms.Button button346;
        private System.Windows.Forms.Button button345;
        private System.Windows.Forms.Button button332;
        private System.Windows.Forms.Button button331;
        private System.Windows.Forms.Button button330;
        private System.Windows.Forms.Button button329;
        private System.Windows.Forms.Button button316;
        private System.Windows.Forms.Button button315;
        private System.Windows.Forms.Button button314;
        private System.Windows.Forms.Button button313;
        private System.Windows.Forms.Button button300;
        private System.Windows.Forms.Button button299;
        private System.Windows.Forms.Button button298;
        private System.Windows.Forms.Button button297;
        private System.Windows.Forms.Button button284;
        private System.Windows.Forms.Button button283;
        private System.Windows.Forms.Button button282;
        private System.Windows.Forms.Button button281;
        private System.Windows.Forms.Button button268;
        private System.Windows.Forms.Button button267;
        private System.Windows.Forms.Button button266;
        private System.Windows.Forms.Button button265;
        private System.Windows.Forms.Button button344;
        private System.Windows.Forms.Button button343;
        private System.Windows.Forms.Button button342;
        private System.Windows.Forms.Button button341;
        private System.Windows.Forms.Button button328;
        private System.Windows.Forms.Button button327;
        private System.Windows.Forms.Button button326;
        private System.Windows.Forms.Button button325;
        private System.Windows.Forms.Button button312;
        private System.Windows.Forms.Button button311;
        private System.Windows.Forms.Button button310;
        private System.Windows.Forms.Button button309;
        private System.Windows.Forms.Button button296;
        private System.Windows.Forms.Button button295;
        private System.Windows.Forms.Button button294;
        private System.Windows.Forms.Button button293;
        private System.Windows.Forms.Button button280;
        private System.Windows.Forms.Button button279;
        private System.Windows.Forms.Button button278;
        private System.Windows.Forms.Button button277;
        private System.Windows.Forms.Button button264;
        private System.Windows.Forms.Button button263;
        private System.Windows.Forms.Button button262;
        private System.Windows.Forms.Button button261;
        private System.Windows.Forms.Button button357;
        private System.Windows.Forms.Button button356;
        private System.Windows.Forms.Button button355;
        private System.Windows.Forms.Button button354;
        private System.Windows.Forms.Button button353;
        private System.Windows.Forms.Button button340;
        private System.Windows.Forms.Button button339;
        private System.Windows.Forms.Button button338;
        private System.Windows.Forms.Button button337;
        private System.Windows.Forms.Button button324;
        private System.Windows.Forms.Button button323;
        private System.Windows.Forms.Button button322;
        private System.Windows.Forms.Button button321;
        private System.Windows.Forms.Button button308;
        private System.Windows.Forms.Button button307;
        private System.Windows.Forms.Button button306;
        private System.Windows.Forms.Button button305;
        private System.Windows.Forms.Button button292;
        private System.Windows.Forms.Button button291;
        private System.Windows.Forms.Button button290;
        private System.Windows.Forms.Button button289;
        private System.Windows.Forms.Button button276;
        private System.Windows.Forms.Button button275;
        private System.Windows.Forms.Button button274;
        private System.Windows.Forms.Button button273;
        private System.Windows.Forms.Button button260;
        private System.Windows.Forms.Button button259;
        private System.Windows.Forms.Button button258;
        private System.Windows.Forms.Button button257;
        private System.Windows.Forms.Button button256;
        private System.Windows.Forms.Button button240;
        private System.Windows.Forms.Button button224;
        private System.Windows.Forms.Button button208;
        private System.Windows.Forms.Button button192;
        private System.Windows.Forms.Button button176;
        private System.Windows.Forms.Button button160;
        private System.Windows.Forms.Button button144;
        private System.Windows.Forms.Button button255;
        private System.Windows.Forms.Button button254;
        private System.Windows.Forms.Button button253;
        private System.Windows.Forms.Button button239;
        private System.Windows.Forms.Button button238;
        private System.Windows.Forms.Button button237;
        private System.Windows.Forms.Button button223;
        private System.Windows.Forms.Button button222;
        private System.Windows.Forms.Button button221;
        private System.Windows.Forms.Button button207;
        private System.Windows.Forms.Button button206;
        private System.Windows.Forms.Button button205;
        private System.Windows.Forms.Button button191;
        private System.Windows.Forms.Button button190;
        private System.Windows.Forms.Button button189;
        private System.Windows.Forms.Button button175;
        private System.Windows.Forms.Button button174;
        private System.Windows.Forms.Button button173;
        private System.Windows.Forms.Button button159;
        private System.Windows.Forms.Button button158;
        private System.Windows.Forms.Button button157;
        private System.Windows.Forms.Button button143;
        private System.Windows.Forms.Button button142;
        private System.Windows.Forms.Button button141;
        private System.Windows.Forms.Button button252;
        private System.Windows.Forms.Button button251;
        private System.Windows.Forms.Button button250;
        private System.Windows.Forms.Button button249;
        private System.Windows.Forms.Button button236;
        private System.Windows.Forms.Button button235;
        private System.Windows.Forms.Button button234;
        private System.Windows.Forms.Button button233;
        private System.Windows.Forms.Button button220;
        private System.Windows.Forms.Button button219;
        private System.Windows.Forms.Button button218;
        private System.Windows.Forms.Button button217;
        private System.Windows.Forms.Button button204;
        private System.Windows.Forms.Button button203;
        private System.Windows.Forms.Button button202;
        private System.Windows.Forms.Button button201;
        private System.Windows.Forms.Button button188;
        private System.Windows.Forms.Button button187;
        private System.Windows.Forms.Button button186;
        private System.Windows.Forms.Button button185;
        private System.Windows.Forms.Button button172;
        private System.Windows.Forms.Button button171;
        private System.Windows.Forms.Button button170;
        private System.Windows.Forms.Button button169;
        private System.Windows.Forms.Button button156;
        private System.Windows.Forms.Button button155;
        private System.Windows.Forms.Button button154;
        private System.Windows.Forms.Button button153;
        private System.Windows.Forms.Button button140;
        private System.Windows.Forms.Button button139;
        private System.Windows.Forms.Button button138;
        private System.Windows.Forms.Button button137;
        private System.Windows.Forms.Button button248;
        private System.Windows.Forms.Button button247;
        private System.Windows.Forms.Button button246;
        private System.Windows.Forms.Button button245;
        private System.Windows.Forms.Button button232;
        private System.Windows.Forms.Button button231;
        private System.Windows.Forms.Button button230;
        private System.Windows.Forms.Button button229;
        private System.Windows.Forms.Button button216;
        private System.Windows.Forms.Button button215;
        private System.Windows.Forms.Button button214;
        private System.Windows.Forms.Button button213;
        private System.Windows.Forms.Button button200;
        private System.Windows.Forms.Button button199;
        private System.Windows.Forms.Button button198;
        private System.Windows.Forms.Button button197;
        private System.Windows.Forms.Button button184;
        private System.Windows.Forms.Button button183;
        private System.Windows.Forms.Button button182;
        private System.Windows.Forms.Button button181;
        private System.Windows.Forms.Button button168;
        private System.Windows.Forms.Button button167;
        private System.Windows.Forms.Button button166;
        private System.Windows.Forms.Button button165;
        private System.Windows.Forms.Button button152;
        private System.Windows.Forms.Button button151;
        private System.Windows.Forms.Button button150;
        private System.Windows.Forms.Button button149;
        private System.Windows.Forms.Button button136;
        private System.Windows.Forms.Button button135;
        private System.Windows.Forms.Button button134;
        private System.Windows.Forms.Button button133;
        private System.Windows.Forms.Button button244;
        private System.Windows.Forms.Button button243;
        private System.Windows.Forms.Button button242;
        private System.Windows.Forms.Button button241;
        private System.Windows.Forms.Button button228;
        private System.Windows.Forms.Button button227;
        private System.Windows.Forms.Button button226;
        private System.Windows.Forms.Button button225;
        private System.Windows.Forms.Button button212;
        private System.Windows.Forms.Button button211;
        private System.Windows.Forms.Button button210;
        private System.Windows.Forms.Button button209;
        private System.Windows.Forms.Button button196;
        private System.Windows.Forms.Button button195;
        private System.Windows.Forms.Button button194;
        private System.Windows.Forms.Button button193;
        private System.Windows.Forms.Button button180;
        private System.Windows.Forms.Button button179;
        private System.Windows.Forms.Button button178;
        private System.Windows.Forms.Button button177;
        private System.Windows.Forms.Button button164;
        private System.Windows.Forms.Button button163;
        private System.Windows.Forms.Button button162;
        private System.Windows.Forms.Button button161;
        private System.Windows.Forms.Button button148;
        private System.Windows.Forms.Button button147;
        private System.Windows.Forms.Button button146;
        private System.Windows.Forms.Button button145;
        private System.Windows.Forms.Button button132;
        private System.Windows.Forms.Button button131;
        private System.Windows.Forms.Button button130;
        private System.Windows.Forms.Button button129;
        private System.Windows.Forms.Button button384;
        private System.Windows.Forms.Button button368;
        private System.Windows.Forms.Button button383;
        private System.Windows.Forms.Button button382;
        private System.Windows.Forms.Button button381;
        private System.Windows.Forms.Button button367;
        private System.Windows.Forms.Button button366;
        private System.Windows.Forms.Button button365;
        private System.Windows.Forms.Button button380;
        private System.Windows.Forms.Button button379;
        private System.Windows.Forms.Button button378;
        private System.Windows.Forms.Button button377;
        private System.Windows.Forms.Button button364;
        private System.Windows.Forms.Button button363;
        private System.Windows.Forms.Button button362;
        private System.Windows.Forms.Button button361;
        private System.Windows.Forms.Button button376;
        private System.Windows.Forms.Button button375;
        private System.Windows.Forms.Button button374;
        private System.Windows.Forms.Button button373;
        private System.Windows.Forms.Button button360;
        private System.Windows.Forms.Button button359;
        private System.Windows.Forms.Button button358;
        private System.Windows.Forms.Button button372;
        private System.Windows.Forms.Button button371;
        private System.Windows.Forms.Button button370;
        private System.Windows.Forms.Button button369;
        private System.Windows.Forms.Button button385;
    }
}