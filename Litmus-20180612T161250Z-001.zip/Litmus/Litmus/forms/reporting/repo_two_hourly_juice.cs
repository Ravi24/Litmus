﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Litmus.forms.reporting
{
    public partial class repo_two_hourly_juice : Form
    {
        classes.reports.hourly_report.repo_hourly_sugar_bags_logic report_logic = new classes.reports.hourly_report.repo_hourly_sugar_bags_logic();
        classes.generalFunctions genFunc = new classes.generalFunctions();
        public repo_two_hourly_juice()
        {
            InitializeComponent();
            execute_data();
        }

        private void execute_data()
        {
            lblReportDateValue.Text = genFunc.reportDate.ToString();
            lblCropDayValue.Text = genFunc.getCropDay(lblReportDateValue.Text).ToString(); ; 
            DataSet ds = null;
            DataSet shift_summary_dataset = null;
            DataSet shift_summary_dataset2 = null;
            DataSet shift_summary_dataset3 = null;
            int report_code = 3;
            try
            {
                ds = report_logic.report_dataset(report_code, genFunc.reportDate);
                if (ds.Tables[0].Rows.Count > 0)
                {
                    int count = 1;
                    for (int y = 0; y <= 11; y++)
                    {
                        for (int i = 0; i <= 17; i++)
                        {
                            string buttonName = "button" + count;
                            Button b = (Button)this.Controls.Find(buttonName, true)[0];
                            if (y < ds.Tables[0].Rows.Count) // checking if rows defined by me (count report value buttons) and rows in dataset are equal
                            {
                                b.Text = ds.Tables[0].Rows[y][i].ToString();
                            }
                            else
                            {
                                b.Text = "";
                            }
                            count++;
                        }
                    }
                    // day summary
                    if (ds.Tables.Count == 2)
                    {
                        for (int x = 1; x <= 18; x++)
                        {
                            string daySummaryButtonName = "btnDaySumm" + x;
                            Button btn = (Button)this.Controls.Find(daySummaryButtonName, true)[0];
                            btn.Text = ds.Tables["table_day_summary"].Rows[0][x - 1].ToString();
                        }
                    }
                    // shift summary
                    if (report_code == 3)
                    {
                        
                        shift_summary_dataset = report_logic.shift_sumary_dataset(genFunc.reportDate, 9, 16);
                        shift_summary_dataset2 = report_logic.shift_sumary_dataset(genFunc.reportDate, 17, 24);
                        shift_summary_dataset3 = report_logic.shift_sumary_dataset(genFunc.reportDate, 1, 8);
                        int col = 0;
                        int col2 = 0;
                        int col3 = 0;
                        for (int x = 217; x <= 234; x++) // button numbers for shift summary are starts from 217 and endt at 271
                        {
                            string shiftSummaryButtonName = "button" + x;
                            Button btn = (Button)this.Controls.Find(shiftSummaryButtonName, true)[0];
                            btn.Text = shift_summary_dataset.Tables[0].Rows[0][col].ToString();
                            col++;
                        }
                        for (int x = 236; x <= 253; x++) // button numbers for shift summary are starts from 217 and endt at 271
                        {
                            string shiftSummaryButtonName = "button" + x;
                            Button btn = (Button)this.Controls.Find(shiftSummaryButtonName, true)[0];
                            btn.Text = shift_summary_dataset2.Tables[0].Rows[0][col2].ToString();
                            col2++;
                        }
                        for (int x = 254; x <= 271; x++) // button numbers for shift summary are starts from 217 and endt at 271
                        {
                            string shiftSummaryButtonName = "button" + x;
                            Button btn = (Button)this.Controls.Find(shiftSummaryButtonName, true)[0];
                            btn.Text = shift_summary_dataset3.Tables[0].Rows[0][col3].ToString();
                            col3++;
                        }
                    }
                }
                else
                {
                    MessageBox.Show("No record found");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
      
    }
}
