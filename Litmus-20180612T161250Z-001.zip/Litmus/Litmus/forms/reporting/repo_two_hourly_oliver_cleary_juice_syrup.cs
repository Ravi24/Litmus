﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Litmus.forms.reporting
{
    public partial class repo_two_hourly_oliver_cleary_juice_syrup : Form
    {
        public repo_two_hourly_oliver_cleary_juice_syrup()
        {
            InitializeComponent();
        }

    }
}
