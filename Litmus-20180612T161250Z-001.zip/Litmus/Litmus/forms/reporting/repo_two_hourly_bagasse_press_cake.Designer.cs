﻿namespace Litmus.forms.reporting
{
    partial class repo_two_hourly_bagasse_press_cake
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.groupBox19 = new System.Windows.Forms.GroupBox();
            this.groupBox20 = new System.Windows.Forms.GroupBox();
            this.groupBox21 = new System.Windows.Forms.GroupBox();
            this.button178 = new System.Windows.Forms.Button();
            this.button179 = new System.Windows.Forms.Button();
            this.button180 = new System.Windows.Forms.Button();
            this.button163 = new System.Windows.Forms.Button();
            this.button164 = new System.Windows.Forms.Button();
            this.button165 = new System.Windows.Forms.Button();
            this.button148 = new System.Windows.Forms.Button();
            this.button149 = new System.Windows.Forms.Button();
            this.button150 = new System.Windows.Forms.Button();
            this.button133 = new System.Windows.Forms.Button();
            this.button134 = new System.Windows.Forms.Button();
            this.button135 = new System.Windows.Forms.Button();
            this.final_mol_purity_head_shift_c = new System.Windows.Forms.Button();
            this.final_mol_Pol_head_shift_c = new System.Windows.Forms.Button();
            this.final_mol_brix_head_shift_c = new System.Windows.Forms.Button();
            this.FMolasses_head_shift_c = new System.Windows.Forms.Button();
            this.groupBox22 = new System.Windows.Forms.GroupBox();
            this.groupBox23 = new System.Windows.Forms.GroupBox();
            this.button170 = new System.Windows.Forms.Button();
            this.button171 = new System.Windows.Forms.Button();
            this.button172 = new System.Windows.Forms.Button();
            this.button173 = new System.Windows.Forms.Button();
            this.button174 = new System.Windows.Forms.Button();
            this.button175 = new System.Windows.Forms.Button();
            this.button176 = new System.Windows.Forms.Button();
            this.button177 = new System.Windows.Forms.Button();
            this.button155 = new System.Windows.Forms.Button();
            this.button156 = new System.Windows.Forms.Button();
            this.button157 = new System.Windows.Forms.Button();
            this.button158 = new System.Windows.Forms.Button();
            this.button159 = new System.Windows.Forms.Button();
            this.button160 = new System.Windows.Forms.Button();
            this.button161 = new System.Windows.Forms.Button();
            this.button162 = new System.Windows.Forms.Button();
            this.button140 = new System.Windows.Forms.Button();
            this.button141 = new System.Windows.Forms.Button();
            this.button142 = new System.Windows.Forms.Button();
            this.button143 = new System.Windows.Forms.Button();
            this.button144 = new System.Windows.Forms.Button();
            this.button145 = new System.Windows.Forms.Button();
            this.button146 = new System.Windows.Forms.Button();
            this.button147 = new System.Windows.Forms.Button();
            this.button125 = new System.Windows.Forms.Button();
            this.button126 = new System.Windows.Forms.Button();
            this.button127 = new System.Windows.Forms.Button();
            this.button128 = new System.Windows.Forms.Button();
            this.button129 = new System.Windows.Forms.Button();
            this.button130 = new System.Windows.Forms.Button();
            this.button131 = new System.Windows.Forms.Button();
            this.button132 = new System.Windows.Forms.Button();
            this.pc_sample_composite_head_shift_c = new System.Windows.Forms.Button();
            this.pc_sample_moist_head_shift_c = new System.Windows.Forms.Button();
            this.pc_sample_avg_head_shift_c = new System.Windows.Forms.Button();
            this.pc_sample_one_head_shift_c = new System.Windows.Forms.Button();
            this.pc_sample_fivve_head_shift_c = new System.Windows.Forms.Button();
            this.pc_sample_two_head_shift_c = new System.Windows.Forms.Button();
            this.pc_sample_four_head_shift_c = new System.Windows.Forms.Button();
            this.pc_sample_three_head_shift_c = new System.Windows.Forms.Button();
            this.pressCake_head_shift_c = new System.Windows.Forms.Button();
            this.groupBox24 = new System.Windows.Forms.GroupBox();
            this.groupBox25 = new System.Windows.Forms.GroupBox();
            this.button168 = new System.Windows.Forms.Button();
            this.button169 = new System.Windows.Forms.Button();
            this.button153 = new System.Windows.Forms.Button();
            this.button154 = new System.Windows.Forms.Button();
            this.button138 = new System.Windows.Forms.Button();
            this.button139 = new System.Windows.Forms.Button();
            this.button123 = new System.Windows.Forms.Button();
            this.button124 = new System.Windows.Forms.Button();
            this.bagasse_om_moist_shift_c = new System.Windows.Forms.Button();
            this.bagasse_om_pol_shift_c = new System.Windows.Forms.Button();
            this.bagasse_head_om_shift_c = new System.Windows.Forms.Button();
            this.groupBox26 = new System.Windows.Forms.GroupBox();
            this.button166 = new System.Windows.Forms.Button();
            this.button167 = new System.Windows.Forms.Button();
            this.button151 = new System.Windows.Forms.Button();
            this.button152 = new System.Windows.Forms.Button();
            this.button136 = new System.Windows.Forms.Button();
            this.button137 = new System.Windows.Forms.Button();
            this.button121 = new System.Windows.Forms.Button();
            this.button122 = new System.Windows.Forms.Button();
            this.bagasse_nm_moist_shift_c = new System.Windows.Forms.Button();
            this.bagasse_nm_pol_shift_c = new System.Windows.Forms.Button();
            this.bagasse_head_nm_shift_c = new System.Windows.Forms.Button();
            this.bagass_head_shift_c = new System.Windows.Forms.Button();
            this.groupBox27 = new System.Windows.Forms.GroupBox();
            this.button181 = new System.Windows.Forms.Button();
            this.button182 = new System.Windows.Forms.Button();
            this.button183 = new System.Windows.Forms.Button();
            this.button184 = new System.Windows.Forms.Button();
            this.button383 = new System.Windows.Forms.Button();
            this.time_head_shiftC = new System.Windows.Forms.Button();
            this.groupBox10 = new System.Windows.Forms.GroupBox();
            this.groupBox11 = new System.Windows.Forms.GroupBox();
            this.groupBox12 = new System.Windows.Forms.GroupBox();
            this.button118 = new System.Windows.Forms.Button();
            this.button119 = new System.Windows.Forms.Button();
            this.button120 = new System.Windows.Forms.Button();
            this.button103 = new System.Windows.Forms.Button();
            this.button104 = new System.Windows.Forms.Button();
            this.button105 = new System.Windows.Forms.Button();
            this.button88 = new System.Windows.Forms.Button();
            this.button89 = new System.Windows.Forms.Button();
            this.button90 = new System.Windows.Forms.Button();
            this.button73 = new System.Windows.Forms.Button();
            this.button74 = new System.Windows.Forms.Button();
            this.button75 = new System.Windows.Forms.Button();
            this.final_mol_purity_head_shift_b = new System.Windows.Forms.Button();
            this.final_mol_Pol_head_shift_b = new System.Windows.Forms.Button();
            this.final_mol_brix_head_shift_b = new System.Windows.Forms.Button();
            this.FMolasses_head_shift_b = new System.Windows.Forms.Button();
            this.groupBox13 = new System.Windows.Forms.GroupBox();
            this.groupBox14 = new System.Windows.Forms.GroupBox();
            this.button110 = new System.Windows.Forms.Button();
            this.button111 = new System.Windows.Forms.Button();
            this.button112 = new System.Windows.Forms.Button();
            this.button113 = new System.Windows.Forms.Button();
            this.button114 = new System.Windows.Forms.Button();
            this.button115 = new System.Windows.Forms.Button();
            this.button116 = new System.Windows.Forms.Button();
            this.button117 = new System.Windows.Forms.Button();
            this.button95 = new System.Windows.Forms.Button();
            this.button96 = new System.Windows.Forms.Button();
            this.button97 = new System.Windows.Forms.Button();
            this.button98 = new System.Windows.Forms.Button();
            this.button99 = new System.Windows.Forms.Button();
            this.button100 = new System.Windows.Forms.Button();
            this.button101 = new System.Windows.Forms.Button();
            this.button102 = new System.Windows.Forms.Button();
            this.button80 = new System.Windows.Forms.Button();
            this.button81 = new System.Windows.Forms.Button();
            this.button82 = new System.Windows.Forms.Button();
            this.button83 = new System.Windows.Forms.Button();
            this.button84 = new System.Windows.Forms.Button();
            this.button85 = new System.Windows.Forms.Button();
            this.button86 = new System.Windows.Forms.Button();
            this.button87 = new System.Windows.Forms.Button();
            this.button65 = new System.Windows.Forms.Button();
            this.button66 = new System.Windows.Forms.Button();
            this.button67 = new System.Windows.Forms.Button();
            this.button68 = new System.Windows.Forms.Button();
            this.button69 = new System.Windows.Forms.Button();
            this.button70 = new System.Windows.Forms.Button();
            this.button71 = new System.Windows.Forms.Button();
            this.button72 = new System.Windows.Forms.Button();
            this.pc_sample_composite_head_shift_b = new System.Windows.Forms.Button();
            this.pc_sample_moist_head_shift_b = new System.Windows.Forms.Button();
            this.pc_sample_avg_head_shift_b = new System.Windows.Forms.Button();
            this.pc_sample_one_head_shift_b = new System.Windows.Forms.Button();
            this.pc_sample_five_head_shift_b = new System.Windows.Forms.Button();
            this.pc_sample_two_head_shift_b = new System.Windows.Forms.Button();
            this.pc_sample_four_head_shift_b = new System.Windows.Forms.Button();
            this.pc_sample_three_head_shift_b = new System.Windows.Forms.Button();
            this.pressCake_head_shift_b = new System.Windows.Forms.Button();
            this.groupBox15 = new System.Windows.Forms.GroupBox();
            this.groupBox16 = new System.Windows.Forms.GroupBox();
            this.button108 = new System.Windows.Forms.Button();
            this.button109 = new System.Windows.Forms.Button();
            this.button93 = new System.Windows.Forms.Button();
            this.button94 = new System.Windows.Forms.Button();
            this.button78 = new System.Windows.Forms.Button();
            this.button79 = new System.Windows.Forms.Button();
            this.button63 = new System.Windows.Forms.Button();
            this.button64 = new System.Windows.Forms.Button();
            this.bagasse_om_moist_shift_b = new System.Windows.Forms.Button();
            this.bagasse_om_pol_shift_b = new System.Windows.Forms.Button();
            this.bagasse_head_om_shift_b = new System.Windows.Forms.Button();
            this.groupBox17 = new System.Windows.Forms.GroupBox();
            this.button106 = new System.Windows.Forms.Button();
            this.button107 = new System.Windows.Forms.Button();
            this.button91 = new System.Windows.Forms.Button();
            this.button92 = new System.Windows.Forms.Button();
            this.button76 = new System.Windows.Forms.Button();
            this.button77 = new System.Windows.Forms.Button();
            this.button61 = new System.Windows.Forms.Button();
            this.button62 = new System.Windows.Forms.Button();
            this.bagasse_nm_moist_shift_b = new System.Windows.Forms.Button();
            this.bagasse_nm_pol_shift_b = new System.Windows.Forms.Button();
            this.bagasse_head_nm_shift_b = new System.Windows.Forms.Button();
            this.bagass_head_shift_b = new System.Windows.Forms.Button();
            this.groupBox18 = new System.Windows.Forms.GroupBox();
            this.time20 = new System.Windows.Forms.Button();
            this.time19 = new System.Windows.Forms.Button();
            this.time18 = new System.Windows.Forms.Button();
            this.time17 = new System.Windows.Forms.Button();
            this.avg_shift_b = new System.Windows.Forms.Button();
            this.time_head_shiftB = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.groupBox8 = new System.Windows.Forms.GroupBox();
            this.groupBox9 = new System.Windows.Forms.GroupBox();
            this.button58 = new System.Windows.Forms.Button();
            this.button59 = new System.Windows.Forms.Button();
            this.button60 = new System.Windows.Forms.Button();
            this.button43 = new System.Windows.Forms.Button();
            this.button44 = new System.Windows.Forms.Button();
            this.button45 = new System.Windows.Forms.Button();
            this.button28 = new System.Windows.Forms.Button();
            this.button29 = new System.Windows.Forms.Button();
            this.button30 = new System.Windows.Forms.Button();
            this.button15 = new System.Windows.Forms.Button();
            this.button14 = new System.Windows.Forms.Button();
            this.button13 = new System.Windows.Forms.Button();
            this.final_mol_purity_head_shift_a = new System.Windows.Forms.Button();
            this.final_mol_Pol_head_shift_a = new System.Windows.Forms.Button();
            this.final_mol_brix_head_shift_a = new System.Windows.Forms.Button();
            this.FMolasses_head_shift_a = new System.Windows.Forms.Button();
            this.groupBox6 = new System.Windows.Forms.GroupBox();
            this.groupBox7 = new System.Windows.Forms.GroupBox();
            this.button50 = new System.Windows.Forms.Button();
            this.button51 = new System.Windows.Forms.Button();
            this.button52 = new System.Windows.Forms.Button();
            this.button53 = new System.Windows.Forms.Button();
            this.button54 = new System.Windows.Forms.Button();
            this.button55 = new System.Windows.Forms.Button();
            this.button56 = new System.Windows.Forms.Button();
            this.button57 = new System.Windows.Forms.Button();
            this.button35 = new System.Windows.Forms.Button();
            this.button36 = new System.Windows.Forms.Button();
            this.button37 = new System.Windows.Forms.Button();
            this.button38 = new System.Windows.Forms.Button();
            this.button39 = new System.Windows.Forms.Button();
            this.button40 = new System.Windows.Forms.Button();
            this.button41 = new System.Windows.Forms.Button();
            this.button42 = new System.Windows.Forms.Button();
            this.button20 = new System.Windows.Forms.Button();
            this.button21 = new System.Windows.Forms.Button();
            this.button22 = new System.Windows.Forms.Button();
            this.button23 = new System.Windows.Forms.Button();
            this.button24 = new System.Windows.Forms.Button();
            this.button25 = new System.Windows.Forms.Button();
            this.button26 = new System.Windows.Forms.Button();
            this.button27 = new System.Windows.Forms.Button();
            this.button12 = new System.Windows.Forms.Button();
            this.button11 = new System.Windows.Forms.Button();
            this.button10 = new System.Windows.Forms.Button();
            this.button9 = new System.Windows.Forms.Button();
            this.button8 = new System.Windows.Forms.Button();
            this.button7 = new System.Windows.Forms.Button();
            this.button6 = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            this.pc_sample_composite_head_shift_a = new System.Windows.Forms.Button();
            this.pc_sample_moist_head_shift_a = new System.Windows.Forms.Button();
            this.pc_sample_avg_head_shift_a = new System.Windows.Forms.Button();
            this.pc_sample_one_head_shift_a = new System.Windows.Forms.Button();
            this.pc_sample_five_head_shift_a = new System.Windows.Forms.Button();
            this.pc_sample_two_head_shift_a = new System.Windows.Forms.Button();
            this.pc_sample_four_head_shift_a = new System.Windows.Forms.Button();
            this.pc_sample_three_head_shift_a = new System.Windows.Forms.Button();
            this.pressCake_head_shift_a = new System.Windows.Forms.Button();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.button48 = new System.Windows.Forms.Button();
            this.button49 = new System.Windows.Forms.Button();
            this.button33 = new System.Windows.Forms.Button();
            this.button34 = new System.Windows.Forms.Button();
            this.button18 = new System.Windows.Forms.Button();
            this.button19 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.bagasse_om_moist_shift_a = new System.Windows.Forms.Button();
            this.bagasse_om_pol_shift_a = new System.Windows.Forms.Button();
            this.bagasse_head_om_shift_a = new System.Windows.Forms.Button();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.button46 = new System.Windows.Forms.Button();
            this.button47 = new System.Windows.Forms.Button();
            this.button31 = new System.Windows.Forms.Button();
            this.button32 = new System.Windows.Forms.Button();
            this.button16 = new System.Windows.Forms.Button();
            this.button17 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.bagasse_nm_moist_shift_a = new System.Windows.Forms.Button();
            this.bagasse_nm_pol_shift_a = new System.Windows.Forms.Button();
            this.bagasse_head_nm_shift_a = new System.Windows.Forms.Button();
            this.bagass_head_shift_a = new System.Windows.Forms.Button();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.time16 = new System.Windows.Forms.Button();
            this.time14 = new System.Windows.Forms.Button();
            this.average_shift_a = new System.Windows.Forms.Button();
            this.time12 = new System.Windows.Forms.Button();
            this.time10 = new System.Windows.Forms.Button();
            this.time_head_shiftA = new System.Windows.Forms.Button();
            this.panel1.SuspendLayout();
            this.groupBox19.SuspendLayout();
            this.groupBox20.SuspendLayout();
            this.groupBox21.SuspendLayout();
            this.groupBox22.SuspendLayout();
            this.groupBox23.SuspendLayout();
            this.groupBox24.SuspendLayout();
            this.groupBox25.SuspendLayout();
            this.groupBox26.SuspendLayout();
            this.groupBox27.SuspendLayout();
            this.groupBox10.SuspendLayout();
            this.groupBox11.SuspendLayout();
            this.groupBox12.SuspendLayout();
            this.groupBox13.SuspendLayout();
            this.groupBox14.SuspendLayout();
            this.groupBox15.SuspendLayout();
            this.groupBox16.SuspendLayout();
            this.groupBox17.SuspendLayout();
            this.groupBox18.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.groupBox8.SuspendLayout();
            this.groupBox9.SuspendLayout();
            this.groupBox6.SuspendLayout();
            this.groupBox7.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.groupBox5.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.AutoScroll = true;
            this.panel1.BackColor = System.Drawing.Color.White;
            this.panel1.Controls.Add(this.groupBox19);
            this.panel1.Controls.Add(this.groupBox10);
            this.panel1.Controls.Add(this.groupBox1);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1667, 1045);
            this.panel1.TabIndex = 0;
            // 
            // groupBox19
            // 
            this.groupBox19.Controls.Add(this.groupBox20);
            this.groupBox19.Controls.Add(this.groupBox22);
            this.groupBox19.Controls.Add(this.groupBox24);
            this.groupBox19.Controls.Add(this.groupBox27);
            this.groupBox19.Location = new System.Drawing.Point(7, 914);
            this.groupBox19.Name = "groupBox19";
            this.groupBox19.Size = new System.Drawing.Size(1630, 574);
            this.groupBox19.TabIndex = 2;
            this.groupBox19.TabStop = false;
            this.groupBox19.Text = "Shift-C";
            // 
            // groupBox20
            // 
            this.groupBox20.Controls.Add(this.groupBox21);
            this.groupBox20.Controls.Add(this.FMolasses_head_shift_c);
            this.groupBox20.Location = new System.Drawing.Point(1363, 15);
            this.groupBox20.Name = "groupBox20";
            this.groupBox20.Size = new System.Drawing.Size(270, 556);
            this.groupBox20.TabIndex = 3;
            this.groupBox20.TabStop = false;
            // 
            // groupBox21
            // 
            this.groupBox21.Controls.Add(this.button178);
            this.groupBox21.Controls.Add(this.button179);
            this.groupBox21.Controls.Add(this.button180);
            this.groupBox21.Controls.Add(this.button163);
            this.groupBox21.Controls.Add(this.button164);
            this.groupBox21.Controls.Add(this.button165);
            this.groupBox21.Controls.Add(this.button148);
            this.groupBox21.Controls.Add(this.button149);
            this.groupBox21.Controls.Add(this.button150);
            this.groupBox21.Controls.Add(this.button133);
            this.groupBox21.Controls.Add(this.button134);
            this.groupBox21.Controls.Add(this.button135);
            this.groupBox21.Controls.Add(this.final_mol_purity_head_shift_c);
            this.groupBox21.Controls.Add(this.final_mol_Pol_head_shift_c);
            this.groupBox21.Controls.Add(this.final_mol_brix_head_shift_c);
            this.groupBox21.Location = new System.Drawing.Point(6, 58);
            this.groupBox21.Name = "groupBox21";
            this.groupBox21.Size = new System.Drawing.Size(252, 284);
            this.groupBox21.TabIndex = 3;
            this.groupBox21.TabStop = false;
            // 
            // button178
            // 
            this.button178.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button178.Location = new System.Drawing.Point(6, 205);
            this.button178.Name = "button178";
            this.button178.Size = new System.Drawing.Size(75, 32);
            this.button178.TabIndex = 54;
            this.button178.Text = "button178";
            this.button178.UseVisualStyleBackColor = true;
            // 
            // button179
            // 
            this.button179.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button179.Location = new System.Drawing.Point(87, 205);
            this.button179.Name = "button179";
            this.button179.Size = new System.Drawing.Size(75, 32);
            this.button179.TabIndex = 53;
            this.button179.Text = "button179";
            this.button179.UseVisualStyleBackColor = true;
            // 
            // button180
            // 
            this.button180.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button180.Location = new System.Drawing.Point(168, 205);
            this.button180.Name = "button180";
            this.button180.Size = new System.Drawing.Size(75, 32);
            this.button180.TabIndex = 52;
            this.button180.Text = "button180";
            this.button180.UseVisualStyleBackColor = true;
            // 
            // button163
            // 
            this.button163.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button163.Location = new System.Drawing.Point(6, 167);
            this.button163.Name = "button163";
            this.button163.Size = new System.Drawing.Size(75, 32);
            this.button163.TabIndex = 51;
            this.button163.Text = "button163";
            this.button163.UseVisualStyleBackColor = true;
            // 
            // button164
            // 
            this.button164.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button164.Location = new System.Drawing.Point(87, 167);
            this.button164.Name = "button164";
            this.button164.Size = new System.Drawing.Size(75, 32);
            this.button164.TabIndex = 50;
            this.button164.Text = "button164";
            this.button164.UseVisualStyleBackColor = true;
            // 
            // button165
            // 
            this.button165.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button165.Location = new System.Drawing.Point(168, 167);
            this.button165.Name = "button165";
            this.button165.Size = new System.Drawing.Size(75, 32);
            this.button165.TabIndex = 49;
            this.button165.Text = "button165";
            this.button165.UseVisualStyleBackColor = true;
            // 
            // button148
            // 
            this.button148.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button148.Location = new System.Drawing.Point(6, 129);
            this.button148.Name = "button148";
            this.button148.Size = new System.Drawing.Size(75, 32);
            this.button148.TabIndex = 48;
            this.button148.Text = "button148";
            this.button148.UseVisualStyleBackColor = true;
            // 
            // button149
            // 
            this.button149.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button149.Location = new System.Drawing.Point(87, 129);
            this.button149.Name = "button149";
            this.button149.Size = new System.Drawing.Size(75, 32);
            this.button149.TabIndex = 47;
            this.button149.Text = "button149";
            this.button149.UseVisualStyleBackColor = true;
            // 
            // button150
            // 
            this.button150.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button150.Location = new System.Drawing.Point(168, 129);
            this.button150.Name = "button150";
            this.button150.Size = new System.Drawing.Size(75, 32);
            this.button150.TabIndex = 46;
            this.button150.Text = "button150";
            this.button150.UseVisualStyleBackColor = true;
            // 
            // button133
            // 
            this.button133.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button133.Location = new System.Drawing.Point(6, 91);
            this.button133.Name = "button133";
            this.button133.Size = new System.Drawing.Size(75, 32);
            this.button133.TabIndex = 45;
            this.button133.Text = "button133";
            this.button133.UseVisualStyleBackColor = true;
            // 
            // button134
            // 
            this.button134.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button134.Location = new System.Drawing.Point(87, 91);
            this.button134.Name = "button134";
            this.button134.Size = new System.Drawing.Size(75, 32);
            this.button134.TabIndex = 44;
            this.button134.Text = "button134";
            this.button134.UseVisualStyleBackColor = true;
            // 
            // button135
            // 
            this.button135.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button135.Location = new System.Drawing.Point(168, 91);
            this.button135.Name = "button135";
            this.button135.Size = new System.Drawing.Size(75, 32);
            this.button135.TabIndex = 43;
            this.button135.Text = "button135";
            this.button135.UseVisualStyleBackColor = true;
            // 
            // final_mol_purity_head_shift_c
            // 
            this.final_mol_purity_head_shift_c.Location = new System.Drawing.Point(168, 13);
            this.final_mol_purity_head_shift_c.Name = "final_mol_purity_head_shift_c";
            this.final_mol_purity_head_shift_c.Size = new System.Drawing.Size(75, 32);
            this.final_mol_purity_head_shift_c.TabIndex = 2;
            this.final_mol_purity_head_shift_c.Text = "Purity";
            this.final_mol_purity_head_shift_c.UseVisualStyleBackColor = true;
            // 
            // final_mol_Pol_head_shift_c
            // 
            this.final_mol_Pol_head_shift_c.Location = new System.Drawing.Point(87, 13);
            this.final_mol_Pol_head_shift_c.Name = "final_mol_Pol_head_shift_c";
            this.final_mol_Pol_head_shift_c.Size = new System.Drawing.Size(75, 32);
            this.final_mol_Pol_head_shift_c.TabIndex = 1;
            this.final_mol_Pol_head_shift_c.Text = "Pol";
            this.final_mol_Pol_head_shift_c.UseVisualStyleBackColor = true;
            // 
            // final_mol_brix_head_shift_c
            // 
            this.final_mol_brix_head_shift_c.Location = new System.Drawing.Point(6, 13);
            this.final_mol_brix_head_shift_c.Name = "final_mol_brix_head_shift_c";
            this.final_mol_brix_head_shift_c.Size = new System.Drawing.Size(75, 32);
            this.final_mol_brix_head_shift_c.TabIndex = 0;
            this.final_mol_brix_head_shift_c.Text = "Brix";
            this.final_mol_brix_head_shift_c.UseVisualStyleBackColor = true;
            // 
            // FMolasses_head_shift_c
            // 
            this.FMolasses_head_shift_c.Location = new System.Drawing.Point(6, 14);
            this.FMolasses_head_shift_c.Name = "FMolasses_head_shift_c";
            this.FMolasses_head_shift_c.Size = new System.Drawing.Size(243, 41);
            this.FMolasses_head_shift_c.TabIndex = 2;
            this.FMolasses_head_shift_c.Text = "Final Molasses";
            this.FMolasses_head_shift_c.UseVisualStyleBackColor = true;
            // 
            // groupBox22
            // 
            this.groupBox22.Controls.Add(this.groupBox23);
            this.groupBox22.Controls.Add(this.pressCake_head_shift_c);
            this.groupBox22.Location = new System.Drawing.Point(537, 15);
            this.groupBox22.Name = "groupBox22";
            this.groupBox22.Size = new System.Drawing.Size(820, 556);
            this.groupBox22.TabIndex = 2;
            this.groupBox22.TabStop = false;
            // 
            // groupBox23
            // 
            this.groupBox23.Controls.Add(this.button170);
            this.groupBox23.Controls.Add(this.button171);
            this.groupBox23.Controls.Add(this.button172);
            this.groupBox23.Controls.Add(this.button173);
            this.groupBox23.Controls.Add(this.button174);
            this.groupBox23.Controls.Add(this.button175);
            this.groupBox23.Controls.Add(this.button176);
            this.groupBox23.Controls.Add(this.button177);
            this.groupBox23.Controls.Add(this.button155);
            this.groupBox23.Controls.Add(this.button156);
            this.groupBox23.Controls.Add(this.button157);
            this.groupBox23.Controls.Add(this.button158);
            this.groupBox23.Controls.Add(this.button159);
            this.groupBox23.Controls.Add(this.button160);
            this.groupBox23.Controls.Add(this.button161);
            this.groupBox23.Controls.Add(this.button162);
            this.groupBox23.Controls.Add(this.button140);
            this.groupBox23.Controls.Add(this.button141);
            this.groupBox23.Controls.Add(this.button142);
            this.groupBox23.Controls.Add(this.button143);
            this.groupBox23.Controls.Add(this.button144);
            this.groupBox23.Controls.Add(this.button145);
            this.groupBox23.Controls.Add(this.button146);
            this.groupBox23.Controls.Add(this.button147);
            this.groupBox23.Controls.Add(this.button125);
            this.groupBox23.Controls.Add(this.button126);
            this.groupBox23.Controls.Add(this.button127);
            this.groupBox23.Controls.Add(this.button128);
            this.groupBox23.Controls.Add(this.button129);
            this.groupBox23.Controls.Add(this.button130);
            this.groupBox23.Controls.Add(this.button131);
            this.groupBox23.Controls.Add(this.button132);
            this.groupBox23.Controls.Add(this.pc_sample_composite_head_shift_c);
            this.groupBox23.Controls.Add(this.pc_sample_moist_head_shift_c);
            this.groupBox23.Controls.Add(this.pc_sample_avg_head_shift_c);
            this.groupBox23.Controls.Add(this.pc_sample_one_head_shift_c);
            this.groupBox23.Controls.Add(this.pc_sample_fivve_head_shift_c);
            this.groupBox23.Controls.Add(this.pc_sample_two_head_shift_c);
            this.groupBox23.Controls.Add(this.pc_sample_four_head_shift_c);
            this.groupBox23.Controls.Add(this.pc_sample_three_head_shift_c);
            this.groupBox23.Location = new System.Drawing.Point(6, 58);
            this.groupBox23.Name = "groupBox23";
            this.groupBox23.Size = new System.Drawing.Size(801, 284);
            this.groupBox23.TabIndex = 7;
            this.groupBox23.TabStop = false;
            // 
            // button170
            // 
            this.button170.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button170.Location = new System.Drawing.Point(9, 205);
            this.button170.Name = "button170";
            this.button170.Size = new System.Drawing.Size(90, 32);
            this.button170.TabIndex = 136;
            this.button170.Text = "button170";
            this.button170.UseVisualStyleBackColor = true;
            // 
            // button171
            // 
            this.button171.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button171.Location = new System.Drawing.Point(111, 205);
            this.button171.Name = "button171";
            this.button171.Size = new System.Drawing.Size(90, 32);
            this.button171.TabIndex = 135;
            this.button171.Text = "button171";
            this.button171.UseVisualStyleBackColor = true;
            // 
            // button172
            // 
            this.button172.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button172.Location = new System.Drawing.Point(210, 205);
            this.button172.Name = "button172";
            this.button172.Size = new System.Drawing.Size(90, 32);
            this.button172.TabIndex = 134;
            this.button172.Text = "button172";
            this.button172.UseVisualStyleBackColor = true;
            // 
            // button173
            // 
            this.button173.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button173.Location = new System.Drawing.Point(309, 205);
            this.button173.Name = "button173";
            this.button173.Size = new System.Drawing.Size(90, 32);
            this.button173.TabIndex = 133;
            this.button173.Text = "button173";
            this.button173.UseVisualStyleBackColor = true;
            // 
            // button174
            // 
            this.button174.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button174.Location = new System.Drawing.Point(405, 205);
            this.button174.Name = "button174";
            this.button174.Size = new System.Drawing.Size(90, 32);
            this.button174.TabIndex = 132;
            this.button174.Text = "button174";
            this.button174.UseVisualStyleBackColor = true;
            // 
            // button175
            // 
            this.button175.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button175.Location = new System.Drawing.Point(504, 205);
            this.button175.Name = "button175";
            this.button175.Size = new System.Drawing.Size(90, 32);
            this.button175.TabIndex = 131;
            this.button175.Text = "button175";
            this.button175.UseVisualStyleBackColor = true;
            // 
            // button176
            // 
            this.button176.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button176.Location = new System.Drawing.Point(603, 205);
            this.button176.Name = "button176";
            this.button176.Size = new System.Drawing.Size(90, 32);
            this.button176.TabIndex = 130;
            this.button176.Text = "button176";
            this.button176.UseVisualStyleBackColor = true;
            // 
            // button177
            // 
            this.button177.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button177.Location = new System.Drawing.Point(699, 205);
            this.button177.Name = "button177";
            this.button177.Size = new System.Drawing.Size(90, 32);
            this.button177.TabIndex = 129;
            this.button177.Text = "button177";
            this.button177.UseVisualStyleBackColor = true;
            // 
            // button155
            // 
            this.button155.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button155.Location = new System.Drawing.Point(9, 167);
            this.button155.Name = "button155";
            this.button155.Size = new System.Drawing.Size(90, 32);
            this.button155.TabIndex = 128;
            this.button155.Text = "button155";
            this.button155.UseVisualStyleBackColor = true;
            // 
            // button156
            // 
            this.button156.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button156.Location = new System.Drawing.Point(111, 167);
            this.button156.Name = "button156";
            this.button156.Size = new System.Drawing.Size(90, 32);
            this.button156.TabIndex = 127;
            this.button156.Text = "button156";
            this.button156.UseVisualStyleBackColor = true;
            // 
            // button157
            // 
            this.button157.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button157.Location = new System.Drawing.Point(210, 167);
            this.button157.Name = "button157";
            this.button157.Size = new System.Drawing.Size(90, 32);
            this.button157.TabIndex = 126;
            this.button157.Text = "button157";
            this.button157.UseVisualStyleBackColor = true;
            // 
            // button158
            // 
            this.button158.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button158.Location = new System.Drawing.Point(309, 167);
            this.button158.Name = "button158";
            this.button158.Size = new System.Drawing.Size(90, 32);
            this.button158.TabIndex = 125;
            this.button158.Text = "button158";
            this.button158.UseVisualStyleBackColor = true;
            // 
            // button159
            // 
            this.button159.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button159.Location = new System.Drawing.Point(405, 167);
            this.button159.Name = "button159";
            this.button159.Size = new System.Drawing.Size(90, 32);
            this.button159.TabIndex = 124;
            this.button159.Text = "button159";
            this.button159.UseVisualStyleBackColor = true;
            // 
            // button160
            // 
            this.button160.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button160.Location = new System.Drawing.Point(504, 167);
            this.button160.Name = "button160";
            this.button160.Size = new System.Drawing.Size(90, 32);
            this.button160.TabIndex = 123;
            this.button160.Text = "button160";
            this.button160.UseVisualStyleBackColor = true;
            // 
            // button161
            // 
            this.button161.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button161.Location = new System.Drawing.Point(603, 167);
            this.button161.Name = "button161";
            this.button161.Size = new System.Drawing.Size(90, 32);
            this.button161.TabIndex = 122;
            this.button161.Text = "button161";
            this.button161.UseVisualStyleBackColor = true;
            // 
            // button162
            // 
            this.button162.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button162.Location = new System.Drawing.Point(699, 167);
            this.button162.Name = "button162";
            this.button162.Size = new System.Drawing.Size(90, 32);
            this.button162.TabIndex = 121;
            this.button162.Text = "button162";
            this.button162.UseVisualStyleBackColor = true;
            // 
            // button140
            // 
            this.button140.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button140.Location = new System.Drawing.Point(9, 129);
            this.button140.Name = "button140";
            this.button140.Size = new System.Drawing.Size(90, 32);
            this.button140.TabIndex = 120;
            this.button140.Text = "button140";
            this.button140.UseVisualStyleBackColor = true;
            // 
            // button141
            // 
            this.button141.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button141.Location = new System.Drawing.Point(111, 129);
            this.button141.Name = "button141";
            this.button141.Size = new System.Drawing.Size(90, 32);
            this.button141.TabIndex = 119;
            this.button141.Text = "button141";
            this.button141.UseVisualStyleBackColor = true;
            // 
            // button142
            // 
            this.button142.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button142.Location = new System.Drawing.Point(210, 129);
            this.button142.Name = "button142";
            this.button142.Size = new System.Drawing.Size(90, 32);
            this.button142.TabIndex = 118;
            this.button142.Text = "button142";
            this.button142.UseVisualStyleBackColor = true;
            // 
            // button143
            // 
            this.button143.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button143.Location = new System.Drawing.Point(309, 129);
            this.button143.Name = "button143";
            this.button143.Size = new System.Drawing.Size(90, 32);
            this.button143.TabIndex = 117;
            this.button143.Text = "button143";
            this.button143.UseVisualStyleBackColor = true;
            // 
            // button144
            // 
            this.button144.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button144.Location = new System.Drawing.Point(405, 129);
            this.button144.Name = "button144";
            this.button144.Size = new System.Drawing.Size(90, 32);
            this.button144.TabIndex = 116;
            this.button144.Text = "button144";
            this.button144.UseVisualStyleBackColor = true;
            // 
            // button145
            // 
            this.button145.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button145.Location = new System.Drawing.Point(504, 129);
            this.button145.Name = "button145";
            this.button145.Size = new System.Drawing.Size(90, 32);
            this.button145.TabIndex = 115;
            this.button145.Text = "button145";
            this.button145.UseVisualStyleBackColor = true;
            // 
            // button146
            // 
            this.button146.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button146.Location = new System.Drawing.Point(603, 129);
            this.button146.Name = "button146";
            this.button146.Size = new System.Drawing.Size(90, 32);
            this.button146.TabIndex = 114;
            this.button146.Text = "button146";
            this.button146.UseVisualStyleBackColor = true;
            // 
            // button147
            // 
            this.button147.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button147.Location = new System.Drawing.Point(699, 129);
            this.button147.Name = "button147";
            this.button147.Size = new System.Drawing.Size(90, 32);
            this.button147.TabIndex = 113;
            this.button147.Text = "button147";
            this.button147.UseVisualStyleBackColor = true;
            // 
            // button125
            // 
            this.button125.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button125.Location = new System.Drawing.Point(9, 91);
            this.button125.Name = "button125";
            this.button125.Size = new System.Drawing.Size(90, 32);
            this.button125.TabIndex = 112;
            this.button125.Text = "button125";
            this.button125.UseVisualStyleBackColor = true;
            // 
            // button126
            // 
            this.button126.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button126.Location = new System.Drawing.Point(111, 91);
            this.button126.Name = "button126";
            this.button126.Size = new System.Drawing.Size(90, 32);
            this.button126.TabIndex = 111;
            this.button126.Text = "button126";
            this.button126.UseVisualStyleBackColor = true;
            // 
            // button127
            // 
            this.button127.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button127.Location = new System.Drawing.Point(210, 91);
            this.button127.Name = "button127";
            this.button127.Size = new System.Drawing.Size(90, 32);
            this.button127.TabIndex = 110;
            this.button127.Text = "button127";
            this.button127.UseVisualStyleBackColor = true;
            // 
            // button128
            // 
            this.button128.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button128.Location = new System.Drawing.Point(309, 91);
            this.button128.Name = "button128";
            this.button128.Size = new System.Drawing.Size(90, 32);
            this.button128.TabIndex = 109;
            this.button128.Text = "button128";
            this.button128.UseVisualStyleBackColor = true;
            // 
            // button129
            // 
            this.button129.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button129.Location = new System.Drawing.Point(405, 91);
            this.button129.Name = "button129";
            this.button129.Size = new System.Drawing.Size(90, 32);
            this.button129.TabIndex = 108;
            this.button129.Text = "button129";
            this.button129.UseVisualStyleBackColor = true;
            // 
            // button130
            // 
            this.button130.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button130.Location = new System.Drawing.Point(504, 91);
            this.button130.Name = "button130";
            this.button130.Size = new System.Drawing.Size(90, 32);
            this.button130.TabIndex = 107;
            this.button130.Text = "button130";
            this.button130.UseVisualStyleBackColor = true;
            // 
            // button131
            // 
            this.button131.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button131.Location = new System.Drawing.Point(603, 91);
            this.button131.Name = "button131";
            this.button131.Size = new System.Drawing.Size(90, 32);
            this.button131.TabIndex = 106;
            this.button131.Text = "button131";
            this.button131.UseVisualStyleBackColor = true;
            // 
            // button132
            // 
            this.button132.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button132.Location = new System.Drawing.Point(699, 91);
            this.button132.Name = "button132";
            this.button132.Size = new System.Drawing.Size(90, 32);
            this.button132.TabIndex = 105;
            this.button132.Text = "button132";
            this.button132.UseVisualStyleBackColor = true;
            // 
            // pc_sample_composite_head_shift_c
            // 
            this.pc_sample_composite_head_shift_c.Location = new System.Drawing.Point(699, 13);
            this.pc_sample_composite_head_shift_c.Name = "pc_sample_composite_head_shift_c";
            this.pc_sample_composite_head_shift_c.Size = new System.Drawing.Size(93, 32);
            this.pc_sample_composite_head_shift_c.TabIndex = 8;
            this.pc_sample_composite_head_shift_c.Text = "Composite";
            this.pc_sample_composite_head_shift_c.UseVisualStyleBackColor = true;
            // 
            // pc_sample_moist_head_shift_c
            // 
            this.pc_sample_moist_head_shift_c.Location = new System.Drawing.Point(600, 13);
            this.pc_sample_moist_head_shift_c.Name = "pc_sample_moist_head_shift_c";
            this.pc_sample_moist_head_shift_c.Size = new System.Drawing.Size(93, 32);
            this.pc_sample_moist_head_shift_c.TabIndex = 8;
            this.pc_sample_moist_head_shift_c.Text = "Moisture";
            this.pc_sample_moist_head_shift_c.UseVisualStyleBackColor = true;
            // 
            // pc_sample_avg_head_shift_c
            // 
            this.pc_sample_avg_head_shift_c.Location = new System.Drawing.Point(501, 13);
            this.pc_sample_avg_head_shift_c.Name = "pc_sample_avg_head_shift_c";
            this.pc_sample_avg_head_shift_c.Size = new System.Drawing.Size(93, 32);
            this.pc_sample_avg_head_shift_c.TabIndex = 7;
            this.pc_sample_avg_head_shift_c.Text = "Average";
            this.pc_sample_avg_head_shift_c.UseVisualStyleBackColor = true;
            // 
            // pc_sample_one_head_shift_c
            // 
            this.pc_sample_one_head_shift_c.Location = new System.Drawing.Point(6, 13);
            this.pc_sample_one_head_shift_c.Name = "pc_sample_one_head_shift_c";
            this.pc_sample_one_head_shift_c.Size = new System.Drawing.Size(93, 32);
            this.pc_sample_one_head_shift_c.TabIndex = 2;
            this.pc_sample_one_head_shift_c.Text = "Sample 1";
            this.pc_sample_one_head_shift_c.UseVisualStyleBackColor = true;
            // 
            // pc_sample_fivve_head_shift_c
            // 
            this.pc_sample_fivve_head_shift_c.Location = new System.Drawing.Point(402, 13);
            this.pc_sample_fivve_head_shift_c.Name = "pc_sample_fivve_head_shift_c";
            this.pc_sample_fivve_head_shift_c.Size = new System.Drawing.Size(93, 32);
            this.pc_sample_fivve_head_shift_c.TabIndex = 6;
            this.pc_sample_fivve_head_shift_c.Text = "Sample 5";
            this.pc_sample_fivve_head_shift_c.UseVisualStyleBackColor = true;
            // 
            // pc_sample_two_head_shift_c
            // 
            this.pc_sample_two_head_shift_c.Location = new System.Drawing.Point(105, 13);
            this.pc_sample_two_head_shift_c.Name = "pc_sample_two_head_shift_c";
            this.pc_sample_two_head_shift_c.Size = new System.Drawing.Size(93, 32);
            this.pc_sample_two_head_shift_c.TabIndex = 3;
            this.pc_sample_two_head_shift_c.Text = "Sample 2";
            this.pc_sample_two_head_shift_c.UseVisualStyleBackColor = true;
            // 
            // pc_sample_four_head_shift_c
            // 
            this.pc_sample_four_head_shift_c.Location = new System.Drawing.Point(303, 13);
            this.pc_sample_four_head_shift_c.Name = "pc_sample_four_head_shift_c";
            this.pc_sample_four_head_shift_c.Size = new System.Drawing.Size(93, 32);
            this.pc_sample_four_head_shift_c.TabIndex = 5;
            this.pc_sample_four_head_shift_c.Text = "Sample 4";
            this.pc_sample_four_head_shift_c.UseVisualStyleBackColor = true;
            // 
            // pc_sample_three_head_shift_c
            // 
            this.pc_sample_three_head_shift_c.Location = new System.Drawing.Point(204, 13);
            this.pc_sample_three_head_shift_c.Name = "pc_sample_three_head_shift_c";
            this.pc_sample_three_head_shift_c.Size = new System.Drawing.Size(93, 32);
            this.pc_sample_three_head_shift_c.TabIndex = 4;
            this.pc_sample_three_head_shift_c.Text = "Sample 3";
            this.pc_sample_three_head_shift_c.UseVisualStyleBackColor = true;
            // 
            // pressCake_head_shift_c
            // 
            this.pressCake_head_shift_c.Location = new System.Drawing.Point(6, 13);
            this.pressCake_head_shift_c.Name = "pressCake_head_shift_c";
            this.pressCake_head_shift_c.Size = new System.Drawing.Size(801, 41);
            this.pressCake_head_shift_c.TabIndex = 1;
            this.pressCake_head_shift_c.Text = "Press Cake";
            this.pressCake_head_shift_c.UseVisualStyleBackColor = true;
            // 
            // groupBox24
            // 
            this.groupBox24.Controls.Add(this.groupBox25);
            this.groupBox24.Controls.Add(this.groupBox26);
            this.groupBox24.Controls.Add(this.bagass_head_shift_c);
            this.groupBox24.Location = new System.Drawing.Point(90, 15);
            this.groupBox24.Name = "groupBox24";
            this.groupBox24.Size = new System.Drawing.Size(441, 556);
            this.groupBox24.TabIndex = 1;
            this.groupBox24.TabStop = false;
            // 
            // groupBox25
            // 
            this.groupBox25.Controls.Add(this.button168);
            this.groupBox25.Controls.Add(this.button169);
            this.groupBox25.Controls.Add(this.button153);
            this.groupBox25.Controls.Add(this.button154);
            this.groupBox25.Controls.Add(this.button138);
            this.groupBox25.Controls.Add(this.button139);
            this.groupBox25.Controls.Add(this.button123);
            this.groupBox25.Controls.Add(this.button124);
            this.groupBox25.Controls.Add(this.bagasse_om_moist_shift_c);
            this.groupBox25.Controls.Add(this.bagasse_om_pol_shift_c);
            this.groupBox25.Controls.Add(this.bagasse_head_om_shift_c);
            this.groupBox25.Location = new System.Drawing.Point(220, 57);
            this.groupBox25.Name = "groupBox25";
            this.groupBox25.Size = new System.Drawing.Size(208, 285);
            this.groupBox25.TabIndex = 2;
            this.groupBox25.TabStop = false;
            // 
            // button168
            // 
            this.button168.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button168.Location = new System.Drawing.Point(6, 206);
            this.button168.Name = "button168";
            this.button168.Size = new System.Drawing.Size(90, 32);
            this.button168.TabIndex = 37;
            this.button168.Text = "button168";
            this.button168.UseVisualStyleBackColor = true;
            // 
            // button169
            // 
            this.button169.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button169.Location = new System.Drawing.Point(102, 206);
            this.button169.Name = "button169";
            this.button169.Size = new System.Drawing.Size(90, 32);
            this.button169.TabIndex = 36;
            this.button169.Text = "button169";
            this.button169.UseVisualStyleBackColor = true;
            // 
            // button153
            // 
            this.button153.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button153.Location = new System.Drawing.Point(6, 168);
            this.button153.Name = "button153";
            this.button153.Size = new System.Drawing.Size(90, 32);
            this.button153.TabIndex = 35;
            this.button153.Text = "button153";
            this.button153.UseVisualStyleBackColor = true;
            // 
            // button154
            // 
            this.button154.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button154.Location = new System.Drawing.Point(102, 168);
            this.button154.Name = "button154";
            this.button154.Size = new System.Drawing.Size(90, 32);
            this.button154.TabIndex = 34;
            this.button154.Text = "button154";
            this.button154.UseVisualStyleBackColor = true;
            // 
            // button138
            // 
            this.button138.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button138.Location = new System.Drawing.Point(6, 130);
            this.button138.Name = "button138";
            this.button138.Size = new System.Drawing.Size(90, 32);
            this.button138.TabIndex = 33;
            this.button138.Text = "button138";
            this.button138.UseVisualStyleBackColor = true;
            // 
            // button139
            // 
            this.button139.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button139.Location = new System.Drawing.Point(102, 130);
            this.button139.Name = "button139";
            this.button139.Size = new System.Drawing.Size(90, 32);
            this.button139.TabIndex = 32;
            this.button139.Text = "button139";
            this.button139.UseVisualStyleBackColor = true;
            // 
            // button123
            // 
            this.button123.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button123.Location = new System.Drawing.Point(6, 92);
            this.button123.Name = "button123";
            this.button123.Size = new System.Drawing.Size(90, 32);
            this.button123.TabIndex = 31;
            this.button123.Text = "button123";
            this.button123.UseVisualStyleBackColor = true;
            // 
            // button124
            // 
            this.button124.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button124.Location = new System.Drawing.Point(102, 92);
            this.button124.Name = "button124";
            this.button124.Size = new System.Drawing.Size(90, 32);
            this.button124.TabIndex = 30;
            this.button124.Text = "button124";
            this.button124.UseVisualStyleBackColor = true;
            // 
            // bagasse_om_moist_shift_c
            // 
            this.bagasse_om_moist_shift_c.Location = new System.Drawing.Point(102, 47);
            this.bagasse_om_moist_shift_c.Name = "bagasse_om_moist_shift_c";
            this.bagasse_om_moist_shift_c.Size = new System.Drawing.Size(90, 32);
            this.bagasse_om_moist_shift_c.TabIndex = 5;
            this.bagasse_om_moist_shift_c.Text = "Moisture";
            this.bagasse_om_moist_shift_c.UseVisualStyleBackColor = true;
            // 
            // bagasse_om_pol_shift_c
            // 
            this.bagasse_om_pol_shift_c.Location = new System.Drawing.Point(6, 47);
            this.bagasse_om_pol_shift_c.Name = "bagasse_om_pol_shift_c";
            this.bagasse_om_pol_shift_c.Size = new System.Drawing.Size(90, 32);
            this.bagasse_om_pol_shift_c.TabIndex = 4;
            this.bagasse_om_pol_shift_c.Text = "Pol";
            this.bagasse_om_pol_shift_c.UseVisualStyleBackColor = true;
            // 
            // bagasse_head_om_shift_c
            // 
            this.bagasse_head_om_shift_c.Location = new System.Drawing.Point(6, 13);
            this.bagasse_head_om_shift_c.Name = "bagasse_head_om_shift_c";
            this.bagasse_head_om_shift_c.Size = new System.Drawing.Size(186, 32);
            this.bagasse_head_om_shift_c.TabIndex = 1;
            this.bagasse_head_om_shift_c.Text = "Old Mill";
            this.bagasse_head_om_shift_c.UseVisualStyleBackColor = true;
            // 
            // groupBox26
            // 
            this.groupBox26.Controls.Add(this.button166);
            this.groupBox26.Controls.Add(this.button167);
            this.groupBox26.Controls.Add(this.button151);
            this.groupBox26.Controls.Add(this.button152);
            this.groupBox26.Controls.Add(this.button136);
            this.groupBox26.Controls.Add(this.button137);
            this.groupBox26.Controls.Add(this.button121);
            this.groupBox26.Controls.Add(this.button122);
            this.groupBox26.Controls.Add(this.bagasse_nm_moist_shift_c);
            this.groupBox26.Controls.Add(this.bagasse_nm_pol_shift_c);
            this.groupBox26.Controls.Add(this.bagasse_head_nm_shift_c);
            this.groupBox26.Location = new System.Drawing.Point(6, 57);
            this.groupBox26.Name = "groupBox26";
            this.groupBox26.Size = new System.Drawing.Size(208, 285);
            this.groupBox26.TabIndex = 1;
            this.groupBox26.TabStop = false;
            // 
            // button166
            // 
            this.button166.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button166.Location = new System.Drawing.Point(6, 206);
            this.button166.Name = "button166";
            this.button166.Size = new System.Drawing.Size(90, 32);
            this.button166.TabIndex = 37;
            this.button166.Text = "button166";
            this.button166.UseVisualStyleBackColor = true;
            // 
            // button167
            // 
            this.button167.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button167.Location = new System.Drawing.Point(102, 206);
            this.button167.Name = "button167";
            this.button167.Size = new System.Drawing.Size(90, 32);
            this.button167.TabIndex = 36;
            this.button167.Text = "button167";
            this.button167.UseVisualStyleBackColor = true;
            // 
            // button151
            // 
            this.button151.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button151.Location = new System.Drawing.Point(6, 168);
            this.button151.Name = "button151";
            this.button151.Size = new System.Drawing.Size(90, 32);
            this.button151.TabIndex = 35;
            this.button151.Text = "button151";
            this.button151.UseVisualStyleBackColor = true;
            // 
            // button152
            // 
            this.button152.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button152.Location = new System.Drawing.Point(102, 168);
            this.button152.Name = "button152";
            this.button152.Size = new System.Drawing.Size(90, 32);
            this.button152.TabIndex = 34;
            this.button152.Text = "button152";
            this.button152.UseVisualStyleBackColor = true;
            // 
            // button136
            // 
            this.button136.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button136.Location = new System.Drawing.Point(6, 130);
            this.button136.Name = "button136";
            this.button136.Size = new System.Drawing.Size(90, 32);
            this.button136.TabIndex = 33;
            this.button136.Text = "button136";
            this.button136.UseVisualStyleBackColor = true;
            // 
            // button137
            // 
            this.button137.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button137.Location = new System.Drawing.Point(102, 130);
            this.button137.Name = "button137";
            this.button137.Size = new System.Drawing.Size(90, 32);
            this.button137.TabIndex = 32;
            this.button137.Text = "button137";
            this.button137.UseVisualStyleBackColor = true;
            // 
            // button121
            // 
            this.button121.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button121.Location = new System.Drawing.Point(6, 92);
            this.button121.Name = "button121";
            this.button121.Size = new System.Drawing.Size(90, 32);
            this.button121.TabIndex = 31;
            this.button121.Text = "button121";
            this.button121.UseVisualStyleBackColor = true;
            // 
            // button122
            // 
            this.button122.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button122.Location = new System.Drawing.Point(102, 92);
            this.button122.Name = "button122";
            this.button122.Size = new System.Drawing.Size(90, 32);
            this.button122.TabIndex = 30;
            this.button122.Text = "button122";
            this.button122.UseVisualStyleBackColor = true;
            // 
            // bagasse_nm_moist_shift_c
            // 
            this.bagasse_nm_moist_shift_c.Location = new System.Drawing.Point(102, 46);
            this.bagasse_nm_moist_shift_c.Name = "bagasse_nm_moist_shift_c";
            this.bagasse_nm_moist_shift_c.Size = new System.Drawing.Size(90, 32);
            this.bagasse_nm_moist_shift_c.TabIndex = 3;
            this.bagasse_nm_moist_shift_c.Text = "Moisture";
            this.bagasse_nm_moist_shift_c.UseVisualStyleBackColor = true;
            // 
            // bagasse_nm_pol_shift_c
            // 
            this.bagasse_nm_pol_shift_c.Location = new System.Drawing.Point(6, 46);
            this.bagasse_nm_pol_shift_c.Name = "bagasse_nm_pol_shift_c";
            this.bagasse_nm_pol_shift_c.Size = new System.Drawing.Size(90, 32);
            this.bagasse_nm_pol_shift_c.TabIndex = 2;
            this.bagasse_nm_pol_shift_c.Text = "Pol";
            this.bagasse_nm_pol_shift_c.UseVisualStyleBackColor = true;
            // 
            // bagasse_head_nm_shift_c
            // 
            this.bagasse_head_nm_shift_c.Location = new System.Drawing.Point(6, 13);
            this.bagasse_head_nm_shift_c.Name = "bagasse_head_nm_shift_c";
            this.bagasse_head_nm_shift_c.Size = new System.Drawing.Size(186, 32);
            this.bagasse_head_nm_shift_c.TabIndex = 1;
            this.bagasse_head_nm_shift_c.Text = "New Mill";
            this.bagasse_head_nm_shift_c.UseVisualStyleBackColor = true;
            // 
            // bagass_head_shift_c
            // 
            this.bagass_head_shift_c.Location = new System.Drawing.Point(6, 13);
            this.bagass_head_shift_c.Name = "bagass_head_shift_c";
            this.bagass_head_shift_c.Size = new System.Drawing.Size(422, 41);
            this.bagass_head_shift_c.TabIndex = 0;
            this.bagass_head_shift_c.Text = "Bagasse";
            this.bagass_head_shift_c.UseVisualStyleBackColor = true;
            // 
            // groupBox27
            // 
            this.groupBox27.Controls.Add(this.button181);
            this.groupBox27.Controls.Add(this.button182);
            this.groupBox27.Controls.Add(this.button183);
            this.groupBox27.Controls.Add(this.button184);
            this.groupBox27.Controls.Add(this.button383);
            this.groupBox27.Controls.Add(this.time_head_shiftC);
            this.groupBox27.Location = new System.Drawing.Point(6, 73);
            this.groupBox27.Name = "groupBox27";
            this.groupBox27.Size = new System.Drawing.Size(78, 480);
            this.groupBox27.TabIndex = 0;
            this.groupBox27.TabStop = false;
            // 
            // button181
            // 
            this.button181.Location = new System.Drawing.Point(7, 213);
            this.button181.Name = "button181";
            this.button181.Size = new System.Drawing.Size(66, 36);
            this.button181.TabIndex = 17;
            this.button181.Text = "8";
            this.button181.UseVisualStyleBackColor = true;
            // 
            // button182
            // 
            this.button182.Location = new System.Drawing.Point(7, 171);
            this.button182.Name = "button182";
            this.button182.Size = new System.Drawing.Size(66, 36);
            this.button182.TabIndex = 16;
            this.button182.Text = "6";
            this.button182.UseVisualStyleBackColor = true;
            // 
            // button183
            // 
            this.button183.Location = new System.Drawing.Point(7, 129);
            this.button183.Name = "button183";
            this.button183.Size = new System.Drawing.Size(66, 36);
            this.button183.TabIndex = 15;
            this.button183.Text = "4";
            this.button183.UseVisualStyleBackColor = true;
            // 
            // button184
            // 
            this.button184.Location = new System.Drawing.Point(7, 87);
            this.button184.Name = "button184";
            this.button184.Size = new System.Drawing.Size(66, 36);
            this.button184.TabIndex = 14;
            this.button184.Text = "2";
            this.button184.UseVisualStyleBackColor = true;
            // 
            // button383
            // 
            this.button383.Location = new System.Drawing.Point(7, 255);
            this.button383.Name = "button383";
            this.button383.Size = new System.Drawing.Size(67, 44);
            this.button383.TabIndex = 7;
            this.button383.Text = "Average";
            this.button383.UseVisualStyleBackColor = true;
            // 
            // time_head_shiftC
            // 
            this.time_head_shiftC.Location = new System.Drawing.Point(6, 17);
            this.time_head_shiftC.Name = "time_head_shiftC";
            this.time_head_shiftC.Size = new System.Drawing.Size(67, 64);
            this.time_head_shiftC.TabIndex = 3;
            this.time_head_shiftC.Text = "Time";
            this.time_head_shiftC.UseVisualStyleBackColor = true;
            // 
            // groupBox10
            // 
            this.groupBox10.Controls.Add(this.groupBox11);
            this.groupBox10.Controls.Add(this.groupBox13);
            this.groupBox10.Controls.Add(this.groupBox15);
            this.groupBox10.Controls.Add(this.groupBox18);
            this.groupBox10.Location = new System.Drawing.Point(4, 474);
            this.groupBox10.Name = "groupBox10";
            this.groupBox10.Size = new System.Drawing.Size(1630, 434);
            this.groupBox10.TabIndex = 1;
            this.groupBox10.TabStop = false;
            this.groupBox10.Text = "Shift-B";
            // 
            // groupBox11
            // 
            this.groupBox11.Controls.Add(this.groupBox12);
            this.groupBox11.Controls.Add(this.FMolasses_head_shift_b);
            this.groupBox11.Location = new System.Drawing.Point(1363, 15);
            this.groupBox11.Name = "groupBox11";
            this.groupBox11.Size = new System.Drawing.Size(270, 556);
            this.groupBox11.TabIndex = 3;
            this.groupBox11.TabStop = false;
            // 
            // groupBox12
            // 
            this.groupBox12.Controls.Add(this.button118);
            this.groupBox12.Controls.Add(this.button119);
            this.groupBox12.Controls.Add(this.button120);
            this.groupBox12.Controls.Add(this.button103);
            this.groupBox12.Controls.Add(this.button104);
            this.groupBox12.Controls.Add(this.button105);
            this.groupBox12.Controls.Add(this.button88);
            this.groupBox12.Controls.Add(this.button89);
            this.groupBox12.Controls.Add(this.button90);
            this.groupBox12.Controls.Add(this.button73);
            this.groupBox12.Controls.Add(this.button74);
            this.groupBox12.Controls.Add(this.button75);
            this.groupBox12.Controls.Add(this.final_mol_purity_head_shift_b);
            this.groupBox12.Controls.Add(this.final_mol_Pol_head_shift_b);
            this.groupBox12.Controls.Add(this.final_mol_brix_head_shift_b);
            this.groupBox12.Location = new System.Drawing.Point(6, 58);
            this.groupBox12.Name = "groupBox12";
            this.groupBox12.Size = new System.Drawing.Size(252, 332);
            this.groupBox12.TabIndex = 3;
            this.groupBox12.TabStop = false;
            // 
            // button118
            // 
            this.button118.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button118.Location = new System.Drawing.Point(6, 215);
            this.button118.Name = "button118";
            this.button118.Size = new System.Drawing.Size(75, 32);
            this.button118.TabIndex = 42;
            this.button118.Text = "button118";
            this.button118.UseVisualStyleBackColor = true;
            // 
            // button119
            // 
            this.button119.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button119.Location = new System.Drawing.Point(87, 215);
            this.button119.Name = "button119";
            this.button119.Size = new System.Drawing.Size(75, 32);
            this.button119.TabIndex = 41;
            this.button119.Text = "button119";
            this.button119.UseVisualStyleBackColor = true;
            // 
            // button120
            // 
            this.button120.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button120.Location = new System.Drawing.Point(168, 215);
            this.button120.Name = "button120";
            this.button120.Size = new System.Drawing.Size(75, 32);
            this.button120.TabIndex = 40;
            this.button120.Text = "button120";
            this.button120.UseVisualStyleBackColor = true;
            // 
            // button103
            // 
            this.button103.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button103.Location = new System.Drawing.Point(6, 173);
            this.button103.Name = "button103";
            this.button103.Size = new System.Drawing.Size(75, 32);
            this.button103.TabIndex = 39;
            this.button103.Text = "button103";
            this.button103.UseVisualStyleBackColor = true;
            // 
            // button104
            // 
            this.button104.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button104.Location = new System.Drawing.Point(87, 173);
            this.button104.Name = "button104";
            this.button104.Size = new System.Drawing.Size(75, 32);
            this.button104.TabIndex = 38;
            this.button104.Text = "button104";
            this.button104.UseVisualStyleBackColor = true;
            // 
            // button105
            // 
            this.button105.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button105.Location = new System.Drawing.Point(168, 173);
            this.button105.Name = "button105";
            this.button105.Size = new System.Drawing.Size(75, 32);
            this.button105.TabIndex = 37;
            this.button105.Text = "button105";
            this.button105.UseVisualStyleBackColor = true;
            // 
            // button88
            // 
            this.button88.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button88.Location = new System.Drawing.Point(6, 129);
            this.button88.Name = "button88";
            this.button88.Size = new System.Drawing.Size(75, 32);
            this.button88.TabIndex = 36;
            this.button88.Text = "button88";
            this.button88.UseVisualStyleBackColor = true;
            // 
            // button89
            // 
            this.button89.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button89.Location = new System.Drawing.Point(87, 129);
            this.button89.Name = "button89";
            this.button89.Size = new System.Drawing.Size(75, 32);
            this.button89.TabIndex = 35;
            this.button89.Text = "button89";
            this.button89.UseVisualStyleBackColor = true;
            // 
            // button90
            // 
            this.button90.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button90.Location = new System.Drawing.Point(168, 129);
            this.button90.Name = "button90";
            this.button90.Size = new System.Drawing.Size(75, 32);
            this.button90.TabIndex = 34;
            this.button90.Text = "button90";
            this.button90.UseVisualStyleBackColor = true;
            // 
            // button73
            // 
            this.button73.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button73.Location = new System.Drawing.Point(6, 89);
            this.button73.Name = "button73";
            this.button73.Size = new System.Drawing.Size(75, 32);
            this.button73.TabIndex = 33;
            this.button73.Text = "button73";
            this.button73.UseVisualStyleBackColor = true;
            // 
            // button74
            // 
            this.button74.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button74.Location = new System.Drawing.Point(87, 89);
            this.button74.Name = "button74";
            this.button74.Size = new System.Drawing.Size(75, 32);
            this.button74.TabIndex = 32;
            this.button74.Text = "button74";
            this.button74.UseVisualStyleBackColor = true;
            // 
            // button75
            // 
            this.button75.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button75.Location = new System.Drawing.Point(168, 89);
            this.button75.Name = "button75";
            this.button75.Size = new System.Drawing.Size(75, 32);
            this.button75.TabIndex = 31;
            this.button75.Text = "button75";
            this.button75.UseVisualStyleBackColor = true;
            // 
            // final_mol_purity_head_shift_b
            // 
            this.final_mol_purity_head_shift_b.Location = new System.Drawing.Point(168, 13);
            this.final_mol_purity_head_shift_b.Name = "final_mol_purity_head_shift_b";
            this.final_mol_purity_head_shift_b.Size = new System.Drawing.Size(75, 32);
            this.final_mol_purity_head_shift_b.TabIndex = 2;
            this.final_mol_purity_head_shift_b.Text = "Purity";
            this.final_mol_purity_head_shift_b.UseVisualStyleBackColor = true;
            // 
            // final_mol_Pol_head_shift_b
            // 
            this.final_mol_Pol_head_shift_b.Location = new System.Drawing.Point(87, 13);
            this.final_mol_Pol_head_shift_b.Name = "final_mol_Pol_head_shift_b";
            this.final_mol_Pol_head_shift_b.Size = new System.Drawing.Size(75, 32);
            this.final_mol_Pol_head_shift_b.TabIndex = 1;
            this.final_mol_Pol_head_shift_b.Text = "Pol";
            this.final_mol_Pol_head_shift_b.UseVisualStyleBackColor = true;
            // 
            // final_mol_brix_head_shift_b
            // 
            this.final_mol_brix_head_shift_b.Location = new System.Drawing.Point(6, 13);
            this.final_mol_brix_head_shift_b.Name = "final_mol_brix_head_shift_b";
            this.final_mol_brix_head_shift_b.Size = new System.Drawing.Size(75, 32);
            this.final_mol_brix_head_shift_b.TabIndex = 0;
            this.final_mol_brix_head_shift_b.Text = "Brix";
            this.final_mol_brix_head_shift_b.UseVisualStyleBackColor = true;
            // 
            // FMolasses_head_shift_b
            // 
            this.FMolasses_head_shift_b.Location = new System.Drawing.Point(6, 14);
            this.FMolasses_head_shift_b.Name = "FMolasses_head_shift_b";
            this.FMolasses_head_shift_b.Size = new System.Drawing.Size(243, 41);
            this.FMolasses_head_shift_b.TabIndex = 2;
            this.FMolasses_head_shift_b.Text = "Final Molasses";
            this.FMolasses_head_shift_b.UseVisualStyleBackColor = true;
            // 
            // groupBox13
            // 
            this.groupBox13.Controls.Add(this.groupBox14);
            this.groupBox13.Controls.Add(this.pressCake_head_shift_b);
            this.groupBox13.Location = new System.Drawing.Point(537, 15);
            this.groupBox13.Name = "groupBox13";
            this.groupBox13.Size = new System.Drawing.Size(820, 390);
            this.groupBox13.TabIndex = 2;
            this.groupBox13.TabStop = false;
            // 
            // groupBox14
            // 
            this.groupBox14.Controls.Add(this.button110);
            this.groupBox14.Controls.Add(this.button111);
            this.groupBox14.Controls.Add(this.button112);
            this.groupBox14.Controls.Add(this.button113);
            this.groupBox14.Controls.Add(this.button114);
            this.groupBox14.Controls.Add(this.button115);
            this.groupBox14.Controls.Add(this.button116);
            this.groupBox14.Controls.Add(this.button117);
            this.groupBox14.Controls.Add(this.button95);
            this.groupBox14.Controls.Add(this.button96);
            this.groupBox14.Controls.Add(this.button97);
            this.groupBox14.Controls.Add(this.button98);
            this.groupBox14.Controls.Add(this.button99);
            this.groupBox14.Controls.Add(this.button100);
            this.groupBox14.Controls.Add(this.button101);
            this.groupBox14.Controls.Add(this.button102);
            this.groupBox14.Controls.Add(this.button80);
            this.groupBox14.Controls.Add(this.button81);
            this.groupBox14.Controls.Add(this.button82);
            this.groupBox14.Controls.Add(this.button83);
            this.groupBox14.Controls.Add(this.button84);
            this.groupBox14.Controls.Add(this.button85);
            this.groupBox14.Controls.Add(this.button86);
            this.groupBox14.Controls.Add(this.button87);
            this.groupBox14.Controls.Add(this.button65);
            this.groupBox14.Controls.Add(this.button66);
            this.groupBox14.Controls.Add(this.button67);
            this.groupBox14.Controls.Add(this.button68);
            this.groupBox14.Controls.Add(this.button69);
            this.groupBox14.Controls.Add(this.button70);
            this.groupBox14.Controls.Add(this.button71);
            this.groupBox14.Controls.Add(this.button72);
            this.groupBox14.Controls.Add(this.pc_sample_composite_head_shift_b);
            this.groupBox14.Controls.Add(this.pc_sample_moist_head_shift_b);
            this.groupBox14.Controls.Add(this.pc_sample_avg_head_shift_b);
            this.groupBox14.Controls.Add(this.pc_sample_one_head_shift_b);
            this.groupBox14.Controls.Add(this.pc_sample_five_head_shift_b);
            this.groupBox14.Controls.Add(this.pc_sample_two_head_shift_b);
            this.groupBox14.Controls.Add(this.pc_sample_four_head_shift_b);
            this.groupBox14.Controls.Add(this.pc_sample_three_head_shift_b);
            this.groupBox14.Location = new System.Drawing.Point(6, 58);
            this.groupBox14.Name = "groupBox14";
            this.groupBox14.Size = new System.Drawing.Size(801, 259);
            this.groupBox14.TabIndex = 7;
            this.groupBox14.TabStop = false;
            // 
            // button110
            // 
            this.button110.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button110.Location = new System.Drawing.Point(9, 213);
            this.button110.Name = "button110";
            this.button110.Size = new System.Drawing.Size(90, 32);
            this.button110.TabIndex = 104;
            this.button110.Text = "button110";
            this.button110.UseVisualStyleBackColor = true;
            // 
            // button111
            // 
            this.button111.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button111.Location = new System.Drawing.Point(111, 213);
            this.button111.Name = "button111";
            this.button111.Size = new System.Drawing.Size(90, 32);
            this.button111.TabIndex = 103;
            this.button111.Text = "button111";
            this.button111.UseVisualStyleBackColor = true;
            // 
            // button112
            // 
            this.button112.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button112.Location = new System.Drawing.Point(210, 213);
            this.button112.Name = "button112";
            this.button112.Size = new System.Drawing.Size(90, 32);
            this.button112.TabIndex = 102;
            this.button112.Text = "button112";
            this.button112.UseVisualStyleBackColor = true;
            // 
            // button113
            // 
            this.button113.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button113.Location = new System.Drawing.Point(309, 213);
            this.button113.Name = "button113";
            this.button113.Size = new System.Drawing.Size(90, 32);
            this.button113.TabIndex = 101;
            this.button113.Text = "button113";
            this.button113.UseVisualStyleBackColor = true;
            // 
            // button114
            // 
            this.button114.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button114.Location = new System.Drawing.Point(405, 213);
            this.button114.Name = "button114";
            this.button114.Size = new System.Drawing.Size(90, 32);
            this.button114.TabIndex = 100;
            this.button114.Text = "button114";
            this.button114.UseVisualStyleBackColor = true;
            // 
            // button115
            // 
            this.button115.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button115.Location = new System.Drawing.Point(504, 213);
            this.button115.Name = "button115";
            this.button115.Size = new System.Drawing.Size(90, 32);
            this.button115.TabIndex = 99;
            this.button115.Text = "button115";
            this.button115.UseVisualStyleBackColor = true;
            // 
            // button116
            // 
            this.button116.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button116.Location = new System.Drawing.Point(603, 213);
            this.button116.Name = "button116";
            this.button116.Size = new System.Drawing.Size(90, 32);
            this.button116.TabIndex = 98;
            this.button116.Text = "button116";
            this.button116.UseVisualStyleBackColor = true;
            // 
            // button117
            // 
            this.button117.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button117.Location = new System.Drawing.Point(699, 213);
            this.button117.Name = "button117";
            this.button117.Size = new System.Drawing.Size(90, 32);
            this.button117.TabIndex = 97;
            this.button117.Text = "button117";
            this.button117.UseVisualStyleBackColor = true;
            // 
            // button95
            // 
            this.button95.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button95.Location = new System.Drawing.Point(9, 171);
            this.button95.Name = "button95";
            this.button95.Size = new System.Drawing.Size(90, 32);
            this.button95.TabIndex = 96;
            this.button95.Text = "button95";
            this.button95.UseVisualStyleBackColor = true;
            // 
            // button96
            // 
            this.button96.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button96.Location = new System.Drawing.Point(111, 171);
            this.button96.Name = "button96";
            this.button96.Size = new System.Drawing.Size(90, 32);
            this.button96.TabIndex = 95;
            this.button96.Text = "button96";
            this.button96.UseVisualStyleBackColor = true;
            // 
            // button97
            // 
            this.button97.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button97.Location = new System.Drawing.Point(210, 171);
            this.button97.Name = "button97";
            this.button97.Size = new System.Drawing.Size(90, 32);
            this.button97.TabIndex = 94;
            this.button97.Text = "button97";
            this.button97.UseVisualStyleBackColor = true;
            // 
            // button98
            // 
            this.button98.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button98.Location = new System.Drawing.Point(309, 171);
            this.button98.Name = "button98";
            this.button98.Size = new System.Drawing.Size(90, 32);
            this.button98.TabIndex = 93;
            this.button98.Text = "button98";
            this.button98.UseVisualStyleBackColor = true;
            // 
            // button99
            // 
            this.button99.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button99.Location = new System.Drawing.Point(405, 171);
            this.button99.Name = "button99";
            this.button99.Size = new System.Drawing.Size(90, 32);
            this.button99.TabIndex = 92;
            this.button99.Text = "button99";
            this.button99.UseVisualStyleBackColor = true;
            // 
            // button100
            // 
            this.button100.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button100.Location = new System.Drawing.Point(504, 171);
            this.button100.Name = "button100";
            this.button100.Size = new System.Drawing.Size(90, 32);
            this.button100.TabIndex = 91;
            this.button100.Text = "button100";
            this.button100.UseVisualStyleBackColor = true;
            // 
            // button101
            // 
            this.button101.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button101.Location = new System.Drawing.Point(603, 171);
            this.button101.Name = "button101";
            this.button101.Size = new System.Drawing.Size(90, 32);
            this.button101.TabIndex = 90;
            this.button101.Text = "button101";
            this.button101.UseVisualStyleBackColor = true;
            // 
            // button102
            // 
            this.button102.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button102.Location = new System.Drawing.Point(699, 171);
            this.button102.Name = "button102";
            this.button102.Size = new System.Drawing.Size(90, 32);
            this.button102.TabIndex = 89;
            this.button102.Text = "button102";
            this.button102.UseVisualStyleBackColor = true;
            // 
            // button80
            // 
            this.button80.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button80.Location = new System.Drawing.Point(9, 129);
            this.button80.Name = "button80";
            this.button80.Size = new System.Drawing.Size(90, 32);
            this.button80.TabIndex = 88;
            this.button80.Text = "button80";
            this.button80.UseVisualStyleBackColor = true;
            // 
            // button81
            // 
            this.button81.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button81.Location = new System.Drawing.Point(111, 129);
            this.button81.Name = "button81";
            this.button81.Size = new System.Drawing.Size(90, 32);
            this.button81.TabIndex = 87;
            this.button81.Text = "button81";
            this.button81.UseVisualStyleBackColor = true;
            // 
            // button82
            // 
            this.button82.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button82.Location = new System.Drawing.Point(210, 129);
            this.button82.Name = "button82";
            this.button82.Size = new System.Drawing.Size(90, 32);
            this.button82.TabIndex = 86;
            this.button82.Text = "button82";
            this.button82.UseVisualStyleBackColor = true;
            // 
            // button83
            // 
            this.button83.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button83.Location = new System.Drawing.Point(309, 129);
            this.button83.Name = "button83";
            this.button83.Size = new System.Drawing.Size(90, 32);
            this.button83.TabIndex = 85;
            this.button83.Text = "button83";
            this.button83.UseVisualStyleBackColor = true;
            // 
            // button84
            // 
            this.button84.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button84.Location = new System.Drawing.Point(405, 129);
            this.button84.Name = "button84";
            this.button84.Size = new System.Drawing.Size(90, 32);
            this.button84.TabIndex = 84;
            this.button84.Text = "button84";
            this.button84.UseVisualStyleBackColor = true;
            // 
            // button85
            // 
            this.button85.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button85.Location = new System.Drawing.Point(504, 129);
            this.button85.Name = "button85";
            this.button85.Size = new System.Drawing.Size(90, 32);
            this.button85.TabIndex = 83;
            this.button85.Text = "button85";
            this.button85.UseVisualStyleBackColor = true;
            // 
            // button86
            // 
            this.button86.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button86.Location = new System.Drawing.Point(603, 129);
            this.button86.Name = "button86";
            this.button86.Size = new System.Drawing.Size(90, 32);
            this.button86.TabIndex = 82;
            this.button86.Text = "button86";
            this.button86.UseVisualStyleBackColor = true;
            // 
            // button87
            // 
            this.button87.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button87.Location = new System.Drawing.Point(699, 129);
            this.button87.Name = "button87";
            this.button87.Size = new System.Drawing.Size(90, 32);
            this.button87.TabIndex = 81;
            this.button87.Text = "button87";
            this.button87.UseVisualStyleBackColor = true;
            // 
            // button65
            // 
            this.button65.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button65.Location = new System.Drawing.Point(9, 87);
            this.button65.Name = "button65";
            this.button65.Size = new System.Drawing.Size(90, 32);
            this.button65.TabIndex = 80;
            this.button65.Text = "button65";
            this.button65.UseVisualStyleBackColor = true;
            // 
            // button66
            // 
            this.button66.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button66.Location = new System.Drawing.Point(111, 87);
            this.button66.Name = "button66";
            this.button66.Size = new System.Drawing.Size(90, 32);
            this.button66.TabIndex = 79;
            this.button66.Text = "button66";
            this.button66.UseVisualStyleBackColor = true;
            // 
            // button67
            // 
            this.button67.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button67.Location = new System.Drawing.Point(210, 87);
            this.button67.Name = "button67";
            this.button67.Size = new System.Drawing.Size(90, 32);
            this.button67.TabIndex = 78;
            this.button67.Text = "button67";
            this.button67.UseVisualStyleBackColor = true;
            // 
            // button68
            // 
            this.button68.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button68.Location = new System.Drawing.Point(309, 87);
            this.button68.Name = "button68";
            this.button68.Size = new System.Drawing.Size(90, 32);
            this.button68.TabIndex = 77;
            this.button68.Text = "button68";
            this.button68.UseVisualStyleBackColor = true;
            // 
            // button69
            // 
            this.button69.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button69.Location = new System.Drawing.Point(405, 87);
            this.button69.Name = "button69";
            this.button69.Size = new System.Drawing.Size(90, 32);
            this.button69.TabIndex = 76;
            this.button69.Text = "button69";
            this.button69.UseVisualStyleBackColor = true;
            // 
            // button70
            // 
            this.button70.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button70.Location = new System.Drawing.Point(504, 87);
            this.button70.Name = "button70";
            this.button70.Size = new System.Drawing.Size(90, 32);
            this.button70.TabIndex = 75;
            this.button70.Text = "button70";
            this.button70.UseVisualStyleBackColor = true;
            // 
            // button71
            // 
            this.button71.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button71.Location = new System.Drawing.Point(603, 87);
            this.button71.Name = "button71";
            this.button71.Size = new System.Drawing.Size(90, 32);
            this.button71.TabIndex = 74;
            this.button71.Text = "button71";
            this.button71.UseVisualStyleBackColor = true;
            // 
            // button72
            // 
            this.button72.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button72.Location = new System.Drawing.Point(699, 87);
            this.button72.Name = "button72";
            this.button72.Size = new System.Drawing.Size(90, 32);
            this.button72.TabIndex = 73;
            this.button72.Text = "button72";
            this.button72.UseVisualStyleBackColor = true;
            // 
            // pc_sample_composite_head_shift_b
            // 
            this.pc_sample_composite_head_shift_b.Location = new System.Drawing.Point(699, 13);
            this.pc_sample_composite_head_shift_b.Name = "pc_sample_composite_head_shift_b";
            this.pc_sample_composite_head_shift_b.Size = new System.Drawing.Size(93, 32);
            this.pc_sample_composite_head_shift_b.TabIndex = 8;
            this.pc_sample_composite_head_shift_b.Text = "Composite";
            this.pc_sample_composite_head_shift_b.UseVisualStyleBackColor = true;
            // 
            // pc_sample_moist_head_shift_b
            // 
            this.pc_sample_moist_head_shift_b.Location = new System.Drawing.Point(600, 13);
            this.pc_sample_moist_head_shift_b.Name = "pc_sample_moist_head_shift_b";
            this.pc_sample_moist_head_shift_b.Size = new System.Drawing.Size(93, 32);
            this.pc_sample_moist_head_shift_b.TabIndex = 8;
            this.pc_sample_moist_head_shift_b.Text = "Moisture";
            this.pc_sample_moist_head_shift_b.UseVisualStyleBackColor = true;
            // 
            // pc_sample_avg_head_shift_b
            // 
            this.pc_sample_avg_head_shift_b.Location = new System.Drawing.Point(501, 13);
            this.pc_sample_avg_head_shift_b.Name = "pc_sample_avg_head_shift_b";
            this.pc_sample_avg_head_shift_b.Size = new System.Drawing.Size(93, 32);
            this.pc_sample_avg_head_shift_b.TabIndex = 7;
            this.pc_sample_avg_head_shift_b.Text = "Average";
            this.pc_sample_avg_head_shift_b.UseVisualStyleBackColor = true;
            // 
            // pc_sample_one_head_shift_b
            // 
            this.pc_sample_one_head_shift_b.Location = new System.Drawing.Point(6, 13);
            this.pc_sample_one_head_shift_b.Name = "pc_sample_one_head_shift_b";
            this.pc_sample_one_head_shift_b.Size = new System.Drawing.Size(93, 32);
            this.pc_sample_one_head_shift_b.TabIndex = 2;
            this.pc_sample_one_head_shift_b.Text = "Sample 1";
            this.pc_sample_one_head_shift_b.UseVisualStyleBackColor = true;
            // 
            // pc_sample_five_head_shift_b
            // 
            this.pc_sample_five_head_shift_b.Location = new System.Drawing.Point(402, 13);
            this.pc_sample_five_head_shift_b.Name = "pc_sample_five_head_shift_b";
            this.pc_sample_five_head_shift_b.Size = new System.Drawing.Size(93, 32);
            this.pc_sample_five_head_shift_b.TabIndex = 6;
            this.pc_sample_five_head_shift_b.Text = "Sample 5";
            this.pc_sample_five_head_shift_b.UseVisualStyleBackColor = true;
            // 
            // pc_sample_two_head_shift_b
            // 
            this.pc_sample_two_head_shift_b.Location = new System.Drawing.Point(105, 13);
            this.pc_sample_two_head_shift_b.Name = "pc_sample_two_head_shift_b";
            this.pc_sample_two_head_shift_b.Size = new System.Drawing.Size(93, 32);
            this.pc_sample_two_head_shift_b.TabIndex = 3;
            this.pc_sample_two_head_shift_b.Text = "Sample 2";
            this.pc_sample_two_head_shift_b.UseVisualStyleBackColor = true;
            // 
            // pc_sample_four_head_shift_b
            // 
            this.pc_sample_four_head_shift_b.Location = new System.Drawing.Point(303, 13);
            this.pc_sample_four_head_shift_b.Name = "pc_sample_four_head_shift_b";
            this.pc_sample_four_head_shift_b.Size = new System.Drawing.Size(93, 32);
            this.pc_sample_four_head_shift_b.TabIndex = 5;
            this.pc_sample_four_head_shift_b.Text = "Sample 4";
            this.pc_sample_four_head_shift_b.UseVisualStyleBackColor = true;
            // 
            // pc_sample_three_head_shift_b
            // 
            this.pc_sample_three_head_shift_b.Location = new System.Drawing.Point(204, 13);
            this.pc_sample_three_head_shift_b.Name = "pc_sample_three_head_shift_b";
            this.pc_sample_three_head_shift_b.Size = new System.Drawing.Size(93, 32);
            this.pc_sample_three_head_shift_b.TabIndex = 4;
            this.pc_sample_three_head_shift_b.Text = "Sample 3";
            this.pc_sample_three_head_shift_b.UseVisualStyleBackColor = true;
            // 
            // pressCake_head_shift_b
            // 
            this.pressCake_head_shift_b.Location = new System.Drawing.Point(6, 13);
            this.pressCake_head_shift_b.Name = "pressCake_head_shift_b";
            this.pressCake_head_shift_b.Size = new System.Drawing.Size(801, 41);
            this.pressCake_head_shift_b.TabIndex = 1;
            this.pressCake_head_shift_b.Text = "Press Cake";
            this.pressCake_head_shift_b.UseVisualStyleBackColor = true;
            // 
            // groupBox15
            // 
            this.groupBox15.Controls.Add(this.groupBox16);
            this.groupBox15.Controls.Add(this.groupBox17);
            this.groupBox15.Controls.Add(this.bagass_head_shift_b);
            this.groupBox15.Location = new System.Drawing.Point(90, 15);
            this.groupBox15.Name = "groupBox15";
            this.groupBox15.Size = new System.Drawing.Size(441, 390);
            this.groupBox15.TabIndex = 1;
            this.groupBox15.TabStop = false;
            // 
            // groupBox16
            // 
            this.groupBox16.Controls.Add(this.button108);
            this.groupBox16.Controls.Add(this.button109);
            this.groupBox16.Controls.Add(this.button93);
            this.groupBox16.Controls.Add(this.button94);
            this.groupBox16.Controls.Add(this.button78);
            this.groupBox16.Controls.Add(this.button79);
            this.groupBox16.Controls.Add(this.button63);
            this.groupBox16.Controls.Add(this.button64);
            this.groupBox16.Controls.Add(this.bagasse_om_moist_shift_b);
            this.groupBox16.Controls.Add(this.bagasse_om_pol_shift_b);
            this.groupBox16.Controls.Add(this.bagasse_head_om_shift_b);
            this.groupBox16.Location = new System.Drawing.Point(220, 57);
            this.groupBox16.Name = "groupBox16";
            this.groupBox16.Size = new System.Drawing.Size(208, 260);
            this.groupBox16.TabIndex = 2;
            this.groupBox16.TabStop = false;
            // 
            // button108
            // 
            this.button108.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button108.Location = new System.Drawing.Point(6, 214);
            this.button108.Name = "button108";
            this.button108.Size = new System.Drawing.Size(90, 32);
            this.button108.TabIndex = 31;
            this.button108.Text = "button108";
            this.button108.UseVisualStyleBackColor = true;
            // 
            // button109
            // 
            this.button109.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button109.Location = new System.Drawing.Point(102, 214);
            this.button109.Name = "button109";
            this.button109.Size = new System.Drawing.Size(90, 32);
            this.button109.TabIndex = 30;
            this.button109.Text = "button109";
            this.button109.UseVisualStyleBackColor = true;
            // 
            // button93
            // 
            this.button93.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button93.Location = new System.Drawing.Point(6, 172);
            this.button93.Name = "button93";
            this.button93.Size = new System.Drawing.Size(90, 32);
            this.button93.TabIndex = 29;
            this.button93.Text = "button93";
            this.button93.UseVisualStyleBackColor = true;
            // 
            // button94
            // 
            this.button94.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button94.Location = new System.Drawing.Point(102, 172);
            this.button94.Name = "button94";
            this.button94.Size = new System.Drawing.Size(90, 32);
            this.button94.TabIndex = 28;
            this.button94.Text = "button94";
            this.button94.UseVisualStyleBackColor = true;
            // 
            // button78
            // 
            this.button78.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button78.Location = new System.Drawing.Point(6, 130);
            this.button78.Name = "button78";
            this.button78.Size = new System.Drawing.Size(90, 32);
            this.button78.TabIndex = 27;
            this.button78.Text = "button78";
            this.button78.UseVisualStyleBackColor = true;
            // 
            // button79
            // 
            this.button79.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button79.Location = new System.Drawing.Point(102, 130);
            this.button79.Name = "button79";
            this.button79.Size = new System.Drawing.Size(90, 32);
            this.button79.TabIndex = 26;
            this.button79.Text = "button79";
            this.button79.UseVisualStyleBackColor = true;
            // 
            // button63
            // 
            this.button63.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button63.Location = new System.Drawing.Point(6, 88);
            this.button63.Name = "button63";
            this.button63.Size = new System.Drawing.Size(90, 32);
            this.button63.TabIndex = 25;
            this.button63.Text = "button63";
            this.button63.UseVisualStyleBackColor = true;
            // 
            // button64
            // 
            this.button64.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button64.Location = new System.Drawing.Point(102, 88);
            this.button64.Name = "button64";
            this.button64.Size = new System.Drawing.Size(90, 32);
            this.button64.TabIndex = 24;
            this.button64.Text = "button64";
            this.button64.UseVisualStyleBackColor = true;
            // 
            // bagasse_om_moist_shift_b
            // 
            this.bagasse_om_moist_shift_b.Location = new System.Drawing.Point(102, 47);
            this.bagasse_om_moist_shift_b.Name = "bagasse_om_moist_shift_b";
            this.bagasse_om_moist_shift_b.Size = new System.Drawing.Size(90, 32);
            this.bagasse_om_moist_shift_b.TabIndex = 5;
            this.bagasse_om_moist_shift_b.Text = "Moisture";
            this.bagasse_om_moist_shift_b.UseVisualStyleBackColor = true;
            // 
            // bagasse_om_pol_shift_b
            // 
            this.bagasse_om_pol_shift_b.Location = new System.Drawing.Point(6, 47);
            this.bagasse_om_pol_shift_b.Name = "bagasse_om_pol_shift_b";
            this.bagasse_om_pol_shift_b.Size = new System.Drawing.Size(90, 32);
            this.bagasse_om_pol_shift_b.TabIndex = 4;
            this.bagasse_om_pol_shift_b.Text = "Pol";
            this.bagasse_om_pol_shift_b.UseVisualStyleBackColor = true;
            // 
            // bagasse_head_om_shift_b
            // 
            this.bagasse_head_om_shift_b.Location = new System.Drawing.Point(6, 13);
            this.bagasse_head_om_shift_b.Name = "bagasse_head_om_shift_b";
            this.bagasse_head_om_shift_b.Size = new System.Drawing.Size(186, 32);
            this.bagasse_head_om_shift_b.TabIndex = 1;
            this.bagasse_head_om_shift_b.Text = "Old Mill";
            this.bagasse_head_om_shift_b.UseVisualStyleBackColor = true;
            // 
            // groupBox17
            // 
            this.groupBox17.Controls.Add(this.button106);
            this.groupBox17.Controls.Add(this.button107);
            this.groupBox17.Controls.Add(this.button91);
            this.groupBox17.Controls.Add(this.button92);
            this.groupBox17.Controls.Add(this.button76);
            this.groupBox17.Controls.Add(this.button77);
            this.groupBox17.Controls.Add(this.button61);
            this.groupBox17.Controls.Add(this.button62);
            this.groupBox17.Controls.Add(this.bagasse_nm_moist_shift_b);
            this.groupBox17.Controls.Add(this.bagasse_nm_pol_shift_b);
            this.groupBox17.Controls.Add(this.bagasse_head_nm_shift_b);
            this.groupBox17.Location = new System.Drawing.Point(6, 57);
            this.groupBox17.Name = "groupBox17";
            this.groupBox17.Size = new System.Drawing.Size(208, 260);
            this.groupBox17.TabIndex = 1;
            this.groupBox17.TabStop = false;
            // 
            // button106
            // 
            this.button106.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button106.Location = new System.Drawing.Point(6, 216);
            this.button106.Name = "button106";
            this.button106.Size = new System.Drawing.Size(90, 32);
            this.button106.TabIndex = 29;
            this.button106.Text = "button106";
            this.button106.UseVisualStyleBackColor = true;
            // 
            // button107
            // 
            this.button107.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button107.Location = new System.Drawing.Point(102, 216);
            this.button107.Name = "button107";
            this.button107.Size = new System.Drawing.Size(90, 32);
            this.button107.TabIndex = 28;
            this.button107.Text = "button107";
            this.button107.UseVisualStyleBackColor = true;
            // 
            // button91
            // 
            this.button91.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button91.Location = new System.Drawing.Point(6, 174);
            this.button91.Name = "button91";
            this.button91.Size = new System.Drawing.Size(90, 32);
            this.button91.TabIndex = 27;
            this.button91.Text = "button91";
            this.button91.UseVisualStyleBackColor = true;
            // 
            // button92
            // 
            this.button92.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button92.Location = new System.Drawing.Point(102, 174);
            this.button92.Name = "button92";
            this.button92.Size = new System.Drawing.Size(90, 32);
            this.button92.TabIndex = 26;
            this.button92.Text = "button92";
            this.button92.UseVisualStyleBackColor = true;
            // 
            // button76
            // 
            this.button76.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button76.Location = new System.Drawing.Point(6, 132);
            this.button76.Name = "button76";
            this.button76.Size = new System.Drawing.Size(90, 32);
            this.button76.TabIndex = 25;
            this.button76.Text = "button76";
            this.button76.UseVisualStyleBackColor = true;
            // 
            // button77
            // 
            this.button77.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button77.Location = new System.Drawing.Point(102, 132);
            this.button77.Name = "button77";
            this.button77.Size = new System.Drawing.Size(90, 32);
            this.button77.TabIndex = 24;
            this.button77.Text = "button77";
            this.button77.UseVisualStyleBackColor = true;
            // 
            // button61
            // 
            this.button61.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button61.Location = new System.Drawing.Point(6, 90);
            this.button61.Name = "button61";
            this.button61.Size = new System.Drawing.Size(90, 32);
            this.button61.TabIndex = 23;
            this.button61.Text = "button61";
            this.button61.UseVisualStyleBackColor = true;
            // 
            // button62
            // 
            this.button62.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button62.Location = new System.Drawing.Point(102, 90);
            this.button62.Name = "button62";
            this.button62.Size = new System.Drawing.Size(90, 32);
            this.button62.TabIndex = 22;
            this.button62.Text = "button62";
            this.button62.UseVisualStyleBackColor = true;
            // 
            // bagasse_nm_moist_shift_b
            // 
            this.bagasse_nm_moist_shift_b.Location = new System.Drawing.Point(102, 46);
            this.bagasse_nm_moist_shift_b.Name = "bagasse_nm_moist_shift_b";
            this.bagasse_nm_moist_shift_b.Size = new System.Drawing.Size(90, 32);
            this.bagasse_nm_moist_shift_b.TabIndex = 3;
            this.bagasse_nm_moist_shift_b.Text = "Moisture";
            this.bagasse_nm_moist_shift_b.UseVisualStyleBackColor = true;
            // 
            // bagasse_nm_pol_shift_b
            // 
            this.bagasse_nm_pol_shift_b.Location = new System.Drawing.Point(6, 46);
            this.bagasse_nm_pol_shift_b.Name = "bagasse_nm_pol_shift_b";
            this.bagasse_nm_pol_shift_b.Size = new System.Drawing.Size(90, 32);
            this.bagasse_nm_pol_shift_b.TabIndex = 2;
            this.bagasse_nm_pol_shift_b.Text = "Pol";
            this.bagasse_nm_pol_shift_b.UseVisualStyleBackColor = true;
            // 
            // bagasse_head_nm_shift_b
            // 
            this.bagasse_head_nm_shift_b.Location = new System.Drawing.Point(6, 13);
            this.bagasse_head_nm_shift_b.Name = "bagasse_head_nm_shift_b";
            this.bagasse_head_nm_shift_b.Size = new System.Drawing.Size(186, 32);
            this.bagasse_head_nm_shift_b.TabIndex = 1;
            this.bagasse_head_nm_shift_b.Text = "New Mill";
            this.bagasse_head_nm_shift_b.UseVisualStyleBackColor = true;
            // 
            // bagass_head_shift_b
            // 
            this.bagass_head_shift_b.Location = new System.Drawing.Point(6, 13);
            this.bagass_head_shift_b.Name = "bagass_head_shift_b";
            this.bagass_head_shift_b.Size = new System.Drawing.Size(422, 41);
            this.bagass_head_shift_b.TabIndex = 0;
            this.bagass_head_shift_b.Text = "Bagasse";
            this.bagass_head_shift_b.UseVisualStyleBackColor = true;
            // 
            // groupBox18
            // 
            this.groupBox18.Controls.Add(this.time20);
            this.groupBox18.Controls.Add(this.time19);
            this.groupBox18.Controls.Add(this.time18);
            this.groupBox18.Controls.Add(this.time17);
            this.groupBox18.Controls.Add(this.avg_shift_b);
            this.groupBox18.Controls.Add(this.time_head_shiftB);
            this.groupBox18.Location = new System.Drawing.Point(6, 73);
            this.groupBox18.Name = "groupBox18";
            this.groupBox18.Size = new System.Drawing.Size(78, 332);
            this.groupBox18.TabIndex = 0;
            this.groupBox18.TabStop = false;
            // 
            // time20
            // 
            this.time20.Location = new System.Drawing.Point(6, 211);
            this.time20.Name = "time20";
            this.time20.Size = new System.Drawing.Size(66, 36);
            this.time20.TabIndex = 13;
            this.time20.Text = "24";
            this.time20.UseVisualStyleBackColor = true;
            // 
            // time19
            // 
            this.time19.Location = new System.Drawing.Point(6, 169);
            this.time19.Name = "time19";
            this.time19.Size = new System.Drawing.Size(66, 36);
            this.time19.TabIndex = 12;
            this.time19.Text = "22";
            this.time19.UseVisualStyleBackColor = true;
            // 
            // time18
            // 
            this.time18.Location = new System.Drawing.Point(6, 127);
            this.time18.Name = "time18";
            this.time18.Size = new System.Drawing.Size(66, 36);
            this.time18.TabIndex = 11;
            this.time18.Text = "20";
            this.time18.UseVisualStyleBackColor = true;
            // 
            // time17
            // 
            this.time17.Location = new System.Drawing.Point(6, 85);
            this.time17.Name = "time17";
            this.time17.Size = new System.Drawing.Size(66, 36);
            this.time17.TabIndex = 10;
            this.time17.Text = "18";
            this.time17.UseVisualStyleBackColor = true;
            // 
            // avg_shift_b
            // 
            this.avg_shift_b.Location = new System.Drawing.Point(5, 255);
            this.avg_shift_b.Name = "avg_shift_b";
            this.avg_shift_b.Size = new System.Drawing.Size(67, 44);
            this.avg_shift_b.TabIndex = 7;
            this.avg_shift_b.Text = "Average";
            this.avg_shift_b.UseVisualStyleBackColor = true;
            // 
            // time_head_shiftB
            // 
            this.time_head_shiftB.Location = new System.Drawing.Point(6, 17);
            this.time_head_shiftB.Name = "time_head_shiftB";
            this.time_head_shiftB.Size = new System.Drawing.Size(67, 64);
            this.time_head_shiftB.TabIndex = 3;
            this.time_head_shiftB.Text = "Time";
            this.time_head_shiftB.UseVisualStyleBackColor = true;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.groupBox8);
            this.groupBox1.Controls.Add(this.groupBox6);
            this.groupBox1.Controls.Add(this.groupBox3);
            this.groupBox1.Controls.Add(this.groupBox2);
            this.groupBox1.Location = new System.Drawing.Point(4, 24);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(1651, 444);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Shift-A";
            // 
            // groupBox8
            // 
            this.groupBox8.Controls.Add(this.groupBox9);
            this.groupBox8.Controls.Add(this.FMolasses_head_shift_a);
            this.groupBox8.Location = new System.Drawing.Point(1363, 15);
            this.groupBox8.Name = "groupBox8";
            this.groupBox8.Size = new System.Drawing.Size(270, 411);
            this.groupBox8.TabIndex = 3;
            this.groupBox8.TabStop = false;
            // 
            // groupBox9
            // 
            this.groupBox9.Controls.Add(this.button58);
            this.groupBox9.Controls.Add(this.button59);
            this.groupBox9.Controls.Add(this.button60);
            this.groupBox9.Controls.Add(this.button43);
            this.groupBox9.Controls.Add(this.button44);
            this.groupBox9.Controls.Add(this.button45);
            this.groupBox9.Controls.Add(this.button28);
            this.groupBox9.Controls.Add(this.button29);
            this.groupBox9.Controls.Add(this.button30);
            this.groupBox9.Controls.Add(this.button15);
            this.groupBox9.Controls.Add(this.button14);
            this.groupBox9.Controls.Add(this.button13);
            this.groupBox9.Controls.Add(this.final_mol_purity_head_shift_a);
            this.groupBox9.Controls.Add(this.final_mol_Pol_head_shift_a);
            this.groupBox9.Controls.Add(this.final_mol_brix_head_shift_a);
            this.groupBox9.Location = new System.Drawing.Point(6, 58);
            this.groupBox9.Name = "groupBox9";
            this.groupBox9.Size = new System.Drawing.Size(252, 259);
            this.groupBox9.TabIndex = 3;
            this.groupBox9.TabStop = false;
            // 
            // button58
            // 
            this.button58.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button58.Location = new System.Drawing.Point(6, 213);
            this.button58.Name = "button58";
            this.button58.Size = new System.Drawing.Size(75, 32);
            this.button58.TabIndex = 18;
            this.button58.Text = "button58";
            this.button58.UseVisualStyleBackColor = true;
            // 
            // button59
            // 
            this.button59.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button59.Location = new System.Drawing.Point(87, 213);
            this.button59.Name = "button59";
            this.button59.Size = new System.Drawing.Size(75, 32);
            this.button59.TabIndex = 17;
            this.button59.Text = "button59";
            this.button59.UseVisualStyleBackColor = true;
            // 
            // button60
            // 
            this.button60.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button60.Location = new System.Drawing.Point(168, 213);
            this.button60.Name = "button60";
            this.button60.Size = new System.Drawing.Size(75, 32);
            this.button60.TabIndex = 16;
            this.button60.Text = "button60";
            this.button60.UseVisualStyleBackColor = true;
            // 
            // button43
            // 
            this.button43.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button43.Location = new System.Drawing.Point(6, 175);
            this.button43.Name = "button43";
            this.button43.Size = new System.Drawing.Size(75, 32);
            this.button43.TabIndex = 15;
            this.button43.Text = "button43";
            this.button43.UseVisualStyleBackColor = true;
            // 
            // button44
            // 
            this.button44.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button44.Location = new System.Drawing.Point(87, 175);
            this.button44.Name = "button44";
            this.button44.Size = new System.Drawing.Size(75, 32);
            this.button44.TabIndex = 14;
            this.button44.Text = "button44";
            this.button44.UseVisualStyleBackColor = true;
            // 
            // button45
            // 
            this.button45.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button45.Location = new System.Drawing.Point(168, 175);
            this.button45.Name = "button45";
            this.button45.Size = new System.Drawing.Size(75, 32);
            this.button45.TabIndex = 13;
            this.button45.Text = "button45";
            this.button45.UseVisualStyleBackColor = true;
            // 
            // button28
            // 
            this.button28.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button28.Location = new System.Drawing.Point(6, 134);
            this.button28.Name = "button28";
            this.button28.Size = new System.Drawing.Size(75, 32);
            this.button28.TabIndex = 12;
            this.button28.Text = "button28";
            this.button28.UseVisualStyleBackColor = true;
            // 
            // button29
            // 
            this.button29.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button29.Location = new System.Drawing.Point(87, 134);
            this.button29.Name = "button29";
            this.button29.Size = new System.Drawing.Size(75, 32);
            this.button29.TabIndex = 11;
            this.button29.Text = "button29";
            this.button29.UseVisualStyleBackColor = true;
            // 
            // button30
            // 
            this.button30.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button30.Location = new System.Drawing.Point(168, 134);
            this.button30.Name = "button30";
            this.button30.Size = new System.Drawing.Size(75, 32);
            this.button30.TabIndex = 10;
            this.button30.Text = "button30";
            this.button30.UseVisualStyleBackColor = true;
            // 
            // button15
            // 
            this.button15.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button15.Location = new System.Drawing.Point(168, 92);
            this.button15.Name = "button15";
            this.button15.Size = new System.Drawing.Size(75, 32);
            this.button15.TabIndex = 9;
            this.button15.Text = "button15";
            this.button15.UseVisualStyleBackColor = true;
            // 
            // button14
            // 
            this.button14.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button14.Location = new System.Drawing.Point(87, 92);
            this.button14.Name = "button14";
            this.button14.Size = new System.Drawing.Size(75, 32);
            this.button14.TabIndex = 8;
            this.button14.Text = "button14";
            this.button14.UseVisualStyleBackColor = true;
            // 
            // button13
            // 
            this.button13.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button13.Location = new System.Drawing.Point(6, 92);
            this.button13.Name = "button13";
            this.button13.Size = new System.Drawing.Size(75, 32);
            this.button13.TabIndex = 7;
            this.button13.Text = "button13";
            this.button13.UseVisualStyleBackColor = true;
            // 
            // final_mol_purity_head_shift_a
            // 
            this.final_mol_purity_head_shift_a.Location = new System.Drawing.Point(168, 13);
            this.final_mol_purity_head_shift_a.Name = "final_mol_purity_head_shift_a";
            this.final_mol_purity_head_shift_a.Size = new System.Drawing.Size(75, 32);
            this.final_mol_purity_head_shift_a.TabIndex = 2;
            this.final_mol_purity_head_shift_a.Text = "Purity";
            this.final_mol_purity_head_shift_a.UseVisualStyleBackColor = true;
            // 
            // final_mol_Pol_head_shift_a
            // 
            this.final_mol_Pol_head_shift_a.Location = new System.Drawing.Point(87, 13);
            this.final_mol_Pol_head_shift_a.Name = "final_mol_Pol_head_shift_a";
            this.final_mol_Pol_head_shift_a.Size = new System.Drawing.Size(75, 32);
            this.final_mol_Pol_head_shift_a.TabIndex = 1;
            this.final_mol_Pol_head_shift_a.Text = "Pol";
            this.final_mol_Pol_head_shift_a.UseVisualStyleBackColor = true;
            // 
            // final_mol_brix_head_shift_a
            // 
            this.final_mol_brix_head_shift_a.Location = new System.Drawing.Point(6, 13);
            this.final_mol_brix_head_shift_a.Name = "final_mol_brix_head_shift_a";
            this.final_mol_brix_head_shift_a.Size = new System.Drawing.Size(75, 32);
            this.final_mol_brix_head_shift_a.TabIndex = 0;
            this.final_mol_brix_head_shift_a.Text = "Brix";
            this.final_mol_brix_head_shift_a.UseVisualStyleBackColor = true;
            // 
            // FMolasses_head_shift_a
            // 
            this.FMolasses_head_shift_a.Location = new System.Drawing.Point(6, 14);
            this.FMolasses_head_shift_a.Name = "FMolasses_head_shift_a";
            this.FMolasses_head_shift_a.Size = new System.Drawing.Size(243, 41);
            this.FMolasses_head_shift_a.TabIndex = 2;
            this.FMolasses_head_shift_a.Text = "Final Molasses";
            this.FMolasses_head_shift_a.UseVisualStyleBackColor = true;
            // 
            // groupBox6
            // 
            this.groupBox6.Controls.Add(this.groupBox7);
            this.groupBox6.Controls.Add(this.pressCake_head_shift_a);
            this.groupBox6.Location = new System.Drawing.Point(537, 15);
            this.groupBox6.Name = "groupBox6";
            this.groupBox6.Size = new System.Drawing.Size(820, 411);
            this.groupBox6.TabIndex = 2;
            this.groupBox6.TabStop = false;
            // 
            // groupBox7
            // 
            this.groupBox7.Controls.Add(this.button50);
            this.groupBox7.Controls.Add(this.button51);
            this.groupBox7.Controls.Add(this.button52);
            this.groupBox7.Controls.Add(this.button53);
            this.groupBox7.Controls.Add(this.button54);
            this.groupBox7.Controls.Add(this.button55);
            this.groupBox7.Controls.Add(this.button56);
            this.groupBox7.Controls.Add(this.button57);
            this.groupBox7.Controls.Add(this.button35);
            this.groupBox7.Controls.Add(this.button36);
            this.groupBox7.Controls.Add(this.button37);
            this.groupBox7.Controls.Add(this.button38);
            this.groupBox7.Controls.Add(this.button39);
            this.groupBox7.Controls.Add(this.button40);
            this.groupBox7.Controls.Add(this.button41);
            this.groupBox7.Controls.Add(this.button42);
            this.groupBox7.Controls.Add(this.button20);
            this.groupBox7.Controls.Add(this.button21);
            this.groupBox7.Controls.Add(this.button22);
            this.groupBox7.Controls.Add(this.button23);
            this.groupBox7.Controls.Add(this.button24);
            this.groupBox7.Controls.Add(this.button25);
            this.groupBox7.Controls.Add(this.button26);
            this.groupBox7.Controls.Add(this.button27);
            this.groupBox7.Controls.Add(this.button12);
            this.groupBox7.Controls.Add(this.button11);
            this.groupBox7.Controls.Add(this.button10);
            this.groupBox7.Controls.Add(this.button9);
            this.groupBox7.Controls.Add(this.button8);
            this.groupBox7.Controls.Add(this.button7);
            this.groupBox7.Controls.Add(this.button6);
            this.groupBox7.Controls.Add(this.button5);
            this.groupBox7.Controls.Add(this.pc_sample_composite_head_shift_a);
            this.groupBox7.Controls.Add(this.pc_sample_moist_head_shift_a);
            this.groupBox7.Controls.Add(this.pc_sample_avg_head_shift_a);
            this.groupBox7.Controls.Add(this.pc_sample_one_head_shift_a);
            this.groupBox7.Controls.Add(this.pc_sample_five_head_shift_a);
            this.groupBox7.Controls.Add(this.pc_sample_two_head_shift_a);
            this.groupBox7.Controls.Add(this.pc_sample_four_head_shift_a);
            this.groupBox7.Controls.Add(this.pc_sample_three_head_shift_a);
            this.groupBox7.Location = new System.Drawing.Point(6, 58);
            this.groupBox7.Name = "groupBox7";
            this.groupBox7.Size = new System.Drawing.Size(801, 259);
            this.groupBox7.TabIndex = 7;
            this.groupBox7.TabStop = false;
            // 
            // button50
            // 
            this.button50.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button50.Location = new System.Drawing.Point(9, 213);
            this.button50.Name = "button50";
            this.button50.Size = new System.Drawing.Size(90, 32);
            this.button50.TabIndex = 40;
            this.button50.Text = "button50";
            this.button50.UseVisualStyleBackColor = true;
            // 
            // button51
            // 
            this.button51.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button51.Location = new System.Drawing.Point(111, 213);
            this.button51.Name = "button51";
            this.button51.Size = new System.Drawing.Size(90, 32);
            this.button51.TabIndex = 39;
            this.button51.Text = "button51";
            this.button51.UseVisualStyleBackColor = true;
            // 
            // button52
            // 
            this.button52.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button52.Location = new System.Drawing.Point(210, 213);
            this.button52.Name = "button52";
            this.button52.Size = new System.Drawing.Size(90, 32);
            this.button52.TabIndex = 38;
            this.button52.Text = "button52";
            this.button52.UseVisualStyleBackColor = true;
            // 
            // button53
            // 
            this.button53.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button53.Location = new System.Drawing.Point(309, 213);
            this.button53.Name = "button53";
            this.button53.Size = new System.Drawing.Size(90, 32);
            this.button53.TabIndex = 37;
            this.button53.Text = "button53";
            this.button53.UseVisualStyleBackColor = true;
            // 
            // button54
            // 
            this.button54.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button54.Location = new System.Drawing.Point(405, 213);
            this.button54.Name = "button54";
            this.button54.Size = new System.Drawing.Size(90, 32);
            this.button54.TabIndex = 36;
            this.button54.Text = "button54";
            this.button54.UseVisualStyleBackColor = true;
            // 
            // button55
            // 
            this.button55.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button55.Location = new System.Drawing.Point(504, 213);
            this.button55.Name = "button55";
            this.button55.Size = new System.Drawing.Size(90, 32);
            this.button55.TabIndex = 35;
            this.button55.Text = "button55";
            this.button55.UseVisualStyleBackColor = true;
            // 
            // button56
            // 
            this.button56.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button56.Location = new System.Drawing.Point(603, 213);
            this.button56.Name = "button56";
            this.button56.Size = new System.Drawing.Size(90, 32);
            this.button56.TabIndex = 34;
            this.button56.Text = "button56";
            this.button56.UseVisualStyleBackColor = true;
            // 
            // button57
            // 
            this.button57.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button57.Location = new System.Drawing.Point(699, 213);
            this.button57.Name = "button57";
            this.button57.Size = new System.Drawing.Size(90, 32);
            this.button57.TabIndex = 33;
            this.button57.Text = "button57";
            this.button57.UseVisualStyleBackColor = true;
            // 
            // button35
            // 
            this.button35.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button35.Location = new System.Drawing.Point(9, 175);
            this.button35.Name = "button35";
            this.button35.Size = new System.Drawing.Size(90, 32);
            this.button35.TabIndex = 32;
            this.button35.Text = "button35";
            this.button35.UseVisualStyleBackColor = true;
            // 
            // button36
            // 
            this.button36.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button36.Location = new System.Drawing.Point(111, 175);
            this.button36.Name = "button36";
            this.button36.Size = new System.Drawing.Size(90, 32);
            this.button36.TabIndex = 31;
            this.button36.Text = "button36";
            this.button36.UseVisualStyleBackColor = true;
            // 
            // button37
            // 
            this.button37.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button37.Location = new System.Drawing.Point(210, 175);
            this.button37.Name = "button37";
            this.button37.Size = new System.Drawing.Size(90, 32);
            this.button37.TabIndex = 30;
            this.button37.Text = "button37";
            this.button37.UseVisualStyleBackColor = true;
            // 
            // button38
            // 
            this.button38.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button38.Location = new System.Drawing.Point(309, 175);
            this.button38.Name = "button38";
            this.button38.Size = new System.Drawing.Size(90, 32);
            this.button38.TabIndex = 29;
            this.button38.Text = "button38";
            this.button38.UseVisualStyleBackColor = true;
            // 
            // button39
            // 
            this.button39.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button39.Location = new System.Drawing.Point(405, 175);
            this.button39.Name = "button39";
            this.button39.Size = new System.Drawing.Size(90, 32);
            this.button39.TabIndex = 28;
            this.button39.Text = "button39";
            this.button39.UseVisualStyleBackColor = true;
            // 
            // button40
            // 
            this.button40.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button40.Location = new System.Drawing.Point(504, 175);
            this.button40.Name = "button40";
            this.button40.Size = new System.Drawing.Size(90, 32);
            this.button40.TabIndex = 27;
            this.button40.Text = "button40";
            this.button40.UseVisualStyleBackColor = true;
            // 
            // button41
            // 
            this.button41.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button41.Location = new System.Drawing.Point(603, 175);
            this.button41.Name = "button41";
            this.button41.Size = new System.Drawing.Size(90, 32);
            this.button41.TabIndex = 26;
            this.button41.Text = "button41";
            this.button41.UseVisualStyleBackColor = true;
            // 
            // button42
            // 
            this.button42.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button42.Location = new System.Drawing.Point(699, 175);
            this.button42.Name = "button42";
            this.button42.Size = new System.Drawing.Size(90, 32);
            this.button42.TabIndex = 25;
            this.button42.Text = "button42";
            this.button42.UseVisualStyleBackColor = true;
            // 
            // button20
            // 
            this.button20.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button20.Location = new System.Drawing.Point(9, 134);
            this.button20.Name = "button20";
            this.button20.Size = new System.Drawing.Size(90, 32);
            this.button20.TabIndex = 24;
            this.button20.Text = "button20";
            this.button20.UseVisualStyleBackColor = true;
            // 
            // button21
            // 
            this.button21.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button21.Location = new System.Drawing.Point(111, 134);
            this.button21.Name = "button21";
            this.button21.Size = new System.Drawing.Size(90, 32);
            this.button21.TabIndex = 23;
            this.button21.Text = "button21";
            this.button21.UseVisualStyleBackColor = true;
            // 
            // button22
            // 
            this.button22.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button22.Location = new System.Drawing.Point(210, 134);
            this.button22.Name = "button22";
            this.button22.Size = new System.Drawing.Size(90, 32);
            this.button22.TabIndex = 22;
            this.button22.Text = "button22";
            this.button22.UseVisualStyleBackColor = true;
            // 
            // button23
            // 
            this.button23.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button23.Location = new System.Drawing.Point(309, 134);
            this.button23.Name = "button23";
            this.button23.Size = new System.Drawing.Size(90, 32);
            this.button23.TabIndex = 21;
            this.button23.Text = "button23";
            this.button23.UseVisualStyleBackColor = true;
            // 
            // button24
            // 
            this.button24.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button24.Location = new System.Drawing.Point(405, 134);
            this.button24.Name = "button24";
            this.button24.Size = new System.Drawing.Size(90, 32);
            this.button24.TabIndex = 20;
            this.button24.Text = "button24";
            this.button24.UseVisualStyleBackColor = true;
            // 
            // button25
            // 
            this.button25.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button25.Location = new System.Drawing.Point(504, 134);
            this.button25.Name = "button25";
            this.button25.Size = new System.Drawing.Size(90, 32);
            this.button25.TabIndex = 19;
            this.button25.Text = "button25";
            this.button25.UseVisualStyleBackColor = true;
            // 
            // button26
            // 
            this.button26.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button26.Location = new System.Drawing.Point(603, 134);
            this.button26.Name = "button26";
            this.button26.Size = new System.Drawing.Size(90, 32);
            this.button26.TabIndex = 18;
            this.button26.Text = "button26";
            this.button26.UseVisualStyleBackColor = true;
            // 
            // button27
            // 
            this.button27.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button27.Location = new System.Drawing.Point(699, 134);
            this.button27.Name = "button27";
            this.button27.Size = new System.Drawing.Size(90, 32);
            this.button27.TabIndex = 17;
            this.button27.Text = "button27";
            this.button27.UseVisualStyleBackColor = true;
            // 
            // button12
            // 
            this.button12.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button12.Location = new System.Drawing.Point(699, 92);
            this.button12.Name = "button12";
            this.button12.Size = new System.Drawing.Size(90, 32);
            this.button12.TabIndex = 16;
            this.button12.Text = "button12";
            this.button12.UseVisualStyleBackColor = true;
            // 
            // button11
            // 
            this.button11.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button11.Location = new System.Drawing.Point(603, 92);
            this.button11.Name = "button11";
            this.button11.Size = new System.Drawing.Size(90, 32);
            this.button11.TabIndex = 15;
            this.button11.Text = "button11";
            this.button11.UseVisualStyleBackColor = true;
            // 
            // button10
            // 
            this.button10.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button10.Location = new System.Drawing.Point(501, 92);
            this.button10.Name = "button10";
            this.button10.Size = new System.Drawing.Size(90, 32);
            this.button10.TabIndex = 14;
            this.button10.Text = "button10";
            this.button10.UseVisualStyleBackColor = true;
            // 
            // button9
            // 
            this.button9.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button9.Location = new System.Drawing.Point(405, 92);
            this.button9.Name = "button9";
            this.button9.Size = new System.Drawing.Size(90, 32);
            this.button9.TabIndex = 13;
            this.button9.Text = "button9";
            this.button9.UseVisualStyleBackColor = true;
            // 
            // button8
            // 
            this.button8.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button8.Location = new System.Drawing.Point(306, 92);
            this.button8.Name = "button8";
            this.button8.Size = new System.Drawing.Size(90, 32);
            this.button8.TabIndex = 12;
            this.button8.Text = "button8";
            this.button8.UseVisualStyleBackColor = true;
            // 
            // button7
            // 
            this.button7.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button7.Location = new System.Drawing.Point(207, 92);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(90, 32);
            this.button7.TabIndex = 11;
            this.button7.Text = "button7";
            this.button7.UseVisualStyleBackColor = true;
            // 
            // button6
            // 
            this.button6.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button6.Location = new System.Drawing.Point(108, 92);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(90, 32);
            this.button6.TabIndex = 10;
            this.button6.Text = "button6";
            this.button6.UseVisualStyleBackColor = true;
            // 
            // button5
            // 
            this.button5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button5.Location = new System.Drawing.Point(6, 92);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(90, 32);
            this.button5.TabIndex = 9;
            this.button5.Text = "button5";
            this.button5.UseVisualStyleBackColor = true;
            // 
            // pc_sample_composite_head_shift_a
            // 
            this.pc_sample_composite_head_shift_a.Location = new System.Drawing.Point(699, 13);
            this.pc_sample_composite_head_shift_a.Name = "pc_sample_composite_head_shift_a";
            this.pc_sample_composite_head_shift_a.Size = new System.Drawing.Size(93, 32);
            this.pc_sample_composite_head_shift_a.TabIndex = 8;
            this.pc_sample_composite_head_shift_a.Text = "Composite";
            this.pc_sample_composite_head_shift_a.UseVisualStyleBackColor = true;
            // 
            // pc_sample_moist_head_shift_a
            // 
            this.pc_sample_moist_head_shift_a.Location = new System.Drawing.Point(600, 13);
            this.pc_sample_moist_head_shift_a.Name = "pc_sample_moist_head_shift_a";
            this.pc_sample_moist_head_shift_a.Size = new System.Drawing.Size(93, 32);
            this.pc_sample_moist_head_shift_a.TabIndex = 8;
            this.pc_sample_moist_head_shift_a.Text = "Moisture";
            this.pc_sample_moist_head_shift_a.UseVisualStyleBackColor = true;
            // 
            // pc_sample_avg_head_shift_a
            // 
            this.pc_sample_avg_head_shift_a.Location = new System.Drawing.Point(501, 13);
            this.pc_sample_avg_head_shift_a.Name = "pc_sample_avg_head_shift_a";
            this.pc_sample_avg_head_shift_a.Size = new System.Drawing.Size(93, 32);
            this.pc_sample_avg_head_shift_a.TabIndex = 7;
            this.pc_sample_avg_head_shift_a.Text = "Average";
            this.pc_sample_avg_head_shift_a.UseVisualStyleBackColor = true;
            // 
            // pc_sample_one_head_shift_a
            // 
            this.pc_sample_one_head_shift_a.Location = new System.Drawing.Point(6, 13);
            this.pc_sample_one_head_shift_a.Name = "pc_sample_one_head_shift_a";
            this.pc_sample_one_head_shift_a.Size = new System.Drawing.Size(93, 32);
            this.pc_sample_one_head_shift_a.TabIndex = 2;
            this.pc_sample_one_head_shift_a.Text = "Sample 1";
            this.pc_sample_one_head_shift_a.UseVisualStyleBackColor = true;
            // 
            // pc_sample_five_head_shift_a
            // 
            this.pc_sample_five_head_shift_a.Location = new System.Drawing.Point(402, 13);
            this.pc_sample_five_head_shift_a.Name = "pc_sample_five_head_shift_a";
            this.pc_sample_five_head_shift_a.Size = new System.Drawing.Size(93, 32);
            this.pc_sample_five_head_shift_a.TabIndex = 6;
            this.pc_sample_five_head_shift_a.Text = "Sample 5";
            this.pc_sample_five_head_shift_a.UseVisualStyleBackColor = true;
            // 
            // pc_sample_two_head_shift_a
            // 
            this.pc_sample_two_head_shift_a.Location = new System.Drawing.Point(105, 13);
            this.pc_sample_two_head_shift_a.Name = "pc_sample_two_head_shift_a";
            this.pc_sample_two_head_shift_a.Size = new System.Drawing.Size(93, 32);
            this.pc_sample_two_head_shift_a.TabIndex = 3;
            this.pc_sample_two_head_shift_a.Text = "Sample 2";
            this.pc_sample_two_head_shift_a.UseVisualStyleBackColor = true;
            // 
            // pc_sample_four_head_shift_a
            // 
            this.pc_sample_four_head_shift_a.Location = new System.Drawing.Point(303, 13);
            this.pc_sample_four_head_shift_a.Name = "pc_sample_four_head_shift_a";
            this.pc_sample_four_head_shift_a.Size = new System.Drawing.Size(93, 32);
            this.pc_sample_four_head_shift_a.TabIndex = 5;
            this.pc_sample_four_head_shift_a.Text = "Sample 4";
            this.pc_sample_four_head_shift_a.UseVisualStyleBackColor = true;
            // 
            // pc_sample_three_head_shift_a
            // 
            this.pc_sample_three_head_shift_a.Location = new System.Drawing.Point(204, 13);
            this.pc_sample_three_head_shift_a.Name = "pc_sample_three_head_shift_a";
            this.pc_sample_three_head_shift_a.Size = new System.Drawing.Size(93, 32);
            this.pc_sample_three_head_shift_a.TabIndex = 4;
            this.pc_sample_three_head_shift_a.Text = "Sample 3";
            this.pc_sample_three_head_shift_a.UseVisualStyleBackColor = true;
            // 
            // pressCake_head_shift_a
            // 
            this.pressCake_head_shift_a.Location = new System.Drawing.Point(6, 13);
            this.pressCake_head_shift_a.Name = "pressCake_head_shift_a";
            this.pressCake_head_shift_a.Size = new System.Drawing.Size(801, 41);
            this.pressCake_head_shift_a.TabIndex = 1;
            this.pressCake_head_shift_a.Text = "Press Cake";
            this.pressCake_head_shift_a.UseVisualStyleBackColor = true;
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.groupBox5);
            this.groupBox3.Controls.Add(this.groupBox4);
            this.groupBox3.Controls.Add(this.bagass_head_shift_a);
            this.groupBox3.Location = new System.Drawing.Point(90, 15);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(441, 411);
            this.groupBox3.TabIndex = 1;
            this.groupBox3.TabStop = false;
            // 
            // groupBox5
            // 
            this.groupBox5.Controls.Add(this.button48);
            this.groupBox5.Controls.Add(this.button49);
            this.groupBox5.Controls.Add(this.button33);
            this.groupBox5.Controls.Add(this.button34);
            this.groupBox5.Controls.Add(this.button18);
            this.groupBox5.Controls.Add(this.button19);
            this.groupBox5.Controls.Add(this.button4);
            this.groupBox5.Controls.Add(this.button3);
            this.groupBox5.Controls.Add(this.bagasse_om_moist_shift_a);
            this.groupBox5.Controls.Add(this.bagasse_om_pol_shift_a);
            this.groupBox5.Controls.Add(this.bagasse_head_om_shift_a);
            this.groupBox5.Location = new System.Drawing.Point(220, 57);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(208, 260);
            this.groupBox5.TabIndex = 2;
            this.groupBox5.TabStop = false;
            // 
            // button48
            // 
            this.button48.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button48.Location = new System.Drawing.Point(6, 218);
            this.button48.Name = "button48";
            this.button48.Size = new System.Drawing.Size(90, 32);
            this.button48.TabIndex = 15;
            this.button48.Text = "button48";
            this.button48.UseVisualStyleBackColor = true;
            // 
            // button49
            // 
            this.button49.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button49.Location = new System.Drawing.Point(102, 218);
            this.button49.Name = "button49";
            this.button49.Size = new System.Drawing.Size(90, 32);
            this.button49.TabIndex = 14;
            this.button49.Text = "button49";
            this.button49.UseVisualStyleBackColor = true;
            // 
            // button33
            // 
            this.button33.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button33.Location = new System.Drawing.Point(6, 176);
            this.button33.Name = "button33";
            this.button33.Size = new System.Drawing.Size(90, 32);
            this.button33.TabIndex = 13;
            this.button33.Text = "button33";
            this.button33.UseVisualStyleBackColor = true;
            // 
            // button34
            // 
            this.button34.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button34.Location = new System.Drawing.Point(102, 176);
            this.button34.Name = "button34";
            this.button34.Size = new System.Drawing.Size(90, 32);
            this.button34.TabIndex = 12;
            this.button34.Text = "button34";
            this.button34.UseVisualStyleBackColor = true;
            // 
            // button18
            // 
            this.button18.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button18.Location = new System.Drawing.Point(6, 134);
            this.button18.Name = "button18";
            this.button18.Size = new System.Drawing.Size(90, 32);
            this.button18.TabIndex = 11;
            this.button18.Text = "button18";
            this.button18.UseVisualStyleBackColor = true;
            // 
            // button19
            // 
            this.button19.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button19.Location = new System.Drawing.Point(102, 134);
            this.button19.Name = "button19";
            this.button19.Size = new System.Drawing.Size(90, 32);
            this.button19.TabIndex = 10;
            this.button19.Text = "button19";
            this.button19.UseVisualStyleBackColor = true;
            // 
            // button4
            // 
            this.button4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button4.Location = new System.Drawing.Point(102, 92);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(90, 32);
            this.button4.TabIndex = 9;
            this.button4.Text = "button4";
            this.button4.UseVisualStyleBackColor = true;
            // 
            // button3
            // 
            this.button3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button3.Location = new System.Drawing.Point(6, 92);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(90, 32);
            this.button3.TabIndex = 8;
            this.button3.Text = "button3";
            this.button3.UseVisualStyleBackColor = true;
            // 
            // bagasse_om_moist_shift_a
            // 
            this.bagasse_om_moist_shift_a.Location = new System.Drawing.Point(102, 51);
            this.bagasse_om_moist_shift_a.Name = "bagasse_om_moist_shift_a";
            this.bagasse_om_moist_shift_a.Size = new System.Drawing.Size(90, 32);
            this.bagasse_om_moist_shift_a.TabIndex = 5;
            this.bagasse_om_moist_shift_a.Text = "Moisture";
            this.bagasse_om_moist_shift_a.UseVisualStyleBackColor = true;
            // 
            // bagasse_om_pol_shift_a
            // 
            this.bagasse_om_pol_shift_a.Location = new System.Drawing.Point(6, 51);
            this.bagasse_om_pol_shift_a.Name = "bagasse_om_pol_shift_a";
            this.bagasse_om_pol_shift_a.Size = new System.Drawing.Size(90, 32);
            this.bagasse_om_pol_shift_a.TabIndex = 4;
            this.bagasse_om_pol_shift_a.Text = "Pol";
            this.bagasse_om_pol_shift_a.UseVisualStyleBackColor = true;
            // 
            // bagasse_head_om_shift_a
            // 
            this.bagasse_head_om_shift_a.Location = new System.Drawing.Point(6, 13);
            this.bagasse_head_om_shift_a.Name = "bagasse_head_om_shift_a";
            this.bagasse_head_om_shift_a.Size = new System.Drawing.Size(186, 32);
            this.bagasse_head_om_shift_a.TabIndex = 1;
            this.bagasse_head_om_shift_a.Text = "Old Mill";
            this.bagasse_head_om_shift_a.UseVisualStyleBackColor = true;
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.button46);
            this.groupBox4.Controls.Add(this.button47);
            this.groupBox4.Controls.Add(this.button31);
            this.groupBox4.Controls.Add(this.button32);
            this.groupBox4.Controls.Add(this.button16);
            this.groupBox4.Controls.Add(this.button17);
            this.groupBox4.Controls.Add(this.button2);
            this.groupBox4.Controls.Add(this.button1);
            this.groupBox4.Controls.Add(this.bagasse_nm_moist_shift_a);
            this.groupBox4.Controls.Add(this.bagasse_nm_pol_shift_a);
            this.groupBox4.Controls.Add(this.bagasse_head_nm_shift_a);
            this.groupBox4.Location = new System.Drawing.Point(6, 57);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(208, 260);
            this.groupBox4.TabIndex = 1;
            this.groupBox4.TabStop = false;
            // 
            // button46
            // 
            this.button46.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button46.Location = new System.Drawing.Point(6, 218);
            this.button46.Name = "button46";
            this.button46.Size = new System.Drawing.Size(90, 32);
            this.button46.TabIndex = 13;
            this.button46.Text = "button46";
            this.button46.UseVisualStyleBackColor = true;
            // 
            // button47
            // 
            this.button47.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button47.Location = new System.Drawing.Point(102, 218);
            this.button47.Name = "button47";
            this.button47.Size = new System.Drawing.Size(90, 32);
            this.button47.TabIndex = 12;
            this.button47.Text = "button47";
            this.button47.UseVisualStyleBackColor = true;
            // 
            // button31
            // 
            this.button31.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button31.Location = new System.Drawing.Point(6, 176);
            this.button31.Name = "button31";
            this.button31.Size = new System.Drawing.Size(90, 32);
            this.button31.TabIndex = 11;
            this.button31.Text = "button31";
            this.button31.UseVisualStyleBackColor = true;
            // 
            // button32
            // 
            this.button32.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button32.Location = new System.Drawing.Point(102, 176);
            this.button32.Name = "button32";
            this.button32.Size = new System.Drawing.Size(90, 32);
            this.button32.TabIndex = 10;
            this.button32.Text = "button32";
            this.button32.UseVisualStyleBackColor = true;
            // 
            // button16
            // 
            this.button16.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button16.Location = new System.Drawing.Point(6, 134);
            this.button16.Name = "button16";
            this.button16.Size = new System.Drawing.Size(90, 32);
            this.button16.TabIndex = 9;
            this.button16.Text = "button16";
            this.button16.UseVisualStyleBackColor = true;
            // 
            // button17
            // 
            this.button17.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button17.Location = new System.Drawing.Point(102, 134);
            this.button17.Name = "button17";
            this.button17.Size = new System.Drawing.Size(90, 32);
            this.button17.TabIndex = 8;
            this.button17.Text = "button17";
            this.button17.UseVisualStyleBackColor = true;
            // 
            // button2
            // 
            this.button2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button2.Location = new System.Drawing.Point(102, 92);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(90, 32);
            this.button2.TabIndex = 7;
            this.button2.Text = "button2";
            this.button2.UseVisualStyleBackColor = true;
            // 
            // button1
            // 
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.Location = new System.Drawing.Point(6, 91);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(90, 32);
            this.button1.TabIndex = 6;
            this.button1.Text = "button1";
            this.button1.UseVisualStyleBackColor = true;
            // 
            // bagasse_nm_moist_shift_a
            // 
            this.bagasse_nm_moist_shift_a.Location = new System.Drawing.Point(102, 51);
            this.bagasse_nm_moist_shift_a.Name = "bagasse_nm_moist_shift_a";
            this.bagasse_nm_moist_shift_a.Size = new System.Drawing.Size(90, 32);
            this.bagasse_nm_moist_shift_a.TabIndex = 3;
            this.bagasse_nm_moist_shift_a.Text = "Moisture";
            this.bagasse_nm_moist_shift_a.UseVisualStyleBackColor = true;
            // 
            // bagasse_nm_pol_shift_a
            // 
            this.bagasse_nm_pol_shift_a.Location = new System.Drawing.Point(6, 51);
            this.bagasse_nm_pol_shift_a.Name = "bagasse_nm_pol_shift_a";
            this.bagasse_nm_pol_shift_a.Size = new System.Drawing.Size(90, 32);
            this.bagasse_nm_pol_shift_a.TabIndex = 2;
            this.bagasse_nm_pol_shift_a.Text = "Pol";
            this.bagasse_nm_pol_shift_a.UseVisualStyleBackColor = true;
            // 
            // bagasse_head_nm_shift_a
            // 
            this.bagasse_head_nm_shift_a.Location = new System.Drawing.Point(6, 13);
            this.bagasse_head_nm_shift_a.Name = "bagasse_head_nm_shift_a";
            this.bagasse_head_nm_shift_a.Size = new System.Drawing.Size(186, 32);
            this.bagasse_head_nm_shift_a.TabIndex = 1;
            this.bagasse_head_nm_shift_a.Text = "New Mill";
            this.bagasse_head_nm_shift_a.UseVisualStyleBackColor = true;
            // 
            // bagass_head_shift_a
            // 
            this.bagass_head_shift_a.Location = new System.Drawing.Point(6, 13);
            this.bagass_head_shift_a.Name = "bagass_head_shift_a";
            this.bagass_head_shift_a.Size = new System.Drawing.Size(422, 41);
            this.bagass_head_shift_a.TabIndex = 0;
            this.bagass_head_shift_a.Text = "Bagasse";
            this.bagass_head_shift_a.UseVisualStyleBackColor = true;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.time16);
            this.groupBox2.Controls.Add(this.time14);
            this.groupBox2.Controls.Add(this.average_shift_a);
            this.groupBox2.Controls.Add(this.time12);
            this.groupBox2.Controls.Add(this.time10);
            this.groupBox2.Controls.Add(this.time_head_shiftA);
            this.groupBox2.Location = new System.Drawing.Point(6, 73);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(78, 353);
            this.groupBox2.TabIndex = 0;
            this.groupBox2.TabStop = false;
            // 
            // time16
            // 
            this.time16.Location = new System.Drawing.Point(6, 213);
            this.time16.Name = "time16";
            this.time16.Size = new System.Drawing.Size(66, 36);
            this.time16.TabIndex = 9;
            this.time16.Text = "16";
            this.time16.UseVisualStyleBackColor = true;
            // 
            // time14
            // 
            this.time14.Location = new System.Drawing.Point(6, 171);
            this.time14.Name = "time14";
            this.time14.Size = new System.Drawing.Size(66, 36);
            this.time14.TabIndex = 8;
            this.time14.Text = "14";
            this.time14.UseVisualStyleBackColor = true;
            // 
            // average_shift_a
            // 
            this.average_shift_a.Location = new System.Drawing.Point(6, 260);
            this.average_shift_a.Name = "average_shift_a";
            this.average_shift_a.Size = new System.Drawing.Size(67, 44);
            this.average_shift_a.TabIndex = 7;
            this.average_shift_a.Text = "Average";
            this.average_shift_a.UseVisualStyleBackColor = true;
            // 
            // time12
            // 
            this.time12.Location = new System.Drawing.Point(6, 129);
            this.time12.Name = "time12";
            this.time12.Size = new System.Drawing.Size(66, 36);
            this.time12.TabIndex = 5;
            this.time12.Text = "12";
            this.time12.UseVisualStyleBackColor = true;
            // 
            // time10
            // 
            this.time10.Location = new System.Drawing.Point(6, 87);
            this.time10.Name = "time10";
            this.time10.Size = new System.Drawing.Size(66, 36);
            this.time10.TabIndex = 4;
            this.time10.Text = "10";
            this.time10.UseVisualStyleBackColor = true;
            // 
            // time_head_shiftA
            // 
            this.time_head_shiftA.Location = new System.Drawing.Point(6, 17);
            this.time_head_shiftA.Name = "time_head_shiftA";
            this.time_head_shiftA.Size = new System.Drawing.Size(67, 64);
            this.time_head_shiftA.TabIndex = 3;
            this.time_head_shiftA.Text = "Time";
            this.time_head_shiftA.UseVisualStyleBackColor = true;
            // 
            // repo_two_hourly_bagasse_press_cake
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1667, 1045);
            this.Controls.Add(this.panel1);
            this.Name = "repo_two_hourly_bagasse_press_cake";
            this.Text = "repo_two_hourly_bagasse_press_cake";
            this.panel1.ResumeLayout(false);
            this.groupBox19.ResumeLayout(false);
            this.groupBox20.ResumeLayout(false);
            this.groupBox21.ResumeLayout(false);
            this.groupBox22.ResumeLayout(false);
            this.groupBox23.ResumeLayout(false);
            this.groupBox24.ResumeLayout(false);
            this.groupBox25.ResumeLayout(false);
            this.groupBox26.ResumeLayout(false);
            this.groupBox27.ResumeLayout(false);
            this.groupBox10.ResumeLayout(false);
            this.groupBox11.ResumeLayout(false);
            this.groupBox12.ResumeLayout(false);
            this.groupBox13.ResumeLayout(false);
            this.groupBox14.ResumeLayout(false);
            this.groupBox15.ResumeLayout(false);
            this.groupBox16.ResumeLayout(false);
            this.groupBox17.ResumeLayout(false);
            this.groupBox18.ResumeLayout(false);
            this.groupBox1.ResumeLayout(false);
            this.groupBox8.ResumeLayout(false);
            this.groupBox9.ResumeLayout(false);
            this.groupBox6.ResumeLayout(false);
            this.groupBox7.ResumeLayout(false);
            this.groupBox3.ResumeLayout(false);
            this.groupBox5.ResumeLayout(false);
            this.groupBox4.ResumeLayout(false);
            this.groupBox2.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Button bagass_head_shift_a;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.Button bagasse_head_om_shift_a;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.Button bagasse_head_nm_shift_a;
        private System.Windows.Forms.GroupBox groupBox6;
        private System.Windows.Forms.GroupBox groupBox7;
        private System.Windows.Forms.Button pc_sample_avg_head_shift_a;
        private System.Windows.Forms.Button pc_sample_one_head_shift_a;
        private System.Windows.Forms.Button pc_sample_five_head_shift_a;
        private System.Windows.Forms.Button pc_sample_two_head_shift_a;
        private System.Windows.Forms.Button pc_sample_four_head_shift_a;
        private System.Windows.Forms.Button pc_sample_three_head_shift_a;
        private System.Windows.Forms.Button pressCake_head_shift_a;
        private System.Windows.Forms.Button pc_sample_composite_head_shift_a;
        private System.Windows.Forms.Button pc_sample_moist_head_shift_a;
        private System.Windows.Forms.Button time_head_shiftA;
        private System.Windows.Forms.GroupBox groupBox8;
        private System.Windows.Forms.Button FMolasses_head_shift_a;
        private System.Windows.Forms.GroupBox groupBox9;
        private System.Windows.Forms.Button final_mol_purity_head_shift_a;
        private System.Windows.Forms.Button final_mol_Pol_head_shift_a;
        private System.Windows.Forms.Button final_mol_brix_head_shift_a;
        private System.Windows.Forms.Button bagasse_om_moist_shift_a;
        private System.Windows.Forms.Button bagasse_om_pol_shift_a;
        private System.Windows.Forms.Button bagasse_nm_moist_shift_a;
        private System.Windows.Forms.Button bagasse_nm_pol_shift_a;
        private System.Windows.Forms.Button time12;
        private System.Windows.Forms.Button time10;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button58;
        private System.Windows.Forms.Button button59;
        private System.Windows.Forms.Button button60;
        private System.Windows.Forms.Button button43;
        private System.Windows.Forms.Button button44;
        private System.Windows.Forms.Button button45;
        private System.Windows.Forms.Button button28;
        private System.Windows.Forms.Button button29;
        private System.Windows.Forms.Button button30;
        private System.Windows.Forms.Button button15;
        private System.Windows.Forms.Button button14;
        private System.Windows.Forms.Button button13;
        private System.Windows.Forms.Button button50;
        private System.Windows.Forms.Button button51;
        private System.Windows.Forms.Button button52;
        private System.Windows.Forms.Button button53;
        private System.Windows.Forms.Button button54;
        private System.Windows.Forms.Button button55;
        private System.Windows.Forms.Button button56;
        private System.Windows.Forms.Button button57;
        private System.Windows.Forms.Button button35;
        private System.Windows.Forms.Button button36;
        private System.Windows.Forms.Button button37;
        private System.Windows.Forms.Button button38;
        private System.Windows.Forms.Button button39;
        private System.Windows.Forms.Button button40;
        private System.Windows.Forms.Button button41;
        private System.Windows.Forms.Button button42;
        private System.Windows.Forms.Button button20;
        private System.Windows.Forms.Button button21;
        private System.Windows.Forms.Button button22;
        private System.Windows.Forms.Button button23;
        private System.Windows.Forms.Button button24;
        private System.Windows.Forms.Button button25;
        private System.Windows.Forms.Button button26;
        private System.Windows.Forms.Button button27;
        private System.Windows.Forms.Button button12;
        private System.Windows.Forms.Button button11;
        private System.Windows.Forms.Button button10;
        private System.Windows.Forms.Button button9;
        private System.Windows.Forms.Button button8;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Button button48;
        private System.Windows.Forms.Button button49;
        private System.Windows.Forms.Button button33;
        private System.Windows.Forms.Button button34;
        private System.Windows.Forms.Button button18;
        private System.Windows.Forms.Button button19;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button31;
        private System.Windows.Forms.Button button32;
        private System.Windows.Forms.Button button16;
        private System.Windows.Forms.Button button17;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button average_shift_a;
        private System.Windows.Forms.GroupBox groupBox10;
        private System.Windows.Forms.GroupBox groupBox11;
        private System.Windows.Forms.GroupBox groupBox12;
        private System.Windows.Forms.Button final_mol_purity_head_shift_b;
        private System.Windows.Forms.Button final_mol_Pol_head_shift_b;
        private System.Windows.Forms.Button final_mol_brix_head_shift_b;
        private System.Windows.Forms.Button FMolasses_head_shift_b;
        private System.Windows.Forms.GroupBox groupBox13;
        private System.Windows.Forms.GroupBox groupBox14;
        private System.Windows.Forms.Button pc_sample_composite_head_shift_b;
        private System.Windows.Forms.Button pc_sample_moist_head_shift_b;
        private System.Windows.Forms.Button pc_sample_avg_head_shift_b;
        private System.Windows.Forms.Button pc_sample_one_head_shift_b;
        private System.Windows.Forms.Button pc_sample_five_head_shift_b;
        private System.Windows.Forms.Button pc_sample_two_head_shift_b;
        private System.Windows.Forms.Button pc_sample_four_head_shift_b;
        private System.Windows.Forms.Button pc_sample_three_head_shift_b;
        private System.Windows.Forms.Button pressCake_head_shift_b;
        private System.Windows.Forms.GroupBox groupBox15;
        private System.Windows.Forms.GroupBox groupBox16;
        private System.Windows.Forms.Button bagasse_om_moist_shift_b;
        private System.Windows.Forms.Button bagasse_om_pol_shift_b;
        private System.Windows.Forms.Button bagasse_head_om_shift_b;
        private System.Windows.Forms.GroupBox groupBox17;
        private System.Windows.Forms.Button bagasse_nm_moist_shift_b;
        private System.Windows.Forms.Button bagasse_nm_pol_shift_b;
        private System.Windows.Forms.Button bagasse_head_nm_shift_b;
        private System.Windows.Forms.Button bagass_head_shift_b;
        private System.Windows.Forms.GroupBox groupBox18;
        private System.Windows.Forms.Button avg_shift_b;
        private System.Windows.Forms.Button time_head_shiftB;
        private System.Windows.Forms.GroupBox groupBox19;
        private System.Windows.Forms.GroupBox groupBox20;
        private System.Windows.Forms.GroupBox groupBox21;
        private System.Windows.Forms.Button final_mol_purity_head_shift_c;
        private System.Windows.Forms.Button final_mol_Pol_head_shift_c;
        private System.Windows.Forms.Button final_mol_brix_head_shift_c;
        private System.Windows.Forms.Button FMolasses_head_shift_c;
        private System.Windows.Forms.GroupBox groupBox22;
        private System.Windows.Forms.GroupBox groupBox23;
        private System.Windows.Forms.Button pc_sample_composite_head_shift_c;
        private System.Windows.Forms.Button pc_sample_moist_head_shift_c;
        private System.Windows.Forms.Button pc_sample_avg_head_shift_c;
        private System.Windows.Forms.Button pc_sample_one_head_shift_c;
        private System.Windows.Forms.Button pc_sample_fivve_head_shift_c;
        private System.Windows.Forms.Button pc_sample_two_head_shift_c;
        private System.Windows.Forms.Button pc_sample_four_head_shift_c;
        private System.Windows.Forms.Button pc_sample_three_head_shift_c;
        private System.Windows.Forms.Button pressCake_head_shift_c;
        private System.Windows.Forms.GroupBox groupBox24;
        private System.Windows.Forms.GroupBox groupBox25;
        private System.Windows.Forms.Button bagasse_om_moist_shift_c;
        private System.Windows.Forms.Button bagasse_om_pol_shift_c;
        private System.Windows.Forms.Button bagasse_head_om_shift_c;
        private System.Windows.Forms.GroupBox groupBox26;
        private System.Windows.Forms.Button bagasse_nm_moist_shift_c;
        private System.Windows.Forms.Button bagasse_nm_pol_shift_c;
        private System.Windows.Forms.Button bagasse_head_nm_shift_c;
        private System.Windows.Forms.Button bagass_head_shift_c;
        private System.Windows.Forms.GroupBox groupBox27;
        private System.Windows.Forms.Button button383;
        private System.Windows.Forms.Button time_head_shiftC;
        private System.Windows.Forms.Button button118;
        private System.Windows.Forms.Button button119;
        private System.Windows.Forms.Button button120;
        private System.Windows.Forms.Button button103;
        private System.Windows.Forms.Button button104;
        private System.Windows.Forms.Button button105;
        private System.Windows.Forms.Button button88;
        private System.Windows.Forms.Button button89;
        private System.Windows.Forms.Button button90;
        private System.Windows.Forms.Button button73;
        private System.Windows.Forms.Button button74;
        private System.Windows.Forms.Button button75;
        private System.Windows.Forms.Button button110;
        private System.Windows.Forms.Button button111;
        private System.Windows.Forms.Button button112;
        private System.Windows.Forms.Button button113;
        private System.Windows.Forms.Button button114;
        private System.Windows.Forms.Button button115;
        private System.Windows.Forms.Button button116;
        private System.Windows.Forms.Button button117;
        private System.Windows.Forms.Button button95;
        private System.Windows.Forms.Button button96;
        private System.Windows.Forms.Button button97;
        private System.Windows.Forms.Button button98;
        private System.Windows.Forms.Button button99;
        private System.Windows.Forms.Button button100;
        private System.Windows.Forms.Button button101;
        private System.Windows.Forms.Button button102;
        private System.Windows.Forms.Button button80;
        private System.Windows.Forms.Button button81;
        private System.Windows.Forms.Button button82;
        private System.Windows.Forms.Button button83;
        private System.Windows.Forms.Button button84;
        private System.Windows.Forms.Button button85;
        private System.Windows.Forms.Button button86;
        private System.Windows.Forms.Button button87;
        private System.Windows.Forms.Button button65;
        private System.Windows.Forms.Button button66;
        private System.Windows.Forms.Button button67;
        private System.Windows.Forms.Button button68;
        private System.Windows.Forms.Button button69;
        private System.Windows.Forms.Button button70;
        private System.Windows.Forms.Button button71;
        private System.Windows.Forms.Button button72;
        private System.Windows.Forms.Button button108;
        private System.Windows.Forms.Button button109;
        private System.Windows.Forms.Button button93;
        private System.Windows.Forms.Button button94;
        private System.Windows.Forms.Button button78;
        private System.Windows.Forms.Button button79;
        private System.Windows.Forms.Button button63;
        private System.Windows.Forms.Button button64;
        private System.Windows.Forms.Button button106;
        private System.Windows.Forms.Button button107;
        private System.Windows.Forms.Button button91;
        private System.Windows.Forms.Button button92;
        private System.Windows.Forms.Button button76;
        private System.Windows.Forms.Button button77;
        private System.Windows.Forms.Button button61;
        private System.Windows.Forms.Button button62;
        private System.Windows.Forms.Button button46;
        private System.Windows.Forms.Button button47;
        private System.Windows.Forms.Button time20;
        private System.Windows.Forms.Button time19;
        private System.Windows.Forms.Button time18;
        private System.Windows.Forms.Button time17;
        private System.Windows.Forms.Button time16;
        private System.Windows.Forms.Button time14;
        private System.Windows.Forms.Button button178;
        private System.Windows.Forms.Button button179;
        private System.Windows.Forms.Button button180;
        private System.Windows.Forms.Button button163;
        private System.Windows.Forms.Button button164;
        private System.Windows.Forms.Button button165;
        private System.Windows.Forms.Button button148;
        private System.Windows.Forms.Button button149;
        private System.Windows.Forms.Button button150;
        private System.Windows.Forms.Button button133;
        private System.Windows.Forms.Button button134;
        private System.Windows.Forms.Button button135;
        private System.Windows.Forms.Button button170;
        private System.Windows.Forms.Button button171;
        private System.Windows.Forms.Button button172;
        private System.Windows.Forms.Button button173;
        private System.Windows.Forms.Button button174;
        private System.Windows.Forms.Button button175;
        private System.Windows.Forms.Button button176;
        private System.Windows.Forms.Button button177;
        private System.Windows.Forms.Button button155;
        private System.Windows.Forms.Button button156;
        private System.Windows.Forms.Button button157;
        private System.Windows.Forms.Button button158;
        private System.Windows.Forms.Button button159;
        private System.Windows.Forms.Button button160;
        private System.Windows.Forms.Button button161;
        private System.Windows.Forms.Button button162;
        private System.Windows.Forms.Button button140;
        private System.Windows.Forms.Button button141;
        private System.Windows.Forms.Button button142;
        private System.Windows.Forms.Button button143;
        private System.Windows.Forms.Button button144;
        private System.Windows.Forms.Button button145;
        private System.Windows.Forms.Button button146;
        private System.Windows.Forms.Button button147;
        private System.Windows.Forms.Button button125;
        private System.Windows.Forms.Button button126;
        private System.Windows.Forms.Button button127;
        private System.Windows.Forms.Button button128;
        private System.Windows.Forms.Button button129;
        private System.Windows.Forms.Button button130;
        private System.Windows.Forms.Button button131;
        private System.Windows.Forms.Button button132;
        private System.Windows.Forms.Button button168;
        private System.Windows.Forms.Button button169;
        private System.Windows.Forms.Button button153;
        private System.Windows.Forms.Button button154;
        private System.Windows.Forms.Button button138;
        private System.Windows.Forms.Button button139;
        private System.Windows.Forms.Button button123;
        private System.Windows.Forms.Button button124;
        private System.Windows.Forms.Button button166;
        private System.Windows.Forms.Button button167;
        private System.Windows.Forms.Button button151;
        private System.Windows.Forms.Button button152;
        private System.Windows.Forms.Button button136;
        private System.Windows.Forms.Button button137;
        private System.Windows.Forms.Button button121;
        private System.Windows.Forms.Button button122;
        private System.Windows.Forms.Button button181;
        private System.Windows.Forms.Button button182;
        private System.Windows.Forms.Button button183;
        private System.Windows.Forms.Button button184;
    }
}