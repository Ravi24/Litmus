﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using Litmus.classes;
using Litmus.classes.reports;

namespace Litmus.forms.reporting
{
    public partial class frmDailyReports : Form
    {
        generalFunctions genFun = new generalFunctions();
        master_parameter_logic masterParameter = new master_parameter_logic();
        classes.reports.dailyReports_logic dailyReport = new classes.reports.dailyReports_logic();
        classes.reports.repo_form_rg_six repo = new classes.reports.repo_form_rg_six();

       

        public frmDailyReports()
        {
            InitializeComponent();
            txtReportDate.Text = masterParameter.processDate;
            bind_report_names();
        }
        public void bind_report_names()
        {
            ddlReportName.DataSource = dailyReport.get_available_reports();
            ddlReportName.ValueMember = "r_code";
            ddlReportName.DisplayMember = "r_name";
        }

        private void btnExecute_Click(object sender, EventArgs e)
        {
            DateTime reportDate = Convert.ToDateTime(txtReportDate.Text);
            DateTime processDate = Convert.ToDateTime(masterParameter.processDate);
            DateTime seasonDate = Convert.ToDateTime(masterParameter.crushingStartDate);

            int report_code = Convert.ToInt16(ddlReportName.SelectedValue);
            if (reportDate > processDate || reportDate < seasonDate)
            {
                MessageBox.Show("Report date must be between Season start date and Process Date", "Invalid Date", MessageBoxButtons.OK, MessageBoxIcon.Hand);
            }

            switch (report_code)
            {
                case 1:
                    break;
                case 2:
                    plant_performance_report();
                    break;
                case 3:
                   
                    break;
                case 4:
                    
                    break;
                case 5:
                    break;
                case 6:
                    register_of_daily_manufacturing();
                    break;
                default:
                    MessageBox.Show("Report not defined for the selection", "Invalid selection", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    break;
            }

        }

        private void register_of_daily_manufacturing()
        {
                SaveFileDialog fileLocation = new SaveFileDialog();

                fileLocation.InitialDirectory = @"c:\";
                fileLocation.RestoreDirectory = true;
                fileLocation.Title = "Save " + ddlReportName.GetItemText(ddlReportName.SelectedItem);
                fileLocation.DefaultExt = "pdf";
                fileLocation.Filter = "PDF files (*.pdf)|*.pdf";
                fileLocation.FileName = ddlReportName.GetItemText(ddlReportName.SelectedItem) + " " + txtReportDate.Text;
                if (fileLocation.ShowDialog() == DialogResult.OK)
                {
                    repo.generate_report(txtReportDate.Text, fileLocation.FileName);
                }
        }

        private void plant_performance_report()
        {
            SaveFileDialog fileLocation = new SaveFileDialog();

            fileLocation.InitialDirectory = @"c:\";
            fileLocation.RestoreDirectory = true;
            fileLocation.Title = "Save " + ddlReportName.GetItemText(ddlReportName.SelectedItem);
            fileLocation.DefaultExt = "pdf";
            fileLocation.Filter = "PDF files (*.pdf)|*.pdf";
            fileLocation.FileName = ddlReportName.GetItemText(ddlReportName.SelectedItem) + " " +txtReportDate.Text;

            if (fileLocation.ShowDialog() == DialogResult.OK)
            {
                repo_plant_performane_pdf repo_ppr = new repo_plant_performane_pdf();
                if (repo_ppr.generate_plant_protection_report(txtReportDate.Text, fileLocation.FileName) == true)
                {
                    MessageBox.Show("Report generated at " + fileLocation.FileName, "Sucess", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                else
                {
                    MessageBox.Show("Report generation failed, kindly check error log", "Failed", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                }
            }

        }
    }
}
