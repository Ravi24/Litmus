﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Litmus.classes;
namespace Litmus.forms.reporting
{
    public partial class repo_two_hourly_bagasse_press_cake : Form
    {
        classes.reports.hourly_report.repo_hourly_sugar_bags_logic hourly_sugar_logic = new classes.reports.hourly_report.repo_hourly_sugar_bags_logic();
        classes.generalFunctions genFunc = new generalFunctions();
        public repo_two_hourly_bagasse_press_cake()
        {
            InitializeComponent();
            load_report();
        }

        private void load_report()
        {
            DataSet ds_data = new DataSet();
            ds_data = hourly_sugar_logic.report_dataset(4, genFunc.reportDate);

            int buttonCount = 1;// form contains 180 buttons for two_hourly data
           
                for (int y = 0; y <= 7; y++)
                {
                        for (int i = 0; i <= 13; i++)
                        {

                            string buttonName = "button" + buttonCount;
                            Button b = (Button)this.Controls.Find(buttonName, true)[0];
                            if (y < ds_data.Tables["table_data"].Rows.Count)
                            {
                                b.Text = ds_data.Tables["table_data"].Rows[y][i].ToString();
                            }
                            else
                            {
                                b.Text = "";
                            }
                            buttonCount++;
                        }
                }
        }

    }
}
