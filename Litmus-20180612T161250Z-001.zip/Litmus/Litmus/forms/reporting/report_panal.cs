﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Litmus.classes;

namespace Litmus.forms.reporting
{
   
    public partial class report_panal : Form
    {
        classes.generalFunctions genFunc = new generalFunctions();
        classes.master_parameter_logic masterParam = new master_parameter_logic();
        classes.hourly_report_logic hourly_report_logic = new hourly_report_logic();

        string report_url = "";

        public report_panal()
        {
            InitializeComponent();
        }

        private void btnSugarBags_Click(object sender, EventArgs e)
        {
            genFunc.reportDate = dateTimePicker1.Text;
            reporting.repo_hourly_sugar_bags form = new repo_hourly_sugar_bags();
           
            form.ShowDialog();
            
        }

        //private void calculateCropDayForTheDay(object sender, EventArgs e)
        //{
        //    lblCropDayValue.Text = genFunc.getCropDay(dateTimePicker1.Text).ToString();
        //}

        private void report_panal_Load(object sender, EventArgs e)
        {
            string entryDate = masterParam.entryDate;
            dateTimePicker1.Text = entryDate;
            lblCropDayValue.Text = genFunc.getCropDay(dateTimePicker1.Text).ToString();

            //dateTimePicker1.LostFocus += new EventHandler(calculateCropDayForTheDay);
        }

        private void dateTimePicker1_ValueChanged(object sender, EventArgs e)
        {
            lblCropDayValue.Text = genFunc.getCropDay(dateTimePicker1.Text).ToString();
        }

        private void btnJuiceWater_Click(object sender, EventArgs e)
        {
            //forms.reporting.hourly_report_view repoView = new hourly_report_view();
            //repoView.ShowDialog();
            string repo_date = dateTimePicker1.Text;
            //System.Diagnostics.Process.Start("http://191.168.1.7:91/juice_and_water_flow.aspx?repo-date=" + repo_date);
            int report_code = 6;
            report_url = hourly_report_logic.get_report_web_address(report_code);
            
            if (report_url != null)
            {
                System.Diagnostics.Process.Start(report_url + repo_date);
            }
            else
            {
                MessageBox.Show("Web url not defined");
            }
        }

        private void btnJuice_Click(object sender, EventArgs e)
        {
            //genFunc.reportDate = dateTimePicker1.Text;
            //forms.reporting.repo_two_hourly_juice repoJuice = new repo_two_hourly_juice();
            //repoJuice.ShowDialog();
            string repo_date = dateTimePicker1.Text;
            //System.Diagnostics.Process.Start("http://191.168.1.7:91/juice_analysis.aspx?repo-date=" + repo_date);
            int report_code = 7;
            report_url = hourly_report_logic.get_report_web_address(report_code);

            if (report_url != null)
            {
                System.Diagnostics.Process.Start(report_url + repo_date);
            }
            else
            {
                MessageBox.Show("Web url not defined");
            }
        }

        private void btnBagassePressCake_Click(object sender, EventArgs e)
        {
            //genFunc.reportDate = dateTimePicker1.Text;
            //forms.reporting.repo_two_hourly_bagasse_press_cake frm = new repo_two_hourly_bagasse_press_cake();
            //frm.Show();
           
        }

        private void btnSyrupFinalMolasses_Click(object sender, EventArgs e)
        {
            //genFunc.reportDate = dateTimePicker1.Text;
            //forms.reporting.repo_two_hourly_oliver_cleary_juice_syrup frm = new repo_two_hourly_oliver_cleary_juice_syrup();
            //frm.Show();
            
            string repo_date = dateTimePicker1.Text;
            //System.Diagnostics.Process.Start("http://191.168.1.7:91/syrup_final_molasses.aspx?repo-date=" + repo_date);
            int report_code = 9;
            report_url = hourly_report_logic.get_report_web_address(report_code);

            if (report_url != null)
            {
                System.Diagnostics.Process.Start(report_url + repo_date);
            }
            else
            {
                MessageBox.Show("Web url not defined");
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string repo_date = dateTimePicker1.Text;
            //System.Diagnostics.Process.Start("http://191.168.1.7:91/bi_hourly_bagasse.aspx?repo-date=" + repo_date);
            //forms.reporting.bagasse_and_press_cake_web web = new bagasse_and_press_cake_web();
            //web.Show();

            int report_code = 8;
            report_url = hourly_report_logic.get_report_web_address(report_code);

            if (report_url != null)
            {
                System.Diagnostics.Process.Start(report_url + repo_date);
            }
            else
            {
                MessageBox.Show("Web url not defined");
            }
        }
    }
}
