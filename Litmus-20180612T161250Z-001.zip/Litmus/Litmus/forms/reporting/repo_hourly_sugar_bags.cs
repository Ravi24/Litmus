﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Litmus.classes;
namespace Litmus.forms.reporting
{
    public partial class repo_hourly_sugar_bags : Form
    {
        classes.reports.hourly_report.repo_hourly_sugar_bags_logic repo_hourly_logic = new classes.reports.hourly_report.repo_hourly_sugar_bags_logic();
        classes.generalFunctions genFunc = new generalFunctions();
        public repo_hourly_sugar_bags()
        {
            InitializeComponent();

            DataSet ds = null;

            try
            {
                
                ds = repo_hourly_logic.report_dataset(1, genFunc.reportDate);
                if (ds.Tables["table_data"].Rows.Count > 0)
                {
                    int count = 1;
                    for (int y = 0; y <= 23; y++)
                    {
                        for (int i = 0; i <= 15; i++)
                        {
                            //MessageBox.Show(ds.Tables[0].Rows[0][i - 1].ToString());
                            string buttonName = "button" + count;
                            Button b = (Button)this.Controls.Find(buttonName, true)[0];
                            b.Text = ds.Tables["table_data"].Rows[y][i].ToString(); ;
                            count++;
                        }
                    }
                }
                else
                {
                    MessageBox.Show("No record found");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

        }

        
        
    }
}
