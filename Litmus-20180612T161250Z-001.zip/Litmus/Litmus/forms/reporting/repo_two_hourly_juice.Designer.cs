﻿namespace Litmus.forms.reporting
{
    partial class repo_two_hourly_juice
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.groupBox35 = new System.Windows.Forms.GroupBox();
            this.panel79 = new System.Windows.Forms.Panel();
            this.btnDaySumm16 = new System.Windows.Forms.Button();
            this.btnDaySumm17 = new System.Windows.Forms.Button();
            this.btnDaySumm18 = new System.Windows.Forms.Button();
            this.panel78 = new System.Windows.Forms.Panel();
            this.btnDaySumm13 = new System.Windows.Forms.Button();
            this.btnDaySumm14 = new System.Windows.Forms.Button();
            this.btnDaySumm15 = new System.Windows.Forms.Button();
            this.panel77 = new System.Windows.Forms.Panel();
            this.btnDaySumm10 = new System.Windows.Forms.Button();
            this.btnDaySumm11 = new System.Windows.Forms.Button();
            this.btnDaySumm12 = new System.Windows.Forms.Button();
            this.panel76 = new System.Windows.Forms.Panel();
            this.btnDaySumm7 = new System.Windows.Forms.Button();
            this.btnDaySumm8 = new System.Windows.Forms.Button();
            this.btnDaySumm9 = new System.Windows.Forms.Button();
            this.panel75 = new System.Windows.Forms.Panel();
            this.btnDaySumm4 = new System.Windows.Forms.Button();
            this.btnDaySumm5 = new System.Windows.Forms.Button();
            this.btnDaySumm6 = new System.Windows.Forms.Button();
            this.panel74 = new System.Windows.Forms.Panel();
            this.btnDaySumm1 = new System.Windows.Forms.Button();
            this.btnDaySumm2 = new System.Windows.Forms.Button();
            this.btnDaySumm3 = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            this.groupBox24 = new System.Windows.Forms.GroupBox();
            this.groupBox25 = new System.Windows.Forms.GroupBox();
            this.groupBox26 = new System.Windows.Forms.GroupBox();
            this.panel97 = new System.Windows.Forms.Panel();
            this.button269 = new System.Windows.Forms.Button();
            this.button270 = new System.Windows.Forms.Button();
            this.button271 = new System.Windows.Forms.Button();
            this.panel73 = new System.Windows.Forms.Panel();
            this.button214 = new System.Windows.Forms.Button();
            this.button215 = new System.Windows.Forms.Button();
            this.button216 = new System.Windows.Forms.Button();
            this.panel67 = new System.Windows.Forms.Panel();
            this.button196 = new System.Windows.Forms.Button();
            this.button197 = new System.Windows.Forms.Button();
            this.button198 = new System.Windows.Forms.Button();
            this.panel61 = new System.Windows.Forms.Panel();
            this.button178 = new System.Windows.Forms.Button();
            this.button179 = new System.Windows.Forms.Button();
            this.button180 = new System.Windows.Forms.Button();
            this.panel55 = new System.Windows.Forms.Panel();
            this.button160 = new System.Windows.Forms.Button();
            this.button161 = new System.Windows.Forms.Button();
            this.button162 = new System.Windows.Forms.Button();
            this.btnLjOmPurityShiftC = new System.Windows.Forms.Button();
            this.btnLjOmPolShiftC = new System.Windows.Forms.Button();
            this.btnLjOmBrixShiftC = new System.Windows.Forms.Button();
            this.btnLjOmShiftC = new System.Windows.Forms.Button();
            this.groupBox27 = new System.Windows.Forms.GroupBox();
            this.panel96 = new System.Windows.Forms.Panel();
            this.button266 = new System.Windows.Forms.Button();
            this.button267 = new System.Windows.Forms.Button();
            this.button268 = new System.Windows.Forms.Button();
            this.panel72 = new System.Windows.Forms.Panel();
            this.button211 = new System.Windows.Forms.Button();
            this.button212 = new System.Windows.Forms.Button();
            this.button213 = new System.Windows.Forms.Button();
            this.panel66 = new System.Windows.Forms.Panel();
            this.button193 = new System.Windows.Forms.Button();
            this.button194 = new System.Windows.Forms.Button();
            this.button195 = new System.Windows.Forms.Button();
            this.panel60 = new System.Windows.Forms.Panel();
            this.button175 = new System.Windows.Forms.Button();
            this.button176 = new System.Windows.Forms.Button();
            this.button177 = new System.Windows.Forms.Button();
            this.panel54 = new System.Windows.Forms.Panel();
            this.button157 = new System.Windows.Forms.Button();
            this.button158 = new System.Windows.Forms.Button();
            this.button159 = new System.Windows.Forms.Button();
            this.btnLjNmPurityShiftC = new System.Windows.Forms.Button();
            this.btnLjNmPolShiftC = new System.Windows.Forms.Button();
            this.btnLjNmBrixShiftC = new System.Windows.Forms.Button();
            this.btnLjNmShiftC = new System.Windows.Forms.Button();
            this.btnLastJuiceShiftC = new System.Windows.Forms.Button();
            this.groupBox28 = new System.Windows.Forms.GroupBox();
            this.groupBox29 = new System.Windows.Forms.GroupBox();
            this.panel95 = new System.Windows.Forms.Panel();
            this.button263 = new System.Windows.Forms.Button();
            this.button264 = new System.Windows.Forms.Button();
            this.button265 = new System.Windows.Forms.Button();
            this.panel71 = new System.Windows.Forms.Panel();
            this.button208 = new System.Windows.Forms.Button();
            this.button209 = new System.Windows.Forms.Button();
            this.button210 = new System.Windows.Forms.Button();
            this.panel65 = new System.Windows.Forms.Panel();
            this.button190 = new System.Windows.Forms.Button();
            this.button191 = new System.Windows.Forms.Button();
            this.button192 = new System.Windows.Forms.Button();
            this.panel59 = new System.Windows.Forms.Panel();
            this.button172 = new System.Windows.Forms.Button();
            this.button173 = new System.Windows.Forms.Button();
            this.button174 = new System.Windows.Forms.Button();
            this.panel53 = new System.Windows.Forms.Panel();
            this.button154 = new System.Windows.Forms.Button();
            this.button155 = new System.Windows.Forms.Button();
            this.button156 = new System.Windows.Forms.Button();
            this.btnMjOmPurityShiftC = new System.Windows.Forms.Button();
            this.btnMjOmPolShiftC = new System.Windows.Forms.Button();
            this.btnMjOmBrixShiftC = new System.Windows.Forms.Button();
            this.btnMjOmShiftC = new System.Windows.Forms.Button();
            this.groupBox30 = new System.Windows.Forms.GroupBox();
            this.panel94 = new System.Windows.Forms.Panel();
            this.button260 = new System.Windows.Forms.Button();
            this.button261 = new System.Windows.Forms.Button();
            this.button262 = new System.Windows.Forms.Button();
            this.panel70 = new System.Windows.Forms.Panel();
            this.button205 = new System.Windows.Forms.Button();
            this.button206 = new System.Windows.Forms.Button();
            this.button207 = new System.Windows.Forms.Button();
            this.panel64 = new System.Windows.Forms.Panel();
            this.button187 = new System.Windows.Forms.Button();
            this.button188 = new System.Windows.Forms.Button();
            this.button189 = new System.Windows.Forms.Button();
            this.panel58 = new System.Windows.Forms.Panel();
            this.button169 = new System.Windows.Forms.Button();
            this.button170 = new System.Windows.Forms.Button();
            this.button171 = new System.Windows.Forms.Button();
            this.panel52 = new System.Windows.Forms.Panel();
            this.button151 = new System.Windows.Forms.Button();
            this.button152 = new System.Windows.Forms.Button();
            this.button153 = new System.Windows.Forms.Button();
            this.btnMjNmPurityShiftC = new System.Windows.Forms.Button();
            this.btnMjNmPolShiftC = new System.Windows.Forms.Button();
            this.btnMjNmBrixShiftC = new System.Windows.Forms.Button();
            this.btnMjNmShiftC = new System.Windows.Forms.Button();
            this.btnMixedJuiceShiftC = new System.Windows.Forms.Button();
            this.groupBox31 = new System.Windows.Forms.GroupBox();
            this.btnAvgShiftC = new System.Windows.Forms.Button();
            this.btnTime8 = new System.Windows.Forms.Button();
            this.btnTime6 = new System.Windows.Forms.Button();
            this.btnTime4 = new System.Windows.Forms.Button();
            this.btnTime2 = new System.Windows.Forms.Button();
            this.btnTimeShiftC = new System.Windows.Forms.Button();
            this.groupBox32 = new System.Windows.Forms.GroupBox();
            this.groupBox33 = new System.Windows.Forms.GroupBox();
            this.panel93 = new System.Windows.Forms.Panel();
            this.button257 = new System.Windows.Forms.Button();
            this.button258 = new System.Windows.Forms.Button();
            this.button259 = new System.Windows.Forms.Button();
            this.panel69 = new System.Windows.Forms.Panel();
            this.button202 = new System.Windows.Forms.Button();
            this.button203 = new System.Windows.Forms.Button();
            this.button204 = new System.Windows.Forms.Button();
            this.panel63 = new System.Windows.Forms.Panel();
            this.button184 = new System.Windows.Forms.Button();
            this.button185 = new System.Windows.Forms.Button();
            this.button186 = new System.Windows.Forms.Button();
            this.panel57 = new System.Windows.Forms.Panel();
            this.button166 = new System.Windows.Forms.Button();
            this.button167 = new System.Windows.Forms.Button();
            this.button168 = new System.Windows.Forms.Button();
            this.panel51 = new System.Windows.Forms.Panel();
            this.button148 = new System.Windows.Forms.Button();
            this.button149 = new System.Windows.Forms.Button();
            this.button150 = new System.Windows.Forms.Button();
            this.btnPjOmPurityShiftC = new System.Windows.Forms.Button();
            this.btnPjOmPolShiftC = new System.Windows.Forms.Button();
            this.btnPjOmBrixShiftC = new System.Windows.Forms.Button();
            this.btnPjOmShiftC = new System.Windows.Forms.Button();
            this.groupBox34 = new System.Windows.Forms.GroupBox();
            this.panel92 = new System.Windows.Forms.Panel();
            this.button254 = new System.Windows.Forms.Button();
            this.button255 = new System.Windows.Forms.Button();
            this.button256 = new System.Windows.Forms.Button();
            this.panel68 = new System.Windows.Forms.Panel();
            this.button199 = new System.Windows.Forms.Button();
            this.button200 = new System.Windows.Forms.Button();
            this.button201 = new System.Windows.Forms.Button();
            this.panel62 = new System.Windows.Forms.Panel();
            this.button181 = new System.Windows.Forms.Button();
            this.button182 = new System.Windows.Forms.Button();
            this.button183 = new System.Windows.Forms.Button();
            this.panel56 = new System.Windows.Forms.Panel();
            this.button163 = new System.Windows.Forms.Button();
            this.button164 = new System.Windows.Forms.Button();
            this.button165 = new System.Windows.Forms.Button();
            this.panel50 = new System.Windows.Forms.Panel();
            this.button145 = new System.Windows.Forms.Button();
            this.button146 = new System.Windows.Forms.Button();
            this.button147 = new System.Windows.Forms.Button();
            this.btnPjNmPurityShiftC = new System.Windows.Forms.Button();
            this.btnPjNmPolShiftC = new System.Windows.Forms.Button();
            this.btnPjNmBrixShiftC = new System.Windows.Forms.Button();
            this.btnPjNmShiftC = new System.Windows.Forms.Button();
            this.btnPrimaryJuiceShiftC = new System.Windows.Forms.Button();
            this.groupBox13 = new System.Windows.Forms.GroupBox();
            this.groupBox14 = new System.Windows.Forms.GroupBox();
            this.groupBox15 = new System.Windows.Forms.GroupBox();
            this.panel91 = new System.Windows.Forms.Panel();
            this.button251 = new System.Windows.Forms.Button();
            this.button252 = new System.Windows.Forms.Button();
            this.button253 = new System.Windows.Forms.Button();
            this.panel49 = new System.Windows.Forms.Panel();
            this.button144 = new System.Windows.Forms.Button();
            this.button142 = new System.Windows.Forms.Button();
            this.button143 = new System.Windows.Forms.Button();
            this.panel43 = new System.Windows.Forms.Panel();
            this.button124 = new System.Windows.Forms.Button();
            this.button125 = new System.Windows.Forms.Button();
            this.button126 = new System.Windows.Forms.Button();
            this.panel37 = new System.Windows.Forms.Panel();
            this.button106 = new System.Windows.Forms.Button();
            this.button107 = new System.Windows.Forms.Button();
            this.button108 = new System.Windows.Forms.Button();
            this.panel31 = new System.Windows.Forms.Panel();
            this.button88 = new System.Windows.Forms.Button();
            this.button89 = new System.Windows.Forms.Button();
            this.button90 = new System.Windows.Forms.Button();
            this.btnLjOmPurityShiftB = new System.Windows.Forms.Button();
            this.btnLjOmPolShiftB = new System.Windows.Forms.Button();
            this.btnLjOmBrixShiftB = new System.Windows.Forms.Button();
            this.btnLjOmShiftB = new System.Windows.Forms.Button();
            this.groupBox16 = new System.Windows.Forms.GroupBox();
            this.panel90 = new System.Windows.Forms.Panel();
            this.button248 = new System.Windows.Forms.Button();
            this.button249 = new System.Windows.Forms.Button();
            this.button250 = new System.Windows.Forms.Button();
            this.panel48 = new System.Windows.Forms.Panel();
            this.button139 = new System.Windows.Forms.Button();
            this.button140 = new System.Windows.Forms.Button();
            this.button141 = new System.Windows.Forms.Button();
            this.panel42 = new System.Windows.Forms.Panel();
            this.button121 = new System.Windows.Forms.Button();
            this.button122 = new System.Windows.Forms.Button();
            this.button123 = new System.Windows.Forms.Button();
            this.panel36 = new System.Windows.Forms.Panel();
            this.button103 = new System.Windows.Forms.Button();
            this.button104 = new System.Windows.Forms.Button();
            this.button105 = new System.Windows.Forms.Button();
            this.panel30 = new System.Windows.Forms.Panel();
            this.button85 = new System.Windows.Forms.Button();
            this.button86 = new System.Windows.Forms.Button();
            this.button87 = new System.Windows.Forms.Button();
            this.btnLjNmPurityShiftB = new System.Windows.Forms.Button();
            this.btnLjNmPolShiftB = new System.Windows.Forms.Button();
            this.btnLjNmBrixShiftB = new System.Windows.Forms.Button();
            this.btnLjNmShiftB = new System.Windows.Forms.Button();
            this.btnLastJuiceShiftB = new System.Windows.Forms.Button();
            this.groupBox17 = new System.Windows.Forms.GroupBox();
            this.groupBox18 = new System.Windows.Forms.GroupBox();
            this.panel89 = new System.Windows.Forms.Panel();
            this.button245 = new System.Windows.Forms.Button();
            this.button246 = new System.Windows.Forms.Button();
            this.button247 = new System.Windows.Forms.Button();
            this.panel47 = new System.Windows.Forms.Panel();
            this.button136 = new System.Windows.Forms.Button();
            this.button137 = new System.Windows.Forms.Button();
            this.button138 = new System.Windows.Forms.Button();
            this.panel41 = new System.Windows.Forms.Panel();
            this.button118 = new System.Windows.Forms.Button();
            this.button119 = new System.Windows.Forms.Button();
            this.button120 = new System.Windows.Forms.Button();
            this.panel35 = new System.Windows.Forms.Panel();
            this.button100 = new System.Windows.Forms.Button();
            this.button101 = new System.Windows.Forms.Button();
            this.button102 = new System.Windows.Forms.Button();
            this.panel29 = new System.Windows.Forms.Panel();
            this.button82 = new System.Windows.Forms.Button();
            this.button83 = new System.Windows.Forms.Button();
            this.button84 = new System.Windows.Forms.Button();
            this.btnMjOmPurityShiftB = new System.Windows.Forms.Button();
            this.btnMjOmPolShiftB = new System.Windows.Forms.Button();
            this.btnMjOmBrixShiftB = new System.Windows.Forms.Button();
            this.btnMjOmShiftB = new System.Windows.Forms.Button();
            this.groupBox19 = new System.Windows.Forms.GroupBox();
            this.panel88 = new System.Windows.Forms.Panel();
            this.button242 = new System.Windows.Forms.Button();
            this.button243 = new System.Windows.Forms.Button();
            this.button244 = new System.Windows.Forms.Button();
            this.panel46 = new System.Windows.Forms.Panel();
            this.button133 = new System.Windows.Forms.Button();
            this.button134 = new System.Windows.Forms.Button();
            this.button135 = new System.Windows.Forms.Button();
            this.panel40 = new System.Windows.Forms.Panel();
            this.button115 = new System.Windows.Forms.Button();
            this.button116 = new System.Windows.Forms.Button();
            this.button117 = new System.Windows.Forms.Button();
            this.panel34 = new System.Windows.Forms.Panel();
            this.button97 = new System.Windows.Forms.Button();
            this.button98 = new System.Windows.Forms.Button();
            this.button99 = new System.Windows.Forms.Button();
            this.panel27 = new System.Windows.Forms.Panel();
            this.button79 = new System.Windows.Forms.Button();
            this.button80 = new System.Windows.Forms.Button();
            this.button81 = new System.Windows.Forms.Button();
            this.btnMjNmPurityShiftB = new System.Windows.Forms.Button();
            this.btnMjNmPolShiftB = new System.Windows.Forms.Button();
            this.btnMjNmBrixShiftB = new System.Windows.Forms.Button();
            this.btnMjNmShiftB = new System.Windows.Forms.Button();
            this.btnMixedJuiceShiftB = new System.Windows.Forms.Button();
            this.groupBox20 = new System.Windows.Forms.GroupBox();
            this.btnAvgShiftB = new System.Windows.Forms.Button();
            this.btnTime24 = new System.Windows.Forms.Button();
            this.btnTime22 = new System.Windows.Forms.Button();
            this.btnTime20 = new System.Windows.Forms.Button();
            this.btnTime18 = new System.Windows.Forms.Button();
            this.btnTimeShiftB = new System.Windows.Forms.Button();
            this.groupBox21 = new System.Windows.Forms.GroupBox();
            this.groupBox22 = new System.Windows.Forms.GroupBox();
            this.panel87 = new System.Windows.Forms.Panel();
            this.button239 = new System.Windows.Forms.Button();
            this.button240 = new System.Windows.Forms.Button();
            this.button241 = new System.Windows.Forms.Button();
            this.panel45 = new System.Windows.Forms.Panel();
            this.button130 = new System.Windows.Forms.Button();
            this.button131 = new System.Windows.Forms.Button();
            this.button132 = new System.Windows.Forms.Button();
            this.panel39 = new System.Windows.Forms.Panel();
            this.button112 = new System.Windows.Forms.Button();
            this.button113 = new System.Windows.Forms.Button();
            this.button114 = new System.Windows.Forms.Button();
            this.panel33 = new System.Windows.Forms.Panel();
            this.button94 = new System.Windows.Forms.Button();
            this.button95 = new System.Windows.Forms.Button();
            this.button96 = new System.Windows.Forms.Button();
            this.panel26 = new System.Windows.Forms.Panel();
            this.button76 = new System.Windows.Forms.Button();
            this.button77 = new System.Windows.Forms.Button();
            this.button78 = new System.Windows.Forms.Button();
            this.btnPjOmPurityShiftB = new System.Windows.Forms.Button();
            this.btnPjOmPolShiftB = new System.Windows.Forms.Button();
            this.btnPjOmBrixShiftB = new System.Windows.Forms.Button();
            this.btnPjOmShiftB = new System.Windows.Forms.Button();
            this.groupBox23 = new System.Windows.Forms.GroupBox();
            this.panel86 = new System.Windows.Forms.Panel();
            this.button236 = new System.Windows.Forms.Button();
            this.button237 = new System.Windows.Forms.Button();
            this.button238 = new System.Windows.Forms.Button();
            this.panel44 = new System.Windows.Forms.Panel();
            this.button127 = new System.Windows.Forms.Button();
            this.button128 = new System.Windows.Forms.Button();
            this.button129 = new System.Windows.Forms.Button();
            this.panel38 = new System.Windows.Forms.Panel();
            this.button109 = new System.Windows.Forms.Button();
            this.button110 = new System.Windows.Forms.Button();
            this.button111 = new System.Windows.Forms.Button();
            this.panel32 = new System.Windows.Forms.Panel();
            this.button91 = new System.Windows.Forms.Button();
            this.button92 = new System.Windows.Forms.Button();
            this.button93 = new System.Windows.Forms.Button();
            this.panel25 = new System.Windows.Forms.Panel();
            this.button73 = new System.Windows.Forms.Button();
            this.button74 = new System.Windows.Forms.Button();
            this.button75 = new System.Windows.Forms.Button();
            this.btnPjNmPurityShiftB = new System.Windows.Forms.Button();
            this.btnPjNmPolShiftB = new System.Windows.Forms.Button();
            this.btnPjNmBrixShiftB = new System.Windows.Forms.Button();
            this.btnPjNmShiftB = new System.Windows.Forms.Button();
            this.btnPrimaryJuiceShiftB = new System.Windows.Forms.Button();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.groupBox10 = new System.Windows.Forms.GroupBox();
            this.groupBox11 = new System.Windows.Forms.GroupBox();
            this.panel85 = new System.Windows.Forms.Panel();
            this.button233 = new System.Windows.Forms.Button();
            this.button234 = new System.Windows.Forms.Button();
            this.button232 = new System.Windows.Forms.Button();
            this.panel24 = new System.Windows.Forms.Panel();
            this.button70 = new System.Windows.Forms.Button();
            this.button71 = new System.Windows.Forms.Button();
            this.button72 = new System.Windows.Forms.Button();
            this.panel18 = new System.Windows.Forms.Panel();
            this.button52 = new System.Windows.Forms.Button();
            this.button53 = new System.Windows.Forms.Button();
            this.button54 = new System.Windows.Forms.Button();
            this.btnLjOmPurityShiftA = new System.Windows.Forms.Button();
            this.panel7 = new System.Windows.Forms.Panel();
            this.button16 = new System.Windows.Forms.Button();
            this.button17 = new System.Windows.Forms.Button();
            this.button18 = new System.Windows.Forms.Button();
            this.btnLjOmPolShiftA = new System.Windows.Forms.Button();
            this.btnLjOmBrixShiftA = new System.Windows.Forms.Button();
            this.panel13 = new System.Windows.Forms.Panel();
            this.button34 = new System.Windows.Forms.Button();
            this.button35 = new System.Windows.Forms.Button();
            this.button36 = new System.Windows.Forms.Button();
            this.btnLjOmShiftA = new System.Windows.Forms.Button();
            this.groupBox12 = new System.Windows.Forms.GroupBox();
            this.panel84 = new System.Windows.Forms.Panel();
            this.button230 = new System.Windows.Forms.Button();
            this.button231 = new System.Windows.Forms.Button();
            this.button229 = new System.Windows.Forms.Button();
            this.panel23 = new System.Windows.Forms.Panel();
            this.button67 = new System.Windows.Forms.Button();
            this.button68 = new System.Windows.Forms.Button();
            this.button69 = new System.Windows.Forms.Button();
            this.panel28 = new System.Windows.Forms.Panel();
            this.button49 = new System.Windows.Forms.Button();
            this.button50 = new System.Windows.Forms.Button();
            this.button51 = new System.Windows.Forms.Button();
            this.btnLjNmPurityShiftA = new System.Windows.Forms.Button();
            this.panel6 = new System.Windows.Forms.Panel();
            this.button13 = new System.Windows.Forms.Button();
            this.button14 = new System.Windows.Forms.Button();
            this.button15 = new System.Windows.Forms.Button();
            this.btnLjNmPolShiftA = new System.Windows.Forms.Button();
            this.btnLjNmBrixShiftA = new System.Windows.Forms.Button();
            this.btnLjNmShiftA = new System.Windows.Forms.Button();
            this.panel12 = new System.Windows.Forms.Panel();
            this.button31 = new System.Windows.Forms.Button();
            this.button32 = new System.Windows.Forms.Button();
            this.button33 = new System.Windows.Forms.Button();
            this.btnLastJuiceShiftA = new System.Windows.Forms.Button();
            this.groupBox7 = new System.Windows.Forms.GroupBox();
            this.groupBox9 = new System.Windows.Forms.GroupBox();
            this.panel83 = new System.Windows.Forms.Panel();
            this.button227 = new System.Windows.Forms.Button();
            this.button228 = new System.Windows.Forms.Button();
            this.button226 = new System.Windows.Forms.Button();
            this.panel22 = new System.Windows.Forms.Panel();
            this.button64 = new System.Windows.Forms.Button();
            this.button65 = new System.Windows.Forms.Button();
            this.button66 = new System.Windows.Forms.Button();
            this.btnMjOmPurityShiftA = new System.Windows.Forms.Button();
            this.btnMjOmPolShiftA = new System.Windows.Forms.Button();
            this.panel5 = new System.Windows.Forms.Panel();
            this.button10 = new System.Windows.Forms.Button();
            this.button11 = new System.Windows.Forms.Button();
            this.button12 = new System.Windows.Forms.Button();
            this.panel17 = new System.Windows.Forms.Panel();
            this.button46 = new System.Windows.Forms.Button();
            this.button47 = new System.Windows.Forms.Button();
            this.button48 = new System.Windows.Forms.Button();
            this.btnMjOmBrixShiftA = new System.Windows.Forms.Button();
            this.btnMjOmShiftA = new System.Windows.Forms.Button();
            this.panel11 = new System.Windows.Forms.Panel();
            this.button28 = new System.Windows.Forms.Button();
            this.button29 = new System.Windows.Forms.Button();
            this.button30 = new System.Windows.Forms.Button();
            this.groupBox8 = new System.Windows.Forms.GroupBox();
            this.panel82 = new System.Windows.Forms.Panel();
            this.button224 = new System.Windows.Forms.Button();
            this.button225 = new System.Windows.Forms.Button();
            this.button223 = new System.Windows.Forms.Button();
            this.panel21 = new System.Windows.Forms.Panel();
            this.button61 = new System.Windows.Forms.Button();
            this.button62 = new System.Windows.Forms.Button();
            this.button63 = new System.Windows.Forms.Button();
            this.btnMjNmPurityShiftA = new System.Windows.Forms.Button();
            this.btnMjNmPolShiftA = new System.Windows.Forms.Button();
            this.panel4 = new System.Windows.Forms.Panel();
            this.button7 = new System.Windows.Forms.Button();
            this.button8 = new System.Windows.Forms.Button();
            this.button9 = new System.Windows.Forms.Button();
            this.btnMjNmBrixShiftA = new System.Windows.Forms.Button();
            this.btnMjNmShiftA = new System.Windows.Forms.Button();
            this.panel16 = new System.Windows.Forms.Panel();
            this.button43 = new System.Windows.Forms.Button();
            this.button44 = new System.Windows.Forms.Button();
            this.button45 = new System.Windows.Forms.Button();
            this.panel10 = new System.Windows.Forms.Panel();
            this.button25 = new System.Windows.Forms.Button();
            this.button26 = new System.Windows.Forms.Button();
            this.button27 = new System.Windows.Forms.Button();
            this.btnMixedJuiceShiftA = new System.Windows.Forms.Button();
            this.groupBox6 = new System.Windows.Forms.GroupBox();
            this.btnAverage = new System.Windows.Forms.Button();
            this.btnTime16 = new System.Windows.Forms.Button();
            this.btnTime14 = new System.Windows.Forms.Button();
            this.btnTime12 = new System.Windows.Forms.Button();
            this.btnTime10 = new System.Windows.Forms.Button();
            this.btnTimePj = new System.Windows.Forms.Button();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.btnPjOmPurityShiftA = new System.Windows.Forms.Button();
            this.btnPjOmPolShiftA = new System.Windows.Forms.Button();
            this.btnPjOmBrixShiftA = new System.Windows.Forms.Button();
            this.btnPjOmShiftA = new System.Windows.Forms.Button();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.button218 = new System.Windows.Forms.Button();
            this.button217 = new System.Windows.Forms.Button();
            this.button219 = new System.Windows.Forms.Button();
            this.button55 = new System.Windows.Forms.Button();
            this.button56 = new System.Windows.Forms.Button();
            this.button57 = new System.Windows.Forms.Button();
            this.button19 = new System.Windows.Forms.Button();
            this.button20 = new System.Windows.Forms.Button();
            this.button21 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.btnPjNmPurityShiftA = new System.Windows.Forms.Button();
            this.btnPjNmPolShiftA = new System.Windows.Forms.Button();
            this.btnPjNmBrixShiftA = new System.Windows.Forms.Button();
            this.btnPjNmShiftA = new System.Windows.Forms.Button();
            this.button37 = new System.Windows.Forms.Button();
            this.button38 = new System.Windows.Forms.Button();
            this.button39 = new System.Windows.Forms.Button();
            this.btnPrimaryJuiceShiftA = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.lblCropDayValue = new System.Windows.Forms.Label();
            this.lblCropDay = new System.Windows.Forms.Label();
            this.lblReportDateValue = new System.Windows.Forms.Label();
            this.lblReportDate = new System.Windows.Forms.Label();
            this.button42 = new System.Windows.Forms.Button();
            this.button41 = new System.Windows.Forms.Button();
            this.button40 = new System.Windows.Forms.Button();
            this.button6 = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.button24 = new System.Windows.Forms.Button();
            this.button23 = new System.Windows.Forms.Button();
            this.button22 = new System.Windows.Forms.Button();
            this.button60 = new System.Windows.Forms.Button();
            this.button59 = new System.Windows.Forms.Button();
            this.button58 = new System.Windows.Forms.Button();
            this.button220 = new System.Windows.Forms.Button();
            this.button222 = new System.Windows.Forms.Button();
            this.button221 = new System.Windows.Forms.Button();
            this.panel81 = new System.Windows.Forms.Panel();
            this.panel1.SuspendLayout();
            this.groupBox35.SuspendLayout();
            this.panel79.SuspendLayout();
            this.panel78.SuspendLayout();
            this.panel77.SuspendLayout();
            this.panel76.SuspendLayout();
            this.panel75.SuspendLayout();
            this.panel74.SuspendLayout();
            this.groupBox24.SuspendLayout();
            this.groupBox25.SuspendLayout();
            this.groupBox26.SuspendLayout();
            this.panel97.SuspendLayout();
            this.panel73.SuspendLayout();
            this.panel67.SuspendLayout();
            this.panel61.SuspendLayout();
            this.panel55.SuspendLayout();
            this.groupBox27.SuspendLayout();
            this.panel96.SuspendLayout();
            this.panel72.SuspendLayout();
            this.panel66.SuspendLayout();
            this.panel60.SuspendLayout();
            this.panel54.SuspendLayout();
            this.groupBox28.SuspendLayout();
            this.groupBox29.SuspendLayout();
            this.panel95.SuspendLayout();
            this.panel71.SuspendLayout();
            this.panel65.SuspendLayout();
            this.panel59.SuspendLayout();
            this.panel53.SuspendLayout();
            this.groupBox30.SuspendLayout();
            this.panel94.SuspendLayout();
            this.panel70.SuspendLayout();
            this.panel64.SuspendLayout();
            this.panel58.SuspendLayout();
            this.panel52.SuspendLayout();
            this.groupBox31.SuspendLayout();
            this.groupBox32.SuspendLayout();
            this.groupBox33.SuspendLayout();
            this.panel93.SuspendLayout();
            this.panel69.SuspendLayout();
            this.panel63.SuspendLayout();
            this.panel57.SuspendLayout();
            this.panel51.SuspendLayout();
            this.groupBox34.SuspendLayout();
            this.panel92.SuspendLayout();
            this.panel68.SuspendLayout();
            this.panel62.SuspendLayout();
            this.panel56.SuspendLayout();
            this.panel50.SuspendLayout();
            this.groupBox13.SuspendLayout();
            this.groupBox14.SuspendLayout();
            this.groupBox15.SuspendLayout();
            this.panel91.SuspendLayout();
            this.panel49.SuspendLayout();
            this.panel43.SuspendLayout();
            this.panel37.SuspendLayout();
            this.panel31.SuspendLayout();
            this.groupBox16.SuspendLayout();
            this.panel90.SuspendLayout();
            this.panel48.SuspendLayout();
            this.panel42.SuspendLayout();
            this.panel36.SuspendLayout();
            this.panel30.SuspendLayout();
            this.groupBox17.SuspendLayout();
            this.groupBox18.SuspendLayout();
            this.panel89.SuspendLayout();
            this.panel47.SuspendLayout();
            this.panel41.SuspendLayout();
            this.panel35.SuspendLayout();
            this.panel29.SuspendLayout();
            this.groupBox19.SuspendLayout();
            this.panel88.SuspendLayout();
            this.panel46.SuspendLayout();
            this.panel40.SuspendLayout();
            this.panel34.SuspendLayout();
            this.panel27.SuspendLayout();
            this.groupBox20.SuspendLayout();
            this.groupBox21.SuspendLayout();
            this.groupBox22.SuspendLayout();
            this.panel87.SuspendLayout();
            this.panel45.SuspendLayout();
            this.panel39.SuspendLayout();
            this.panel33.SuspendLayout();
            this.panel26.SuspendLayout();
            this.groupBox23.SuspendLayout();
            this.panel86.SuspendLayout();
            this.panel44.SuspendLayout();
            this.panel38.SuspendLayout();
            this.panel32.SuspendLayout();
            this.panel25.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox10.SuspendLayout();
            this.groupBox11.SuspendLayout();
            this.panel85.SuspendLayout();
            this.panel24.SuspendLayout();
            this.panel18.SuspendLayout();
            this.panel7.SuspendLayout();
            this.panel13.SuspendLayout();
            this.groupBox12.SuspendLayout();
            this.panel84.SuspendLayout();
            this.panel23.SuspendLayout();
            this.panel28.SuspendLayout();
            this.panel6.SuspendLayout();
            this.panel12.SuspendLayout();
            this.groupBox7.SuspendLayout();
            this.groupBox9.SuspendLayout();
            this.panel83.SuspendLayout();
            this.panel22.SuspendLayout();
            this.panel5.SuspendLayout();
            this.panel17.SuspendLayout();
            this.panel11.SuspendLayout();
            this.groupBox8.SuspendLayout();
            this.panel82.SuspendLayout();
            this.panel21.SuspendLayout();
            this.panel4.SuspendLayout();
            this.panel16.SuspendLayout();
            this.panel10.SuspendLayout();
            this.groupBox6.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.groupBox5.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.panel81.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.AutoScroll = true;
            this.panel1.Controls.Add(this.groupBox35);
            this.panel1.Controls.Add(this.groupBox24);
            this.panel1.Controls.Add(this.groupBox13);
            this.panel1.Controls.Add(this.groupBox2);
            this.panel1.Controls.Add(this.groupBox1);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1835, 942);
            this.panel1.TabIndex = 0;
            // 
            // groupBox35
            // 
            this.groupBox35.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.groupBox35.Controls.Add(this.panel79);
            this.groupBox35.Controls.Add(this.panel78);
            this.groupBox35.Controls.Add(this.panel77);
            this.groupBox35.Controls.Add(this.panel76);
            this.groupBox35.Controls.Add(this.panel75);
            this.groupBox35.Controls.Add(this.panel74);
            this.groupBox35.Controls.Add(this.label4);
            this.groupBox35.Location = new System.Drawing.Point(14, 1176);
            this.groupBox35.Name = "groupBox35";
            this.groupBox35.Size = new System.Drawing.Size(2055, 61);
            this.groupBox35.TabIndex = 15;
            this.groupBox35.TabStop = false;
            this.groupBox35.Text = "Average";
            // 
            // panel79
            // 
            this.panel79.Controls.Add(this.btnDaySumm16);
            this.panel79.Controls.Add(this.btnDaySumm17);
            this.panel79.Controls.Add(this.btnDaySumm18);
            this.panel79.Location = new System.Drawing.Point(1748, 13);
            this.panel79.Name = "panel79";
            this.panel79.Size = new System.Drawing.Size(289, 40);
            this.panel79.TabIndex = 26;
            // 
            // btnDaySumm16
            // 
            this.btnDaySumm16.BackColor = System.Drawing.SystemColors.Highlight;
            this.btnDaySumm16.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnDaySumm16.Font = new System.Drawing.Font("MS Reference Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDaySumm16.Location = new System.Drawing.Point(4, 3);
            this.btnDaySumm16.Name = "btnDaySumm16";
            this.btnDaySumm16.Size = new System.Drawing.Size(89, 34);
            this.btnDaySumm16.TabIndex = 2;
            this.btnDaySumm16.Text = "button233";
            this.btnDaySumm16.UseVisualStyleBackColor = false;
            // 
            // btnDaySumm17
            // 
            this.btnDaySumm17.BackColor = System.Drawing.SystemColors.Highlight;
            this.btnDaySumm17.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnDaySumm17.Font = new System.Drawing.Font("MS Reference Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDaySumm17.Location = new System.Drawing.Point(99, 3);
            this.btnDaySumm17.Name = "btnDaySumm17";
            this.btnDaySumm17.Size = new System.Drawing.Size(89, 34);
            this.btnDaySumm17.TabIndex = 1;
            this.btnDaySumm17.Text = "button234";
            this.btnDaySumm17.UseVisualStyleBackColor = false;
            // 
            // btnDaySumm18
            // 
            this.btnDaySumm18.BackColor = System.Drawing.SystemColors.Highlight;
            this.btnDaySumm18.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnDaySumm18.Font = new System.Drawing.Font("MS Reference Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDaySumm18.Location = new System.Drawing.Point(192, 3);
            this.btnDaySumm18.Name = "btnDaySumm18";
            this.btnDaySumm18.Size = new System.Drawing.Size(89, 34);
            this.btnDaySumm18.TabIndex = 0;
            this.btnDaySumm18.Text = "button235";
            this.btnDaySumm18.UseVisualStyleBackColor = false;
            // 
            // panel78
            // 
            this.panel78.Controls.Add(this.btnDaySumm13);
            this.panel78.Controls.Add(this.btnDaySumm14);
            this.panel78.Controls.Add(this.btnDaySumm15);
            this.panel78.Location = new System.Drawing.Point(1421, 13);
            this.panel78.Name = "panel78";
            this.panel78.Size = new System.Drawing.Size(289, 40);
            this.panel78.TabIndex = 25;
            // 
            // btnDaySumm13
            // 
            this.btnDaySumm13.BackColor = System.Drawing.SystemColors.Highlight;
            this.btnDaySumm13.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnDaySumm13.Font = new System.Drawing.Font("MS Reference Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDaySumm13.Location = new System.Drawing.Point(4, 3);
            this.btnDaySumm13.Name = "btnDaySumm13";
            this.btnDaySumm13.Size = new System.Drawing.Size(89, 34);
            this.btnDaySumm13.TabIndex = 2;
            this.btnDaySumm13.Text = "button230";
            this.btnDaySumm13.UseVisualStyleBackColor = false;
            // 
            // btnDaySumm14
            // 
            this.btnDaySumm14.BackColor = System.Drawing.SystemColors.Highlight;
            this.btnDaySumm14.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnDaySumm14.Font = new System.Drawing.Font("MS Reference Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDaySumm14.Location = new System.Drawing.Point(99, 3);
            this.btnDaySumm14.Name = "btnDaySumm14";
            this.btnDaySumm14.Size = new System.Drawing.Size(89, 34);
            this.btnDaySumm14.TabIndex = 1;
            this.btnDaySumm14.Text = "button231";
            this.btnDaySumm14.UseVisualStyleBackColor = false;
            // 
            // btnDaySumm15
            // 
            this.btnDaySumm15.BackColor = System.Drawing.SystemColors.Highlight;
            this.btnDaySumm15.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnDaySumm15.Font = new System.Drawing.Font("MS Reference Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDaySumm15.Location = new System.Drawing.Point(192, 3);
            this.btnDaySumm15.Name = "btnDaySumm15";
            this.btnDaySumm15.Size = new System.Drawing.Size(89, 34);
            this.btnDaySumm15.TabIndex = 0;
            this.btnDaySumm15.Text = "button232";
            this.btnDaySumm15.UseVisualStyleBackColor = false;
            // 
            // panel77
            // 
            this.panel77.Controls.Add(this.btnDaySumm10);
            this.panel77.Controls.Add(this.btnDaySumm11);
            this.panel77.Controls.Add(this.btnDaySumm12);
            this.panel77.Location = new System.Drawing.Point(1096, 13);
            this.panel77.Name = "panel77";
            this.panel77.Size = new System.Drawing.Size(289, 40);
            this.panel77.TabIndex = 24;
            // 
            // btnDaySumm10
            // 
            this.btnDaySumm10.BackColor = System.Drawing.SystemColors.Highlight;
            this.btnDaySumm10.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnDaySumm10.Font = new System.Drawing.Font("MS Reference Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDaySumm10.Location = new System.Drawing.Point(4, 3);
            this.btnDaySumm10.Name = "btnDaySumm10";
            this.btnDaySumm10.Size = new System.Drawing.Size(89, 34);
            this.btnDaySumm10.TabIndex = 2;
            this.btnDaySumm10.Text = "button227";
            this.btnDaySumm10.UseVisualStyleBackColor = false;
            // 
            // btnDaySumm11
            // 
            this.btnDaySumm11.BackColor = System.Drawing.SystemColors.Highlight;
            this.btnDaySumm11.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnDaySumm11.Font = new System.Drawing.Font("MS Reference Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDaySumm11.Location = new System.Drawing.Point(99, 3);
            this.btnDaySumm11.Name = "btnDaySumm11";
            this.btnDaySumm11.Size = new System.Drawing.Size(89, 34);
            this.btnDaySumm11.TabIndex = 1;
            this.btnDaySumm11.Text = "button228";
            this.btnDaySumm11.UseVisualStyleBackColor = false;
            // 
            // btnDaySumm12
            // 
            this.btnDaySumm12.BackColor = System.Drawing.SystemColors.Highlight;
            this.btnDaySumm12.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnDaySumm12.Font = new System.Drawing.Font("MS Reference Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDaySumm12.Location = new System.Drawing.Point(192, 3);
            this.btnDaySumm12.Name = "btnDaySumm12";
            this.btnDaySumm12.Size = new System.Drawing.Size(89, 34);
            this.btnDaySumm12.TabIndex = 0;
            this.btnDaySumm12.Text = "button229";
            this.btnDaySumm12.UseVisualStyleBackColor = false;
            // 
            // panel76
            // 
            this.panel76.Controls.Add(this.btnDaySumm7);
            this.panel76.Controls.Add(this.btnDaySumm8);
            this.panel76.Controls.Add(this.btnDaySumm9);
            this.panel76.Location = new System.Drawing.Point(787, 13);
            this.panel76.Name = "panel76";
            this.panel76.Size = new System.Drawing.Size(289, 40);
            this.panel76.TabIndex = 23;
            // 
            // btnDaySumm7
            // 
            this.btnDaySumm7.BackColor = System.Drawing.SystemColors.Highlight;
            this.btnDaySumm7.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnDaySumm7.Font = new System.Drawing.Font("MS Reference Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDaySumm7.Location = new System.Drawing.Point(4, 3);
            this.btnDaySumm7.Name = "btnDaySumm7";
            this.btnDaySumm7.Size = new System.Drawing.Size(89, 34);
            this.btnDaySumm7.TabIndex = 2;
            this.btnDaySumm7.Text = "button224";
            this.btnDaySumm7.UseVisualStyleBackColor = false;
            // 
            // btnDaySumm8
            // 
            this.btnDaySumm8.BackColor = System.Drawing.SystemColors.Highlight;
            this.btnDaySumm8.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnDaySumm8.Font = new System.Drawing.Font("MS Reference Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDaySumm8.Location = new System.Drawing.Point(99, 3);
            this.btnDaySumm8.Name = "btnDaySumm8";
            this.btnDaySumm8.Size = new System.Drawing.Size(89, 34);
            this.btnDaySumm8.TabIndex = 1;
            this.btnDaySumm8.Text = "button225";
            this.btnDaySumm8.UseVisualStyleBackColor = false;
            // 
            // btnDaySumm9
            // 
            this.btnDaySumm9.BackColor = System.Drawing.SystemColors.Highlight;
            this.btnDaySumm9.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnDaySumm9.Font = new System.Drawing.Font("MS Reference Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDaySumm9.Location = new System.Drawing.Point(192, 3);
            this.btnDaySumm9.Name = "btnDaySumm9";
            this.btnDaySumm9.Size = new System.Drawing.Size(89, 34);
            this.btnDaySumm9.TabIndex = 0;
            this.btnDaySumm9.Text = "button226";
            this.btnDaySumm9.UseVisualStyleBackColor = false;
            // 
            // panel75
            // 
            this.panel75.Controls.Add(this.btnDaySumm4);
            this.panel75.Controls.Add(this.btnDaySumm5);
            this.panel75.Controls.Add(this.btnDaySumm6);
            this.panel75.Location = new System.Drawing.Point(444, 13);
            this.panel75.Name = "panel75";
            this.panel75.Size = new System.Drawing.Size(289, 40);
            this.panel75.TabIndex = 22;
            // 
            // btnDaySumm4
            // 
            this.btnDaySumm4.BackColor = System.Drawing.SystemColors.Highlight;
            this.btnDaySumm4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnDaySumm4.Font = new System.Drawing.Font("MS Reference Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDaySumm4.Location = new System.Drawing.Point(4, 3);
            this.btnDaySumm4.Name = "btnDaySumm4";
            this.btnDaySumm4.Size = new System.Drawing.Size(89, 34);
            this.btnDaySumm4.TabIndex = 2;
            this.btnDaySumm4.Text = "button221";
            this.btnDaySumm4.UseVisualStyleBackColor = false;
            // 
            // btnDaySumm5
            // 
            this.btnDaySumm5.BackColor = System.Drawing.SystemColors.Highlight;
            this.btnDaySumm5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnDaySumm5.Font = new System.Drawing.Font("MS Reference Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDaySumm5.Location = new System.Drawing.Point(99, 3);
            this.btnDaySumm5.Name = "btnDaySumm5";
            this.btnDaySumm5.Size = new System.Drawing.Size(89, 34);
            this.btnDaySumm5.TabIndex = 1;
            this.btnDaySumm5.Text = "button222";
            this.btnDaySumm5.UseVisualStyleBackColor = false;
            // 
            // btnDaySumm6
            // 
            this.btnDaySumm6.BackColor = System.Drawing.SystemColors.Highlight;
            this.btnDaySumm6.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnDaySumm6.Font = new System.Drawing.Font("MS Reference Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDaySumm6.Location = new System.Drawing.Point(192, 3);
            this.btnDaySumm6.Name = "btnDaySumm6";
            this.btnDaySumm6.Size = new System.Drawing.Size(89, 34);
            this.btnDaySumm6.TabIndex = 0;
            this.btnDaySumm6.Text = "button223";
            this.btnDaySumm6.UseVisualStyleBackColor = false;
            // 
            // panel74
            // 
            this.panel74.Controls.Add(this.btnDaySumm1);
            this.panel74.Controls.Add(this.btnDaySumm2);
            this.panel74.Controls.Add(this.btnDaySumm3);
            this.panel74.Location = new System.Drawing.Point(132, 13);
            this.panel74.Name = "panel74";
            this.panel74.Size = new System.Drawing.Size(289, 40);
            this.panel74.TabIndex = 21;
            // 
            // btnDaySumm1
            // 
            this.btnDaySumm1.BackColor = System.Drawing.SystemColors.Highlight;
            this.btnDaySumm1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnDaySumm1.Font = new System.Drawing.Font("MS Reference Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDaySumm1.Location = new System.Drawing.Point(4, 3);
            this.btnDaySumm1.Name = "btnDaySumm1";
            this.btnDaySumm1.Size = new System.Drawing.Size(89, 34);
            this.btnDaySumm1.TabIndex = 2;
            this.btnDaySumm1.Text = "button217";
            this.btnDaySumm1.UseVisualStyleBackColor = false;
            // 
            // btnDaySumm2
            // 
            this.btnDaySumm2.BackColor = System.Drawing.SystemColors.Highlight;
            this.btnDaySumm2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnDaySumm2.Font = new System.Drawing.Font("MS Reference Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDaySumm2.Location = new System.Drawing.Point(99, 3);
            this.btnDaySumm2.Name = "btnDaySumm2";
            this.btnDaySumm2.Size = new System.Drawing.Size(89, 34);
            this.btnDaySumm2.TabIndex = 1;
            this.btnDaySumm2.Text = "button219";
            this.btnDaySumm2.UseVisualStyleBackColor = false;
            // 
            // btnDaySumm3
            // 
            this.btnDaySumm3.BackColor = System.Drawing.SystemColors.Highlight;
            this.btnDaySumm3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnDaySumm3.Font = new System.Drawing.Font("MS Reference Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDaySumm3.Location = new System.Drawing.Point(192, 3);
            this.btnDaySumm3.Name = "btnDaySumm3";
            this.btnDaySumm3.Size = new System.Drawing.Size(89, 34);
            this.btnDaySumm3.TabIndex = 0;
            this.btnDaySumm3.Text = "button220";
            this.btnDaySumm3.UseVisualStyleBackColor = false;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(16, 27);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(90, 17);
            this.label4.TabIndex = 0;
            this.label4.Text = "Day Average";
            // 
            // groupBox24
            // 
            this.groupBox24.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.groupBox24.Controls.Add(this.groupBox25);
            this.groupBox24.Controls.Add(this.groupBox28);
            this.groupBox24.Controls.Add(this.groupBox31);
            this.groupBox24.Controls.Add(this.groupBox32);
            this.groupBox24.Location = new System.Drawing.Point(16, 819);
            this.groupBox24.Name = "groupBox24";
            this.groupBox24.Size = new System.Drawing.Size(2059, 364);
            this.groupBox24.TabIndex = 3;
            this.groupBox24.TabStop = false;
            this.groupBox24.Text = "Shift-C";
            // 
            // groupBox25
            // 
            this.groupBox25.Controls.Add(this.groupBox26);
            this.groupBox25.Controls.Add(this.groupBox27);
            this.groupBox25.Controls.Add(this.btnLastJuiceShiftC);
            this.groupBox25.Location = new System.Drawing.Point(1407, 21);
            this.groupBox25.Name = "groupBox25";
            this.groupBox25.Size = new System.Drawing.Size(636, 330);
            this.groupBox25.TabIndex = 14;
            this.groupBox25.TabStop = false;
            // 
            // groupBox26
            // 
            this.groupBox26.Controls.Add(this.panel97);
            this.groupBox26.Controls.Add(this.panel73);
            this.groupBox26.Controls.Add(this.panel67);
            this.groupBox26.Controls.Add(this.panel61);
            this.groupBox26.Controls.Add(this.panel55);
            this.groupBox26.Controls.Add(this.btnLjOmPurityShiftC);
            this.groupBox26.Controls.Add(this.btnLjOmPolShiftC);
            this.groupBox26.Controls.Add(this.btnLjOmBrixShiftC);
            this.groupBox26.Controls.Add(this.btnLjOmShiftC);
            this.groupBox26.Location = new System.Drawing.Point(325, 32);
            this.groupBox26.Name = "groupBox26";
            this.groupBox26.Size = new System.Drawing.Size(301, 279);
            this.groupBox26.TabIndex = 3;
            this.groupBox26.TabStop = false;
            // 
            // panel97
            // 
            this.panel97.Controls.Add(this.button269);
            this.panel97.Controls.Add(this.button270);
            this.panel97.Controls.Add(this.button271);
            this.panel97.Location = new System.Drawing.Point(10, 238);
            this.panel97.Name = "panel97";
            this.panel97.Size = new System.Drawing.Size(289, 32);
            this.panel97.TabIndex = 22;
            // 
            // button269
            // 
            this.button269.BackColor = System.Drawing.SystemColors.HotTrack;
            this.button269.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button269.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button269.Location = new System.Drawing.Point(4, 3);
            this.button269.Name = "button269";
            this.button269.Size = new System.Drawing.Size(89, 26);
            this.button269.TabIndex = 2;
            this.button269.Text = "button269";
            this.button269.UseVisualStyleBackColor = false;
            // 
            // button270
            // 
            this.button270.BackColor = System.Drawing.SystemColors.HotTrack;
            this.button270.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button270.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button270.Location = new System.Drawing.Point(99, 3);
            this.button270.Name = "button270";
            this.button270.Size = new System.Drawing.Size(89, 26);
            this.button270.TabIndex = 1;
            this.button270.Text = "button270";
            this.button270.UseVisualStyleBackColor = false;
            // 
            // button271
            // 
            this.button271.BackColor = System.Drawing.SystemColors.HotTrack;
            this.button271.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button271.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button271.Location = new System.Drawing.Point(192, 3);
            this.button271.Name = "button271";
            this.button271.Size = new System.Drawing.Size(89, 26);
            this.button271.TabIndex = 0;
            this.button271.Text = "button271";
            this.button271.UseVisualStyleBackColor = false;
            // 
            // panel73
            // 
            this.panel73.Controls.Add(this.button214);
            this.panel73.Controls.Add(this.button215);
            this.panel73.Controls.Add(this.button216);
            this.panel73.Location = new System.Drawing.Point(6, 195);
            this.panel73.Name = "panel73";
            this.panel73.Size = new System.Drawing.Size(289, 32);
            this.panel73.TabIndex = 21;
            // 
            // button214
            // 
            this.button214.BackColor = System.Drawing.Color.White;
            this.button214.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button214.Location = new System.Drawing.Point(4, 3);
            this.button214.Name = "button214";
            this.button214.Size = new System.Drawing.Size(89, 26);
            this.button214.TabIndex = 2;
            this.button214.Text = "button214";
            this.button214.UseVisualStyleBackColor = false;
            // 
            // button215
            // 
            this.button215.BackColor = System.Drawing.Color.White;
            this.button215.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button215.Location = new System.Drawing.Point(99, 3);
            this.button215.Name = "button215";
            this.button215.Size = new System.Drawing.Size(89, 26);
            this.button215.TabIndex = 1;
            this.button215.Text = "button215";
            this.button215.UseVisualStyleBackColor = false;
            // 
            // button216
            // 
            this.button216.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.button216.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button216.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button216.Location = new System.Drawing.Point(192, 3);
            this.button216.Name = "button216";
            this.button216.Size = new System.Drawing.Size(89, 26);
            this.button216.TabIndex = 0;
            this.button216.Text = "button216";
            this.button216.UseVisualStyleBackColor = false;
            // 
            // panel67
            // 
            this.panel67.Controls.Add(this.button196);
            this.panel67.Controls.Add(this.button197);
            this.panel67.Controls.Add(this.button198);
            this.panel67.Location = new System.Drawing.Point(10, 151);
            this.panel67.Name = "panel67";
            this.panel67.Size = new System.Drawing.Size(289, 32);
            this.panel67.TabIndex = 20;
            // 
            // button196
            // 
            this.button196.BackColor = System.Drawing.Color.White;
            this.button196.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button196.Location = new System.Drawing.Point(4, 3);
            this.button196.Name = "button196";
            this.button196.Size = new System.Drawing.Size(89, 26);
            this.button196.TabIndex = 2;
            this.button196.Text = "button196";
            this.button196.UseVisualStyleBackColor = false;
            // 
            // button197
            // 
            this.button197.BackColor = System.Drawing.Color.White;
            this.button197.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button197.Location = new System.Drawing.Point(99, 3);
            this.button197.Name = "button197";
            this.button197.Size = new System.Drawing.Size(89, 26);
            this.button197.TabIndex = 1;
            this.button197.Text = "button197";
            this.button197.UseVisualStyleBackColor = false;
            // 
            // button198
            // 
            this.button198.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.button198.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button198.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button198.Location = new System.Drawing.Point(192, 3);
            this.button198.Name = "button198";
            this.button198.Size = new System.Drawing.Size(89, 26);
            this.button198.TabIndex = 0;
            this.button198.Text = "button198";
            this.button198.UseVisualStyleBackColor = false;
            // 
            // panel61
            // 
            this.panel61.Controls.Add(this.button178);
            this.panel61.Controls.Add(this.button179);
            this.panel61.Controls.Add(this.button180);
            this.panel61.Location = new System.Drawing.Point(10, 119);
            this.panel61.Name = "panel61";
            this.panel61.Size = new System.Drawing.Size(289, 32);
            this.panel61.TabIndex = 18;
            // 
            // button178
            // 
            this.button178.BackColor = System.Drawing.Color.White;
            this.button178.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button178.Location = new System.Drawing.Point(4, 3);
            this.button178.Name = "button178";
            this.button178.Size = new System.Drawing.Size(89, 26);
            this.button178.TabIndex = 2;
            this.button178.Text = "button178";
            this.button178.UseVisualStyleBackColor = false;
            // 
            // button179
            // 
            this.button179.BackColor = System.Drawing.Color.White;
            this.button179.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button179.Location = new System.Drawing.Point(99, 3);
            this.button179.Name = "button179";
            this.button179.Size = new System.Drawing.Size(89, 26);
            this.button179.TabIndex = 1;
            this.button179.Text = "button179";
            this.button179.UseVisualStyleBackColor = false;
            // 
            // button180
            // 
            this.button180.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.button180.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button180.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button180.Location = new System.Drawing.Point(192, 3);
            this.button180.Name = "button180";
            this.button180.Size = new System.Drawing.Size(89, 26);
            this.button180.TabIndex = 0;
            this.button180.Text = "button180";
            this.button180.UseVisualStyleBackColor = false;
            // 
            // panel55
            // 
            this.panel55.Controls.Add(this.button160);
            this.panel55.Controls.Add(this.button161);
            this.panel55.Controls.Add(this.button162);
            this.panel55.Location = new System.Drawing.Point(6, 81);
            this.panel55.Name = "panel55";
            this.panel55.Size = new System.Drawing.Size(289, 32);
            this.panel55.TabIndex = 17;
            // 
            // button160
            // 
            this.button160.BackColor = System.Drawing.Color.White;
            this.button160.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button160.Location = new System.Drawing.Point(4, 3);
            this.button160.Name = "button160";
            this.button160.Size = new System.Drawing.Size(89, 26);
            this.button160.TabIndex = 2;
            this.button160.Text = "button160";
            this.button160.UseVisualStyleBackColor = false;
            // 
            // button161
            // 
            this.button161.BackColor = System.Drawing.Color.White;
            this.button161.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button161.Location = new System.Drawing.Point(99, 3);
            this.button161.Name = "button161";
            this.button161.Size = new System.Drawing.Size(89, 26);
            this.button161.TabIndex = 1;
            this.button161.Text = "button161";
            this.button161.UseVisualStyleBackColor = false;
            // 
            // button162
            // 
            this.button162.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.button162.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button162.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button162.Location = new System.Drawing.Point(192, 3);
            this.button162.Name = "button162";
            this.button162.Size = new System.Drawing.Size(89, 26);
            this.button162.TabIndex = 0;
            this.button162.Text = "button162";
            this.button162.UseVisualStyleBackColor = false;
            // 
            // btnLjOmPurityShiftC
            // 
            this.btnLjOmPurityShiftC.Location = new System.Drawing.Point(198, 46);
            this.btnLjOmPurityShiftC.Name = "btnLjOmPurityShiftC";
            this.btnLjOmPurityShiftC.Size = new System.Drawing.Size(89, 26);
            this.btnLjOmPurityShiftC.TabIndex = 6;
            this.btnLjOmPurityShiftC.Text = "Purity";
            this.btnLjOmPurityShiftC.UseVisualStyleBackColor = true;
            // 
            // btnLjOmPolShiftC
            // 
            this.btnLjOmPolShiftC.Location = new System.Drawing.Point(101, 46);
            this.btnLjOmPolShiftC.Name = "btnLjOmPolShiftC";
            this.btnLjOmPolShiftC.Size = new System.Drawing.Size(89, 26);
            this.btnLjOmPolShiftC.TabIndex = 5;
            this.btnLjOmPolShiftC.Text = "Pol";
            this.btnLjOmPolShiftC.UseVisualStyleBackColor = true;
            // 
            // btnLjOmBrixShiftC
            // 
            this.btnLjOmBrixShiftC.Location = new System.Drawing.Point(6, 46);
            this.btnLjOmBrixShiftC.Name = "btnLjOmBrixShiftC";
            this.btnLjOmBrixShiftC.Size = new System.Drawing.Size(89, 26);
            this.btnLjOmBrixShiftC.TabIndex = 4;
            this.btnLjOmBrixShiftC.Text = "Brix";
            this.btnLjOmBrixShiftC.UseVisualStyleBackColor = true;
            // 
            // btnLjOmShiftC
            // 
            this.btnLjOmShiftC.Location = new System.Drawing.Point(6, 10);
            this.btnLjOmShiftC.Name = "btnLjOmShiftC";
            this.btnLjOmShiftC.Size = new System.Drawing.Size(281, 34);
            this.btnLjOmShiftC.TabIndex = 1;
            this.btnLjOmShiftC.Text = "Old Mill";
            this.btnLjOmShiftC.UseVisualStyleBackColor = true;
            // 
            // groupBox27
            // 
            this.groupBox27.Controls.Add(this.panel96);
            this.groupBox27.Controls.Add(this.panel72);
            this.groupBox27.Controls.Add(this.panel66);
            this.groupBox27.Controls.Add(this.panel60);
            this.groupBox27.Controls.Add(this.panel54);
            this.groupBox27.Controls.Add(this.btnLjNmPurityShiftC);
            this.groupBox27.Controls.Add(this.btnLjNmPolShiftC);
            this.groupBox27.Controls.Add(this.btnLjNmBrixShiftC);
            this.groupBox27.Controls.Add(this.btnLjNmShiftC);
            this.groupBox27.Location = new System.Drawing.Point(6, 32);
            this.groupBox27.Name = "groupBox27";
            this.groupBox27.Size = new System.Drawing.Size(301, 279);
            this.groupBox27.TabIndex = 2;
            this.groupBox27.TabStop = false;
            // 
            // panel96
            // 
            this.panel96.Controls.Add(this.button266);
            this.panel96.Controls.Add(this.button267);
            this.panel96.Controls.Add(this.button268);
            this.panel96.Location = new System.Drawing.Point(10, 230);
            this.panel96.Name = "panel96";
            this.panel96.Size = new System.Drawing.Size(289, 32);
            this.panel96.TabIndex = 22;
            // 
            // button266
            // 
            this.button266.BackColor = System.Drawing.SystemColors.HotTrack;
            this.button266.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button266.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button266.Location = new System.Drawing.Point(4, 3);
            this.button266.Name = "button266";
            this.button266.Size = new System.Drawing.Size(89, 26);
            this.button266.TabIndex = 2;
            this.button266.Text = "button266";
            this.button266.UseVisualStyleBackColor = false;
            // 
            // button267
            // 
            this.button267.BackColor = System.Drawing.SystemColors.HotTrack;
            this.button267.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button267.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button267.Location = new System.Drawing.Point(99, 3);
            this.button267.Name = "button267";
            this.button267.Size = new System.Drawing.Size(89, 26);
            this.button267.TabIndex = 1;
            this.button267.Text = "button267";
            this.button267.UseVisualStyleBackColor = false;
            // 
            // button268
            // 
            this.button268.BackColor = System.Drawing.SystemColors.HotTrack;
            this.button268.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button268.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button268.Location = new System.Drawing.Point(192, 3);
            this.button268.Name = "button268";
            this.button268.Size = new System.Drawing.Size(89, 26);
            this.button268.TabIndex = 0;
            this.button268.Text = "button268";
            this.button268.UseVisualStyleBackColor = false;
            // 
            // panel72
            // 
            this.panel72.Controls.Add(this.button211);
            this.panel72.Controls.Add(this.button212);
            this.panel72.Controls.Add(this.button213);
            this.panel72.Location = new System.Drawing.Point(10, 192);
            this.panel72.Name = "panel72";
            this.panel72.Size = new System.Drawing.Size(289, 32);
            this.panel72.TabIndex = 21;
            // 
            // button211
            // 
            this.button211.BackColor = System.Drawing.Color.White;
            this.button211.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button211.Location = new System.Drawing.Point(4, 3);
            this.button211.Name = "button211";
            this.button211.Size = new System.Drawing.Size(89, 26);
            this.button211.TabIndex = 2;
            this.button211.Text = "button211";
            this.button211.UseVisualStyleBackColor = false;
            // 
            // button212
            // 
            this.button212.BackColor = System.Drawing.Color.White;
            this.button212.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button212.Location = new System.Drawing.Point(99, 3);
            this.button212.Name = "button212";
            this.button212.Size = new System.Drawing.Size(89, 26);
            this.button212.TabIndex = 1;
            this.button212.Text = "button212";
            this.button212.UseVisualStyleBackColor = false;
            // 
            // button213
            // 
            this.button213.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.button213.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button213.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button213.Location = new System.Drawing.Point(192, 3);
            this.button213.Name = "button213";
            this.button213.Size = new System.Drawing.Size(89, 26);
            this.button213.TabIndex = 0;
            this.button213.Text = "button213";
            this.button213.UseVisualStyleBackColor = false;
            // 
            // panel66
            // 
            this.panel66.Controls.Add(this.button193);
            this.panel66.Controls.Add(this.button194);
            this.panel66.Controls.Add(this.button195);
            this.panel66.Location = new System.Drawing.Point(6, 154);
            this.panel66.Name = "panel66";
            this.panel66.Size = new System.Drawing.Size(289, 32);
            this.panel66.TabIndex = 20;
            // 
            // button193
            // 
            this.button193.BackColor = System.Drawing.Color.White;
            this.button193.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button193.Location = new System.Drawing.Point(4, 3);
            this.button193.Name = "button193";
            this.button193.Size = new System.Drawing.Size(89, 26);
            this.button193.TabIndex = 2;
            this.button193.Text = "button193";
            this.button193.UseVisualStyleBackColor = false;
            // 
            // button194
            // 
            this.button194.BackColor = System.Drawing.Color.White;
            this.button194.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button194.Location = new System.Drawing.Point(99, 3);
            this.button194.Name = "button194";
            this.button194.Size = new System.Drawing.Size(89, 26);
            this.button194.TabIndex = 1;
            this.button194.Text = "button194";
            this.button194.UseVisualStyleBackColor = false;
            // 
            // button195
            // 
            this.button195.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.button195.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button195.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button195.Location = new System.Drawing.Point(192, 3);
            this.button195.Name = "button195";
            this.button195.Size = new System.Drawing.Size(89, 26);
            this.button195.TabIndex = 0;
            this.button195.Text = "button195";
            this.button195.UseVisualStyleBackColor = false;
            // 
            // panel60
            // 
            this.panel60.Controls.Add(this.button175);
            this.panel60.Controls.Add(this.button176);
            this.panel60.Controls.Add(this.button177);
            this.panel60.Location = new System.Drawing.Point(6, 116);
            this.panel60.Name = "panel60";
            this.panel60.Size = new System.Drawing.Size(289, 32);
            this.panel60.TabIndex = 18;
            // 
            // button175
            // 
            this.button175.BackColor = System.Drawing.Color.White;
            this.button175.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button175.Location = new System.Drawing.Point(4, 3);
            this.button175.Name = "button175";
            this.button175.Size = new System.Drawing.Size(89, 26);
            this.button175.TabIndex = 2;
            this.button175.Text = "button175";
            this.button175.UseVisualStyleBackColor = false;
            // 
            // button176
            // 
            this.button176.BackColor = System.Drawing.Color.White;
            this.button176.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button176.Location = new System.Drawing.Point(99, 3);
            this.button176.Name = "button176";
            this.button176.Size = new System.Drawing.Size(89, 26);
            this.button176.TabIndex = 1;
            this.button176.Text = "button176";
            this.button176.UseVisualStyleBackColor = false;
            // 
            // button177
            // 
            this.button177.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.button177.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button177.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button177.Location = new System.Drawing.Point(192, 3);
            this.button177.Name = "button177";
            this.button177.Size = new System.Drawing.Size(89, 26);
            this.button177.TabIndex = 0;
            this.button177.Text = "button177";
            this.button177.UseVisualStyleBackColor = false;
            // 
            // panel54
            // 
            this.panel54.Controls.Add(this.button157);
            this.panel54.Controls.Add(this.button158);
            this.panel54.Controls.Add(this.button159);
            this.panel54.Location = new System.Drawing.Point(6, 78);
            this.panel54.Name = "panel54";
            this.panel54.Size = new System.Drawing.Size(289, 32);
            this.panel54.TabIndex = 17;
            // 
            // button157
            // 
            this.button157.BackColor = System.Drawing.Color.White;
            this.button157.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button157.Location = new System.Drawing.Point(4, 3);
            this.button157.Name = "button157";
            this.button157.Size = new System.Drawing.Size(89, 26);
            this.button157.TabIndex = 2;
            this.button157.Text = "button157";
            this.button157.UseVisualStyleBackColor = false;
            // 
            // button158
            // 
            this.button158.BackColor = System.Drawing.Color.White;
            this.button158.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button158.Location = new System.Drawing.Point(99, 3);
            this.button158.Name = "button158";
            this.button158.Size = new System.Drawing.Size(89, 26);
            this.button158.TabIndex = 1;
            this.button158.Text = "button158";
            this.button158.UseVisualStyleBackColor = false;
            // 
            // button159
            // 
            this.button159.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.button159.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button159.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button159.Location = new System.Drawing.Point(192, 3);
            this.button159.Name = "button159";
            this.button159.Size = new System.Drawing.Size(89, 26);
            this.button159.TabIndex = 0;
            this.button159.Text = "button159";
            this.button159.UseVisualStyleBackColor = false;
            // 
            // btnLjNmPurityShiftC
            // 
            this.btnLjNmPurityShiftC.Location = new System.Drawing.Point(198, 46);
            this.btnLjNmPurityShiftC.Name = "btnLjNmPurityShiftC";
            this.btnLjNmPurityShiftC.Size = new System.Drawing.Size(89, 26);
            this.btnLjNmPurityShiftC.TabIndex = 6;
            this.btnLjNmPurityShiftC.Text = "Purity";
            this.btnLjNmPurityShiftC.UseVisualStyleBackColor = true;
            // 
            // btnLjNmPolShiftC
            // 
            this.btnLjNmPolShiftC.Location = new System.Drawing.Point(101, 46);
            this.btnLjNmPolShiftC.Name = "btnLjNmPolShiftC";
            this.btnLjNmPolShiftC.Size = new System.Drawing.Size(89, 26);
            this.btnLjNmPolShiftC.TabIndex = 5;
            this.btnLjNmPolShiftC.Text = "Pol";
            this.btnLjNmPolShiftC.UseVisualStyleBackColor = true;
            // 
            // btnLjNmBrixShiftC
            // 
            this.btnLjNmBrixShiftC.Location = new System.Drawing.Point(6, 46);
            this.btnLjNmBrixShiftC.Name = "btnLjNmBrixShiftC";
            this.btnLjNmBrixShiftC.Size = new System.Drawing.Size(89, 26);
            this.btnLjNmBrixShiftC.TabIndex = 4;
            this.btnLjNmBrixShiftC.Text = "Brix";
            this.btnLjNmBrixShiftC.UseVisualStyleBackColor = true;
            // 
            // btnLjNmShiftC
            // 
            this.btnLjNmShiftC.Location = new System.Drawing.Point(6, 10);
            this.btnLjNmShiftC.Name = "btnLjNmShiftC";
            this.btnLjNmShiftC.Size = new System.Drawing.Size(281, 34);
            this.btnLjNmShiftC.TabIndex = 1;
            this.btnLjNmShiftC.Text = "New Mill";
            this.btnLjNmShiftC.UseVisualStyleBackColor = true;
            // 
            // btnLastJuiceShiftC
            // 
            this.btnLastJuiceShiftC.Location = new System.Drawing.Point(6, 10);
            this.btnLastJuiceShiftC.Name = "btnLastJuiceShiftC";
            this.btnLastJuiceShiftC.Size = new System.Drawing.Size(620, 23);
            this.btnLastJuiceShiftC.TabIndex = 1;
            this.btnLastJuiceShiftC.Text = "Last Juice";
            this.btnLastJuiceShiftC.UseVisualStyleBackColor = true;
            // 
            // groupBox28
            // 
            this.groupBox28.Controls.Add(this.groupBox29);
            this.groupBox28.Controls.Add(this.groupBox30);
            this.groupBox28.Controls.Add(this.btnMixedJuiceShiftC);
            this.groupBox28.Location = new System.Drawing.Point(765, 12);
            this.groupBox28.Name = "groupBox28";
            this.groupBox28.Size = new System.Drawing.Size(636, 320);
            this.groupBox28.TabIndex = 2;
            this.groupBox28.TabStop = false;
            // 
            // groupBox29
            // 
            this.groupBox29.Controls.Add(this.panel95);
            this.groupBox29.Controls.Add(this.panel71);
            this.groupBox29.Controls.Add(this.panel65);
            this.groupBox29.Controls.Add(this.panel59);
            this.groupBox29.Controls.Add(this.panel53);
            this.groupBox29.Controls.Add(this.btnMjOmPurityShiftC);
            this.groupBox29.Controls.Add(this.btnMjOmPolShiftC);
            this.groupBox29.Controls.Add(this.btnMjOmBrixShiftC);
            this.groupBox29.Controls.Add(this.btnMjOmShiftC);
            this.groupBox29.Location = new System.Drawing.Point(325, 32);
            this.groupBox29.Name = "groupBox29";
            this.groupBox29.Size = new System.Drawing.Size(301, 279);
            this.groupBox29.TabIndex = 3;
            this.groupBox29.TabStop = false;
            // 
            // panel95
            // 
            this.panel95.Controls.Add(this.button263);
            this.panel95.Controls.Add(this.button264);
            this.panel95.Controls.Add(this.button265);
            this.panel95.Location = new System.Drawing.Point(6, 230);
            this.panel95.Name = "panel95";
            this.panel95.Size = new System.Drawing.Size(289, 32);
            this.panel95.TabIndex = 21;
            // 
            // button263
            // 
            this.button263.BackColor = System.Drawing.SystemColors.HotTrack;
            this.button263.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button263.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button263.Location = new System.Drawing.Point(4, 3);
            this.button263.Name = "button263";
            this.button263.Size = new System.Drawing.Size(89, 26);
            this.button263.TabIndex = 2;
            this.button263.Text = "button263";
            this.button263.UseVisualStyleBackColor = false;
            // 
            // button264
            // 
            this.button264.BackColor = System.Drawing.SystemColors.HotTrack;
            this.button264.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button264.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button264.Location = new System.Drawing.Point(99, 3);
            this.button264.Name = "button264";
            this.button264.Size = new System.Drawing.Size(89, 26);
            this.button264.TabIndex = 1;
            this.button264.Text = "button264";
            this.button264.UseVisualStyleBackColor = false;
            // 
            // button265
            // 
            this.button265.BackColor = System.Drawing.SystemColors.HotTrack;
            this.button265.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button265.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button265.Location = new System.Drawing.Point(192, 3);
            this.button265.Name = "button265";
            this.button265.Size = new System.Drawing.Size(89, 26);
            this.button265.TabIndex = 0;
            this.button265.Text = "button265";
            this.button265.UseVisualStyleBackColor = false;
            // 
            // panel71
            // 
            this.panel71.Controls.Add(this.button208);
            this.panel71.Controls.Add(this.button209);
            this.panel71.Controls.Add(this.button210);
            this.panel71.Location = new System.Drawing.Point(6, 192);
            this.panel71.Name = "panel71";
            this.panel71.Size = new System.Drawing.Size(289, 32);
            this.panel71.TabIndex = 20;
            // 
            // button208
            // 
            this.button208.BackColor = System.Drawing.Color.White;
            this.button208.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button208.Location = new System.Drawing.Point(4, 3);
            this.button208.Name = "button208";
            this.button208.Size = new System.Drawing.Size(89, 26);
            this.button208.TabIndex = 2;
            this.button208.Text = "button208";
            this.button208.UseVisualStyleBackColor = false;
            // 
            // button209
            // 
            this.button209.BackColor = System.Drawing.Color.White;
            this.button209.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button209.Location = new System.Drawing.Point(99, 3);
            this.button209.Name = "button209";
            this.button209.Size = new System.Drawing.Size(89, 26);
            this.button209.TabIndex = 1;
            this.button209.Text = "button209";
            this.button209.UseVisualStyleBackColor = false;
            // 
            // button210
            // 
            this.button210.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.button210.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button210.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button210.Location = new System.Drawing.Point(192, 3);
            this.button210.Name = "button210";
            this.button210.Size = new System.Drawing.Size(89, 26);
            this.button210.TabIndex = 0;
            this.button210.Text = "button210";
            this.button210.UseVisualStyleBackColor = false;
            // 
            // panel65
            // 
            this.panel65.Controls.Add(this.button190);
            this.panel65.Controls.Add(this.button191);
            this.panel65.Controls.Add(this.button192);
            this.panel65.Location = new System.Drawing.Point(6, 157);
            this.panel65.Name = "panel65";
            this.panel65.Size = new System.Drawing.Size(289, 32);
            this.panel65.TabIndex = 19;
            // 
            // button190
            // 
            this.button190.BackColor = System.Drawing.Color.White;
            this.button190.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button190.Location = new System.Drawing.Point(4, 3);
            this.button190.Name = "button190";
            this.button190.Size = new System.Drawing.Size(89, 26);
            this.button190.TabIndex = 2;
            this.button190.Text = "button190";
            this.button190.UseVisualStyleBackColor = false;
            // 
            // button191
            // 
            this.button191.BackColor = System.Drawing.Color.White;
            this.button191.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button191.Location = new System.Drawing.Point(99, 3);
            this.button191.Name = "button191";
            this.button191.Size = new System.Drawing.Size(89, 26);
            this.button191.TabIndex = 1;
            this.button191.Text = "button191";
            this.button191.UseVisualStyleBackColor = false;
            // 
            // button192
            // 
            this.button192.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.button192.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button192.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button192.Location = new System.Drawing.Point(192, 3);
            this.button192.Name = "button192";
            this.button192.Size = new System.Drawing.Size(89, 26);
            this.button192.TabIndex = 0;
            this.button192.Text = "button192";
            this.button192.UseVisualStyleBackColor = false;
            // 
            // panel59
            // 
            this.panel59.Controls.Add(this.button172);
            this.panel59.Controls.Add(this.button173);
            this.panel59.Controls.Add(this.button174);
            this.panel59.Location = new System.Drawing.Point(6, 119);
            this.panel59.Name = "panel59";
            this.panel59.Size = new System.Drawing.Size(289, 32);
            this.panel59.TabIndex = 18;
            // 
            // button172
            // 
            this.button172.BackColor = System.Drawing.Color.White;
            this.button172.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button172.Location = new System.Drawing.Point(4, 3);
            this.button172.Name = "button172";
            this.button172.Size = new System.Drawing.Size(89, 26);
            this.button172.TabIndex = 2;
            this.button172.Text = "button172";
            this.button172.UseVisualStyleBackColor = false;
            // 
            // button173
            // 
            this.button173.BackColor = System.Drawing.Color.White;
            this.button173.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button173.Location = new System.Drawing.Point(99, 3);
            this.button173.Name = "button173";
            this.button173.Size = new System.Drawing.Size(89, 26);
            this.button173.TabIndex = 1;
            this.button173.Text = "button173";
            this.button173.UseVisualStyleBackColor = false;
            // 
            // button174
            // 
            this.button174.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.button174.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button174.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button174.Location = new System.Drawing.Point(192, 3);
            this.button174.Name = "button174";
            this.button174.Size = new System.Drawing.Size(89, 26);
            this.button174.TabIndex = 0;
            this.button174.Text = "button174";
            this.button174.UseVisualStyleBackColor = false;
            // 
            // panel53
            // 
            this.panel53.Controls.Add(this.button154);
            this.panel53.Controls.Add(this.button155);
            this.panel53.Controls.Add(this.button156);
            this.panel53.Location = new System.Drawing.Point(6, 81);
            this.panel53.Name = "panel53";
            this.panel53.Size = new System.Drawing.Size(289, 32);
            this.panel53.TabIndex = 17;
            // 
            // button154
            // 
            this.button154.BackColor = System.Drawing.Color.White;
            this.button154.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button154.Location = new System.Drawing.Point(4, 3);
            this.button154.Name = "button154";
            this.button154.Size = new System.Drawing.Size(89, 26);
            this.button154.TabIndex = 2;
            this.button154.Text = "button154";
            this.button154.UseVisualStyleBackColor = false;
            // 
            // button155
            // 
            this.button155.BackColor = System.Drawing.Color.White;
            this.button155.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button155.Location = new System.Drawing.Point(99, 3);
            this.button155.Name = "button155";
            this.button155.Size = new System.Drawing.Size(89, 26);
            this.button155.TabIndex = 1;
            this.button155.Text = "button155";
            this.button155.UseVisualStyleBackColor = false;
            // 
            // button156
            // 
            this.button156.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.button156.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button156.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button156.Location = new System.Drawing.Point(192, 3);
            this.button156.Name = "button156";
            this.button156.Size = new System.Drawing.Size(89, 26);
            this.button156.TabIndex = 0;
            this.button156.Text = "button156";
            this.button156.UseVisualStyleBackColor = false;
            // 
            // btnMjOmPurityShiftC
            // 
            this.btnMjOmPurityShiftC.Location = new System.Drawing.Point(198, 46);
            this.btnMjOmPurityShiftC.Name = "btnMjOmPurityShiftC";
            this.btnMjOmPurityShiftC.Size = new System.Drawing.Size(89, 26);
            this.btnMjOmPurityShiftC.TabIndex = 6;
            this.btnMjOmPurityShiftC.Text = "Purity";
            this.btnMjOmPurityShiftC.UseVisualStyleBackColor = true;
            // 
            // btnMjOmPolShiftC
            // 
            this.btnMjOmPolShiftC.Location = new System.Drawing.Point(101, 46);
            this.btnMjOmPolShiftC.Name = "btnMjOmPolShiftC";
            this.btnMjOmPolShiftC.Size = new System.Drawing.Size(89, 26);
            this.btnMjOmPolShiftC.TabIndex = 5;
            this.btnMjOmPolShiftC.Text = "Pol";
            this.btnMjOmPolShiftC.UseVisualStyleBackColor = true;
            // 
            // btnMjOmBrixShiftC
            // 
            this.btnMjOmBrixShiftC.Location = new System.Drawing.Point(6, 46);
            this.btnMjOmBrixShiftC.Name = "btnMjOmBrixShiftC";
            this.btnMjOmBrixShiftC.Size = new System.Drawing.Size(89, 26);
            this.btnMjOmBrixShiftC.TabIndex = 4;
            this.btnMjOmBrixShiftC.Text = "Brix";
            this.btnMjOmBrixShiftC.UseVisualStyleBackColor = true;
            // 
            // btnMjOmShiftC
            // 
            this.btnMjOmShiftC.Location = new System.Drawing.Point(6, 10);
            this.btnMjOmShiftC.Name = "btnMjOmShiftC";
            this.btnMjOmShiftC.Size = new System.Drawing.Size(281, 34);
            this.btnMjOmShiftC.TabIndex = 1;
            this.btnMjOmShiftC.Text = "Old Mill";
            this.btnMjOmShiftC.UseVisualStyleBackColor = true;
            // 
            // groupBox30
            // 
            this.groupBox30.Controls.Add(this.panel94);
            this.groupBox30.Controls.Add(this.panel70);
            this.groupBox30.Controls.Add(this.panel64);
            this.groupBox30.Controls.Add(this.panel58);
            this.groupBox30.Controls.Add(this.panel52);
            this.groupBox30.Controls.Add(this.btnMjNmPurityShiftC);
            this.groupBox30.Controls.Add(this.btnMjNmPolShiftC);
            this.groupBox30.Controls.Add(this.btnMjNmBrixShiftC);
            this.groupBox30.Controls.Add(this.btnMjNmShiftC);
            this.groupBox30.Location = new System.Drawing.Point(6, 32);
            this.groupBox30.Name = "groupBox30";
            this.groupBox30.Size = new System.Drawing.Size(301, 279);
            this.groupBox30.TabIndex = 2;
            this.groupBox30.TabStop = false;
            // 
            // panel94
            // 
            this.panel94.Controls.Add(this.button260);
            this.panel94.Controls.Add(this.button261);
            this.panel94.Controls.Add(this.button262);
            this.panel94.Location = new System.Drawing.Point(6, 230);
            this.panel94.Name = "panel94";
            this.panel94.Size = new System.Drawing.Size(289, 32);
            this.panel94.TabIndex = 21;
            // 
            // button260
            // 
            this.button260.BackColor = System.Drawing.SystemColors.HotTrack;
            this.button260.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button260.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button260.Location = new System.Drawing.Point(4, 3);
            this.button260.Name = "button260";
            this.button260.Size = new System.Drawing.Size(89, 26);
            this.button260.TabIndex = 2;
            this.button260.Text = "button260";
            this.button260.UseVisualStyleBackColor = false;
            // 
            // button261
            // 
            this.button261.BackColor = System.Drawing.SystemColors.HotTrack;
            this.button261.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button261.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button261.Location = new System.Drawing.Point(99, 3);
            this.button261.Name = "button261";
            this.button261.Size = new System.Drawing.Size(89, 26);
            this.button261.TabIndex = 1;
            this.button261.Text = "button261";
            this.button261.UseVisualStyleBackColor = false;
            // 
            // button262
            // 
            this.button262.BackColor = System.Drawing.SystemColors.HotTrack;
            this.button262.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button262.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button262.Location = new System.Drawing.Point(192, 3);
            this.button262.Name = "button262";
            this.button262.Size = new System.Drawing.Size(89, 26);
            this.button262.TabIndex = 0;
            this.button262.Text = "button262";
            this.button262.UseVisualStyleBackColor = false;
            // 
            // panel70
            // 
            this.panel70.Controls.Add(this.button205);
            this.panel70.Controls.Add(this.button206);
            this.panel70.Controls.Add(this.button207);
            this.panel70.Location = new System.Drawing.Point(6, 192);
            this.panel70.Name = "panel70";
            this.panel70.Size = new System.Drawing.Size(289, 32);
            this.panel70.TabIndex = 20;
            // 
            // button205
            // 
            this.button205.BackColor = System.Drawing.Color.White;
            this.button205.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button205.Location = new System.Drawing.Point(4, 3);
            this.button205.Name = "button205";
            this.button205.Size = new System.Drawing.Size(89, 26);
            this.button205.TabIndex = 2;
            this.button205.Text = "button205";
            this.button205.UseVisualStyleBackColor = false;
            // 
            // button206
            // 
            this.button206.BackColor = System.Drawing.Color.White;
            this.button206.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button206.Location = new System.Drawing.Point(99, 3);
            this.button206.Name = "button206";
            this.button206.Size = new System.Drawing.Size(89, 26);
            this.button206.TabIndex = 1;
            this.button206.Text = "button206";
            this.button206.UseVisualStyleBackColor = false;
            // 
            // button207
            // 
            this.button207.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.button207.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button207.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button207.Location = new System.Drawing.Point(192, 3);
            this.button207.Name = "button207";
            this.button207.Size = new System.Drawing.Size(89, 26);
            this.button207.TabIndex = 0;
            this.button207.Text = "button207";
            this.button207.UseVisualStyleBackColor = false;
            // 
            // panel64
            // 
            this.panel64.Controls.Add(this.button187);
            this.panel64.Controls.Add(this.button188);
            this.panel64.Controls.Add(this.button189);
            this.panel64.Location = new System.Drawing.Point(8, 157);
            this.panel64.Name = "panel64";
            this.panel64.Size = new System.Drawing.Size(289, 32);
            this.panel64.TabIndex = 19;
            // 
            // button187
            // 
            this.button187.BackColor = System.Drawing.Color.White;
            this.button187.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button187.Location = new System.Drawing.Point(4, 3);
            this.button187.Name = "button187";
            this.button187.Size = new System.Drawing.Size(89, 26);
            this.button187.TabIndex = 2;
            this.button187.Text = "button187";
            this.button187.UseVisualStyleBackColor = false;
            // 
            // button188
            // 
            this.button188.BackColor = System.Drawing.Color.White;
            this.button188.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button188.Location = new System.Drawing.Point(99, 3);
            this.button188.Name = "button188";
            this.button188.Size = new System.Drawing.Size(89, 26);
            this.button188.TabIndex = 1;
            this.button188.Text = "button188";
            this.button188.UseVisualStyleBackColor = false;
            // 
            // button189
            // 
            this.button189.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.button189.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button189.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button189.Location = new System.Drawing.Point(192, 3);
            this.button189.Name = "button189";
            this.button189.Size = new System.Drawing.Size(89, 26);
            this.button189.TabIndex = 0;
            this.button189.Text = "button189";
            this.button189.UseVisualStyleBackColor = false;
            // 
            // panel58
            // 
            this.panel58.Controls.Add(this.button169);
            this.panel58.Controls.Add(this.button170);
            this.panel58.Controls.Add(this.button171);
            this.panel58.Location = new System.Drawing.Point(6, 119);
            this.panel58.Name = "panel58";
            this.panel58.Size = new System.Drawing.Size(289, 32);
            this.panel58.TabIndex = 18;
            // 
            // button169
            // 
            this.button169.BackColor = System.Drawing.Color.White;
            this.button169.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button169.Location = new System.Drawing.Point(4, 3);
            this.button169.Name = "button169";
            this.button169.Size = new System.Drawing.Size(89, 26);
            this.button169.TabIndex = 2;
            this.button169.Text = "button169";
            this.button169.UseVisualStyleBackColor = false;
            // 
            // button170
            // 
            this.button170.BackColor = System.Drawing.Color.White;
            this.button170.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button170.Location = new System.Drawing.Point(99, 3);
            this.button170.Name = "button170";
            this.button170.Size = new System.Drawing.Size(89, 26);
            this.button170.TabIndex = 1;
            this.button170.Text = "button170";
            this.button170.UseVisualStyleBackColor = false;
            // 
            // button171
            // 
            this.button171.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.button171.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button171.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button171.Location = new System.Drawing.Point(192, 3);
            this.button171.Name = "button171";
            this.button171.Size = new System.Drawing.Size(89, 26);
            this.button171.TabIndex = 0;
            this.button171.Text = "button171";
            this.button171.UseVisualStyleBackColor = false;
            // 
            // panel52
            // 
            this.panel52.Controls.Add(this.button151);
            this.panel52.Controls.Add(this.button152);
            this.panel52.Controls.Add(this.button153);
            this.panel52.Location = new System.Drawing.Point(6, 81);
            this.panel52.Name = "panel52";
            this.panel52.Size = new System.Drawing.Size(289, 32);
            this.panel52.TabIndex = 17;
            // 
            // button151
            // 
            this.button151.BackColor = System.Drawing.Color.White;
            this.button151.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button151.Location = new System.Drawing.Point(4, 3);
            this.button151.Name = "button151";
            this.button151.Size = new System.Drawing.Size(89, 26);
            this.button151.TabIndex = 2;
            this.button151.Text = "button151";
            this.button151.UseVisualStyleBackColor = false;
            // 
            // button152
            // 
            this.button152.BackColor = System.Drawing.Color.White;
            this.button152.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button152.Location = new System.Drawing.Point(99, 3);
            this.button152.Name = "button152";
            this.button152.Size = new System.Drawing.Size(89, 26);
            this.button152.TabIndex = 1;
            this.button152.Text = "button152";
            this.button152.UseVisualStyleBackColor = false;
            // 
            // button153
            // 
            this.button153.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.button153.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button153.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button153.Location = new System.Drawing.Point(192, 3);
            this.button153.Name = "button153";
            this.button153.Size = new System.Drawing.Size(89, 26);
            this.button153.TabIndex = 0;
            this.button153.Text = "button153";
            this.button153.UseVisualStyleBackColor = false;
            // 
            // btnMjNmPurityShiftC
            // 
            this.btnMjNmPurityShiftC.Location = new System.Drawing.Point(198, 46);
            this.btnMjNmPurityShiftC.Name = "btnMjNmPurityShiftC";
            this.btnMjNmPurityShiftC.Size = new System.Drawing.Size(89, 26);
            this.btnMjNmPurityShiftC.TabIndex = 6;
            this.btnMjNmPurityShiftC.Text = "Purity";
            this.btnMjNmPurityShiftC.UseVisualStyleBackColor = true;
            // 
            // btnMjNmPolShiftC
            // 
            this.btnMjNmPolShiftC.Location = new System.Drawing.Point(101, 46);
            this.btnMjNmPolShiftC.Name = "btnMjNmPolShiftC";
            this.btnMjNmPolShiftC.Size = new System.Drawing.Size(89, 26);
            this.btnMjNmPolShiftC.TabIndex = 5;
            this.btnMjNmPolShiftC.Text = "Pol";
            this.btnMjNmPolShiftC.UseVisualStyleBackColor = true;
            // 
            // btnMjNmBrixShiftC
            // 
            this.btnMjNmBrixShiftC.Location = new System.Drawing.Point(6, 46);
            this.btnMjNmBrixShiftC.Name = "btnMjNmBrixShiftC";
            this.btnMjNmBrixShiftC.Size = new System.Drawing.Size(89, 26);
            this.btnMjNmBrixShiftC.TabIndex = 4;
            this.btnMjNmBrixShiftC.Text = "Brix";
            this.btnMjNmBrixShiftC.UseVisualStyleBackColor = true;
            // 
            // btnMjNmShiftC
            // 
            this.btnMjNmShiftC.Location = new System.Drawing.Point(6, 10);
            this.btnMjNmShiftC.Name = "btnMjNmShiftC";
            this.btnMjNmShiftC.Size = new System.Drawing.Size(281, 34);
            this.btnMjNmShiftC.TabIndex = 1;
            this.btnMjNmShiftC.Text = "New Mill";
            this.btnMjNmShiftC.UseVisualStyleBackColor = true;
            // 
            // btnMixedJuiceShiftC
            // 
            this.btnMixedJuiceShiftC.Location = new System.Drawing.Point(6, 10);
            this.btnMixedJuiceShiftC.Name = "btnMixedJuiceShiftC";
            this.btnMixedJuiceShiftC.Size = new System.Drawing.Size(620, 23);
            this.btnMixedJuiceShiftC.TabIndex = 1;
            this.btnMixedJuiceShiftC.Text = "Mixed Juice";
            this.btnMixedJuiceShiftC.UseVisualStyleBackColor = true;
            // 
            // groupBox31
            // 
            this.groupBox31.Controls.Add(this.btnAvgShiftC);
            this.groupBox31.Controls.Add(this.btnTime8);
            this.groupBox31.Controls.Add(this.btnTime6);
            this.groupBox31.Controls.Add(this.btnTime4);
            this.groupBox31.Controls.Add(this.btnTime2);
            this.groupBox31.Controls.Add(this.btnTimeShiftC);
            this.groupBox31.Location = new System.Drawing.Point(23, 32);
            this.groupBox31.Name = "groupBox31";
            this.groupBox31.Size = new System.Drawing.Size(92, 310);
            this.groupBox31.TabIndex = 1;
            this.groupBox31.TabStop = false;
            // 
            // btnAvgShiftC
            // 
            this.btnAvgShiftC.Location = new System.Drawing.Point(11, 233);
            this.btnAvgShiftC.Name = "btnAvgShiftC";
            this.btnAvgShiftC.Size = new System.Drawing.Size(75, 26);
            this.btnAvgShiftC.TabIndex = 6;
            this.btnAvgShiftC.Text = "Average";
            this.btnAvgShiftC.UseVisualStyleBackColor = true;
            // 
            // btnTime8
            // 
            this.btnTime8.Location = new System.Drawing.Point(11, 191);
            this.btnTime8.Name = "btnTime8";
            this.btnTime8.Size = new System.Drawing.Size(75, 26);
            this.btnTime8.TabIndex = 5;
            this.btnTime8.Text = "8";
            this.btnTime8.UseVisualStyleBackColor = true;
            // 
            // btnTime6
            // 
            this.btnTime6.Location = new System.Drawing.Point(11, 156);
            this.btnTime6.Name = "btnTime6";
            this.btnTime6.Size = new System.Drawing.Size(75, 26);
            this.btnTime6.TabIndex = 4;
            this.btnTime6.Text = "6";
            this.btnTime6.UseVisualStyleBackColor = true;
            // 
            // btnTime4
            // 
            this.btnTime4.Location = new System.Drawing.Point(11, 118);
            this.btnTime4.Name = "btnTime4";
            this.btnTime4.Size = new System.Drawing.Size(75, 26);
            this.btnTime4.TabIndex = 3;
            this.btnTime4.Text = "4";
            this.btnTime4.UseVisualStyleBackColor = true;
            // 
            // btnTime2
            // 
            this.btnTime2.Location = new System.Drawing.Point(11, 80);
            this.btnTime2.Name = "btnTime2";
            this.btnTime2.Size = new System.Drawing.Size(75, 26);
            this.btnTime2.TabIndex = 2;
            this.btnTime2.Text = "2";
            this.btnTime2.UseVisualStyleBackColor = true;
            // 
            // btnTimeShiftC
            // 
            this.btnTimeShiftC.Location = new System.Drawing.Point(10, 15);
            this.btnTimeShiftC.Name = "btnTimeShiftC";
            this.btnTimeShiftC.Size = new System.Drawing.Size(76, 56);
            this.btnTimeShiftC.TabIndex = 2;
            this.btnTimeShiftC.Text = "Time";
            this.btnTimeShiftC.UseVisualStyleBackColor = true;
            // 
            // groupBox32
            // 
            this.groupBox32.Controls.Add(this.groupBox33);
            this.groupBox32.Controls.Add(this.groupBox34);
            this.groupBox32.Controls.Add(this.btnPrimaryJuiceShiftC);
            this.groupBox32.Location = new System.Drawing.Point(123, 12);
            this.groupBox32.Name = "groupBox32";
            this.groupBox32.Size = new System.Drawing.Size(636, 330);
            this.groupBox32.TabIndex = 0;
            this.groupBox32.TabStop = false;
            // 
            // groupBox33
            // 
            this.groupBox33.Controls.Add(this.panel93);
            this.groupBox33.Controls.Add(this.panel69);
            this.groupBox33.Controls.Add(this.panel63);
            this.groupBox33.Controls.Add(this.panel57);
            this.groupBox33.Controls.Add(this.panel51);
            this.groupBox33.Controls.Add(this.btnPjOmPurityShiftC);
            this.groupBox33.Controls.Add(this.btnPjOmPolShiftC);
            this.groupBox33.Controls.Add(this.btnPjOmBrixShiftC);
            this.groupBox33.Controls.Add(this.btnPjOmShiftC);
            this.groupBox33.Location = new System.Drawing.Point(319, 32);
            this.groupBox33.Name = "groupBox33";
            this.groupBox33.Size = new System.Drawing.Size(301, 279);
            this.groupBox33.TabIndex = 2;
            this.groupBox33.TabStop = false;
            // 
            // panel93
            // 
            this.panel93.Controls.Add(this.button257);
            this.panel93.Controls.Add(this.button258);
            this.panel93.Controls.Add(this.button259);
            this.panel93.Location = new System.Drawing.Point(2, 227);
            this.panel93.Name = "panel93";
            this.panel93.Size = new System.Drawing.Size(289, 32);
            this.panel93.TabIndex = 21;
            // 
            // button257
            // 
            this.button257.BackColor = System.Drawing.SystemColors.HotTrack;
            this.button257.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button257.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button257.Location = new System.Drawing.Point(4, 3);
            this.button257.Name = "button257";
            this.button257.Size = new System.Drawing.Size(89, 26);
            this.button257.TabIndex = 2;
            this.button257.Text = "button257";
            this.button257.UseVisualStyleBackColor = false;
            // 
            // button258
            // 
            this.button258.BackColor = System.Drawing.SystemColors.HotTrack;
            this.button258.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button258.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button258.Location = new System.Drawing.Point(99, 3);
            this.button258.Name = "button258";
            this.button258.Size = new System.Drawing.Size(89, 26);
            this.button258.TabIndex = 1;
            this.button258.Text = "button258";
            this.button258.UseVisualStyleBackColor = false;
            // 
            // button259
            // 
            this.button259.BackColor = System.Drawing.SystemColors.HotTrack;
            this.button259.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button259.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button259.Location = new System.Drawing.Point(192, 3);
            this.button259.Name = "button259";
            this.button259.Size = new System.Drawing.Size(89, 26);
            this.button259.TabIndex = 0;
            this.button259.Text = "button259";
            this.button259.UseVisualStyleBackColor = false;
            // 
            // panel69
            // 
            this.panel69.Controls.Add(this.button202);
            this.panel69.Controls.Add(this.button203);
            this.panel69.Controls.Add(this.button204);
            this.panel69.Location = new System.Drawing.Point(2, 189);
            this.panel69.Name = "panel69";
            this.panel69.Size = new System.Drawing.Size(289, 32);
            this.panel69.TabIndex = 20;
            // 
            // button202
            // 
            this.button202.BackColor = System.Drawing.Color.White;
            this.button202.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button202.Location = new System.Drawing.Point(4, 3);
            this.button202.Name = "button202";
            this.button202.Size = new System.Drawing.Size(89, 26);
            this.button202.TabIndex = 2;
            this.button202.Text = "button202";
            this.button202.UseVisualStyleBackColor = false;
            // 
            // button203
            // 
            this.button203.BackColor = System.Drawing.Color.White;
            this.button203.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button203.Location = new System.Drawing.Point(99, 3);
            this.button203.Name = "button203";
            this.button203.Size = new System.Drawing.Size(89, 26);
            this.button203.TabIndex = 1;
            this.button203.Text = "button203";
            this.button203.UseVisualStyleBackColor = false;
            // 
            // button204
            // 
            this.button204.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.button204.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button204.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button204.Location = new System.Drawing.Point(192, 3);
            this.button204.Name = "button204";
            this.button204.Size = new System.Drawing.Size(89, 26);
            this.button204.TabIndex = 0;
            this.button204.Text = "button204";
            this.button204.UseVisualStyleBackColor = false;
            // 
            // panel63
            // 
            this.panel63.Controls.Add(this.button184);
            this.panel63.Controls.Add(this.button185);
            this.panel63.Controls.Add(this.button186);
            this.panel63.Location = new System.Drawing.Point(6, 154);
            this.panel63.Name = "panel63";
            this.panel63.Size = new System.Drawing.Size(289, 32);
            this.panel63.TabIndex = 19;
            // 
            // button184
            // 
            this.button184.BackColor = System.Drawing.Color.White;
            this.button184.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button184.Location = new System.Drawing.Point(4, 3);
            this.button184.Name = "button184";
            this.button184.Size = new System.Drawing.Size(89, 26);
            this.button184.TabIndex = 2;
            this.button184.Text = "button184";
            this.button184.UseVisualStyleBackColor = false;
            // 
            // button185
            // 
            this.button185.BackColor = System.Drawing.Color.White;
            this.button185.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button185.Location = new System.Drawing.Point(99, 3);
            this.button185.Name = "button185";
            this.button185.Size = new System.Drawing.Size(89, 26);
            this.button185.TabIndex = 1;
            this.button185.Text = "button185";
            this.button185.UseVisualStyleBackColor = false;
            // 
            // button186
            // 
            this.button186.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.button186.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button186.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button186.Location = new System.Drawing.Point(192, 3);
            this.button186.Name = "button186";
            this.button186.Size = new System.Drawing.Size(89, 26);
            this.button186.TabIndex = 0;
            this.button186.Text = "button186";
            this.button186.UseVisualStyleBackColor = false;
            // 
            // panel57
            // 
            this.panel57.Controls.Add(this.button166);
            this.panel57.Controls.Add(this.button167);
            this.panel57.Controls.Add(this.button168);
            this.panel57.Location = new System.Drawing.Point(6, 119);
            this.panel57.Name = "panel57";
            this.panel57.Size = new System.Drawing.Size(289, 32);
            this.panel57.TabIndex = 18;
            // 
            // button166
            // 
            this.button166.BackColor = System.Drawing.Color.White;
            this.button166.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button166.Location = new System.Drawing.Point(4, 3);
            this.button166.Name = "button166";
            this.button166.Size = new System.Drawing.Size(89, 26);
            this.button166.TabIndex = 2;
            this.button166.Text = "button166";
            this.button166.UseVisualStyleBackColor = false;
            // 
            // button167
            // 
            this.button167.BackColor = System.Drawing.Color.White;
            this.button167.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button167.Location = new System.Drawing.Point(99, 3);
            this.button167.Name = "button167";
            this.button167.Size = new System.Drawing.Size(89, 26);
            this.button167.TabIndex = 1;
            this.button167.Text = "button167";
            this.button167.UseVisualStyleBackColor = false;
            // 
            // button168
            // 
            this.button168.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.button168.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button168.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button168.Location = new System.Drawing.Point(192, 3);
            this.button168.Name = "button168";
            this.button168.Size = new System.Drawing.Size(89, 26);
            this.button168.TabIndex = 0;
            this.button168.Text = "button168";
            this.button168.UseVisualStyleBackColor = false;
            // 
            // panel51
            // 
            this.panel51.Controls.Add(this.button148);
            this.panel51.Controls.Add(this.button149);
            this.panel51.Controls.Add(this.button150);
            this.panel51.Location = new System.Drawing.Point(6, 81);
            this.panel51.Name = "panel51";
            this.panel51.Size = new System.Drawing.Size(289, 32);
            this.panel51.TabIndex = 17;
            // 
            // button148
            // 
            this.button148.BackColor = System.Drawing.Color.White;
            this.button148.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button148.Location = new System.Drawing.Point(4, 3);
            this.button148.Name = "button148";
            this.button148.Size = new System.Drawing.Size(89, 26);
            this.button148.TabIndex = 2;
            this.button148.Text = "button148";
            this.button148.UseVisualStyleBackColor = false;
            // 
            // button149
            // 
            this.button149.BackColor = System.Drawing.Color.White;
            this.button149.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button149.Location = new System.Drawing.Point(99, 3);
            this.button149.Name = "button149";
            this.button149.Size = new System.Drawing.Size(89, 26);
            this.button149.TabIndex = 1;
            this.button149.Text = "button149";
            this.button149.UseVisualStyleBackColor = false;
            // 
            // button150
            // 
            this.button150.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.button150.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button150.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button150.Location = new System.Drawing.Point(192, 3);
            this.button150.Name = "button150";
            this.button150.Size = new System.Drawing.Size(89, 26);
            this.button150.TabIndex = 0;
            this.button150.Text = "button150";
            this.button150.UseVisualStyleBackColor = false;
            // 
            // btnPjOmPurityShiftC
            // 
            this.btnPjOmPurityShiftC.Location = new System.Drawing.Point(202, 46);
            this.btnPjOmPurityShiftC.Name = "btnPjOmPurityShiftC";
            this.btnPjOmPurityShiftC.Size = new System.Drawing.Size(89, 26);
            this.btnPjOmPurityShiftC.TabIndex = 6;
            this.btnPjOmPurityShiftC.Text = "Purity";
            this.btnPjOmPurityShiftC.UseVisualStyleBackColor = true;
            // 
            // btnPjOmPolShiftC
            // 
            this.btnPjOmPolShiftC.Location = new System.Drawing.Point(105, 46);
            this.btnPjOmPolShiftC.Name = "btnPjOmPolShiftC";
            this.btnPjOmPolShiftC.Size = new System.Drawing.Size(89, 26);
            this.btnPjOmPolShiftC.TabIndex = 5;
            this.btnPjOmPolShiftC.Text = "Pol";
            this.btnPjOmPolShiftC.UseVisualStyleBackColor = true;
            // 
            // btnPjOmBrixShiftC
            // 
            this.btnPjOmBrixShiftC.Location = new System.Drawing.Point(8, 46);
            this.btnPjOmBrixShiftC.Name = "btnPjOmBrixShiftC";
            this.btnPjOmBrixShiftC.Size = new System.Drawing.Size(89, 26);
            this.btnPjOmBrixShiftC.TabIndex = 4;
            this.btnPjOmBrixShiftC.Text = "Brix";
            this.btnPjOmBrixShiftC.UseVisualStyleBackColor = true;
            // 
            // btnPjOmShiftC
            // 
            this.btnPjOmShiftC.Location = new System.Drawing.Point(8, 10);
            this.btnPjOmShiftC.Name = "btnPjOmShiftC";
            this.btnPjOmShiftC.Size = new System.Drawing.Size(281, 34);
            this.btnPjOmShiftC.TabIndex = 0;
            this.btnPjOmShiftC.Text = "Old Mill";
            this.btnPjOmShiftC.UseVisualStyleBackColor = true;
            // 
            // groupBox34
            // 
            this.groupBox34.Controls.Add(this.panel92);
            this.groupBox34.Controls.Add(this.panel68);
            this.groupBox34.Controls.Add(this.panel62);
            this.groupBox34.Controls.Add(this.panel56);
            this.groupBox34.Controls.Add(this.panel50);
            this.groupBox34.Controls.Add(this.btnPjNmPurityShiftC);
            this.groupBox34.Controls.Add(this.btnPjNmPolShiftC);
            this.groupBox34.Controls.Add(this.btnPjNmBrixShiftC);
            this.groupBox34.Controls.Add(this.btnPjNmShiftC);
            this.groupBox34.Location = new System.Drawing.Point(7, 32);
            this.groupBox34.Name = "groupBox34";
            this.groupBox34.Size = new System.Drawing.Size(301, 279);
            this.groupBox34.TabIndex = 1;
            this.groupBox34.TabStop = false;
            // 
            // panel92
            // 
            this.panel92.Controls.Add(this.button254);
            this.panel92.Controls.Add(this.button255);
            this.panel92.Controls.Add(this.button256);
            this.panel92.Location = new System.Drawing.Point(6, 224);
            this.panel92.Name = "panel92";
            this.panel92.Size = new System.Drawing.Size(289, 32);
            this.panel92.TabIndex = 21;
            // 
            // button254
            // 
            this.button254.BackColor = System.Drawing.SystemColors.HotTrack;
            this.button254.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button254.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button254.Location = new System.Drawing.Point(4, 3);
            this.button254.Name = "button254";
            this.button254.Size = new System.Drawing.Size(89, 26);
            this.button254.TabIndex = 2;
            this.button254.Text = "button254";
            this.button254.UseVisualStyleBackColor = false;
            // 
            // button255
            // 
            this.button255.BackColor = System.Drawing.SystemColors.HotTrack;
            this.button255.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button255.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button255.Location = new System.Drawing.Point(99, 3);
            this.button255.Name = "button255";
            this.button255.Size = new System.Drawing.Size(89, 26);
            this.button255.TabIndex = 1;
            this.button255.Text = "button255";
            this.button255.UseVisualStyleBackColor = false;
            // 
            // button256
            // 
            this.button256.BackColor = System.Drawing.SystemColors.HotTrack;
            this.button256.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button256.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button256.Location = new System.Drawing.Point(192, 3);
            this.button256.Name = "button256";
            this.button256.Size = new System.Drawing.Size(89, 26);
            this.button256.TabIndex = 0;
            this.button256.Text = "button256";
            this.button256.UseVisualStyleBackColor = false;
            // 
            // panel68
            // 
            this.panel68.Controls.Add(this.button199);
            this.panel68.Controls.Add(this.button200);
            this.panel68.Controls.Add(this.button201);
            this.panel68.Location = new System.Drawing.Point(6, 186);
            this.panel68.Name = "panel68";
            this.panel68.Size = new System.Drawing.Size(289, 32);
            this.panel68.TabIndex = 20;
            // 
            // button199
            // 
            this.button199.BackColor = System.Drawing.Color.White;
            this.button199.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button199.Location = new System.Drawing.Point(4, 3);
            this.button199.Name = "button199";
            this.button199.Size = new System.Drawing.Size(89, 26);
            this.button199.TabIndex = 2;
            this.button199.Text = "button199";
            this.button199.UseVisualStyleBackColor = false;
            // 
            // button200
            // 
            this.button200.BackColor = System.Drawing.Color.White;
            this.button200.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button200.Location = new System.Drawing.Point(99, 3);
            this.button200.Name = "button200";
            this.button200.Size = new System.Drawing.Size(89, 26);
            this.button200.TabIndex = 1;
            this.button200.Text = "button200";
            this.button200.UseVisualStyleBackColor = false;
            // 
            // button201
            // 
            this.button201.BackColor = System.Drawing.Color.White;
            this.button201.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button201.Location = new System.Drawing.Point(192, 3);
            this.button201.Name = "button201";
            this.button201.Size = new System.Drawing.Size(89, 26);
            this.button201.TabIndex = 0;
            this.button201.Text = "button201";
            this.button201.UseVisualStyleBackColor = false;
            // 
            // panel62
            // 
            this.panel62.Controls.Add(this.button181);
            this.panel62.Controls.Add(this.button182);
            this.panel62.Controls.Add(this.button183);
            this.panel62.Location = new System.Drawing.Point(6, 151);
            this.panel62.Name = "panel62";
            this.panel62.Size = new System.Drawing.Size(289, 32);
            this.panel62.TabIndex = 19;
            // 
            // button181
            // 
            this.button181.BackColor = System.Drawing.Color.White;
            this.button181.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button181.Location = new System.Drawing.Point(4, 3);
            this.button181.Name = "button181";
            this.button181.Size = new System.Drawing.Size(89, 26);
            this.button181.TabIndex = 2;
            this.button181.Text = "button181";
            this.button181.UseVisualStyleBackColor = false;
            // 
            // button182
            // 
            this.button182.BackColor = System.Drawing.Color.White;
            this.button182.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button182.Location = new System.Drawing.Point(99, 3);
            this.button182.Name = "button182";
            this.button182.Size = new System.Drawing.Size(89, 26);
            this.button182.TabIndex = 1;
            this.button182.Text = "button182";
            this.button182.UseVisualStyleBackColor = false;
            // 
            // button183
            // 
            this.button183.BackColor = System.Drawing.Color.White;
            this.button183.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button183.Location = new System.Drawing.Point(192, 3);
            this.button183.Name = "button183";
            this.button183.Size = new System.Drawing.Size(89, 26);
            this.button183.TabIndex = 0;
            this.button183.Text = "button183";
            this.button183.UseVisualStyleBackColor = false;
            // 
            // panel56
            // 
            this.panel56.Controls.Add(this.button163);
            this.panel56.Controls.Add(this.button164);
            this.panel56.Controls.Add(this.button165);
            this.panel56.Location = new System.Drawing.Point(6, 113);
            this.panel56.Name = "panel56";
            this.panel56.Size = new System.Drawing.Size(289, 32);
            this.panel56.TabIndex = 18;
            // 
            // button163
            // 
            this.button163.BackColor = System.Drawing.Color.White;
            this.button163.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button163.Location = new System.Drawing.Point(4, 3);
            this.button163.Name = "button163";
            this.button163.Size = new System.Drawing.Size(89, 26);
            this.button163.TabIndex = 2;
            this.button163.Text = "button163";
            this.button163.UseVisualStyleBackColor = false;
            // 
            // button164
            // 
            this.button164.BackColor = System.Drawing.Color.White;
            this.button164.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button164.Location = new System.Drawing.Point(99, 3);
            this.button164.Name = "button164";
            this.button164.Size = new System.Drawing.Size(89, 26);
            this.button164.TabIndex = 1;
            this.button164.Text = "button164";
            this.button164.UseVisualStyleBackColor = false;
            // 
            // button165
            // 
            this.button165.BackColor = System.Drawing.Color.White;
            this.button165.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button165.Location = new System.Drawing.Point(192, 3);
            this.button165.Name = "button165";
            this.button165.Size = new System.Drawing.Size(89, 26);
            this.button165.TabIndex = 0;
            this.button165.Text = "button165";
            this.button165.UseVisualStyleBackColor = false;
            // 
            // panel50
            // 
            this.panel50.Controls.Add(this.button145);
            this.panel50.Controls.Add(this.button146);
            this.panel50.Controls.Add(this.button147);
            this.panel50.Location = new System.Drawing.Point(6, 78);
            this.panel50.Name = "panel50";
            this.panel50.Size = new System.Drawing.Size(289, 32);
            this.panel50.TabIndex = 17;
            // 
            // button145
            // 
            this.button145.BackColor = System.Drawing.Color.White;
            this.button145.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button145.Location = new System.Drawing.Point(4, 3);
            this.button145.Name = "button145";
            this.button145.Size = new System.Drawing.Size(89, 26);
            this.button145.TabIndex = 2;
            this.button145.Text = "button145";
            this.button145.UseVisualStyleBackColor = false;
            // 
            // button146
            // 
            this.button146.BackColor = System.Drawing.Color.White;
            this.button146.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button146.Location = new System.Drawing.Point(99, 3);
            this.button146.Name = "button146";
            this.button146.Size = new System.Drawing.Size(89, 26);
            this.button146.TabIndex = 1;
            this.button146.Text = "button146";
            this.button146.UseVisualStyleBackColor = false;
            // 
            // button147
            // 
            this.button147.BackColor = System.Drawing.Color.White;
            this.button147.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button147.Location = new System.Drawing.Point(192, 3);
            this.button147.Name = "button147";
            this.button147.Size = new System.Drawing.Size(89, 26);
            this.button147.TabIndex = 0;
            this.button147.Text = "button147";
            this.button147.UseVisualStyleBackColor = false;
            // 
            // btnPjNmPurityShiftC
            // 
            this.btnPjNmPurityShiftC.Location = new System.Drawing.Point(202, 46);
            this.btnPjNmPurityShiftC.Name = "btnPjNmPurityShiftC";
            this.btnPjNmPurityShiftC.Size = new System.Drawing.Size(89, 26);
            this.btnPjNmPurityShiftC.TabIndex = 3;
            this.btnPjNmPurityShiftC.Text = "Purity";
            this.btnPjNmPurityShiftC.UseVisualStyleBackColor = true;
            // 
            // btnPjNmPolShiftC
            // 
            this.btnPjNmPolShiftC.Location = new System.Drawing.Point(105, 46);
            this.btnPjNmPolShiftC.Name = "btnPjNmPolShiftC";
            this.btnPjNmPolShiftC.Size = new System.Drawing.Size(89, 26);
            this.btnPjNmPolShiftC.TabIndex = 2;
            this.btnPjNmPolShiftC.Text = "Pol";
            this.btnPjNmPolShiftC.UseVisualStyleBackColor = true;
            // 
            // btnPjNmBrixShiftC
            // 
            this.btnPjNmBrixShiftC.Location = new System.Drawing.Point(10, 46);
            this.btnPjNmBrixShiftC.Name = "btnPjNmBrixShiftC";
            this.btnPjNmBrixShiftC.Size = new System.Drawing.Size(89, 26);
            this.btnPjNmBrixShiftC.TabIndex = 1;
            this.btnPjNmBrixShiftC.Text = "Brix";
            this.btnPjNmBrixShiftC.UseVisualStyleBackColor = true;
            // 
            // btnPjNmShiftC
            // 
            this.btnPjNmShiftC.Location = new System.Drawing.Point(10, 10);
            this.btnPjNmShiftC.Name = "btnPjNmShiftC";
            this.btnPjNmShiftC.Size = new System.Drawing.Size(281, 34);
            this.btnPjNmShiftC.TabIndex = 0;
            this.btnPjNmShiftC.Text = "New Mill";
            this.btnPjNmShiftC.UseVisualStyleBackColor = true;
            // 
            // btnPrimaryJuiceShiftC
            // 
            this.btnPrimaryJuiceShiftC.Location = new System.Drawing.Point(7, 10);
            this.btnPrimaryJuiceShiftC.Name = "btnPrimaryJuiceShiftC";
            this.btnPrimaryJuiceShiftC.Size = new System.Drawing.Size(620, 23);
            this.btnPrimaryJuiceShiftC.TabIndex = 0;
            this.btnPrimaryJuiceShiftC.Text = "Primary Juice";
            this.btnPrimaryJuiceShiftC.UseVisualStyleBackColor = true;
            // 
            // groupBox13
            // 
            this.groupBox13.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.groupBox13.Controls.Add(this.groupBox14);
            this.groupBox13.Controls.Add(this.groupBox17);
            this.groupBox13.Controls.Add(this.groupBox20);
            this.groupBox13.Controls.Add(this.groupBox21);
            this.groupBox13.Location = new System.Drawing.Point(14, 449);
            this.groupBox13.Name = "groupBox13";
            this.groupBox13.Size = new System.Drawing.Size(2061, 364);
            this.groupBox13.TabIndex = 2;
            this.groupBox13.TabStop = false;
            this.groupBox13.Text = "Shift-B";
            // 
            // groupBox14
            // 
            this.groupBox14.Controls.Add(this.groupBox15);
            this.groupBox14.Controls.Add(this.groupBox16);
            this.groupBox14.Controls.Add(this.btnLastJuiceShiftB);
            this.groupBox14.Location = new System.Drawing.Point(1407, 12);
            this.groupBox14.Name = "groupBox14";
            this.groupBox14.Size = new System.Drawing.Size(636, 330);
            this.groupBox14.TabIndex = 14;
            this.groupBox14.TabStop = false;
            // 
            // groupBox15
            // 
            this.groupBox15.Controls.Add(this.panel91);
            this.groupBox15.Controls.Add(this.panel49);
            this.groupBox15.Controls.Add(this.panel43);
            this.groupBox15.Controls.Add(this.panel37);
            this.groupBox15.Controls.Add(this.panel31);
            this.groupBox15.Controls.Add(this.btnLjOmPurityShiftB);
            this.groupBox15.Controls.Add(this.btnLjOmPolShiftB);
            this.groupBox15.Controls.Add(this.btnLjOmBrixShiftB);
            this.groupBox15.Controls.Add(this.btnLjOmShiftB);
            this.groupBox15.Location = new System.Drawing.Point(325, 32);
            this.groupBox15.Name = "groupBox15";
            this.groupBox15.Size = new System.Drawing.Size(301, 279);
            this.groupBox15.TabIndex = 3;
            this.groupBox15.TabStop = false;
            // 
            // panel91
            // 
            this.panel91.Controls.Add(this.button251);
            this.panel91.Controls.Add(this.button252);
            this.panel91.Controls.Add(this.button253);
            this.panel91.Location = new System.Drawing.Point(6, 233);
            this.panel91.Name = "panel91";
            this.panel91.Size = new System.Drawing.Size(289, 32);
            this.panel91.TabIndex = 18;
            // 
            // button251
            // 
            this.button251.BackColor = System.Drawing.SystemColors.HotTrack;
            this.button251.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button251.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button251.ForeColor = System.Drawing.Color.White;
            this.button251.Location = new System.Drawing.Point(4, 3);
            this.button251.Name = "button251";
            this.button251.Size = new System.Drawing.Size(89, 26);
            this.button251.TabIndex = 2;
            this.button251.Text = "button251";
            this.button251.UseVisualStyleBackColor = false;
            // 
            // button252
            // 
            this.button252.BackColor = System.Drawing.SystemColors.HotTrack;
            this.button252.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button252.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button252.ForeColor = System.Drawing.Color.White;
            this.button252.Location = new System.Drawing.Point(99, 3);
            this.button252.Name = "button252";
            this.button252.Size = new System.Drawing.Size(89, 26);
            this.button252.TabIndex = 1;
            this.button252.Text = "button252";
            this.button252.UseVisualStyleBackColor = false;
            // 
            // button253
            // 
            this.button253.BackColor = System.Drawing.SystemColors.HotTrack;
            this.button253.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button253.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button253.ForeColor = System.Drawing.Color.White;
            this.button253.Location = new System.Drawing.Point(192, 3);
            this.button253.Name = "button253";
            this.button253.Size = new System.Drawing.Size(89, 26);
            this.button253.TabIndex = 0;
            this.button253.Text = "button253";
            this.button253.UseVisualStyleBackColor = false;
            // 
            // panel49
            // 
            this.panel49.Controls.Add(this.button144);
            this.panel49.Controls.Add(this.button142);
            this.panel49.Controls.Add(this.button143);
            this.panel49.Location = new System.Drawing.Point(6, 192);
            this.panel49.Name = "panel49";
            this.panel49.Size = new System.Drawing.Size(289, 32);
            this.panel49.TabIndex = 17;
            // 
            // button144
            // 
            this.button144.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.button144.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button144.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button144.Location = new System.Drawing.Point(194, 3);
            this.button144.Name = "button144";
            this.button144.Size = new System.Drawing.Size(89, 26);
            this.button144.TabIndex = 18;
            this.button144.Text = "button144";
            this.button144.UseVisualStyleBackColor = false;
            // 
            // button142
            // 
            this.button142.BackColor = System.Drawing.Color.White;
            this.button142.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button142.Location = new System.Drawing.Point(4, 3);
            this.button142.Name = "button142";
            this.button142.Size = new System.Drawing.Size(89, 26);
            this.button142.TabIndex = 2;
            this.button142.Text = "button142";
            this.button142.UseVisualStyleBackColor = false;
            // 
            // button143
            // 
            this.button143.BackColor = System.Drawing.Color.White;
            this.button143.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button143.Location = new System.Drawing.Point(99, 3);
            this.button143.Name = "button143";
            this.button143.Size = new System.Drawing.Size(89, 26);
            this.button143.TabIndex = 1;
            this.button143.Text = "button143";
            this.button143.UseVisualStyleBackColor = false;
            // 
            // panel43
            // 
            this.panel43.Controls.Add(this.button124);
            this.panel43.Controls.Add(this.button125);
            this.panel43.Controls.Add(this.button126);
            this.panel43.Location = new System.Drawing.Point(6, 151);
            this.panel43.Name = "panel43";
            this.panel43.Size = new System.Drawing.Size(289, 32);
            this.panel43.TabIndex = 16;
            // 
            // button124
            // 
            this.button124.BackColor = System.Drawing.Color.White;
            this.button124.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button124.Location = new System.Drawing.Point(4, 3);
            this.button124.Name = "button124";
            this.button124.Size = new System.Drawing.Size(89, 26);
            this.button124.TabIndex = 2;
            this.button124.Text = "button124";
            this.button124.UseVisualStyleBackColor = false;
            // 
            // button125
            // 
            this.button125.BackColor = System.Drawing.Color.White;
            this.button125.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button125.Location = new System.Drawing.Point(99, 3);
            this.button125.Name = "button125";
            this.button125.Size = new System.Drawing.Size(89, 26);
            this.button125.TabIndex = 1;
            this.button125.Text = "button125";
            this.button125.UseVisualStyleBackColor = false;
            // 
            // button126
            // 
            this.button126.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.button126.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button126.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button126.Location = new System.Drawing.Point(192, 3);
            this.button126.Name = "button126";
            this.button126.Size = new System.Drawing.Size(89, 26);
            this.button126.TabIndex = 0;
            this.button126.Text = "button126";
            this.button126.UseVisualStyleBackColor = false;
            // 
            // panel37
            // 
            this.panel37.Controls.Add(this.button106);
            this.panel37.Controls.Add(this.button107);
            this.panel37.Controls.Add(this.button108);
            this.panel37.Location = new System.Drawing.Point(6, 113);
            this.panel37.Name = "panel37";
            this.panel37.Size = new System.Drawing.Size(289, 32);
            this.panel37.TabIndex = 15;
            // 
            // button106
            // 
            this.button106.BackColor = System.Drawing.Color.White;
            this.button106.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button106.Location = new System.Drawing.Point(4, 3);
            this.button106.Name = "button106";
            this.button106.Size = new System.Drawing.Size(89, 26);
            this.button106.TabIndex = 2;
            this.button106.Text = "button106";
            this.button106.UseVisualStyleBackColor = false;
            // 
            // button107
            // 
            this.button107.BackColor = System.Drawing.Color.White;
            this.button107.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button107.Location = new System.Drawing.Point(99, 3);
            this.button107.Name = "button107";
            this.button107.Size = new System.Drawing.Size(89, 26);
            this.button107.TabIndex = 1;
            this.button107.Text = "button107";
            this.button107.UseVisualStyleBackColor = false;
            // 
            // button108
            // 
            this.button108.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.button108.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button108.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button108.Location = new System.Drawing.Point(192, 3);
            this.button108.Name = "button108";
            this.button108.Size = new System.Drawing.Size(89, 26);
            this.button108.TabIndex = 0;
            this.button108.Text = "button108";
            this.button108.UseVisualStyleBackColor = false;
            // 
            // panel31
            // 
            this.panel31.Controls.Add(this.button88);
            this.panel31.Controls.Add(this.button89);
            this.panel31.Controls.Add(this.button90);
            this.panel31.Location = new System.Drawing.Point(6, 78);
            this.panel31.Name = "panel31";
            this.panel31.Size = new System.Drawing.Size(289, 32);
            this.panel31.TabIndex = 14;
            // 
            // button88
            // 
            this.button88.BackColor = System.Drawing.Color.White;
            this.button88.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button88.Location = new System.Drawing.Point(4, 3);
            this.button88.Name = "button88";
            this.button88.Size = new System.Drawing.Size(89, 26);
            this.button88.TabIndex = 2;
            this.button88.Text = "button88";
            this.button88.UseVisualStyleBackColor = false;
            // 
            // button89
            // 
            this.button89.BackColor = System.Drawing.Color.White;
            this.button89.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button89.Location = new System.Drawing.Point(99, 3);
            this.button89.Name = "button89";
            this.button89.Size = new System.Drawing.Size(89, 26);
            this.button89.TabIndex = 1;
            this.button89.Text = "button89";
            this.button89.UseVisualStyleBackColor = false;
            // 
            // button90
            // 
            this.button90.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.button90.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button90.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button90.Location = new System.Drawing.Point(192, 3);
            this.button90.Name = "button90";
            this.button90.Size = new System.Drawing.Size(89, 26);
            this.button90.TabIndex = 0;
            this.button90.Text = "button90";
            this.button90.UseVisualStyleBackColor = false;
            // 
            // btnLjOmPurityShiftB
            // 
            this.btnLjOmPurityShiftB.Location = new System.Drawing.Point(198, 46);
            this.btnLjOmPurityShiftB.Name = "btnLjOmPurityShiftB";
            this.btnLjOmPurityShiftB.Size = new System.Drawing.Size(89, 26);
            this.btnLjOmPurityShiftB.TabIndex = 6;
            this.btnLjOmPurityShiftB.Text = "Purity";
            this.btnLjOmPurityShiftB.UseVisualStyleBackColor = true;
            // 
            // btnLjOmPolShiftB
            // 
            this.btnLjOmPolShiftB.Location = new System.Drawing.Point(101, 46);
            this.btnLjOmPolShiftB.Name = "btnLjOmPolShiftB";
            this.btnLjOmPolShiftB.Size = new System.Drawing.Size(89, 26);
            this.btnLjOmPolShiftB.TabIndex = 5;
            this.btnLjOmPolShiftB.Text = "Pol";
            this.btnLjOmPolShiftB.UseVisualStyleBackColor = true;
            // 
            // btnLjOmBrixShiftB
            // 
            this.btnLjOmBrixShiftB.Location = new System.Drawing.Point(6, 46);
            this.btnLjOmBrixShiftB.Name = "btnLjOmBrixShiftB";
            this.btnLjOmBrixShiftB.Size = new System.Drawing.Size(89, 26);
            this.btnLjOmBrixShiftB.TabIndex = 4;
            this.btnLjOmBrixShiftB.Text = "Brix";
            this.btnLjOmBrixShiftB.UseVisualStyleBackColor = true;
            // 
            // btnLjOmShiftB
            // 
            this.btnLjOmShiftB.Location = new System.Drawing.Point(6, 10);
            this.btnLjOmShiftB.Name = "btnLjOmShiftB";
            this.btnLjOmShiftB.Size = new System.Drawing.Size(281, 34);
            this.btnLjOmShiftB.TabIndex = 1;
            this.btnLjOmShiftB.Text = "Old Mill";
            this.btnLjOmShiftB.UseVisualStyleBackColor = true;
            // 
            // groupBox16
            // 
            this.groupBox16.Controls.Add(this.panel90);
            this.groupBox16.Controls.Add(this.panel48);
            this.groupBox16.Controls.Add(this.panel42);
            this.groupBox16.Controls.Add(this.panel36);
            this.groupBox16.Controls.Add(this.panel30);
            this.groupBox16.Controls.Add(this.btnLjNmPurityShiftB);
            this.groupBox16.Controls.Add(this.btnLjNmPolShiftB);
            this.groupBox16.Controls.Add(this.btnLjNmBrixShiftB);
            this.groupBox16.Controls.Add(this.btnLjNmShiftB);
            this.groupBox16.Location = new System.Drawing.Point(6, 32);
            this.groupBox16.Name = "groupBox16";
            this.groupBox16.Size = new System.Drawing.Size(301, 279);
            this.groupBox16.TabIndex = 2;
            this.groupBox16.TabStop = false;
            // 
            // panel90
            // 
            this.panel90.Controls.Add(this.button248);
            this.panel90.Controls.Add(this.button249);
            this.panel90.Controls.Add(this.button250);
            this.panel90.Location = new System.Drawing.Point(8, 233);
            this.panel90.Name = "panel90";
            this.panel90.Size = new System.Drawing.Size(289, 32);
            this.panel90.TabIndex = 18;
            // 
            // button248
            // 
            this.button248.BackColor = System.Drawing.SystemColors.HotTrack;
            this.button248.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button248.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button248.ForeColor = System.Drawing.Color.White;
            this.button248.Location = new System.Drawing.Point(4, 3);
            this.button248.Name = "button248";
            this.button248.Size = new System.Drawing.Size(89, 26);
            this.button248.TabIndex = 2;
            this.button248.Text = "button248";
            this.button248.UseVisualStyleBackColor = false;
            // 
            // button249
            // 
            this.button249.BackColor = System.Drawing.SystemColors.HotTrack;
            this.button249.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button249.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button249.ForeColor = System.Drawing.Color.White;
            this.button249.Location = new System.Drawing.Point(99, 3);
            this.button249.Name = "button249";
            this.button249.Size = new System.Drawing.Size(89, 26);
            this.button249.TabIndex = 1;
            this.button249.Text = "button249";
            this.button249.UseVisualStyleBackColor = false;
            // 
            // button250
            // 
            this.button250.BackColor = System.Drawing.SystemColors.HotTrack;
            this.button250.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button250.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button250.ForeColor = System.Drawing.Color.White;
            this.button250.Location = new System.Drawing.Point(192, 3);
            this.button250.Name = "button250";
            this.button250.Size = new System.Drawing.Size(89, 26);
            this.button250.TabIndex = 0;
            this.button250.Text = "button250";
            this.button250.UseVisualStyleBackColor = false;
            // 
            // panel48
            // 
            this.panel48.Controls.Add(this.button139);
            this.panel48.Controls.Add(this.button140);
            this.panel48.Controls.Add(this.button141);
            this.panel48.Location = new System.Drawing.Point(6, 192);
            this.panel48.Name = "panel48";
            this.panel48.Size = new System.Drawing.Size(289, 32);
            this.panel48.TabIndex = 17;
            // 
            // button139
            // 
            this.button139.BackColor = System.Drawing.Color.White;
            this.button139.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button139.Location = new System.Drawing.Point(4, 3);
            this.button139.Name = "button139";
            this.button139.Size = new System.Drawing.Size(89, 26);
            this.button139.TabIndex = 2;
            this.button139.Text = "button139";
            this.button139.UseVisualStyleBackColor = false;
            // 
            // button140
            // 
            this.button140.BackColor = System.Drawing.Color.White;
            this.button140.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button140.Location = new System.Drawing.Point(99, 3);
            this.button140.Name = "button140";
            this.button140.Size = new System.Drawing.Size(89, 26);
            this.button140.TabIndex = 1;
            this.button140.Text = "button140";
            this.button140.UseVisualStyleBackColor = false;
            // 
            // button141
            // 
            this.button141.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.button141.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button141.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button141.Location = new System.Drawing.Point(192, 3);
            this.button141.Name = "button141";
            this.button141.Size = new System.Drawing.Size(89, 26);
            this.button141.TabIndex = 0;
            this.button141.Text = "button141";
            this.button141.UseVisualStyleBackColor = false;
            // 
            // panel42
            // 
            this.panel42.Controls.Add(this.button121);
            this.panel42.Controls.Add(this.button122);
            this.panel42.Controls.Add(this.button123);
            this.panel42.Location = new System.Drawing.Point(6, 154);
            this.panel42.Name = "panel42";
            this.panel42.Size = new System.Drawing.Size(289, 32);
            this.panel42.TabIndex = 16;
            // 
            // button121
            // 
            this.button121.BackColor = System.Drawing.Color.White;
            this.button121.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button121.Location = new System.Drawing.Point(4, 3);
            this.button121.Name = "button121";
            this.button121.Size = new System.Drawing.Size(89, 26);
            this.button121.TabIndex = 2;
            this.button121.Text = "button121";
            this.button121.UseVisualStyleBackColor = false;
            // 
            // button122
            // 
            this.button122.BackColor = System.Drawing.Color.White;
            this.button122.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button122.Location = new System.Drawing.Point(99, 3);
            this.button122.Name = "button122";
            this.button122.Size = new System.Drawing.Size(89, 26);
            this.button122.TabIndex = 1;
            this.button122.Text = "button122";
            this.button122.UseVisualStyleBackColor = false;
            // 
            // button123
            // 
            this.button123.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.button123.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button123.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button123.Location = new System.Drawing.Point(192, 3);
            this.button123.Name = "button123";
            this.button123.Size = new System.Drawing.Size(89, 26);
            this.button123.TabIndex = 0;
            this.button123.Text = "button123";
            this.button123.UseVisualStyleBackColor = false;
            // 
            // panel36
            // 
            this.panel36.Controls.Add(this.button103);
            this.panel36.Controls.Add(this.button104);
            this.panel36.Controls.Add(this.button105);
            this.panel36.Location = new System.Drawing.Point(6, 116);
            this.panel36.Name = "panel36";
            this.panel36.Size = new System.Drawing.Size(289, 32);
            this.panel36.TabIndex = 15;
            // 
            // button103
            // 
            this.button103.BackColor = System.Drawing.Color.White;
            this.button103.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button103.Location = new System.Drawing.Point(4, 3);
            this.button103.Name = "button103";
            this.button103.Size = new System.Drawing.Size(89, 26);
            this.button103.TabIndex = 2;
            this.button103.Text = "button103";
            this.button103.UseVisualStyleBackColor = false;
            // 
            // button104
            // 
            this.button104.BackColor = System.Drawing.Color.White;
            this.button104.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button104.Location = new System.Drawing.Point(99, 3);
            this.button104.Name = "button104";
            this.button104.Size = new System.Drawing.Size(89, 26);
            this.button104.TabIndex = 1;
            this.button104.Text = "button104";
            this.button104.UseVisualStyleBackColor = false;
            // 
            // button105
            // 
            this.button105.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.button105.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button105.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button105.Location = new System.Drawing.Point(192, 3);
            this.button105.Name = "button105";
            this.button105.Size = new System.Drawing.Size(89, 26);
            this.button105.TabIndex = 0;
            this.button105.Text = "button105";
            this.button105.UseVisualStyleBackColor = false;
            // 
            // panel30
            // 
            this.panel30.Controls.Add(this.button85);
            this.panel30.Controls.Add(this.button86);
            this.panel30.Controls.Add(this.button87);
            this.panel30.Location = new System.Drawing.Point(6, 81);
            this.panel30.Name = "panel30";
            this.panel30.Size = new System.Drawing.Size(289, 32);
            this.panel30.TabIndex = 14;
            // 
            // button85
            // 
            this.button85.BackColor = System.Drawing.Color.White;
            this.button85.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button85.Location = new System.Drawing.Point(4, 3);
            this.button85.Name = "button85";
            this.button85.Size = new System.Drawing.Size(89, 26);
            this.button85.TabIndex = 2;
            this.button85.Text = "button85";
            this.button85.UseVisualStyleBackColor = false;
            // 
            // button86
            // 
            this.button86.BackColor = System.Drawing.Color.White;
            this.button86.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button86.Location = new System.Drawing.Point(99, 3);
            this.button86.Name = "button86";
            this.button86.Size = new System.Drawing.Size(89, 26);
            this.button86.TabIndex = 1;
            this.button86.Text = "button86";
            this.button86.UseVisualStyleBackColor = false;
            // 
            // button87
            // 
            this.button87.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.button87.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button87.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button87.Location = new System.Drawing.Point(192, 3);
            this.button87.Name = "button87";
            this.button87.Size = new System.Drawing.Size(89, 26);
            this.button87.TabIndex = 0;
            this.button87.Text = "button87";
            this.button87.UseVisualStyleBackColor = false;
            // 
            // btnLjNmPurityShiftB
            // 
            this.btnLjNmPurityShiftB.Location = new System.Drawing.Point(198, 46);
            this.btnLjNmPurityShiftB.Name = "btnLjNmPurityShiftB";
            this.btnLjNmPurityShiftB.Size = new System.Drawing.Size(89, 26);
            this.btnLjNmPurityShiftB.TabIndex = 6;
            this.btnLjNmPurityShiftB.Text = "Purity";
            this.btnLjNmPurityShiftB.UseVisualStyleBackColor = true;
            // 
            // btnLjNmPolShiftB
            // 
            this.btnLjNmPolShiftB.Location = new System.Drawing.Point(101, 46);
            this.btnLjNmPolShiftB.Name = "btnLjNmPolShiftB";
            this.btnLjNmPolShiftB.Size = new System.Drawing.Size(89, 26);
            this.btnLjNmPolShiftB.TabIndex = 5;
            this.btnLjNmPolShiftB.Text = "Pol";
            this.btnLjNmPolShiftB.UseVisualStyleBackColor = true;
            // 
            // btnLjNmBrixShiftB
            // 
            this.btnLjNmBrixShiftB.Location = new System.Drawing.Point(6, 46);
            this.btnLjNmBrixShiftB.Name = "btnLjNmBrixShiftB";
            this.btnLjNmBrixShiftB.Size = new System.Drawing.Size(89, 26);
            this.btnLjNmBrixShiftB.TabIndex = 4;
            this.btnLjNmBrixShiftB.Text = "Brix";
            this.btnLjNmBrixShiftB.UseVisualStyleBackColor = true;
            // 
            // btnLjNmShiftB
            // 
            this.btnLjNmShiftB.Location = new System.Drawing.Point(6, 10);
            this.btnLjNmShiftB.Name = "btnLjNmShiftB";
            this.btnLjNmShiftB.Size = new System.Drawing.Size(281, 34);
            this.btnLjNmShiftB.TabIndex = 1;
            this.btnLjNmShiftB.Text = "New Mill";
            this.btnLjNmShiftB.UseVisualStyleBackColor = true;
            // 
            // btnLastJuiceShiftB
            // 
            this.btnLastJuiceShiftB.Location = new System.Drawing.Point(6, 10);
            this.btnLastJuiceShiftB.Name = "btnLastJuiceShiftB";
            this.btnLastJuiceShiftB.Size = new System.Drawing.Size(620, 23);
            this.btnLastJuiceShiftB.TabIndex = 1;
            this.btnLastJuiceShiftB.Text = "Last Juice";
            this.btnLastJuiceShiftB.UseVisualStyleBackColor = true;
            // 
            // groupBox17
            // 
            this.groupBox17.Controls.Add(this.groupBox18);
            this.groupBox17.Controls.Add(this.groupBox19);
            this.groupBox17.Controls.Add(this.btnMixedJuiceShiftB);
            this.groupBox17.Location = new System.Drawing.Point(765, 12);
            this.groupBox17.Name = "groupBox17";
            this.groupBox17.Size = new System.Drawing.Size(636, 330);
            this.groupBox17.TabIndex = 2;
            this.groupBox17.TabStop = false;
            // 
            // groupBox18
            // 
            this.groupBox18.Controls.Add(this.panel89);
            this.groupBox18.Controls.Add(this.panel47);
            this.groupBox18.Controls.Add(this.panel41);
            this.groupBox18.Controls.Add(this.panel35);
            this.groupBox18.Controls.Add(this.panel29);
            this.groupBox18.Controls.Add(this.btnMjOmPurityShiftB);
            this.groupBox18.Controls.Add(this.btnMjOmPolShiftB);
            this.groupBox18.Controls.Add(this.btnMjOmBrixShiftB);
            this.groupBox18.Controls.Add(this.btnMjOmShiftB);
            this.groupBox18.Location = new System.Drawing.Point(325, 32);
            this.groupBox18.Name = "groupBox18";
            this.groupBox18.Size = new System.Drawing.Size(301, 279);
            this.groupBox18.TabIndex = 3;
            this.groupBox18.TabStop = false;
            // 
            // panel89
            // 
            this.panel89.Controls.Add(this.button245);
            this.panel89.Controls.Add(this.button246);
            this.panel89.Controls.Add(this.button247);
            this.panel89.Location = new System.Drawing.Point(8, 237);
            this.panel89.Name = "panel89";
            this.panel89.Size = new System.Drawing.Size(289, 32);
            this.panel89.TabIndex = 18;
            // 
            // button245
            // 
            this.button245.BackColor = System.Drawing.SystemColors.HotTrack;
            this.button245.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button245.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button245.ForeColor = System.Drawing.Color.White;
            this.button245.Location = new System.Drawing.Point(4, 3);
            this.button245.Name = "button245";
            this.button245.Size = new System.Drawing.Size(89, 26);
            this.button245.TabIndex = 2;
            this.button245.Text = "button245";
            this.button245.UseVisualStyleBackColor = false;
            // 
            // button246
            // 
            this.button246.BackColor = System.Drawing.SystemColors.HotTrack;
            this.button246.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button246.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button246.ForeColor = System.Drawing.Color.White;
            this.button246.Location = new System.Drawing.Point(99, 3);
            this.button246.Name = "button246";
            this.button246.Size = new System.Drawing.Size(89, 26);
            this.button246.TabIndex = 1;
            this.button246.Text = "button246";
            this.button246.UseVisualStyleBackColor = false;
            // 
            // button247
            // 
            this.button247.BackColor = System.Drawing.SystemColors.HotTrack;
            this.button247.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button247.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button247.ForeColor = System.Drawing.Color.White;
            this.button247.Location = new System.Drawing.Point(192, 3);
            this.button247.Name = "button247";
            this.button247.Size = new System.Drawing.Size(89, 26);
            this.button247.TabIndex = 0;
            this.button247.Text = "button247";
            this.button247.UseVisualStyleBackColor = false;
            // 
            // panel47
            // 
            this.panel47.Controls.Add(this.button136);
            this.panel47.Controls.Add(this.button137);
            this.panel47.Controls.Add(this.button138);
            this.panel47.Location = new System.Drawing.Point(6, 195);
            this.panel47.Name = "panel47";
            this.panel47.Size = new System.Drawing.Size(289, 32);
            this.panel47.TabIndex = 17;
            // 
            // button136
            // 
            this.button136.BackColor = System.Drawing.Color.White;
            this.button136.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button136.Location = new System.Drawing.Point(4, 3);
            this.button136.Name = "button136";
            this.button136.Size = new System.Drawing.Size(89, 26);
            this.button136.TabIndex = 2;
            this.button136.Text = "button136";
            this.button136.UseVisualStyleBackColor = false;
            // 
            // button137
            // 
            this.button137.BackColor = System.Drawing.Color.White;
            this.button137.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button137.Location = new System.Drawing.Point(99, 3);
            this.button137.Name = "button137";
            this.button137.Size = new System.Drawing.Size(89, 26);
            this.button137.TabIndex = 1;
            this.button137.Text = "button137";
            this.button137.UseVisualStyleBackColor = false;
            // 
            // button138
            // 
            this.button138.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.button138.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button138.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button138.Location = new System.Drawing.Point(192, 3);
            this.button138.Name = "button138";
            this.button138.Size = new System.Drawing.Size(89, 26);
            this.button138.TabIndex = 0;
            this.button138.Text = "button138";
            this.button138.UseVisualStyleBackColor = false;
            // 
            // panel41
            // 
            this.panel41.Controls.Add(this.button118);
            this.panel41.Controls.Add(this.button119);
            this.panel41.Controls.Add(this.button120);
            this.panel41.Location = new System.Drawing.Point(6, 157);
            this.panel41.Name = "panel41";
            this.panel41.Size = new System.Drawing.Size(289, 32);
            this.panel41.TabIndex = 16;
            // 
            // button118
            // 
            this.button118.BackColor = System.Drawing.Color.White;
            this.button118.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button118.Location = new System.Drawing.Point(4, 3);
            this.button118.Name = "button118";
            this.button118.Size = new System.Drawing.Size(89, 26);
            this.button118.TabIndex = 2;
            this.button118.Text = "button118";
            this.button118.UseVisualStyleBackColor = false;
            // 
            // button119
            // 
            this.button119.BackColor = System.Drawing.Color.White;
            this.button119.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button119.Location = new System.Drawing.Point(99, 3);
            this.button119.Name = "button119";
            this.button119.Size = new System.Drawing.Size(89, 26);
            this.button119.TabIndex = 1;
            this.button119.Text = "button119";
            this.button119.UseVisualStyleBackColor = false;
            // 
            // button120
            // 
            this.button120.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.button120.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button120.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button120.Location = new System.Drawing.Point(192, 3);
            this.button120.Name = "button120";
            this.button120.Size = new System.Drawing.Size(89, 26);
            this.button120.TabIndex = 0;
            this.button120.Text = "button120";
            this.button120.UseVisualStyleBackColor = false;
            // 
            // panel35
            // 
            this.panel35.Controls.Add(this.button100);
            this.panel35.Controls.Add(this.button101);
            this.panel35.Controls.Add(this.button102);
            this.panel35.Location = new System.Drawing.Point(6, 119);
            this.panel35.Name = "panel35";
            this.panel35.Size = new System.Drawing.Size(289, 32);
            this.panel35.TabIndex = 15;
            // 
            // button100
            // 
            this.button100.BackColor = System.Drawing.Color.White;
            this.button100.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button100.Location = new System.Drawing.Point(4, 3);
            this.button100.Name = "button100";
            this.button100.Size = new System.Drawing.Size(89, 26);
            this.button100.TabIndex = 2;
            this.button100.Text = "button100";
            this.button100.UseVisualStyleBackColor = false;
            // 
            // button101
            // 
            this.button101.BackColor = System.Drawing.Color.White;
            this.button101.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button101.Location = new System.Drawing.Point(99, 3);
            this.button101.Name = "button101";
            this.button101.Size = new System.Drawing.Size(89, 26);
            this.button101.TabIndex = 1;
            this.button101.Text = "button101";
            this.button101.UseVisualStyleBackColor = false;
            // 
            // button102
            // 
            this.button102.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.button102.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button102.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button102.Location = new System.Drawing.Point(192, 3);
            this.button102.Name = "button102";
            this.button102.Size = new System.Drawing.Size(89, 26);
            this.button102.TabIndex = 0;
            this.button102.Text = "button102";
            this.button102.UseVisualStyleBackColor = false;
            // 
            // panel29
            // 
            this.panel29.Controls.Add(this.button82);
            this.panel29.Controls.Add(this.button83);
            this.panel29.Controls.Add(this.button84);
            this.panel29.Location = new System.Drawing.Point(6, 84);
            this.panel29.Name = "panel29";
            this.panel29.Size = new System.Drawing.Size(289, 32);
            this.panel29.TabIndex = 14;
            // 
            // button82
            // 
            this.button82.BackColor = System.Drawing.Color.White;
            this.button82.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button82.Location = new System.Drawing.Point(4, 3);
            this.button82.Name = "button82";
            this.button82.Size = new System.Drawing.Size(89, 26);
            this.button82.TabIndex = 2;
            this.button82.Text = "button82";
            this.button82.UseVisualStyleBackColor = false;
            // 
            // button83
            // 
            this.button83.BackColor = System.Drawing.Color.White;
            this.button83.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button83.Location = new System.Drawing.Point(99, 3);
            this.button83.Name = "button83";
            this.button83.Size = new System.Drawing.Size(89, 26);
            this.button83.TabIndex = 1;
            this.button83.Text = "button83";
            this.button83.UseVisualStyleBackColor = false;
            // 
            // button84
            // 
            this.button84.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.button84.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button84.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button84.Location = new System.Drawing.Point(192, 3);
            this.button84.Name = "button84";
            this.button84.Size = new System.Drawing.Size(89, 26);
            this.button84.TabIndex = 0;
            this.button84.Text = "button84";
            this.button84.UseVisualStyleBackColor = false;
            // 
            // btnMjOmPurityShiftB
            // 
            this.btnMjOmPurityShiftB.Location = new System.Drawing.Point(198, 46);
            this.btnMjOmPurityShiftB.Name = "btnMjOmPurityShiftB";
            this.btnMjOmPurityShiftB.Size = new System.Drawing.Size(89, 26);
            this.btnMjOmPurityShiftB.TabIndex = 6;
            this.btnMjOmPurityShiftB.Text = "Purity";
            this.btnMjOmPurityShiftB.UseVisualStyleBackColor = true;
            // 
            // btnMjOmPolShiftB
            // 
            this.btnMjOmPolShiftB.Location = new System.Drawing.Point(101, 46);
            this.btnMjOmPolShiftB.Name = "btnMjOmPolShiftB";
            this.btnMjOmPolShiftB.Size = new System.Drawing.Size(89, 26);
            this.btnMjOmPolShiftB.TabIndex = 5;
            this.btnMjOmPolShiftB.Text = "Pol";
            this.btnMjOmPolShiftB.UseVisualStyleBackColor = true;
            // 
            // btnMjOmBrixShiftB
            // 
            this.btnMjOmBrixShiftB.Location = new System.Drawing.Point(6, 46);
            this.btnMjOmBrixShiftB.Name = "btnMjOmBrixShiftB";
            this.btnMjOmBrixShiftB.Size = new System.Drawing.Size(89, 26);
            this.btnMjOmBrixShiftB.TabIndex = 4;
            this.btnMjOmBrixShiftB.Text = "Brix";
            this.btnMjOmBrixShiftB.UseVisualStyleBackColor = true;
            // 
            // btnMjOmShiftB
            // 
            this.btnMjOmShiftB.Location = new System.Drawing.Point(6, 10);
            this.btnMjOmShiftB.Name = "btnMjOmShiftB";
            this.btnMjOmShiftB.Size = new System.Drawing.Size(281, 34);
            this.btnMjOmShiftB.TabIndex = 1;
            this.btnMjOmShiftB.Text = "Old Mill";
            this.btnMjOmShiftB.UseVisualStyleBackColor = true;
            // 
            // groupBox19
            // 
            this.groupBox19.Controls.Add(this.panel88);
            this.groupBox19.Controls.Add(this.panel46);
            this.groupBox19.Controls.Add(this.panel40);
            this.groupBox19.Controls.Add(this.panel34);
            this.groupBox19.Controls.Add(this.panel27);
            this.groupBox19.Controls.Add(this.btnMjNmPurityShiftB);
            this.groupBox19.Controls.Add(this.btnMjNmPolShiftB);
            this.groupBox19.Controls.Add(this.btnMjNmBrixShiftB);
            this.groupBox19.Controls.Add(this.btnMjNmShiftB);
            this.groupBox19.Location = new System.Drawing.Point(6, 32);
            this.groupBox19.Name = "groupBox19";
            this.groupBox19.Size = new System.Drawing.Size(301, 279);
            this.groupBox19.TabIndex = 2;
            this.groupBox19.TabStop = false;
            // 
            // panel88
            // 
            this.panel88.Controls.Add(this.button242);
            this.panel88.Controls.Add(this.button243);
            this.panel88.Controls.Add(this.button244);
            this.panel88.Location = new System.Drawing.Point(12, 236);
            this.panel88.Name = "panel88";
            this.panel88.Size = new System.Drawing.Size(289, 32);
            this.panel88.TabIndex = 18;
            // 
            // button242
            // 
            this.button242.BackColor = System.Drawing.SystemColors.HotTrack;
            this.button242.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button242.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button242.ForeColor = System.Drawing.Color.White;
            this.button242.Location = new System.Drawing.Point(4, 3);
            this.button242.Name = "button242";
            this.button242.Size = new System.Drawing.Size(89, 26);
            this.button242.TabIndex = 2;
            this.button242.Text = "button242";
            this.button242.UseVisualStyleBackColor = false;
            // 
            // button243
            // 
            this.button243.BackColor = System.Drawing.SystemColors.HotTrack;
            this.button243.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button243.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button243.ForeColor = System.Drawing.Color.White;
            this.button243.Location = new System.Drawing.Point(99, 3);
            this.button243.Name = "button243";
            this.button243.Size = new System.Drawing.Size(89, 26);
            this.button243.TabIndex = 1;
            this.button243.Text = "button243";
            this.button243.UseVisualStyleBackColor = false;
            // 
            // button244
            // 
            this.button244.BackColor = System.Drawing.SystemColors.HotTrack;
            this.button244.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button244.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button244.ForeColor = System.Drawing.Color.White;
            this.button244.Location = new System.Drawing.Point(192, 3);
            this.button244.Name = "button244";
            this.button244.Size = new System.Drawing.Size(89, 26);
            this.button244.TabIndex = 0;
            this.button244.Text = "button244";
            this.button244.UseVisualStyleBackColor = false;
            // 
            // panel46
            // 
            this.panel46.Controls.Add(this.button133);
            this.panel46.Controls.Add(this.button134);
            this.panel46.Controls.Add(this.button135);
            this.panel46.Location = new System.Drawing.Point(8, 195);
            this.panel46.Name = "panel46";
            this.panel46.Size = new System.Drawing.Size(289, 32);
            this.panel46.TabIndex = 17;
            // 
            // button133
            // 
            this.button133.BackColor = System.Drawing.Color.White;
            this.button133.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button133.Location = new System.Drawing.Point(4, 3);
            this.button133.Name = "button133";
            this.button133.Size = new System.Drawing.Size(89, 26);
            this.button133.TabIndex = 2;
            this.button133.Text = "button133";
            this.button133.UseVisualStyleBackColor = false;
            // 
            // button134
            // 
            this.button134.BackColor = System.Drawing.Color.White;
            this.button134.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button134.Location = new System.Drawing.Point(99, 3);
            this.button134.Name = "button134";
            this.button134.Size = new System.Drawing.Size(89, 26);
            this.button134.TabIndex = 1;
            this.button134.Text = "button134";
            this.button134.UseVisualStyleBackColor = false;
            // 
            // button135
            // 
            this.button135.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.button135.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button135.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button135.Location = new System.Drawing.Point(192, 3);
            this.button135.Name = "button135";
            this.button135.Size = new System.Drawing.Size(89, 26);
            this.button135.TabIndex = 0;
            this.button135.Text = "button135";
            this.button135.UseVisualStyleBackColor = false;
            // 
            // panel40
            // 
            this.panel40.Controls.Add(this.button115);
            this.panel40.Controls.Add(this.button116);
            this.panel40.Controls.Add(this.button117);
            this.panel40.Location = new System.Drawing.Point(12, 157);
            this.panel40.Name = "panel40";
            this.panel40.Size = new System.Drawing.Size(289, 32);
            this.panel40.TabIndex = 16;
            // 
            // button115
            // 
            this.button115.BackColor = System.Drawing.Color.White;
            this.button115.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button115.Location = new System.Drawing.Point(4, 3);
            this.button115.Name = "button115";
            this.button115.Size = new System.Drawing.Size(89, 26);
            this.button115.TabIndex = 2;
            this.button115.Text = "button115";
            this.button115.UseVisualStyleBackColor = false;
            // 
            // button116
            // 
            this.button116.BackColor = System.Drawing.Color.White;
            this.button116.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button116.Location = new System.Drawing.Point(99, 3);
            this.button116.Name = "button116";
            this.button116.Size = new System.Drawing.Size(89, 26);
            this.button116.TabIndex = 1;
            this.button116.Text = "button116";
            this.button116.UseVisualStyleBackColor = false;
            // 
            // button117
            // 
            this.button117.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.button117.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button117.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button117.Location = new System.Drawing.Point(192, 3);
            this.button117.Name = "button117";
            this.button117.Size = new System.Drawing.Size(89, 26);
            this.button117.TabIndex = 0;
            this.button117.Text = "button117";
            this.button117.UseVisualStyleBackColor = false;
            // 
            // panel34
            // 
            this.panel34.Controls.Add(this.button97);
            this.panel34.Controls.Add(this.button98);
            this.panel34.Controls.Add(this.button99);
            this.panel34.Location = new System.Drawing.Point(12, 119);
            this.panel34.Name = "panel34";
            this.panel34.Size = new System.Drawing.Size(289, 32);
            this.panel34.TabIndex = 15;
            // 
            // button97
            // 
            this.button97.BackColor = System.Drawing.Color.White;
            this.button97.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button97.Location = new System.Drawing.Point(4, 3);
            this.button97.Name = "button97";
            this.button97.Size = new System.Drawing.Size(89, 26);
            this.button97.TabIndex = 2;
            this.button97.Text = "button97";
            this.button97.UseVisualStyleBackColor = false;
            // 
            // button98
            // 
            this.button98.BackColor = System.Drawing.Color.White;
            this.button98.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button98.Location = new System.Drawing.Point(99, 3);
            this.button98.Name = "button98";
            this.button98.Size = new System.Drawing.Size(89, 26);
            this.button98.TabIndex = 1;
            this.button98.Text = "button98";
            this.button98.UseVisualStyleBackColor = false;
            // 
            // button99
            // 
            this.button99.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.button99.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button99.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button99.Location = new System.Drawing.Point(192, 3);
            this.button99.Name = "button99";
            this.button99.Size = new System.Drawing.Size(89, 26);
            this.button99.TabIndex = 0;
            this.button99.Text = "button99";
            this.button99.UseVisualStyleBackColor = false;
            // 
            // panel27
            // 
            this.panel27.Controls.Add(this.button79);
            this.panel27.Controls.Add(this.button80);
            this.panel27.Controls.Add(this.button81);
            this.panel27.Location = new System.Drawing.Point(10, 84);
            this.panel27.Name = "panel27";
            this.panel27.Size = new System.Drawing.Size(289, 32);
            this.panel27.TabIndex = 14;
            // 
            // button79
            // 
            this.button79.BackColor = System.Drawing.Color.White;
            this.button79.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button79.Location = new System.Drawing.Point(4, 3);
            this.button79.Name = "button79";
            this.button79.Size = new System.Drawing.Size(89, 26);
            this.button79.TabIndex = 2;
            this.button79.Text = "button79";
            this.button79.UseVisualStyleBackColor = false;
            // 
            // button80
            // 
            this.button80.BackColor = System.Drawing.Color.White;
            this.button80.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button80.Location = new System.Drawing.Point(99, 3);
            this.button80.Name = "button80";
            this.button80.Size = new System.Drawing.Size(89, 26);
            this.button80.TabIndex = 1;
            this.button80.Text = "button80";
            this.button80.UseVisualStyleBackColor = false;
            // 
            // button81
            // 
            this.button81.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.button81.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button81.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button81.Location = new System.Drawing.Point(192, 3);
            this.button81.Name = "button81";
            this.button81.Size = new System.Drawing.Size(89, 26);
            this.button81.TabIndex = 0;
            this.button81.Text = "button81";
            this.button81.UseVisualStyleBackColor = false;
            // 
            // btnMjNmPurityShiftB
            // 
            this.btnMjNmPurityShiftB.Location = new System.Drawing.Point(198, 46);
            this.btnMjNmPurityShiftB.Name = "btnMjNmPurityShiftB";
            this.btnMjNmPurityShiftB.Size = new System.Drawing.Size(89, 26);
            this.btnMjNmPurityShiftB.TabIndex = 6;
            this.btnMjNmPurityShiftB.Text = "Purity";
            this.btnMjNmPurityShiftB.UseVisualStyleBackColor = true;
            // 
            // btnMjNmPolShiftB
            // 
            this.btnMjNmPolShiftB.Location = new System.Drawing.Point(101, 46);
            this.btnMjNmPolShiftB.Name = "btnMjNmPolShiftB";
            this.btnMjNmPolShiftB.Size = new System.Drawing.Size(89, 26);
            this.btnMjNmPolShiftB.TabIndex = 5;
            this.btnMjNmPolShiftB.Text = "Pol";
            this.btnMjNmPolShiftB.UseVisualStyleBackColor = true;
            // 
            // btnMjNmBrixShiftB
            // 
            this.btnMjNmBrixShiftB.Location = new System.Drawing.Point(6, 46);
            this.btnMjNmBrixShiftB.Name = "btnMjNmBrixShiftB";
            this.btnMjNmBrixShiftB.Size = new System.Drawing.Size(89, 26);
            this.btnMjNmBrixShiftB.TabIndex = 4;
            this.btnMjNmBrixShiftB.Text = "Brix";
            this.btnMjNmBrixShiftB.UseVisualStyleBackColor = true;
            // 
            // btnMjNmShiftB
            // 
            this.btnMjNmShiftB.Location = new System.Drawing.Point(6, 10);
            this.btnMjNmShiftB.Name = "btnMjNmShiftB";
            this.btnMjNmShiftB.Size = new System.Drawing.Size(281, 34);
            this.btnMjNmShiftB.TabIndex = 1;
            this.btnMjNmShiftB.Text = "New Mill";
            this.btnMjNmShiftB.UseVisualStyleBackColor = true;
            // 
            // btnMixedJuiceShiftB
            // 
            this.btnMixedJuiceShiftB.Location = new System.Drawing.Point(6, 10);
            this.btnMixedJuiceShiftB.Name = "btnMixedJuiceShiftB";
            this.btnMixedJuiceShiftB.Size = new System.Drawing.Size(620, 23);
            this.btnMixedJuiceShiftB.TabIndex = 1;
            this.btnMixedJuiceShiftB.Text = "Mixed Juice";
            this.btnMixedJuiceShiftB.UseVisualStyleBackColor = true;
            // 
            // groupBox20
            // 
            this.groupBox20.Controls.Add(this.btnAvgShiftB);
            this.groupBox20.Controls.Add(this.btnTime24);
            this.groupBox20.Controls.Add(this.btnTime22);
            this.groupBox20.Controls.Add(this.btnTime20);
            this.groupBox20.Controls.Add(this.btnTime18);
            this.groupBox20.Controls.Add(this.btnTimeShiftB);
            this.groupBox20.Location = new System.Drawing.Point(15, 54);
            this.groupBox20.Name = "groupBox20";
            this.groupBox20.Size = new System.Drawing.Size(92, 281);
            this.groupBox20.TabIndex = 1;
            this.groupBox20.TabStop = false;
            // 
            // btnAvgShiftB
            // 
            this.btnAvgShiftB.Location = new System.Drawing.Point(11, 230);
            this.btnAvgShiftB.Name = "btnAvgShiftB";
            this.btnAvgShiftB.Size = new System.Drawing.Size(75, 26);
            this.btnAvgShiftB.TabIndex = 6;
            this.btnAvgShiftB.Text = "Average";
            this.btnAvgShiftB.UseVisualStyleBackColor = true;
            // 
            // btnTime24
            // 
            this.btnTime24.Location = new System.Drawing.Point(11, 188);
            this.btnTime24.Name = "btnTime24";
            this.btnTime24.Size = new System.Drawing.Size(75, 26);
            this.btnTime24.TabIndex = 5;
            this.btnTime24.Text = "24";
            this.btnTime24.UseVisualStyleBackColor = true;
            // 
            // btnTime22
            // 
            this.btnTime22.Location = new System.Drawing.Point(11, 153);
            this.btnTime22.Name = "btnTime22";
            this.btnTime22.Size = new System.Drawing.Size(75, 26);
            this.btnTime22.TabIndex = 4;
            this.btnTime22.Text = "22";
            this.btnTime22.UseVisualStyleBackColor = true;
            // 
            // btnTime20
            // 
            this.btnTime20.Location = new System.Drawing.Point(11, 115);
            this.btnTime20.Name = "btnTime20";
            this.btnTime20.Size = new System.Drawing.Size(75, 26);
            this.btnTime20.TabIndex = 3;
            this.btnTime20.Text = "20";
            this.btnTime20.UseVisualStyleBackColor = true;
            // 
            // btnTime18
            // 
            this.btnTime18.Location = new System.Drawing.Point(11, 77);
            this.btnTime18.Name = "btnTime18";
            this.btnTime18.Size = new System.Drawing.Size(75, 26);
            this.btnTime18.TabIndex = 2;
            this.btnTime18.Text = "18";
            this.btnTime18.UseVisualStyleBackColor = true;
            // 
            // btnTimeShiftB
            // 
            this.btnTimeShiftB.Location = new System.Drawing.Point(10, 12);
            this.btnTimeShiftB.Name = "btnTimeShiftB";
            this.btnTimeShiftB.Size = new System.Drawing.Size(76, 56);
            this.btnTimeShiftB.TabIndex = 2;
            this.btnTimeShiftB.Text = "Time";
            this.btnTimeShiftB.UseVisualStyleBackColor = true;
            // 
            // groupBox21
            // 
            this.groupBox21.Controls.Add(this.groupBox22);
            this.groupBox21.Controls.Add(this.groupBox23);
            this.groupBox21.Controls.Add(this.btnPrimaryJuiceShiftB);
            this.groupBox21.Location = new System.Drawing.Point(123, 12);
            this.groupBox21.Name = "groupBox21";
            this.groupBox21.Size = new System.Drawing.Size(636, 330);
            this.groupBox21.TabIndex = 0;
            this.groupBox21.TabStop = false;
            // 
            // groupBox22
            // 
            this.groupBox22.Controls.Add(this.panel87);
            this.groupBox22.Controls.Add(this.panel45);
            this.groupBox22.Controls.Add(this.panel39);
            this.groupBox22.Controls.Add(this.panel33);
            this.groupBox22.Controls.Add(this.panel26);
            this.groupBox22.Controls.Add(this.btnPjOmPurityShiftB);
            this.groupBox22.Controls.Add(this.btnPjOmPolShiftB);
            this.groupBox22.Controls.Add(this.btnPjOmBrixShiftB);
            this.groupBox22.Controls.Add(this.btnPjOmShiftB);
            this.groupBox22.Location = new System.Drawing.Point(319, 32);
            this.groupBox22.Name = "groupBox22";
            this.groupBox22.Size = new System.Drawing.Size(301, 279);
            this.groupBox22.TabIndex = 2;
            this.groupBox22.TabStop = false;
            // 
            // panel87
            // 
            this.panel87.Controls.Add(this.button239);
            this.panel87.Controls.Add(this.button240);
            this.panel87.Controls.Add(this.button241);
            this.panel87.Location = new System.Drawing.Point(6, 233);
            this.panel87.Name = "panel87";
            this.panel87.Size = new System.Drawing.Size(289, 32);
            this.panel87.TabIndex = 18;
            // 
            // button239
            // 
            this.button239.BackColor = System.Drawing.SystemColors.HotTrack;
            this.button239.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button239.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button239.ForeColor = System.Drawing.Color.White;
            this.button239.Location = new System.Drawing.Point(4, 3);
            this.button239.Name = "button239";
            this.button239.Size = new System.Drawing.Size(89, 26);
            this.button239.TabIndex = 2;
            this.button239.Text = "button239";
            this.button239.UseVisualStyleBackColor = false;
            // 
            // button240
            // 
            this.button240.BackColor = System.Drawing.SystemColors.HotTrack;
            this.button240.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button240.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button240.ForeColor = System.Drawing.Color.White;
            this.button240.Location = new System.Drawing.Point(99, 3);
            this.button240.Name = "button240";
            this.button240.Size = new System.Drawing.Size(89, 26);
            this.button240.TabIndex = 1;
            this.button240.Text = "button240";
            this.button240.UseVisualStyleBackColor = false;
            // 
            // button241
            // 
            this.button241.BackColor = System.Drawing.SystemColors.HotTrack;
            this.button241.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button241.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button241.ForeColor = System.Drawing.Color.White;
            this.button241.Location = new System.Drawing.Point(192, 3);
            this.button241.Name = "button241";
            this.button241.Size = new System.Drawing.Size(89, 26);
            this.button241.TabIndex = 0;
            this.button241.Text = "button241";
            this.button241.UseVisualStyleBackColor = false;
            // 
            // panel45
            // 
            this.panel45.Controls.Add(this.button130);
            this.panel45.Controls.Add(this.button131);
            this.panel45.Controls.Add(this.button132);
            this.panel45.Location = new System.Drawing.Point(6, 195);
            this.panel45.Name = "panel45";
            this.panel45.Size = new System.Drawing.Size(289, 32);
            this.panel45.TabIndex = 17;
            // 
            // button130
            // 
            this.button130.BackColor = System.Drawing.Color.White;
            this.button130.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button130.Location = new System.Drawing.Point(4, 3);
            this.button130.Name = "button130";
            this.button130.Size = new System.Drawing.Size(89, 26);
            this.button130.TabIndex = 2;
            this.button130.Text = "button130";
            this.button130.UseVisualStyleBackColor = false;
            // 
            // button131
            // 
            this.button131.BackColor = System.Drawing.Color.White;
            this.button131.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button131.Location = new System.Drawing.Point(99, 3);
            this.button131.Name = "button131";
            this.button131.Size = new System.Drawing.Size(89, 26);
            this.button131.TabIndex = 1;
            this.button131.Text = "button131";
            this.button131.UseVisualStyleBackColor = false;
            // 
            // button132
            // 
            this.button132.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.button132.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button132.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button132.Location = new System.Drawing.Point(192, 3);
            this.button132.Name = "button132";
            this.button132.Size = new System.Drawing.Size(89, 26);
            this.button132.TabIndex = 0;
            this.button132.Text = "button132";
            this.button132.UseVisualStyleBackColor = false;
            // 
            // panel39
            // 
            this.panel39.Controls.Add(this.button112);
            this.panel39.Controls.Add(this.button113);
            this.panel39.Controls.Add(this.button114);
            this.panel39.Location = new System.Drawing.Point(6, 157);
            this.panel39.Name = "panel39";
            this.panel39.Size = new System.Drawing.Size(289, 32);
            this.panel39.TabIndex = 16;
            // 
            // button112
            // 
            this.button112.BackColor = System.Drawing.Color.White;
            this.button112.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button112.Location = new System.Drawing.Point(4, 3);
            this.button112.Name = "button112";
            this.button112.Size = new System.Drawing.Size(89, 26);
            this.button112.TabIndex = 2;
            this.button112.Text = "button112";
            this.button112.UseVisualStyleBackColor = false;
            // 
            // button113
            // 
            this.button113.BackColor = System.Drawing.Color.White;
            this.button113.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button113.Location = new System.Drawing.Point(99, 3);
            this.button113.Name = "button113";
            this.button113.Size = new System.Drawing.Size(89, 26);
            this.button113.TabIndex = 1;
            this.button113.Text = "button113";
            this.button113.UseVisualStyleBackColor = false;
            // 
            // button114
            // 
            this.button114.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.button114.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button114.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button114.Location = new System.Drawing.Point(192, 3);
            this.button114.Name = "button114";
            this.button114.Size = new System.Drawing.Size(89, 26);
            this.button114.TabIndex = 0;
            this.button114.Text = "button114";
            this.button114.UseVisualStyleBackColor = false;
            // 
            // panel33
            // 
            this.panel33.Controls.Add(this.button94);
            this.panel33.Controls.Add(this.button95);
            this.panel33.Controls.Add(this.button96);
            this.panel33.Location = new System.Drawing.Point(6, 119);
            this.panel33.Name = "panel33";
            this.panel33.Size = new System.Drawing.Size(289, 32);
            this.panel33.TabIndex = 15;
            // 
            // button94
            // 
            this.button94.BackColor = System.Drawing.Color.White;
            this.button94.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button94.Location = new System.Drawing.Point(4, 3);
            this.button94.Name = "button94";
            this.button94.Size = new System.Drawing.Size(89, 26);
            this.button94.TabIndex = 2;
            this.button94.Text = "button94";
            this.button94.UseVisualStyleBackColor = false;
            // 
            // button95
            // 
            this.button95.BackColor = System.Drawing.Color.White;
            this.button95.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button95.Location = new System.Drawing.Point(99, 3);
            this.button95.Name = "button95";
            this.button95.Size = new System.Drawing.Size(89, 26);
            this.button95.TabIndex = 1;
            this.button95.Text = "button95";
            this.button95.UseVisualStyleBackColor = false;
            // 
            // button96
            // 
            this.button96.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.button96.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button96.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button96.Location = new System.Drawing.Point(192, 3);
            this.button96.Name = "button96";
            this.button96.Size = new System.Drawing.Size(89, 26);
            this.button96.TabIndex = 0;
            this.button96.Text = "button96";
            this.button96.UseVisualStyleBackColor = false;
            // 
            // panel26
            // 
            this.panel26.Controls.Add(this.button76);
            this.panel26.Controls.Add(this.button77);
            this.panel26.Controls.Add(this.button78);
            this.panel26.Location = new System.Drawing.Point(6, 81);
            this.panel26.Name = "panel26";
            this.panel26.Size = new System.Drawing.Size(289, 32);
            this.panel26.TabIndex = 14;
            // 
            // button76
            // 
            this.button76.BackColor = System.Drawing.Color.White;
            this.button76.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button76.Location = new System.Drawing.Point(4, 3);
            this.button76.Name = "button76";
            this.button76.Size = new System.Drawing.Size(89, 26);
            this.button76.TabIndex = 2;
            this.button76.Text = "button76";
            this.button76.UseVisualStyleBackColor = false;
            // 
            // button77
            // 
            this.button77.BackColor = System.Drawing.Color.White;
            this.button77.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button77.Location = new System.Drawing.Point(99, 3);
            this.button77.Name = "button77";
            this.button77.Size = new System.Drawing.Size(89, 26);
            this.button77.TabIndex = 1;
            this.button77.Text = "button77";
            this.button77.UseVisualStyleBackColor = false;
            // 
            // button78
            // 
            this.button78.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.button78.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button78.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button78.Location = new System.Drawing.Point(192, 3);
            this.button78.Name = "button78";
            this.button78.Size = new System.Drawing.Size(89, 26);
            this.button78.TabIndex = 0;
            this.button78.Text = "button78";
            this.button78.UseVisualStyleBackColor = false;
            // 
            // btnPjOmPurityShiftB
            // 
            this.btnPjOmPurityShiftB.Location = new System.Drawing.Point(202, 46);
            this.btnPjOmPurityShiftB.Name = "btnPjOmPurityShiftB";
            this.btnPjOmPurityShiftB.Size = new System.Drawing.Size(89, 26);
            this.btnPjOmPurityShiftB.TabIndex = 6;
            this.btnPjOmPurityShiftB.Text = "Purity";
            this.btnPjOmPurityShiftB.UseVisualStyleBackColor = true;
            // 
            // btnPjOmPolShiftB
            // 
            this.btnPjOmPolShiftB.Location = new System.Drawing.Point(105, 46);
            this.btnPjOmPolShiftB.Name = "btnPjOmPolShiftB";
            this.btnPjOmPolShiftB.Size = new System.Drawing.Size(89, 26);
            this.btnPjOmPolShiftB.TabIndex = 5;
            this.btnPjOmPolShiftB.Text = "Pol";
            this.btnPjOmPolShiftB.UseVisualStyleBackColor = true;
            // 
            // btnPjOmBrixShiftB
            // 
            this.btnPjOmBrixShiftB.Location = new System.Drawing.Point(8, 46);
            this.btnPjOmBrixShiftB.Name = "btnPjOmBrixShiftB";
            this.btnPjOmBrixShiftB.Size = new System.Drawing.Size(89, 26);
            this.btnPjOmBrixShiftB.TabIndex = 4;
            this.btnPjOmBrixShiftB.Text = "Brix";
            this.btnPjOmBrixShiftB.UseVisualStyleBackColor = true;
            // 
            // btnPjOmShiftB
            // 
            this.btnPjOmShiftB.Location = new System.Drawing.Point(8, 10);
            this.btnPjOmShiftB.Name = "btnPjOmShiftB";
            this.btnPjOmShiftB.Size = new System.Drawing.Size(283, 34);
            this.btnPjOmShiftB.TabIndex = 0;
            this.btnPjOmShiftB.Text = "Old Mill";
            this.btnPjOmShiftB.UseVisualStyleBackColor = true;
            // 
            // groupBox23
            // 
            this.groupBox23.Controls.Add(this.panel86);
            this.groupBox23.Controls.Add(this.panel44);
            this.groupBox23.Controls.Add(this.panel38);
            this.groupBox23.Controls.Add(this.panel32);
            this.groupBox23.Controls.Add(this.panel25);
            this.groupBox23.Controls.Add(this.btnPjNmPurityShiftB);
            this.groupBox23.Controls.Add(this.btnPjNmPolShiftB);
            this.groupBox23.Controls.Add(this.btnPjNmBrixShiftB);
            this.groupBox23.Controls.Add(this.btnPjNmShiftB);
            this.groupBox23.Location = new System.Drawing.Point(7, 32);
            this.groupBox23.Name = "groupBox23";
            this.groupBox23.Size = new System.Drawing.Size(301, 279);
            this.groupBox23.TabIndex = 1;
            this.groupBox23.TabStop = false;
            // 
            // panel86
            // 
            this.panel86.Controls.Add(this.button236);
            this.panel86.Controls.Add(this.button237);
            this.panel86.Controls.Add(this.button238);
            this.panel86.Location = new System.Drawing.Point(6, 234);
            this.panel86.Name = "panel86";
            this.panel86.Size = new System.Drawing.Size(289, 32);
            this.panel86.TabIndex = 17;
            // 
            // button236
            // 
            this.button236.BackColor = System.Drawing.SystemColors.HotTrack;
            this.button236.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button236.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button236.ForeColor = System.Drawing.Color.White;
            this.button236.Location = new System.Drawing.Point(4, 3);
            this.button236.Name = "button236";
            this.button236.Size = new System.Drawing.Size(89, 26);
            this.button236.TabIndex = 2;
            this.button236.Text = "button236";
            this.button236.UseVisualStyleBackColor = false;
            // 
            // button237
            // 
            this.button237.BackColor = System.Drawing.SystemColors.HotTrack;
            this.button237.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button237.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button237.ForeColor = System.Drawing.Color.White;
            this.button237.Location = new System.Drawing.Point(99, 3);
            this.button237.Name = "button237";
            this.button237.Size = new System.Drawing.Size(89, 26);
            this.button237.TabIndex = 1;
            this.button237.Text = "button237";
            this.button237.UseVisualStyleBackColor = false;
            // 
            // button238
            // 
            this.button238.BackColor = System.Drawing.SystemColors.HotTrack;
            this.button238.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button238.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button238.ForeColor = System.Drawing.Color.White;
            this.button238.Location = new System.Drawing.Point(192, 3);
            this.button238.Name = "button238";
            this.button238.Size = new System.Drawing.Size(89, 26);
            this.button238.TabIndex = 0;
            this.button238.Text = "button238";
            this.button238.UseVisualStyleBackColor = false;
            // 
            // panel44
            // 
            this.panel44.Controls.Add(this.button127);
            this.panel44.Controls.Add(this.button128);
            this.panel44.Controls.Add(this.button129);
            this.panel44.Location = new System.Drawing.Point(6, 192);
            this.panel44.Name = "panel44";
            this.panel44.Size = new System.Drawing.Size(289, 32);
            this.panel44.TabIndex = 16;
            // 
            // button127
            // 
            this.button127.BackColor = System.Drawing.Color.White;
            this.button127.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button127.Location = new System.Drawing.Point(4, 3);
            this.button127.Name = "button127";
            this.button127.Size = new System.Drawing.Size(89, 26);
            this.button127.TabIndex = 2;
            this.button127.Text = "button127";
            this.button127.UseVisualStyleBackColor = false;
            // 
            // button128
            // 
            this.button128.BackColor = System.Drawing.Color.White;
            this.button128.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button128.Location = new System.Drawing.Point(99, 3);
            this.button128.Name = "button128";
            this.button128.Size = new System.Drawing.Size(89, 26);
            this.button128.TabIndex = 1;
            this.button128.Text = "button128";
            this.button128.UseVisualStyleBackColor = false;
            // 
            // button129
            // 
            this.button129.BackColor = System.Drawing.Color.White;
            this.button129.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button129.Location = new System.Drawing.Point(192, 3);
            this.button129.Name = "button129";
            this.button129.Size = new System.Drawing.Size(89, 26);
            this.button129.TabIndex = 0;
            this.button129.Text = "button129";
            this.button129.UseVisualStyleBackColor = false;
            // 
            // panel38
            // 
            this.panel38.Controls.Add(this.button109);
            this.panel38.Controls.Add(this.button110);
            this.panel38.Controls.Add(this.button111);
            this.panel38.Location = new System.Drawing.Point(6, 154);
            this.panel38.Name = "panel38";
            this.panel38.Size = new System.Drawing.Size(289, 32);
            this.panel38.TabIndex = 15;
            // 
            // button109
            // 
            this.button109.BackColor = System.Drawing.Color.White;
            this.button109.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button109.Location = new System.Drawing.Point(4, 3);
            this.button109.Name = "button109";
            this.button109.Size = new System.Drawing.Size(89, 26);
            this.button109.TabIndex = 2;
            this.button109.Text = "button109";
            this.button109.UseVisualStyleBackColor = false;
            // 
            // button110
            // 
            this.button110.BackColor = System.Drawing.Color.White;
            this.button110.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button110.Location = new System.Drawing.Point(99, 3);
            this.button110.Name = "button110";
            this.button110.Size = new System.Drawing.Size(89, 26);
            this.button110.TabIndex = 1;
            this.button110.Text = "button110";
            this.button110.UseVisualStyleBackColor = false;
            // 
            // button111
            // 
            this.button111.BackColor = System.Drawing.Color.White;
            this.button111.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button111.Location = new System.Drawing.Point(192, 3);
            this.button111.Name = "button111";
            this.button111.Size = new System.Drawing.Size(89, 26);
            this.button111.TabIndex = 0;
            this.button111.Text = "button111";
            this.button111.UseVisualStyleBackColor = false;
            // 
            // panel32
            // 
            this.panel32.Controls.Add(this.button91);
            this.panel32.Controls.Add(this.button92);
            this.panel32.Controls.Add(this.button93);
            this.panel32.Location = new System.Drawing.Point(6, 116);
            this.panel32.Name = "panel32";
            this.panel32.Size = new System.Drawing.Size(289, 32);
            this.panel32.TabIndex = 14;
            // 
            // button91
            // 
            this.button91.BackColor = System.Drawing.Color.White;
            this.button91.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button91.Location = new System.Drawing.Point(4, 3);
            this.button91.Name = "button91";
            this.button91.Size = new System.Drawing.Size(89, 26);
            this.button91.TabIndex = 2;
            this.button91.Text = "button91";
            this.button91.UseVisualStyleBackColor = false;
            // 
            // button92
            // 
            this.button92.BackColor = System.Drawing.Color.White;
            this.button92.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button92.Location = new System.Drawing.Point(99, 3);
            this.button92.Name = "button92";
            this.button92.Size = new System.Drawing.Size(89, 26);
            this.button92.TabIndex = 1;
            this.button92.Text = "button92";
            this.button92.UseVisualStyleBackColor = false;
            // 
            // button93
            // 
            this.button93.BackColor = System.Drawing.Color.White;
            this.button93.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button93.Location = new System.Drawing.Point(192, 3);
            this.button93.Name = "button93";
            this.button93.Size = new System.Drawing.Size(89, 26);
            this.button93.TabIndex = 0;
            this.button93.Text = "button93";
            this.button93.UseVisualStyleBackColor = false;
            // 
            // panel25
            // 
            this.panel25.Controls.Add(this.button73);
            this.panel25.Controls.Add(this.button74);
            this.panel25.Controls.Add(this.button75);
            this.panel25.Location = new System.Drawing.Point(6, 78);
            this.panel25.Name = "panel25";
            this.panel25.Size = new System.Drawing.Size(289, 32);
            this.panel25.TabIndex = 13;
            // 
            // button73
            // 
            this.button73.BackColor = System.Drawing.Color.White;
            this.button73.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button73.Location = new System.Drawing.Point(4, 3);
            this.button73.Name = "button73";
            this.button73.Size = new System.Drawing.Size(89, 26);
            this.button73.TabIndex = 2;
            this.button73.Text = "button73";
            this.button73.UseVisualStyleBackColor = false;
            // 
            // button74
            // 
            this.button74.BackColor = System.Drawing.Color.White;
            this.button74.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button74.Location = new System.Drawing.Point(99, 3);
            this.button74.Name = "button74";
            this.button74.Size = new System.Drawing.Size(89, 26);
            this.button74.TabIndex = 1;
            this.button74.Text = "button74";
            this.button74.UseVisualStyleBackColor = false;
            // 
            // button75
            // 
            this.button75.BackColor = System.Drawing.Color.White;
            this.button75.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button75.Location = new System.Drawing.Point(192, 3);
            this.button75.Name = "button75";
            this.button75.Size = new System.Drawing.Size(89, 26);
            this.button75.TabIndex = 0;
            this.button75.Text = "button75";
            this.button75.UseVisualStyleBackColor = false;
            // 
            // btnPjNmPurityShiftB
            // 
            this.btnPjNmPurityShiftB.Location = new System.Drawing.Point(202, 46);
            this.btnPjNmPurityShiftB.Name = "btnPjNmPurityShiftB";
            this.btnPjNmPurityShiftB.Size = new System.Drawing.Size(89, 26);
            this.btnPjNmPurityShiftB.TabIndex = 3;
            this.btnPjNmPurityShiftB.Text = "Purity";
            this.btnPjNmPurityShiftB.UseVisualStyleBackColor = true;
            // 
            // btnPjNmPolShiftB
            // 
            this.btnPjNmPolShiftB.Location = new System.Drawing.Point(105, 46);
            this.btnPjNmPolShiftB.Name = "btnPjNmPolShiftB";
            this.btnPjNmPolShiftB.Size = new System.Drawing.Size(89, 26);
            this.btnPjNmPolShiftB.TabIndex = 2;
            this.btnPjNmPolShiftB.Text = "Pol";
            this.btnPjNmPolShiftB.UseVisualStyleBackColor = true;
            // 
            // btnPjNmBrixShiftB
            // 
            this.btnPjNmBrixShiftB.Location = new System.Drawing.Point(10, 46);
            this.btnPjNmBrixShiftB.Name = "btnPjNmBrixShiftB";
            this.btnPjNmBrixShiftB.Size = new System.Drawing.Size(89, 26);
            this.btnPjNmBrixShiftB.TabIndex = 1;
            this.btnPjNmBrixShiftB.Text = "Brix";
            this.btnPjNmBrixShiftB.UseVisualStyleBackColor = true;
            // 
            // btnPjNmShiftB
            // 
            this.btnPjNmShiftB.Location = new System.Drawing.Point(10, 10);
            this.btnPjNmShiftB.Name = "btnPjNmShiftB";
            this.btnPjNmShiftB.Size = new System.Drawing.Size(281, 34);
            this.btnPjNmShiftB.TabIndex = 0;
            this.btnPjNmShiftB.Text = "New Mill";
            this.btnPjNmShiftB.UseVisualStyleBackColor = true;
            // 
            // btnPrimaryJuiceShiftB
            // 
            this.btnPrimaryJuiceShiftB.Location = new System.Drawing.Point(17, 10);
            this.btnPrimaryJuiceShiftB.Name = "btnPrimaryJuiceShiftB";
            this.btnPrimaryJuiceShiftB.Size = new System.Drawing.Size(593, 23);
            this.btnPrimaryJuiceShiftB.TabIndex = 0;
            this.btnPrimaryJuiceShiftB.Text = "Primary Juice";
            this.btnPrimaryJuiceShiftB.UseVisualStyleBackColor = true;
            // 
            // groupBox2
            // 
            this.groupBox2.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.groupBox2.Controls.Add(this.groupBox10);
            this.groupBox2.Controls.Add(this.groupBox7);
            this.groupBox2.Controls.Add(this.groupBox6);
            this.groupBox2.Controls.Add(this.groupBox3);
            this.groupBox2.Location = new System.Drawing.Point(16, 79);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(2059, 364);
            this.groupBox2.TabIndex = 1;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Shift-A";
            // 
            // groupBox10
            // 
            this.groupBox10.Controls.Add(this.groupBox11);
            this.groupBox10.Controls.Add(this.groupBox12);
            this.groupBox10.Controls.Add(this.btnLastJuiceShiftA);
            this.groupBox10.Location = new System.Drawing.Point(1407, 12);
            this.groupBox10.Name = "groupBox10";
            this.groupBox10.Size = new System.Drawing.Size(636, 330);
            this.groupBox10.TabIndex = 14;
            this.groupBox10.TabStop = false;
            // 
            // groupBox11
            // 
            this.groupBox11.Controls.Add(this.panel85);
            this.groupBox11.Controls.Add(this.panel24);
            this.groupBox11.Controls.Add(this.panel18);
            this.groupBox11.Controls.Add(this.btnLjOmPurityShiftA);
            this.groupBox11.Controls.Add(this.panel7);
            this.groupBox11.Controls.Add(this.btnLjOmPolShiftA);
            this.groupBox11.Controls.Add(this.btnLjOmBrixShiftA);
            this.groupBox11.Controls.Add(this.panel13);
            this.groupBox11.Controls.Add(this.btnLjOmShiftA);
            this.groupBox11.Location = new System.Drawing.Point(325, 32);
            this.groupBox11.Name = "groupBox11";
            this.groupBox11.Size = new System.Drawing.Size(301, 279);
            this.groupBox11.TabIndex = 3;
            this.groupBox11.TabStop = false;
            // 
            // panel85
            // 
            this.panel85.Controls.Add(this.button233);
            this.panel85.Controls.Add(this.button234);
            this.panel85.Controls.Add(this.button232);
            this.panel85.Location = new System.Drawing.Point(8, 237);
            this.panel85.Name = "panel85";
            this.panel85.Size = new System.Drawing.Size(289, 32);
            this.panel85.TabIndex = 17;
            // 
            // button233
            // 
            this.button233.BackColor = System.Drawing.SystemColors.HotTrack;
            this.button233.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button233.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button233.ForeColor = System.Drawing.Color.White;
            this.button233.Location = new System.Drawing.Point(101, 0);
            this.button233.Name = "button233";
            this.button233.Size = new System.Drawing.Size(89, 26);
            this.button233.TabIndex = 2;
            this.button233.Text = "button233";
            this.button233.UseVisualStyleBackColor = false;
            // 
            // button234
            // 
            this.button234.BackColor = System.Drawing.SystemColors.HotTrack;
            this.button234.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button234.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button234.ForeColor = System.Drawing.Color.White;
            this.button234.Location = new System.Drawing.Point(196, 0);
            this.button234.Name = "button234";
            this.button234.Size = new System.Drawing.Size(89, 26);
            this.button234.TabIndex = 1;
            this.button234.Text = "button234";
            this.button234.UseVisualStyleBackColor = false;
            // 
            // button232
            // 
            this.button232.BackColor = System.Drawing.SystemColors.HotTrack;
            this.button232.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button232.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button232.ForeColor = System.Drawing.Color.White;
            this.button232.Location = new System.Drawing.Point(6, 0);
            this.button232.Name = "button232";
            this.button232.Size = new System.Drawing.Size(89, 26);
            this.button232.TabIndex = 0;
            this.button232.Text = "button232";
            this.button232.UseVisualStyleBackColor = false;
            // 
            // panel24
            // 
            this.panel24.Controls.Add(this.button70);
            this.panel24.Controls.Add(this.button71);
            this.panel24.Controls.Add(this.button72);
            this.panel24.Location = new System.Drawing.Point(6, 195);
            this.panel24.Name = "panel24";
            this.panel24.Size = new System.Drawing.Size(289, 32);
            this.panel24.TabIndex = 16;
            // 
            // button70
            // 
            this.button70.BackColor = System.Drawing.Color.White;
            this.button70.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button70.Location = new System.Drawing.Point(4, 3);
            this.button70.Name = "button70";
            this.button70.Size = new System.Drawing.Size(89, 26);
            this.button70.TabIndex = 2;
            this.button70.Text = "button70";
            this.button70.UseVisualStyleBackColor = false;
            // 
            // button71
            // 
            this.button71.BackColor = System.Drawing.Color.White;
            this.button71.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button71.Location = new System.Drawing.Point(99, 3);
            this.button71.Name = "button71";
            this.button71.Size = new System.Drawing.Size(89, 26);
            this.button71.TabIndex = 1;
            this.button71.Text = "button71";
            this.button71.UseVisualStyleBackColor = false;
            // 
            // button72
            // 
            this.button72.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.button72.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button72.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button72.Location = new System.Drawing.Point(192, 3);
            this.button72.Name = "button72";
            this.button72.Size = new System.Drawing.Size(89, 26);
            this.button72.TabIndex = 0;
            this.button72.Text = "button72";
            this.button72.UseVisualStyleBackColor = false;
            // 
            // panel18
            // 
            this.panel18.Controls.Add(this.button52);
            this.panel18.Controls.Add(this.button53);
            this.panel18.Controls.Add(this.button54);
            this.panel18.Location = new System.Drawing.Point(10, 157);
            this.panel18.Name = "panel18";
            this.panel18.Size = new System.Drawing.Size(289, 32);
            this.panel18.TabIndex = 15;
            // 
            // button52
            // 
            this.button52.BackColor = System.Drawing.Color.White;
            this.button52.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button52.Location = new System.Drawing.Point(4, 3);
            this.button52.Name = "button52";
            this.button52.Size = new System.Drawing.Size(89, 26);
            this.button52.TabIndex = 2;
            this.button52.Text = "button52";
            this.button52.UseVisualStyleBackColor = false;
            // 
            // button53
            // 
            this.button53.BackColor = System.Drawing.Color.White;
            this.button53.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button53.Location = new System.Drawing.Point(99, 3);
            this.button53.Name = "button53";
            this.button53.Size = new System.Drawing.Size(89, 26);
            this.button53.TabIndex = 1;
            this.button53.Text = "button53";
            this.button53.UseVisualStyleBackColor = false;
            // 
            // button54
            // 
            this.button54.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.button54.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button54.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button54.Location = new System.Drawing.Point(192, 3);
            this.button54.Name = "button54";
            this.button54.Size = new System.Drawing.Size(89, 26);
            this.button54.TabIndex = 0;
            this.button54.Text = "button54";
            this.button54.UseVisualStyleBackColor = false;
            // 
            // btnLjOmPurityShiftA
            // 
            this.btnLjOmPurityShiftA.Location = new System.Drawing.Point(198, 46);
            this.btnLjOmPurityShiftA.Name = "btnLjOmPurityShiftA";
            this.btnLjOmPurityShiftA.Size = new System.Drawing.Size(89, 26);
            this.btnLjOmPurityShiftA.TabIndex = 6;
            this.btnLjOmPurityShiftA.Text = "Purity";
            this.btnLjOmPurityShiftA.UseVisualStyleBackColor = true;
            // 
            // panel7
            // 
            this.panel7.Controls.Add(this.button16);
            this.panel7.Controls.Add(this.button17);
            this.panel7.Controls.Add(this.button18);
            this.panel7.Location = new System.Drawing.Point(6, 78);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(289, 32);
            this.panel7.TabIndex = 10;
            // 
            // button16
            // 
            this.button16.BackColor = System.Drawing.Color.White;
            this.button16.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button16.Location = new System.Drawing.Point(4, 3);
            this.button16.Name = "button16";
            this.button16.Size = new System.Drawing.Size(89, 26);
            this.button16.TabIndex = 2;
            this.button16.Text = "button16";
            this.button16.UseVisualStyleBackColor = false;
            // 
            // button17
            // 
            this.button17.BackColor = System.Drawing.Color.White;
            this.button17.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button17.Location = new System.Drawing.Point(98, 3);
            this.button17.Name = "button17";
            this.button17.Size = new System.Drawing.Size(89, 26);
            this.button17.TabIndex = 1;
            this.button17.Text = "button17";
            this.button17.UseVisualStyleBackColor = false;
            // 
            // button18
            // 
            this.button18.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.button18.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button18.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button18.Location = new System.Drawing.Point(194, 3);
            this.button18.Name = "button18";
            this.button18.Size = new System.Drawing.Size(89, 26);
            this.button18.TabIndex = 0;
            this.button18.Text = "button18";
            this.button18.UseVisualStyleBackColor = false;
            // 
            // btnLjOmPolShiftA
            // 
            this.btnLjOmPolShiftA.Location = new System.Drawing.Point(101, 46);
            this.btnLjOmPolShiftA.Name = "btnLjOmPolShiftA";
            this.btnLjOmPolShiftA.Size = new System.Drawing.Size(89, 26);
            this.btnLjOmPolShiftA.TabIndex = 5;
            this.btnLjOmPolShiftA.Text = "Pol";
            this.btnLjOmPolShiftA.UseVisualStyleBackColor = true;
            // 
            // btnLjOmBrixShiftA
            // 
            this.btnLjOmBrixShiftA.Location = new System.Drawing.Point(6, 46);
            this.btnLjOmBrixShiftA.Name = "btnLjOmBrixShiftA";
            this.btnLjOmBrixShiftA.Size = new System.Drawing.Size(89, 26);
            this.btnLjOmBrixShiftA.TabIndex = 4;
            this.btnLjOmBrixShiftA.Text = "Brix";
            this.btnLjOmBrixShiftA.UseVisualStyleBackColor = true;
            // 
            // panel13
            // 
            this.panel13.Controls.Add(this.button34);
            this.panel13.Controls.Add(this.button35);
            this.panel13.Controls.Add(this.button36);
            this.panel13.Location = new System.Drawing.Point(6, 119);
            this.panel13.Name = "panel13";
            this.panel13.Size = new System.Drawing.Size(289, 32);
            this.panel13.TabIndex = 9;
            // 
            // button34
            // 
            this.button34.BackColor = System.Drawing.Color.White;
            this.button34.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button34.Location = new System.Drawing.Point(4, 3);
            this.button34.Name = "button34";
            this.button34.Size = new System.Drawing.Size(89, 26);
            this.button34.TabIndex = 2;
            this.button34.Text = "button34";
            this.button34.UseVisualStyleBackColor = false;
            // 
            // button35
            // 
            this.button35.BackColor = System.Drawing.Color.White;
            this.button35.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button35.Location = new System.Drawing.Point(99, 3);
            this.button35.Name = "button35";
            this.button35.Size = new System.Drawing.Size(89, 26);
            this.button35.TabIndex = 1;
            this.button35.Text = "button35";
            this.button35.UseVisualStyleBackColor = false;
            // 
            // button36
            // 
            this.button36.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.button36.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button36.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button36.Location = new System.Drawing.Point(192, 3);
            this.button36.Name = "button36";
            this.button36.Size = new System.Drawing.Size(89, 26);
            this.button36.TabIndex = 0;
            this.button36.Text = "button36";
            this.button36.UseVisualStyleBackColor = false;
            // 
            // btnLjOmShiftA
            // 
            this.btnLjOmShiftA.Location = new System.Drawing.Point(6, 10);
            this.btnLjOmShiftA.Name = "btnLjOmShiftA";
            this.btnLjOmShiftA.Size = new System.Drawing.Size(281, 34);
            this.btnLjOmShiftA.TabIndex = 1;
            this.btnLjOmShiftA.Text = "Old Mill";
            this.btnLjOmShiftA.UseVisualStyleBackColor = true;
            // 
            // groupBox12
            // 
            this.groupBox12.Controls.Add(this.panel84);
            this.groupBox12.Controls.Add(this.panel23);
            this.groupBox12.Controls.Add(this.panel28);
            this.groupBox12.Controls.Add(this.btnLjNmPurityShiftA);
            this.groupBox12.Controls.Add(this.panel6);
            this.groupBox12.Controls.Add(this.btnLjNmPolShiftA);
            this.groupBox12.Controls.Add(this.btnLjNmBrixShiftA);
            this.groupBox12.Controls.Add(this.btnLjNmShiftA);
            this.groupBox12.Controls.Add(this.panel12);
            this.groupBox12.Location = new System.Drawing.Point(6, 32);
            this.groupBox12.Name = "groupBox12";
            this.groupBox12.Size = new System.Drawing.Size(301, 279);
            this.groupBox12.TabIndex = 2;
            this.groupBox12.TabStop = false;
            // 
            // panel84
            // 
            this.panel84.Controls.Add(this.button230);
            this.panel84.Controls.Add(this.button231);
            this.panel84.Controls.Add(this.button229);
            this.panel84.Location = new System.Drawing.Point(10, 233);
            this.panel84.Name = "panel84";
            this.panel84.Size = new System.Drawing.Size(289, 32);
            this.panel84.TabIndex = 17;
            // 
            // button230
            // 
            this.button230.BackColor = System.Drawing.SystemColors.HotTrack;
            this.button230.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button230.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button230.ForeColor = System.Drawing.Color.White;
            this.button230.Location = new System.Drawing.Point(95, 1);
            this.button230.Name = "button230";
            this.button230.Size = new System.Drawing.Size(89, 26);
            this.button230.TabIndex = 2;
            this.button230.Text = "button230";
            this.button230.UseVisualStyleBackColor = false;
            // 
            // button231
            // 
            this.button231.BackColor = System.Drawing.SystemColors.HotTrack;
            this.button231.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button231.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button231.ForeColor = System.Drawing.Color.White;
            this.button231.Location = new System.Drawing.Point(190, 1);
            this.button231.Name = "button231";
            this.button231.Size = new System.Drawing.Size(89, 26);
            this.button231.TabIndex = 1;
            this.button231.Text = "button231";
            this.button231.UseVisualStyleBackColor = false;
            // 
            // button229
            // 
            this.button229.BackColor = System.Drawing.SystemColors.HotTrack;
            this.button229.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button229.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button229.ForeColor = System.Drawing.Color.White;
            this.button229.Location = new System.Drawing.Point(4, 3);
            this.button229.Name = "button229";
            this.button229.Size = new System.Drawing.Size(89, 26);
            this.button229.TabIndex = 0;
            this.button229.Text = "button229";
            this.button229.UseVisualStyleBackColor = false;
            // 
            // panel23
            // 
            this.panel23.Controls.Add(this.button67);
            this.panel23.Controls.Add(this.button68);
            this.panel23.Controls.Add(this.button69);
            this.panel23.Location = new System.Drawing.Point(10, 195);
            this.panel23.Name = "panel23";
            this.panel23.Size = new System.Drawing.Size(289, 32);
            this.panel23.TabIndex = 16;
            // 
            // button67
            // 
            this.button67.BackColor = System.Drawing.Color.White;
            this.button67.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button67.Location = new System.Drawing.Point(4, 3);
            this.button67.Name = "button67";
            this.button67.Size = new System.Drawing.Size(89, 26);
            this.button67.TabIndex = 2;
            this.button67.Text = "button67";
            this.button67.UseVisualStyleBackColor = false;
            // 
            // button68
            // 
            this.button68.BackColor = System.Drawing.Color.White;
            this.button68.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button68.Location = new System.Drawing.Point(99, 3);
            this.button68.Name = "button68";
            this.button68.Size = new System.Drawing.Size(89, 26);
            this.button68.TabIndex = 1;
            this.button68.Text = "button68";
            this.button68.UseVisualStyleBackColor = false;
            // 
            // button69
            // 
            this.button69.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.button69.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button69.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button69.Location = new System.Drawing.Point(192, 3);
            this.button69.Name = "button69";
            this.button69.Size = new System.Drawing.Size(89, 26);
            this.button69.TabIndex = 0;
            this.button69.Text = "button69";
            this.button69.UseVisualStyleBackColor = false;
            // 
            // panel28
            // 
            this.panel28.Controls.Add(this.button49);
            this.panel28.Controls.Add(this.button50);
            this.panel28.Controls.Add(this.button51);
            this.panel28.Location = new System.Drawing.Point(10, 160);
            this.panel28.Name = "panel28";
            this.panel28.Size = new System.Drawing.Size(289, 32);
            this.panel28.TabIndex = 15;
            // 
            // button49
            // 
            this.button49.BackColor = System.Drawing.Color.White;
            this.button49.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button49.Location = new System.Drawing.Point(4, 3);
            this.button49.Name = "button49";
            this.button49.Size = new System.Drawing.Size(89, 26);
            this.button49.TabIndex = 2;
            this.button49.Text = "button49";
            this.button49.UseVisualStyleBackColor = false;
            // 
            // button50
            // 
            this.button50.BackColor = System.Drawing.Color.White;
            this.button50.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button50.Location = new System.Drawing.Point(99, 3);
            this.button50.Name = "button50";
            this.button50.Size = new System.Drawing.Size(89, 26);
            this.button50.TabIndex = 1;
            this.button50.Text = "button50";
            this.button50.UseVisualStyleBackColor = false;
            // 
            // button51
            // 
            this.button51.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.button51.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button51.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button51.Location = new System.Drawing.Point(192, 3);
            this.button51.Name = "button51";
            this.button51.Size = new System.Drawing.Size(89, 26);
            this.button51.TabIndex = 0;
            this.button51.Text = "button51";
            this.button51.UseVisualStyleBackColor = false;
            // 
            // btnLjNmPurityShiftA
            // 
            this.btnLjNmPurityShiftA.Location = new System.Drawing.Point(198, 46);
            this.btnLjNmPurityShiftA.Name = "btnLjNmPurityShiftA";
            this.btnLjNmPurityShiftA.Size = new System.Drawing.Size(89, 26);
            this.btnLjNmPurityShiftA.TabIndex = 6;
            this.btnLjNmPurityShiftA.Text = "Purity";
            this.btnLjNmPurityShiftA.UseVisualStyleBackColor = true;
            // 
            // panel6
            // 
            this.panel6.Controls.Add(this.button13);
            this.panel6.Controls.Add(this.button14);
            this.panel6.Controls.Add(this.button15);
            this.panel6.Location = new System.Drawing.Point(6, 78);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(289, 32);
            this.panel6.TabIndex = 9;
            // 
            // button13
            // 
            this.button13.BackColor = System.Drawing.Color.White;
            this.button13.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button13.Location = new System.Drawing.Point(4, 3);
            this.button13.Name = "button13";
            this.button13.Size = new System.Drawing.Size(89, 26);
            this.button13.TabIndex = 2;
            this.button13.Text = "button13";
            this.button13.UseVisualStyleBackColor = false;
            // 
            // button14
            // 
            this.button14.BackColor = System.Drawing.Color.White;
            this.button14.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button14.Location = new System.Drawing.Point(99, 3);
            this.button14.Name = "button14";
            this.button14.Size = new System.Drawing.Size(89, 26);
            this.button14.TabIndex = 1;
            this.button14.Text = "button14";
            this.button14.UseVisualStyleBackColor = false;
            // 
            // button15
            // 
            this.button15.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.button15.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button15.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button15.Location = new System.Drawing.Point(194, 3);
            this.button15.Name = "button15";
            this.button15.Size = new System.Drawing.Size(89, 26);
            this.button15.TabIndex = 0;
            this.button15.Text = "button15";
            this.button15.UseVisualStyleBackColor = false;
            // 
            // btnLjNmPolShiftA
            // 
            this.btnLjNmPolShiftA.Location = new System.Drawing.Point(101, 46);
            this.btnLjNmPolShiftA.Name = "btnLjNmPolShiftA";
            this.btnLjNmPolShiftA.Size = new System.Drawing.Size(89, 26);
            this.btnLjNmPolShiftA.TabIndex = 5;
            this.btnLjNmPolShiftA.Text = "Pol";
            this.btnLjNmPolShiftA.UseVisualStyleBackColor = true;
            // 
            // btnLjNmBrixShiftA
            // 
            this.btnLjNmBrixShiftA.Location = new System.Drawing.Point(6, 46);
            this.btnLjNmBrixShiftA.Name = "btnLjNmBrixShiftA";
            this.btnLjNmBrixShiftA.Size = new System.Drawing.Size(89, 26);
            this.btnLjNmBrixShiftA.TabIndex = 4;
            this.btnLjNmBrixShiftA.Text = "Brix";
            this.btnLjNmBrixShiftA.UseVisualStyleBackColor = true;
            // 
            // btnLjNmShiftA
            // 
            this.btnLjNmShiftA.Location = new System.Drawing.Point(6, 10);
            this.btnLjNmShiftA.Name = "btnLjNmShiftA";
            this.btnLjNmShiftA.Size = new System.Drawing.Size(281, 34);
            this.btnLjNmShiftA.TabIndex = 1;
            this.btnLjNmShiftA.Text = "New Mill";
            this.btnLjNmShiftA.UseVisualStyleBackColor = true;
            // 
            // panel12
            // 
            this.panel12.Controls.Add(this.button31);
            this.panel12.Controls.Add(this.button32);
            this.panel12.Controls.Add(this.button33);
            this.panel12.Location = new System.Drawing.Point(6, 119);
            this.panel12.Name = "panel12";
            this.panel12.Size = new System.Drawing.Size(289, 32);
            this.panel12.TabIndex = 8;
            // 
            // button31
            // 
            this.button31.BackColor = System.Drawing.Color.White;
            this.button31.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button31.Location = new System.Drawing.Point(4, 3);
            this.button31.Name = "button31";
            this.button31.Size = new System.Drawing.Size(89, 26);
            this.button31.TabIndex = 2;
            this.button31.Text = "button31";
            this.button31.UseVisualStyleBackColor = false;
            // 
            // button32
            // 
            this.button32.BackColor = System.Drawing.Color.White;
            this.button32.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button32.Location = new System.Drawing.Point(99, 3);
            this.button32.Name = "button32";
            this.button32.Size = new System.Drawing.Size(89, 26);
            this.button32.TabIndex = 1;
            this.button32.Text = "button32";
            this.button32.UseVisualStyleBackColor = false;
            // 
            // button33
            // 
            this.button33.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.button33.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button33.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button33.Location = new System.Drawing.Point(192, 3);
            this.button33.Name = "button33";
            this.button33.Size = new System.Drawing.Size(89, 26);
            this.button33.TabIndex = 0;
            this.button33.Text = "button33";
            this.button33.UseVisualStyleBackColor = false;
            // 
            // btnLastJuiceShiftA
            // 
            this.btnLastJuiceShiftA.Location = new System.Drawing.Point(6, 10);
            this.btnLastJuiceShiftA.Name = "btnLastJuiceShiftA";
            this.btnLastJuiceShiftA.Size = new System.Drawing.Size(620, 23);
            this.btnLastJuiceShiftA.TabIndex = 1;
            this.btnLastJuiceShiftA.Text = "Last Juice";
            this.btnLastJuiceShiftA.UseVisualStyleBackColor = true;
            // 
            // groupBox7
            // 
            this.groupBox7.Controls.Add(this.groupBox9);
            this.groupBox7.Controls.Add(this.groupBox8);
            this.groupBox7.Controls.Add(this.btnMixedJuiceShiftA);
            this.groupBox7.Location = new System.Drawing.Point(765, 12);
            this.groupBox7.Name = "groupBox7";
            this.groupBox7.Size = new System.Drawing.Size(636, 330);
            this.groupBox7.TabIndex = 2;
            this.groupBox7.TabStop = false;
            // 
            // groupBox9
            // 
            this.groupBox9.Controls.Add(this.panel83);
            this.groupBox9.Controls.Add(this.panel22);
            this.groupBox9.Controls.Add(this.btnMjOmPurityShiftA);
            this.groupBox9.Controls.Add(this.btnMjOmPolShiftA);
            this.groupBox9.Controls.Add(this.panel5);
            this.groupBox9.Controls.Add(this.panel17);
            this.groupBox9.Controls.Add(this.btnMjOmBrixShiftA);
            this.groupBox9.Controls.Add(this.btnMjOmShiftA);
            this.groupBox9.Controls.Add(this.panel11);
            this.groupBox9.Location = new System.Drawing.Point(325, 32);
            this.groupBox9.Name = "groupBox9";
            this.groupBox9.Size = new System.Drawing.Size(301, 279);
            this.groupBox9.TabIndex = 3;
            this.groupBox9.TabStop = false;
            // 
            // panel83
            // 
            this.panel83.Controls.Add(this.button227);
            this.panel83.Controls.Add(this.button228);
            this.panel83.Controls.Add(this.button226);
            this.panel83.Location = new System.Drawing.Point(6, 240);
            this.panel83.Name = "panel83";
            this.panel83.Size = new System.Drawing.Size(289, 32);
            this.panel83.TabIndex = 17;
            // 
            // button227
            // 
            this.button227.BackColor = System.Drawing.SystemColors.HotTrack;
            this.button227.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button227.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button227.ForeColor = System.Drawing.Color.White;
            this.button227.Location = new System.Drawing.Point(99, 3);
            this.button227.Name = "button227";
            this.button227.Size = new System.Drawing.Size(89, 26);
            this.button227.TabIndex = 2;
            this.button227.Text = "button227";
            this.button227.UseVisualStyleBackColor = false;
            // 
            // button228
            // 
            this.button228.BackColor = System.Drawing.SystemColors.HotTrack;
            this.button228.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button228.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button228.ForeColor = System.Drawing.Color.White;
            this.button228.Location = new System.Drawing.Point(194, 3);
            this.button228.Name = "button228";
            this.button228.Size = new System.Drawing.Size(89, 26);
            this.button228.TabIndex = 1;
            this.button228.Text = "button228";
            this.button228.UseVisualStyleBackColor = false;
            // 
            // button226
            // 
            this.button226.BackColor = System.Drawing.SystemColors.HotTrack;
            this.button226.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button226.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button226.ForeColor = System.Drawing.Color.White;
            this.button226.Location = new System.Drawing.Point(6, 3);
            this.button226.Name = "button226";
            this.button226.Size = new System.Drawing.Size(89, 26);
            this.button226.TabIndex = 0;
            this.button226.Text = "button226";
            this.button226.UseVisualStyleBackColor = false;
            // 
            // panel22
            // 
            this.panel22.Controls.Add(this.button64);
            this.panel22.Controls.Add(this.button65);
            this.panel22.Controls.Add(this.button66);
            this.panel22.Location = new System.Drawing.Point(6, 195);
            this.panel22.Name = "panel22";
            this.panel22.Size = new System.Drawing.Size(289, 32);
            this.panel22.TabIndex = 13;
            // 
            // button64
            // 
            this.button64.BackColor = System.Drawing.Color.White;
            this.button64.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button64.Location = new System.Drawing.Point(4, 3);
            this.button64.Name = "button64";
            this.button64.Size = new System.Drawing.Size(89, 26);
            this.button64.TabIndex = 2;
            this.button64.Text = "button64";
            this.button64.UseVisualStyleBackColor = false;
            // 
            // button65
            // 
            this.button65.BackColor = System.Drawing.Color.White;
            this.button65.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button65.Location = new System.Drawing.Point(99, 3);
            this.button65.Name = "button65";
            this.button65.Size = new System.Drawing.Size(89, 26);
            this.button65.TabIndex = 1;
            this.button65.Text = "button65";
            this.button65.UseVisualStyleBackColor = false;
            // 
            // button66
            // 
            this.button66.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.button66.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button66.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button66.Location = new System.Drawing.Point(192, 3);
            this.button66.Name = "button66";
            this.button66.Size = new System.Drawing.Size(89, 26);
            this.button66.TabIndex = 0;
            this.button66.Text = "button66";
            this.button66.UseVisualStyleBackColor = false;
            // 
            // btnMjOmPurityShiftA
            // 
            this.btnMjOmPurityShiftA.Location = new System.Drawing.Point(198, 46);
            this.btnMjOmPurityShiftA.Name = "btnMjOmPurityShiftA";
            this.btnMjOmPurityShiftA.Size = new System.Drawing.Size(89, 26);
            this.btnMjOmPurityShiftA.TabIndex = 6;
            this.btnMjOmPurityShiftA.Text = "Purity";
            this.btnMjOmPurityShiftA.UseVisualStyleBackColor = true;
            // 
            // btnMjOmPolShiftA
            // 
            this.btnMjOmPolShiftA.Location = new System.Drawing.Point(101, 46);
            this.btnMjOmPolShiftA.Name = "btnMjOmPolShiftA";
            this.btnMjOmPolShiftA.Size = new System.Drawing.Size(89, 26);
            this.btnMjOmPolShiftA.TabIndex = 5;
            this.btnMjOmPolShiftA.Text = "Pol";
            this.btnMjOmPolShiftA.UseVisualStyleBackColor = true;
            // 
            // panel5
            // 
            this.panel5.Controls.Add(this.button10);
            this.panel5.Controls.Add(this.button11);
            this.panel5.Controls.Add(this.button12);
            this.panel5.Location = new System.Drawing.Point(6, 78);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(289, 32);
            this.panel5.TabIndex = 9;
            // 
            // button10
            // 
            this.button10.BackColor = System.Drawing.Color.White;
            this.button10.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button10.Location = new System.Drawing.Point(6, 3);
            this.button10.Name = "button10";
            this.button10.Size = new System.Drawing.Size(89, 26);
            this.button10.TabIndex = 2;
            this.button10.Text = "button10";
            this.button10.UseVisualStyleBackColor = false;
            // 
            // button11
            // 
            this.button11.BackColor = System.Drawing.Color.White;
            this.button11.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button11.Location = new System.Drawing.Point(98, 3);
            this.button11.Name = "button11";
            this.button11.Size = new System.Drawing.Size(89, 26);
            this.button11.TabIndex = 1;
            this.button11.Text = "button11";
            this.button11.UseVisualStyleBackColor = false;
            // 
            // button12
            // 
            this.button12.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.button12.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button12.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button12.Location = new System.Drawing.Point(194, 3);
            this.button12.Name = "button12";
            this.button12.Size = new System.Drawing.Size(89, 26);
            this.button12.TabIndex = 0;
            this.button12.Text = "button12";
            this.button12.UseVisualStyleBackColor = false;
            // 
            // panel17
            // 
            this.panel17.Controls.Add(this.button46);
            this.panel17.Controls.Add(this.button47);
            this.panel17.Controls.Add(this.button48);
            this.panel17.Location = new System.Drawing.Point(6, 157);
            this.panel17.Name = "panel17";
            this.panel17.Size = new System.Drawing.Size(289, 32);
            this.panel17.TabIndex = 11;
            // 
            // button46
            // 
            this.button46.BackColor = System.Drawing.Color.White;
            this.button46.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button46.Location = new System.Drawing.Point(4, 3);
            this.button46.Name = "button46";
            this.button46.Size = new System.Drawing.Size(89, 26);
            this.button46.TabIndex = 2;
            this.button46.Text = "button46";
            this.button46.UseVisualStyleBackColor = false;
            // 
            // button47
            // 
            this.button47.BackColor = System.Drawing.Color.White;
            this.button47.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button47.Location = new System.Drawing.Point(99, 3);
            this.button47.Name = "button47";
            this.button47.Size = new System.Drawing.Size(89, 26);
            this.button47.TabIndex = 1;
            this.button47.Text = "button47";
            this.button47.UseVisualStyleBackColor = false;
            // 
            // button48
            // 
            this.button48.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.button48.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button48.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button48.Location = new System.Drawing.Point(192, 3);
            this.button48.Name = "button48";
            this.button48.Size = new System.Drawing.Size(89, 26);
            this.button48.TabIndex = 0;
            this.button48.Text = "button48";
            this.button48.UseVisualStyleBackColor = false;
            // 
            // btnMjOmBrixShiftA
            // 
            this.btnMjOmBrixShiftA.Location = new System.Drawing.Point(6, 46);
            this.btnMjOmBrixShiftA.Name = "btnMjOmBrixShiftA";
            this.btnMjOmBrixShiftA.Size = new System.Drawing.Size(89, 26);
            this.btnMjOmBrixShiftA.TabIndex = 4;
            this.btnMjOmBrixShiftA.Text = "Brix";
            this.btnMjOmBrixShiftA.UseVisualStyleBackColor = true;
            // 
            // btnMjOmShiftA
            // 
            this.btnMjOmShiftA.Location = new System.Drawing.Point(6, 10);
            this.btnMjOmShiftA.Name = "btnMjOmShiftA";
            this.btnMjOmShiftA.Size = new System.Drawing.Size(281, 34);
            this.btnMjOmShiftA.TabIndex = 1;
            this.btnMjOmShiftA.Text = "Old Mill";
            this.btnMjOmShiftA.UseVisualStyleBackColor = true;
            // 
            // panel11
            // 
            this.panel11.Controls.Add(this.button28);
            this.panel11.Controls.Add(this.button29);
            this.panel11.Controls.Add(this.button30);
            this.panel11.Location = new System.Drawing.Point(6, 119);
            this.panel11.Name = "panel11";
            this.panel11.Size = new System.Drawing.Size(289, 32);
            this.panel11.TabIndex = 12;
            // 
            // button28
            // 
            this.button28.BackColor = System.Drawing.Color.White;
            this.button28.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button28.Location = new System.Drawing.Point(4, 3);
            this.button28.Name = "button28";
            this.button28.Size = new System.Drawing.Size(89, 26);
            this.button28.TabIndex = 2;
            this.button28.Text = "button28";
            this.button28.UseVisualStyleBackColor = false;
            // 
            // button29
            // 
            this.button29.BackColor = System.Drawing.Color.White;
            this.button29.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button29.Location = new System.Drawing.Point(99, 3);
            this.button29.Name = "button29";
            this.button29.Size = new System.Drawing.Size(89, 26);
            this.button29.TabIndex = 1;
            this.button29.Text = "button29";
            this.button29.UseVisualStyleBackColor = false;
            // 
            // button30
            // 
            this.button30.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.button30.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button30.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button30.Location = new System.Drawing.Point(194, 3);
            this.button30.Name = "button30";
            this.button30.Size = new System.Drawing.Size(89, 26);
            this.button30.TabIndex = 0;
            this.button30.Text = "button30";
            this.button30.UseVisualStyleBackColor = false;
            // 
            // groupBox8
            // 
            this.groupBox8.Controls.Add(this.panel82);
            this.groupBox8.Controls.Add(this.panel21);
            this.groupBox8.Controls.Add(this.btnMjNmPurityShiftA);
            this.groupBox8.Controls.Add(this.btnMjNmPolShiftA);
            this.groupBox8.Controls.Add(this.panel4);
            this.groupBox8.Controls.Add(this.btnMjNmBrixShiftA);
            this.groupBox8.Controls.Add(this.btnMjNmShiftA);
            this.groupBox8.Controls.Add(this.panel16);
            this.groupBox8.Controls.Add(this.panel10);
            this.groupBox8.Location = new System.Drawing.Point(6, 32);
            this.groupBox8.Name = "groupBox8";
            this.groupBox8.Size = new System.Drawing.Size(301, 279);
            this.groupBox8.TabIndex = 2;
            this.groupBox8.TabStop = false;
            // 
            // panel82
            // 
            this.panel82.Controls.Add(this.button224);
            this.panel82.Controls.Add(this.button225);
            this.panel82.Controls.Add(this.button223);
            this.panel82.Location = new System.Drawing.Point(10, 233);
            this.panel82.Name = "panel82";
            this.panel82.Size = new System.Drawing.Size(289, 32);
            this.panel82.TabIndex = 17;
            // 
            // button224
            // 
            this.button224.BackColor = System.Drawing.SystemColors.HotTrack;
            this.button224.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button224.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button224.ForeColor = System.Drawing.Color.White;
            this.button224.Location = new System.Drawing.Point(99, 3);
            this.button224.Name = "button224";
            this.button224.Size = new System.Drawing.Size(89, 26);
            this.button224.TabIndex = 2;
            this.button224.Text = "button224";
            this.button224.UseVisualStyleBackColor = false;
            // 
            // button225
            // 
            this.button225.BackColor = System.Drawing.SystemColors.HotTrack;
            this.button225.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button225.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button225.ForeColor = System.Drawing.Color.White;
            this.button225.Location = new System.Drawing.Point(194, 3);
            this.button225.Name = "button225";
            this.button225.Size = new System.Drawing.Size(89, 26);
            this.button225.TabIndex = 1;
            this.button225.Text = "button225";
            this.button225.UseVisualStyleBackColor = false;
            // 
            // button223
            // 
            this.button223.BackColor = System.Drawing.SystemColors.HotTrack;
            this.button223.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button223.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button223.ForeColor = System.Drawing.Color.White;
            this.button223.Location = new System.Drawing.Point(4, 3);
            this.button223.Name = "button223";
            this.button223.Size = new System.Drawing.Size(89, 26);
            this.button223.TabIndex = 0;
            this.button223.Text = "button223";
            this.button223.UseVisualStyleBackColor = false;
            // 
            // panel21
            // 
            this.panel21.Controls.Add(this.button61);
            this.panel21.Controls.Add(this.button62);
            this.panel21.Controls.Add(this.button63);
            this.panel21.Location = new System.Drawing.Point(6, 195);
            this.panel21.Name = "panel21";
            this.panel21.Size = new System.Drawing.Size(289, 32);
            this.panel21.TabIndex = 12;
            // 
            // button61
            // 
            this.button61.BackColor = System.Drawing.Color.White;
            this.button61.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button61.Location = new System.Drawing.Point(4, 3);
            this.button61.Name = "button61";
            this.button61.Size = new System.Drawing.Size(89, 26);
            this.button61.TabIndex = 2;
            this.button61.Text = "button61";
            this.button61.UseVisualStyleBackColor = false;
            // 
            // button62
            // 
            this.button62.BackColor = System.Drawing.Color.White;
            this.button62.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button62.Location = new System.Drawing.Point(99, 3);
            this.button62.Name = "button62";
            this.button62.Size = new System.Drawing.Size(89, 26);
            this.button62.TabIndex = 1;
            this.button62.Text = "button62";
            this.button62.UseVisualStyleBackColor = false;
            // 
            // button63
            // 
            this.button63.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.button63.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button63.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button63.Location = new System.Drawing.Point(192, 3);
            this.button63.Name = "button63";
            this.button63.Size = new System.Drawing.Size(89, 26);
            this.button63.TabIndex = 0;
            this.button63.Text = "button63";
            this.button63.UseVisualStyleBackColor = false;
            // 
            // btnMjNmPurityShiftA
            // 
            this.btnMjNmPurityShiftA.Location = new System.Drawing.Point(198, 46);
            this.btnMjNmPurityShiftA.Name = "btnMjNmPurityShiftA";
            this.btnMjNmPurityShiftA.Size = new System.Drawing.Size(89, 26);
            this.btnMjNmPurityShiftA.TabIndex = 6;
            this.btnMjNmPurityShiftA.Text = "Purity";
            this.btnMjNmPurityShiftA.UseVisualStyleBackColor = true;
            // 
            // btnMjNmPolShiftA
            // 
            this.btnMjNmPolShiftA.Location = new System.Drawing.Point(101, 46);
            this.btnMjNmPolShiftA.Name = "btnMjNmPolShiftA";
            this.btnMjNmPolShiftA.Size = new System.Drawing.Size(89, 26);
            this.btnMjNmPolShiftA.TabIndex = 5;
            this.btnMjNmPolShiftA.Text = "Pol";
            this.btnMjNmPolShiftA.UseVisualStyleBackColor = true;
            // 
            // panel4
            // 
            this.panel4.Controls.Add(this.button7);
            this.panel4.Controls.Add(this.button8);
            this.panel4.Controls.Add(this.button9);
            this.panel4.Location = new System.Drawing.Point(4, 78);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(289, 32);
            this.panel4.TabIndex = 8;
            // 
            // button7
            // 
            this.button7.BackColor = System.Drawing.Color.White;
            this.button7.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button7.Location = new System.Drawing.Point(4, 3);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(89, 26);
            this.button7.TabIndex = 2;
            this.button7.Text = "button7";
            this.button7.UseVisualStyleBackColor = false;
            // 
            // button8
            // 
            this.button8.BackColor = System.Drawing.Color.White;
            this.button8.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button8.Location = new System.Drawing.Point(99, 3);
            this.button8.Name = "button8";
            this.button8.Size = new System.Drawing.Size(89, 26);
            this.button8.TabIndex = 1;
            this.button8.Text = "button8";
            this.button8.UseVisualStyleBackColor = false;
            // 
            // button9
            // 
            this.button9.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.button9.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button9.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button9.Location = new System.Drawing.Point(194, 3);
            this.button9.Name = "button9";
            this.button9.Size = new System.Drawing.Size(89, 26);
            this.button9.TabIndex = 0;
            this.button9.Text = "button9";
            this.button9.UseVisualStyleBackColor = false;
            // 
            // btnMjNmBrixShiftA
            // 
            this.btnMjNmBrixShiftA.Location = new System.Drawing.Point(6, 46);
            this.btnMjNmBrixShiftA.Name = "btnMjNmBrixShiftA";
            this.btnMjNmBrixShiftA.Size = new System.Drawing.Size(89, 26);
            this.btnMjNmBrixShiftA.TabIndex = 4;
            this.btnMjNmBrixShiftA.Text = "Brix";
            this.btnMjNmBrixShiftA.UseVisualStyleBackColor = true;
            // 
            // btnMjNmShiftA
            // 
            this.btnMjNmShiftA.Location = new System.Drawing.Point(6, 10);
            this.btnMjNmShiftA.Name = "btnMjNmShiftA";
            this.btnMjNmShiftA.Size = new System.Drawing.Size(281, 34);
            this.btnMjNmShiftA.TabIndex = 1;
            this.btnMjNmShiftA.Text = "New Mill";
            this.btnMjNmShiftA.UseVisualStyleBackColor = true;
            // 
            // panel16
            // 
            this.panel16.Controls.Add(this.button43);
            this.panel16.Controls.Add(this.button44);
            this.panel16.Controls.Add(this.button45);
            this.panel16.Location = new System.Drawing.Point(6, 157);
            this.panel16.Name = "panel16";
            this.panel16.Size = new System.Drawing.Size(289, 32);
            this.panel16.TabIndex = 10;
            // 
            // button43
            // 
            this.button43.BackColor = System.Drawing.Color.White;
            this.button43.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button43.Location = new System.Drawing.Point(4, 3);
            this.button43.Name = "button43";
            this.button43.Size = new System.Drawing.Size(89, 26);
            this.button43.TabIndex = 2;
            this.button43.Text = "button43";
            this.button43.UseVisualStyleBackColor = false;
            // 
            // button44
            // 
            this.button44.BackColor = System.Drawing.Color.White;
            this.button44.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button44.Location = new System.Drawing.Point(99, 3);
            this.button44.Name = "button44";
            this.button44.Size = new System.Drawing.Size(89, 26);
            this.button44.TabIndex = 1;
            this.button44.Text = "button44";
            this.button44.UseVisualStyleBackColor = false;
            // 
            // button45
            // 
            this.button45.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.button45.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button45.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button45.Location = new System.Drawing.Point(192, 3);
            this.button45.Name = "button45";
            this.button45.Size = new System.Drawing.Size(89, 26);
            this.button45.TabIndex = 0;
            this.button45.Text = "button45";
            this.button45.UseVisualStyleBackColor = false;
            // 
            // panel10
            // 
            this.panel10.Controls.Add(this.button25);
            this.panel10.Controls.Add(this.button26);
            this.panel10.Controls.Add(this.button27);
            this.panel10.Location = new System.Drawing.Point(4, 116);
            this.panel10.Name = "panel10";
            this.panel10.Size = new System.Drawing.Size(289, 32);
            this.panel10.TabIndex = 11;
            // 
            // button25
            // 
            this.button25.BackColor = System.Drawing.Color.White;
            this.button25.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button25.Location = new System.Drawing.Point(4, 3);
            this.button25.Name = "button25";
            this.button25.Size = new System.Drawing.Size(89, 26);
            this.button25.TabIndex = 2;
            this.button25.Text = "button25";
            this.button25.UseVisualStyleBackColor = false;
            // 
            // button26
            // 
            this.button26.BackColor = System.Drawing.Color.White;
            this.button26.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button26.Location = new System.Drawing.Point(99, 3);
            this.button26.Name = "button26";
            this.button26.Size = new System.Drawing.Size(89, 26);
            this.button26.TabIndex = 1;
            this.button26.Text = "button26";
            this.button26.UseVisualStyleBackColor = false;
            // 
            // button27
            // 
            this.button27.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.button27.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button27.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button27.Location = new System.Drawing.Point(194, 3);
            this.button27.Name = "button27";
            this.button27.Size = new System.Drawing.Size(89, 26);
            this.button27.TabIndex = 0;
            this.button27.Text = "button27";
            this.button27.UseVisualStyleBackColor = false;
            // 
            // btnMixedJuiceShiftA
            // 
            this.btnMixedJuiceShiftA.Location = new System.Drawing.Point(12, 10);
            this.btnMixedJuiceShiftA.Name = "btnMixedJuiceShiftA";
            this.btnMixedJuiceShiftA.Size = new System.Drawing.Size(602, 23);
            this.btnMixedJuiceShiftA.TabIndex = 1;
            this.btnMixedJuiceShiftA.Text = "Mixed Juice";
            this.btnMixedJuiceShiftA.UseVisualStyleBackColor = true;
            // 
            // groupBox6
            // 
            this.groupBox6.Controls.Add(this.btnAverage);
            this.groupBox6.Controls.Add(this.btnTime16);
            this.groupBox6.Controls.Add(this.btnTime14);
            this.groupBox6.Controls.Add(this.btnTime12);
            this.groupBox6.Controls.Add(this.btnTime10);
            this.groupBox6.Controls.Add(this.btnTimePj);
            this.groupBox6.Location = new System.Drawing.Point(15, 12);
            this.groupBox6.Name = "groupBox6";
            this.groupBox6.Size = new System.Drawing.Size(92, 330);
            this.groupBox6.TabIndex = 1;
            this.groupBox6.TabStop = false;
            // 
            // btnAverage
            // 
            this.btnAverage.Location = new System.Drawing.Point(7, 266);
            this.btnAverage.Name = "btnAverage";
            this.btnAverage.Size = new System.Drawing.Size(75, 26);
            this.btnAverage.TabIndex = 6;
            this.btnAverage.Text = "Average";
            this.btnAverage.UseVisualStyleBackColor = true;
            // 
            // btnTime16
            // 
            this.btnTime16.Location = new System.Drawing.Point(7, 224);
            this.btnTime16.Name = "btnTime16";
            this.btnTime16.Size = new System.Drawing.Size(75, 26);
            this.btnTime16.TabIndex = 5;
            this.btnTime16.Text = "16";
            this.btnTime16.UseVisualStyleBackColor = true;
            // 
            // btnTime14
            // 
            this.btnTime14.Location = new System.Drawing.Point(7, 189);
            this.btnTime14.Name = "btnTime14";
            this.btnTime14.Size = new System.Drawing.Size(75, 26);
            this.btnTime14.TabIndex = 4;
            this.btnTime14.Text = "14";
            this.btnTime14.UseVisualStyleBackColor = true;
            // 
            // btnTime12
            // 
            this.btnTime12.Location = new System.Drawing.Point(7, 151);
            this.btnTime12.Name = "btnTime12";
            this.btnTime12.Size = new System.Drawing.Size(75, 26);
            this.btnTime12.TabIndex = 3;
            this.btnTime12.Text = "12";
            this.btnTime12.UseVisualStyleBackColor = true;
            // 
            // btnTime10
            // 
            this.btnTime10.Location = new System.Drawing.Point(7, 113);
            this.btnTime10.Name = "btnTime10";
            this.btnTime10.Size = new System.Drawing.Size(75, 26);
            this.btnTime10.TabIndex = 2;
            this.btnTime10.Text = "10";
            this.btnTime10.UseVisualStyleBackColor = true;
            // 
            // btnTimePj
            // 
            this.btnTimePj.Location = new System.Drawing.Point(6, 48);
            this.btnTimePj.Name = "btnTimePj";
            this.btnTimePj.Size = new System.Drawing.Size(76, 56);
            this.btnTimePj.TabIndex = 2;
            this.btnTimePj.Text = "Time";
            this.btnTimePj.UseVisualStyleBackColor = true;
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.groupBox5);
            this.groupBox3.Controls.Add(this.groupBox4);
            this.groupBox3.Controls.Add(this.btnPrimaryJuiceShiftA);
            this.groupBox3.Location = new System.Drawing.Point(112, 12);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(614, 330);
            this.groupBox3.TabIndex = 0;
            this.groupBox3.TabStop = false;
            // 
            // groupBox5
            // 
            this.groupBox5.Controls.Add(this.button58);
            this.groupBox5.Controls.Add(this.button59);
            this.groupBox5.Controls.Add(this.button22);
            this.groupBox5.Controls.Add(this.button60);
            this.groupBox5.Controls.Add(this.panel81);
            this.groupBox5.Controls.Add(this.button40);
            this.groupBox5.Controls.Add(this.button23);
            this.groupBox5.Controls.Add(this.button41);
            this.groupBox5.Controls.Add(this.button24);
            this.groupBox5.Controls.Add(this.button4);
            this.groupBox5.Controls.Add(this.button42);
            this.groupBox5.Controls.Add(this.btnPjOmPurityShiftA);
            this.groupBox5.Controls.Add(this.button5);
            this.groupBox5.Controls.Add(this.btnPjOmPolShiftA);
            this.groupBox5.Controls.Add(this.btnPjOmBrixShiftA);
            this.groupBox5.Controls.Add(this.button6);
            this.groupBox5.Controls.Add(this.btnPjOmShiftA);
            this.groupBox5.Location = new System.Drawing.Point(312, 32);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(297, 279);
            this.groupBox5.TabIndex = 2;
            this.groupBox5.TabStop = false;
            // 
            // btnPjOmPurityShiftA
            // 
            this.btnPjOmPurityShiftA.Location = new System.Drawing.Point(202, 46);
            this.btnPjOmPurityShiftA.Name = "btnPjOmPurityShiftA";
            this.btnPjOmPurityShiftA.Size = new System.Drawing.Size(89, 26);
            this.btnPjOmPurityShiftA.TabIndex = 6;
            this.btnPjOmPurityShiftA.Text = "Purity";
            this.btnPjOmPurityShiftA.UseVisualStyleBackColor = true;
            // 
            // btnPjOmPolShiftA
            // 
            this.btnPjOmPolShiftA.Location = new System.Drawing.Point(105, 46);
            this.btnPjOmPolShiftA.Name = "btnPjOmPolShiftA";
            this.btnPjOmPolShiftA.Size = new System.Drawing.Size(89, 26);
            this.btnPjOmPolShiftA.TabIndex = 5;
            this.btnPjOmPolShiftA.Text = "Pol";
            this.btnPjOmPolShiftA.UseVisualStyleBackColor = true;
            // 
            // btnPjOmBrixShiftA
            // 
            this.btnPjOmBrixShiftA.Location = new System.Drawing.Point(8, 46);
            this.btnPjOmBrixShiftA.Name = "btnPjOmBrixShiftA";
            this.btnPjOmBrixShiftA.Size = new System.Drawing.Size(89, 26);
            this.btnPjOmBrixShiftA.TabIndex = 4;
            this.btnPjOmBrixShiftA.Text = "Brix";
            this.btnPjOmBrixShiftA.UseVisualStyleBackColor = true;
            // 
            // btnPjOmShiftA
            // 
            this.btnPjOmShiftA.Location = new System.Drawing.Point(8, 10);
            this.btnPjOmShiftA.Name = "btnPjOmShiftA";
            this.btnPjOmShiftA.Size = new System.Drawing.Size(287, 34);
            this.btnPjOmShiftA.TabIndex = 0;
            this.btnPjOmShiftA.Text = "Old Mill";
            this.btnPjOmShiftA.UseVisualStyleBackColor = true;
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.button218);
            this.groupBox4.Controls.Add(this.button55);
            this.groupBox4.Controls.Add(this.button56);
            this.groupBox4.Controls.Add(this.button217);
            this.groupBox4.Controls.Add(this.button219);
            this.groupBox4.Controls.Add(this.button19);
            this.groupBox4.Controls.Add(this.button57);
            this.groupBox4.Controls.Add(this.button3);
            this.groupBox4.Controls.Add(this.button37);
            this.groupBox4.Controls.Add(this.button20);
            this.groupBox4.Controls.Add(this.button38);
            this.groupBox4.Controls.Add(this.button21);
            this.groupBox4.Controls.Add(this.button39);
            this.groupBox4.Controls.Add(this.button2);
            this.groupBox4.Controls.Add(this.btnPjNmPurityShiftA);
            this.groupBox4.Controls.Add(this.button1);
            this.groupBox4.Controls.Add(this.btnPjNmPolShiftA);
            this.groupBox4.Controls.Add(this.btnPjNmBrixShiftA);
            this.groupBox4.Controls.Add(this.btnPjNmShiftA);
            this.groupBox4.Location = new System.Drawing.Point(11, 32);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(297, 279);
            this.groupBox4.TabIndex = 1;
            this.groupBox4.TabStop = false;
            // 
            // button218
            // 
            this.button218.BackColor = System.Drawing.SystemColors.HotTrack;
            this.button218.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button218.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button218.ForeColor = System.Drawing.Color.White;
            this.button218.Location = new System.Drawing.Point(100, 230);
            this.button218.Name = "button218";
            this.button218.Size = new System.Drawing.Size(89, 26);
            this.button218.TabIndex = 3;
            this.button218.Text = "button218";
            this.button218.UseVisualStyleBackColor = false;
            // 
            // button217
            // 
            this.button217.BackColor = System.Drawing.SystemColors.HotTrack;
            this.button217.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button217.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button217.ForeColor = System.Drawing.Color.White;
            this.button217.Location = new System.Drawing.Point(5, 233);
            this.button217.Name = "button217";
            this.button217.Size = new System.Drawing.Size(89, 26);
            this.button217.TabIndex = 2;
            this.button217.Text = "button217";
            this.button217.UseVisualStyleBackColor = false;
            // 
            // button219
            // 
            this.button219.BackColor = System.Drawing.SystemColors.HotTrack;
            this.button219.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button219.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button219.ForeColor = System.Drawing.Color.White;
            this.button219.Location = new System.Drawing.Point(195, 233);
            this.button219.Name = "button219";
            this.button219.Size = new System.Drawing.Size(89, 26);
            this.button219.TabIndex = 1;
            this.button219.Text = "button219";
            this.button219.UseVisualStyleBackColor = false;
            // 
            // button55
            // 
            this.button55.BackColor = System.Drawing.Color.White;
            this.button55.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button55.Location = new System.Drawing.Point(5, 186);
            this.button55.Name = "button55";
            this.button55.Size = new System.Drawing.Size(89, 26);
            this.button55.TabIndex = 2;
            this.button55.Text = "button55";
            this.button55.UseVisualStyleBackColor = false;
            // 
            // button56
            // 
            this.button56.BackColor = System.Drawing.Color.White;
            this.button56.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button56.Location = new System.Drawing.Point(100, 186);
            this.button56.Name = "button56";
            this.button56.Size = new System.Drawing.Size(89, 26);
            this.button56.TabIndex = 1;
            this.button56.Text = "button56";
            this.button56.UseVisualStyleBackColor = false;
            // 
            // button57
            // 
            this.button57.BackColor = System.Drawing.Color.White;
            this.button57.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button57.Location = new System.Drawing.Point(193, 186);
            this.button57.Name = "button57";
            this.button57.Size = new System.Drawing.Size(89, 26);
            this.button57.TabIndex = 0;
            this.button57.Text = "button57";
            this.button57.UseVisualStyleBackColor = false;
            // 
            // button19
            // 
            this.button19.BackColor = System.Drawing.Color.White;
            this.button19.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button19.Location = new System.Drawing.Point(5, 110);
            this.button19.Name = "button19";
            this.button19.Size = new System.Drawing.Size(89, 26);
            this.button19.TabIndex = 2;
            this.button19.Text = "button19";
            this.button19.UseVisualStyleBackColor = false;
            // 
            // button20
            // 
            this.button20.BackColor = System.Drawing.Color.White;
            this.button20.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button20.Location = new System.Drawing.Point(100, 110);
            this.button20.Name = "button20";
            this.button20.Size = new System.Drawing.Size(89, 26);
            this.button20.TabIndex = 1;
            this.button20.Text = "button20";
            this.button20.UseVisualStyleBackColor = false;
            // 
            // button21
            // 
            this.button21.BackColor = System.Drawing.Color.White;
            this.button21.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button21.Location = new System.Drawing.Point(195, 110);
            this.button21.Name = "button21";
            this.button21.Size = new System.Drawing.Size(89, 26);
            this.button21.TabIndex = 0;
            this.button21.Text = "button21";
            this.button21.UseVisualStyleBackColor = false;
            // 
            // button3
            // 
            this.button3.BackColor = System.Drawing.Color.White;
            this.button3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button3.Location = new System.Drawing.Point(195, 78);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(89, 26);
            this.button3.TabIndex = 2;
            this.button3.Text = "button3";
            this.button3.UseVisualStyleBackColor = false;
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.White;
            this.button2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button2.Location = new System.Drawing.Point(100, 78);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(89, 26);
            this.button2.TabIndex = 1;
            this.button2.Text = "button2";
            this.button2.UseVisualStyleBackColor = false;
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.White;
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.Location = new System.Drawing.Point(5, 78);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(89, 26);
            this.button1.TabIndex = 0;
            this.button1.Text = "button1";
            this.button1.UseVisualStyleBackColor = false;
            // 
            // btnPjNmPurityShiftA
            // 
            this.btnPjNmPurityShiftA.Location = new System.Drawing.Point(190, 46);
            this.btnPjNmPurityShiftA.Name = "btnPjNmPurityShiftA";
            this.btnPjNmPurityShiftA.Size = new System.Drawing.Size(89, 26);
            this.btnPjNmPurityShiftA.TabIndex = 3;
            this.btnPjNmPurityShiftA.Text = "Purity";
            this.btnPjNmPurityShiftA.UseVisualStyleBackColor = true;
            // 
            // btnPjNmPolShiftA
            // 
            this.btnPjNmPolShiftA.Location = new System.Drawing.Point(95, 46);
            this.btnPjNmPolShiftA.Name = "btnPjNmPolShiftA";
            this.btnPjNmPolShiftA.Size = new System.Drawing.Size(89, 26);
            this.btnPjNmPolShiftA.TabIndex = 2;
            this.btnPjNmPolShiftA.Text = "Pol";
            this.btnPjNmPolShiftA.UseVisualStyleBackColor = true;
            // 
            // btnPjNmBrixShiftA
            // 
            this.btnPjNmBrixShiftA.Location = new System.Drawing.Point(0, 46);
            this.btnPjNmBrixShiftA.Name = "btnPjNmBrixShiftA";
            this.btnPjNmBrixShiftA.Size = new System.Drawing.Size(89, 26);
            this.btnPjNmBrixShiftA.TabIndex = 1;
            this.btnPjNmBrixShiftA.Text = "Brix";
            this.btnPjNmBrixShiftA.UseVisualStyleBackColor = true;
            // 
            // btnPjNmShiftA
            // 
            this.btnPjNmShiftA.Location = new System.Drawing.Point(0, 10);
            this.btnPjNmShiftA.Name = "btnPjNmShiftA";
            this.btnPjNmShiftA.Size = new System.Drawing.Size(279, 34);
            this.btnPjNmShiftA.TabIndex = 0;
            this.btnPjNmShiftA.Text = "New Mill";
            this.btnPjNmShiftA.UseVisualStyleBackColor = true;
            // 
            // button37
            // 
            this.button37.BackColor = System.Drawing.Color.White;
            this.button37.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button37.Location = new System.Drawing.Point(5, 154);
            this.button37.Name = "button37";
            this.button37.Size = new System.Drawing.Size(89, 26);
            this.button37.TabIndex = 2;
            this.button37.Text = "button37";
            this.button37.UseVisualStyleBackColor = false;
            // 
            // button38
            // 
            this.button38.BackColor = System.Drawing.Color.White;
            this.button38.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button38.Location = new System.Drawing.Point(100, 154);
            this.button38.Name = "button38";
            this.button38.Size = new System.Drawing.Size(89, 26);
            this.button38.TabIndex = 1;
            this.button38.Text = "button38";
            this.button38.UseVisualStyleBackColor = false;
            // 
            // button39
            // 
            this.button39.BackColor = System.Drawing.Color.White;
            this.button39.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button39.Location = new System.Drawing.Point(193, 154);
            this.button39.Name = "button39";
            this.button39.Size = new System.Drawing.Size(89, 26);
            this.button39.TabIndex = 0;
            this.button39.Text = "button39";
            this.button39.UseVisualStyleBackColor = false;
            // 
            // btnPrimaryJuiceShiftA
            // 
            this.btnPrimaryJuiceShiftA.Location = new System.Drawing.Point(17, 10);
            this.btnPrimaryJuiceShiftA.Name = "btnPrimaryJuiceShiftA";
            this.btnPrimaryJuiceShiftA.Size = new System.Drawing.Size(593, 23);
            this.btnPrimaryJuiceShiftA.TabIndex = 0;
            this.btnPrimaryJuiceShiftA.Text = "Primary Juice";
            this.btnPrimaryJuiceShiftA.UseVisualStyleBackColor = true;
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.groupBox1.Controls.Add(this.lblCropDayValue);
            this.groupBox1.Controls.Add(this.lblCropDay);
            this.groupBox1.Controls.Add(this.lblReportDateValue);
            this.groupBox1.Controls.Add(this.lblReportDate);
            this.groupBox1.Location = new System.Drawing.Point(12, 12);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(2063, 61);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Report Parameters";
            // 
            // lblCropDayValue
            // 
            this.lblCropDayValue.AutoSize = true;
            this.lblCropDayValue.Location = new System.Drawing.Point(368, 27);
            this.lblCropDayValue.Name = "lblCropDayValue";
            this.lblCropDayValue.Size = new System.Drawing.Size(67, 17);
            this.lblCropDayValue.TabIndex = 3;
            this.lblCropDayValue.Text = "Crop Day";
            // 
            // lblCropDay
            // 
            this.lblCropDay.AutoSize = true;
            this.lblCropDay.Location = new System.Drawing.Point(284, 27);
            this.lblCropDay.Name = "lblCropDay";
            this.lblCropDay.Size = new System.Drawing.Size(67, 17);
            this.lblCropDay.TabIndex = 2;
            this.lblCropDay.Text = "Crop Day";
            // 
            // lblReportDateValue
            // 
            this.lblReportDateValue.AutoSize = true;
            this.lblReportDateValue.Location = new System.Drawing.Point(119, 27);
            this.lblReportDateValue.Name = "lblReportDateValue";
            this.lblReportDateValue.Size = new System.Drawing.Size(85, 17);
            this.lblReportDateValue.TabIndex = 1;
            this.lblReportDateValue.Text = "Report Date";
            // 
            // lblReportDate
            // 
            this.lblReportDate.AutoSize = true;
            this.lblReportDate.Location = new System.Drawing.Point(16, 27);
            this.lblReportDate.Name = "lblReportDate";
            this.lblReportDate.Size = new System.Drawing.Size(85, 17);
            this.lblReportDate.TabIndex = 0;
            this.lblReportDate.Text = "Report Date";
            // 
            // button42
            // 
            this.button42.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.button42.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button42.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button42.Location = new System.Drawing.Point(201, 154);
            this.button42.Name = "button42";
            this.button42.Size = new System.Drawing.Size(89, 26);
            this.button42.TabIndex = 0;
            this.button42.Text = "button42";
            this.button42.UseVisualStyleBackColor = false;
            // 
            // button41
            // 
            this.button41.BackColor = System.Drawing.Color.White;
            this.button41.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button41.Location = new System.Drawing.Point(108, 154);
            this.button41.Name = "button41";
            this.button41.Size = new System.Drawing.Size(89, 26);
            this.button41.TabIndex = 1;
            this.button41.Text = "button41";
            this.button41.UseVisualStyleBackColor = false;
            // 
            // button40
            // 
            this.button40.BackColor = System.Drawing.Color.White;
            this.button40.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button40.Location = new System.Drawing.Point(13, 154);
            this.button40.Name = "button40";
            this.button40.Size = new System.Drawing.Size(89, 26);
            this.button40.TabIndex = 2;
            this.button40.Text = "button40";
            this.button40.UseVisualStyleBackColor = false;
            // 
            // button6
            // 
            this.button6.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.button6.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button6.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button6.Location = new System.Drawing.Point(200, 78);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(89, 26);
            this.button6.TabIndex = 0;
            this.button6.Text = "button6";
            this.button6.UseVisualStyleBackColor = false;
            // 
            // button5
            // 
            this.button5.BackColor = System.Drawing.Color.White;
            this.button5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button5.Location = new System.Drawing.Point(104, 78);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(89, 26);
            this.button5.TabIndex = 1;
            this.button5.Text = "button5";
            this.button5.UseVisualStyleBackColor = false;
            // 
            // button4
            // 
            this.button4.BackColor = System.Drawing.Color.White;
            this.button4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button4.Location = new System.Drawing.Point(10, 78);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(89, 26);
            this.button4.TabIndex = 2;
            this.button4.Text = "button4";
            this.button4.UseVisualStyleBackColor = false;
            // 
            // button24
            // 
            this.button24.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.button24.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button24.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button24.Location = new System.Drawing.Point(198, 110);
            this.button24.Name = "button24";
            this.button24.Size = new System.Drawing.Size(89, 26);
            this.button24.TabIndex = 0;
            this.button24.Text = "button24";
            this.button24.UseVisualStyleBackColor = false;
            // 
            // button23
            // 
            this.button23.BackColor = System.Drawing.Color.White;
            this.button23.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button23.Location = new System.Drawing.Point(102, 110);
            this.button23.Name = "button23";
            this.button23.Size = new System.Drawing.Size(89, 26);
            this.button23.TabIndex = 1;
            this.button23.Text = "button23";
            this.button23.UseVisualStyleBackColor = false;
            // 
            // button22
            // 
            this.button22.BackColor = System.Drawing.Color.White;
            this.button22.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button22.Location = new System.Drawing.Point(10, 110);
            this.button22.Name = "button22";
            this.button22.Size = new System.Drawing.Size(89, 26);
            this.button22.TabIndex = 2;
            this.button22.Text = "button22";
            this.button22.UseVisualStyleBackColor = false;
            // 
            // button60
            // 
            this.button60.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.button60.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button60.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button60.Location = new System.Drawing.Point(201, 192);
            this.button60.Name = "button60";
            this.button60.Size = new System.Drawing.Size(89, 26);
            this.button60.TabIndex = 0;
            this.button60.Text = "button60";
            this.button60.UseVisualStyleBackColor = false;
            // 
            // button59
            // 
            this.button59.BackColor = System.Drawing.Color.White;
            this.button59.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button59.Location = new System.Drawing.Point(108, 192);
            this.button59.Name = "button59";
            this.button59.Size = new System.Drawing.Size(89, 26);
            this.button59.TabIndex = 1;
            this.button59.Text = "button59";
            this.button59.UseVisualStyleBackColor = false;
            // 
            // button58
            // 
            this.button58.BackColor = System.Drawing.Color.White;
            this.button58.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button58.Location = new System.Drawing.Point(13, 192);
            this.button58.Name = "button58";
            this.button58.Size = new System.Drawing.Size(89, 26);
            this.button58.TabIndex = 2;
            this.button58.Text = "button58";
            this.button58.UseVisualStyleBackColor = false;
            // 
            // button220
            // 
            this.button220.BackColor = System.Drawing.SystemColors.HotTrack;
            this.button220.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button220.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button220.ForeColor = System.Drawing.Color.White;
            this.button220.Location = new System.Drawing.Point(3, 2);
            this.button220.Name = "button220";
            this.button220.Size = new System.Drawing.Size(89, 26);
            this.button220.TabIndex = 0;
            this.button220.Text = "button220";
            this.button220.UseVisualStyleBackColor = false;
            // 
            // button222
            // 
            this.button222.BackColor = System.Drawing.SystemColors.HotTrack;
            this.button222.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button222.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button222.ForeColor = System.Drawing.Color.White;
            this.button222.Location = new System.Drawing.Point(192, 3);
            this.button222.Name = "button222";
            this.button222.Size = new System.Drawing.Size(89, 26);
            this.button222.TabIndex = 1;
            this.button222.Text = "button222";
            this.button222.UseVisualStyleBackColor = false;
            // 
            // button221
            // 
            this.button221.BackColor = System.Drawing.SystemColors.HotTrack;
            this.button221.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button221.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button221.ForeColor = System.Drawing.Color.White;
            this.button221.Location = new System.Drawing.Point(97, 3);
            this.button221.Name = "button221";
            this.button221.Size = new System.Drawing.Size(89, 26);
            this.button221.TabIndex = 2;
            this.button221.Text = "button221";
            this.button221.UseVisualStyleBackColor = false;
            // 
            // panel81
            // 
            this.panel81.Controls.Add(this.button221);
            this.panel81.Controls.Add(this.button222);
            this.panel81.Controls.Add(this.button220);
            this.panel81.Location = new System.Drawing.Point(10, 237);
            this.panel81.Name = "panel81";
            this.panel81.Size = new System.Drawing.Size(289, 32);
            this.panel81.TabIndex = 17;
            // 
            // repo_two_hourly_juice
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1835, 942);
            this.Controls.Add(this.panel1);
            this.Name = "repo_two_hourly_juice";
            this.Text = "repo_two_hourly_juice";
            this.panel1.ResumeLayout(false);
            this.groupBox35.ResumeLayout(false);
            this.groupBox35.PerformLayout();
            this.panel79.ResumeLayout(false);
            this.panel78.ResumeLayout(false);
            this.panel77.ResumeLayout(false);
            this.panel76.ResumeLayout(false);
            this.panel75.ResumeLayout(false);
            this.panel74.ResumeLayout(false);
            this.groupBox24.ResumeLayout(false);
            this.groupBox25.ResumeLayout(false);
            this.groupBox26.ResumeLayout(false);
            this.panel97.ResumeLayout(false);
            this.panel73.ResumeLayout(false);
            this.panel67.ResumeLayout(false);
            this.panel61.ResumeLayout(false);
            this.panel55.ResumeLayout(false);
            this.groupBox27.ResumeLayout(false);
            this.panel96.ResumeLayout(false);
            this.panel72.ResumeLayout(false);
            this.panel66.ResumeLayout(false);
            this.panel60.ResumeLayout(false);
            this.panel54.ResumeLayout(false);
            this.groupBox28.ResumeLayout(false);
            this.groupBox29.ResumeLayout(false);
            this.panel95.ResumeLayout(false);
            this.panel71.ResumeLayout(false);
            this.panel65.ResumeLayout(false);
            this.panel59.ResumeLayout(false);
            this.panel53.ResumeLayout(false);
            this.groupBox30.ResumeLayout(false);
            this.panel94.ResumeLayout(false);
            this.panel70.ResumeLayout(false);
            this.panel64.ResumeLayout(false);
            this.panel58.ResumeLayout(false);
            this.panel52.ResumeLayout(false);
            this.groupBox31.ResumeLayout(false);
            this.groupBox32.ResumeLayout(false);
            this.groupBox33.ResumeLayout(false);
            this.panel93.ResumeLayout(false);
            this.panel69.ResumeLayout(false);
            this.panel63.ResumeLayout(false);
            this.panel57.ResumeLayout(false);
            this.panel51.ResumeLayout(false);
            this.groupBox34.ResumeLayout(false);
            this.panel92.ResumeLayout(false);
            this.panel68.ResumeLayout(false);
            this.panel62.ResumeLayout(false);
            this.panel56.ResumeLayout(false);
            this.panel50.ResumeLayout(false);
            this.groupBox13.ResumeLayout(false);
            this.groupBox14.ResumeLayout(false);
            this.groupBox15.ResumeLayout(false);
            this.panel91.ResumeLayout(false);
            this.panel49.ResumeLayout(false);
            this.panel43.ResumeLayout(false);
            this.panel37.ResumeLayout(false);
            this.panel31.ResumeLayout(false);
            this.groupBox16.ResumeLayout(false);
            this.panel90.ResumeLayout(false);
            this.panel48.ResumeLayout(false);
            this.panel42.ResumeLayout(false);
            this.panel36.ResumeLayout(false);
            this.panel30.ResumeLayout(false);
            this.groupBox17.ResumeLayout(false);
            this.groupBox18.ResumeLayout(false);
            this.panel89.ResumeLayout(false);
            this.panel47.ResumeLayout(false);
            this.panel41.ResumeLayout(false);
            this.panel35.ResumeLayout(false);
            this.panel29.ResumeLayout(false);
            this.groupBox19.ResumeLayout(false);
            this.panel88.ResumeLayout(false);
            this.panel46.ResumeLayout(false);
            this.panel40.ResumeLayout(false);
            this.panel34.ResumeLayout(false);
            this.panel27.ResumeLayout(false);
            this.groupBox20.ResumeLayout(false);
            this.groupBox21.ResumeLayout(false);
            this.groupBox22.ResumeLayout(false);
            this.panel87.ResumeLayout(false);
            this.panel45.ResumeLayout(false);
            this.panel39.ResumeLayout(false);
            this.panel33.ResumeLayout(false);
            this.panel26.ResumeLayout(false);
            this.groupBox23.ResumeLayout(false);
            this.panel86.ResumeLayout(false);
            this.panel44.ResumeLayout(false);
            this.panel38.ResumeLayout(false);
            this.panel32.ResumeLayout(false);
            this.panel25.ResumeLayout(false);
            this.groupBox2.ResumeLayout(false);
            this.groupBox10.ResumeLayout(false);
            this.groupBox11.ResumeLayout(false);
            this.panel85.ResumeLayout(false);
            this.panel24.ResumeLayout(false);
            this.panel18.ResumeLayout(false);
            this.panel7.ResumeLayout(false);
            this.panel13.ResumeLayout(false);
            this.groupBox12.ResumeLayout(false);
            this.panel84.ResumeLayout(false);
            this.panel23.ResumeLayout(false);
            this.panel28.ResumeLayout(false);
            this.panel6.ResumeLayout(false);
            this.panel12.ResumeLayout(false);
            this.groupBox7.ResumeLayout(false);
            this.groupBox9.ResumeLayout(false);
            this.panel83.ResumeLayout(false);
            this.panel22.ResumeLayout(false);
            this.panel5.ResumeLayout(false);
            this.panel17.ResumeLayout(false);
            this.panel11.ResumeLayout(false);
            this.groupBox8.ResumeLayout(false);
            this.panel82.ResumeLayout(false);
            this.panel21.ResumeLayout(false);
            this.panel4.ResumeLayout(false);
            this.panel16.ResumeLayout(false);
            this.panel10.ResumeLayout(false);
            this.groupBox6.ResumeLayout(false);
            this.groupBox3.ResumeLayout(false);
            this.groupBox5.ResumeLayout(false);
            this.groupBox4.ResumeLayout(false);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.panel81.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label lblCropDayValue;
        private System.Windows.Forms.Label lblCropDay;
        private System.Windows.Forms.Label lblReportDateValue;
        private System.Windows.Forms.Label lblReportDate;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.GroupBox groupBox6;
        private System.Windows.Forms.Button btnTimePj;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.Button btnPjOmShiftA;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.Button btnPjNmShiftA;
        private System.Windows.Forms.Button btnPrimaryJuiceShiftA;
        private System.Windows.Forms.Button btnPjOmPurityShiftA;
        private System.Windows.Forms.Button btnPjOmPolShiftA;
        private System.Windows.Forms.Button btnPjOmBrixShiftA;
        private System.Windows.Forms.Button btnPjNmPurityShiftA;
        private System.Windows.Forms.Button btnPjNmPolShiftA;
        private System.Windows.Forms.Button btnPjNmBrixShiftA;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Panel panel7;
        private System.Windows.Forms.Button button16;
        private System.Windows.Forms.Button button17;
        private System.Windows.Forms.Button button18;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Button button10;
        private System.Windows.Forms.Button button11;
        private System.Windows.Forms.Button button12;
        private System.Windows.Forms.Button button19;
        private System.Windows.Forms.Button button20;
        private System.Windows.Forms.Button button21;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.Button button13;
        private System.Windows.Forms.Button button14;
        private System.Windows.Forms.Button button15;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.Button button8;
        private System.Windows.Forms.Button button9;
        private System.Windows.Forms.Button btnTime16;
        private System.Windows.Forms.Button btnTime14;
        private System.Windows.Forms.Button btnTime12;
        private System.Windows.Forms.Button btnTime10;
        private System.Windows.Forms.Button btnAverage;
        private System.Windows.Forms.Panel panel11;
        private System.Windows.Forms.Button button28;
        private System.Windows.Forms.Button button29;
        private System.Windows.Forms.Button button30;
        private System.Windows.Forms.Panel panel10;
        private System.Windows.Forms.Button button25;
        private System.Windows.Forms.Button button26;
        private System.Windows.Forms.Button button27;
        private System.Windows.Forms.GroupBox groupBox7;
        private System.Windows.Forms.GroupBox groupBox9;
        private System.Windows.Forms.Button btnMjOmPurityShiftA;
        private System.Windows.Forms.Button btnMjOmPolShiftA;
        private System.Windows.Forms.Button btnMjOmBrixShiftA;
        private System.Windows.Forms.Button btnMjOmShiftA;
        private System.Windows.Forms.GroupBox groupBox8;
        private System.Windows.Forms.Button btnMjNmPurityShiftA;
        private System.Windows.Forms.Button btnMjNmPolShiftA;
        private System.Windows.Forms.Button btnMjNmBrixShiftA;
        private System.Windows.Forms.Button btnMjNmShiftA;
        private System.Windows.Forms.Button btnMixedJuiceShiftA;
        private System.Windows.Forms.Panel panel17;
        private System.Windows.Forms.Button button46;
        private System.Windows.Forms.Button button47;
        private System.Windows.Forms.Button button48;
        private System.Windows.Forms.Panel panel16;
        private System.Windows.Forms.Button button43;
        private System.Windows.Forms.Button button44;
        private System.Windows.Forms.Button button45;
        private System.Windows.Forms.Panel panel13;
        private System.Windows.Forms.Button button34;
        private System.Windows.Forms.Button button35;
        private System.Windows.Forms.Button button36;
        private System.Windows.Forms.Button button37;
        private System.Windows.Forms.Button button38;
        private System.Windows.Forms.Button button39;
        private System.Windows.Forms.Panel panel12;
        private System.Windows.Forms.Button button31;
        private System.Windows.Forms.Button button32;
        private System.Windows.Forms.Button button33;
        private System.Windows.Forms.GroupBox groupBox10;
        private System.Windows.Forms.GroupBox groupBox11;
        private System.Windows.Forms.Button btnLjOmPurityShiftA;
        private System.Windows.Forms.Button btnLjOmPolShiftA;
        private System.Windows.Forms.Button btnLjOmBrixShiftA;
        private System.Windows.Forms.Button btnLjOmShiftA;
        private System.Windows.Forms.GroupBox groupBox12;
        private System.Windows.Forms.Button btnLjNmPurityShiftA;
        private System.Windows.Forms.Button btnLjNmPolShiftA;
        private System.Windows.Forms.Button btnLjNmBrixShiftA;
        private System.Windows.Forms.Button btnLjNmShiftA;
        private System.Windows.Forms.Button btnLastJuiceShiftA;
        private System.Windows.Forms.Panel panel24;
        private System.Windows.Forms.Button button70;
        private System.Windows.Forms.Button button71;
        private System.Windows.Forms.Button button72;
        private System.Windows.Forms.Panel panel18;
        private System.Windows.Forms.Button button52;
        private System.Windows.Forms.Button button53;
        private System.Windows.Forms.Button button54;
        private System.Windows.Forms.Panel panel23;
        private System.Windows.Forms.Button button67;
        private System.Windows.Forms.Button button68;
        private System.Windows.Forms.Button button69;
        private System.Windows.Forms.Panel panel28;
        private System.Windows.Forms.Button button49;
        private System.Windows.Forms.Button button50;
        private System.Windows.Forms.Button button51;
        private System.Windows.Forms.Panel panel22;
        private System.Windows.Forms.Button button64;
        private System.Windows.Forms.Button button65;
        private System.Windows.Forms.Button button66;
        private System.Windows.Forms.Panel panel21;
        private System.Windows.Forms.Button button61;
        private System.Windows.Forms.Button button62;
        private System.Windows.Forms.Button button63;
        private System.Windows.Forms.Button button55;
        private System.Windows.Forms.Button button56;
        private System.Windows.Forms.Button button57;
        private System.Windows.Forms.GroupBox groupBox13;
        private System.Windows.Forms.GroupBox groupBox14;
        private System.Windows.Forms.GroupBox groupBox15;
        private System.Windows.Forms.Button btnLjOmPurityShiftB;
        private System.Windows.Forms.Button btnLjOmPolShiftB;
        private System.Windows.Forms.Button btnLjOmBrixShiftB;
        private System.Windows.Forms.Button btnLjOmShiftB;
        private System.Windows.Forms.GroupBox groupBox16;
        private System.Windows.Forms.Button btnLjNmPurityShiftB;
        private System.Windows.Forms.Button btnLjNmPolShiftB;
        private System.Windows.Forms.Button btnLjNmBrixShiftB;
        private System.Windows.Forms.Button btnLjNmShiftB;
        private System.Windows.Forms.Button btnLastJuiceShiftB;
        private System.Windows.Forms.GroupBox groupBox17;
        private System.Windows.Forms.GroupBox groupBox18;
        private System.Windows.Forms.Button btnMjOmPurityShiftB;
        private System.Windows.Forms.Button btnMjOmPolShiftB;
        private System.Windows.Forms.Button btnMjOmBrixShiftB;
        private System.Windows.Forms.Button btnMjOmShiftB;
        private System.Windows.Forms.GroupBox groupBox19;
        private System.Windows.Forms.Button btnMjNmPurityShiftB;
        private System.Windows.Forms.Button btnMjNmPolShiftB;
        private System.Windows.Forms.Button btnMjNmBrixShiftB;
        private System.Windows.Forms.Button btnMjNmShiftB;
        private System.Windows.Forms.Button btnMixedJuiceShiftB;
        private System.Windows.Forms.GroupBox groupBox20;
        private System.Windows.Forms.Button btnAvgShiftB;
        private System.Windows.Forms.Button btnTime24;
        private System.Windows.Forms.Button btnTime22;
        private System.Windows.Forms.Button btnTime20;
        private System.Windows.Forms.Button btnTime18;
        private System.Windows.Forms.Button btnTimeShiftB;
        private System.Windows.Forms.GroupBox groupBox21;
        private System.Windows.Forms.GroupBox groupBox22;
        private System.Windows.Forms.Button btnPjOmPurityShiftB;
        private System.Windows.Forms.Button btnPjOmPolShiftB;
        private System.Windows.Forms.Button btnPjOmBrixShiftB;
        private System.Windows.Forms.Button btnPjOmShiftB;
        private System.Windows.Forms.GroupBox groupBox23;
        private System.Windows.Forms.Button btnPjNmPurityShiftB;
        private System.Windows.Forms.Button btnPjNmPolShiftB;
        private System.Windows.Forms.Button btnPjNmBrixShiftB;
        private System.Windows.Forms.Button btnPjNmShiftB;
        private System.Windows.Forms.Button btnPrimaryJuiceShiftB;
        private System.Windows.Forms.GroupBox groupBox24;
        private System.Windows.Forms.GroupBox groupBox25;
        private System.Windows.Forms.GroupBox groupBox26;
        private System.Windows.Forms.Button btnLjOmPurityShiftC;
        private System.Windows.Forms.Button btnLjOmPolShiftC;
        private System.Windows.Forms.Button btnLjOmBrixShiftC;
        private System.Windows.Forms.Button btnLjOmShiftC;
        private System.Windows.Forms.GroupBox groupBox27;
        private System.Windows.Forms.Button btnLjNmPurityShiftC;
        private System.Windows.Forms.Button btnLjNmPolShiftC;
        private System.Windows.Forms.Button btnLjNmBrixShiftC;
        private System.Windows.Forms.Button btnLjNmShiftC;
        private System.Windows.Forms.Button btnLastJuiceShiftC;
        private System.Windows.Forms.GroupBox groupBox28;
        private System.Windows.Forms.GroupBox groupBox29;
        private System.Windows.Forms.Button btnMjOmPurityShiftC;
        private System.Windows.Forms.Button btnMjOmPolShiftC;
        private System.Windows.Forms.Button btnMjOmBrixShiftC;
        private System.Windows.Forms.Button btnMjOmShiftC;
        private System.Windows.Forms.GroupBox groupBox30;
        private System.Windows.Forms.Button btnMjNmPurityShiftC;
        private System.Windows.Forms.Button btnMjNmPolShiftC;
        private System.Windows.Forms.Button btnMjNmBrixShiftC;
        private System.Windows.Forms.Button btnMjNmShiftC;
        private System.Windows.Forms.Button btnMixedJuiceShiftC;
        private System.Windows.Forms.GroupBox groupBox31;
        private System.Windows.Forms.Button btnAvgShiftC;
        private System.Windows.Forms.Button btnTime8;
        private System.Windows.Forms.Button btnTime6;
        private System.Windows.Forms.Button btnTime4;
        private System.Windows.Forms.Button btnTime2;
        private System.Windows.Forms.Button btnTimeShiftC;
        private System.Windows.Forms.GroupBox groupBox32;
        private System.Windows.Forms.GroupBox groupBox33;
        private System.Windows.Forms.Button btnPjOmPurityShiftC;
        private System.Windows.Forms.Button btnPjOmPolShiftC;
        private System.Windows.Forms.Button btnPjOmBrixShiftC;
        private System.Windows.Forms.Button btnPjOmShiftC;
        private System.Windows.Forms.GroupBox groupBox34;
        private System.Windows.Forms.Button btnPjNmPurityShiftC;
        private System.Windows.Forms.Button btnPjNmPolShiftC;
        private System.Windows.Forms.Button btnPjNmBrixShiftC;
        private System.Windows.Forms.Button btnPjNmShiftC;
        private System.Windows.Forms.Button btnPrimaryJuiceShiftC;
        private System.Windows.Forms.Panel panel49;
        private System.Windows.Forms.Button button142;
        private System.Windows.Forms.Button button143;
        private System.Windows.Forms.Panel panel43;
        private System.Windows.Forms.Button button124;
        private System.Windows.Forms.Button button125;
        private System.Windows.Forms.Button button126;
        private System.Windows.Forms.Panel panel37;
        private System.Windows.Forms.Button button106;
        private System.Windows.Forms.Button button107;
        private System.Windows.Forms.Button button108;
        private System.Windows.Forms.Panel panel31;
        private System.Windows.Forms.Button button88;
        private System.Windows.Forms.Button button89;
        private System.Windows.Forms.Button button90;
        private System.Windows.Forms.Panel panel48;
        private System.Windows.Forms.Button button139;
        private System.Windows.Forms.Button button140;
        private System.Windows.Forms.Button button141;
        private System.Windows.Forms.Panel panel42;
        private System.Windows.Forms.Button button121;
        private System.Windows.Forms.Button button122;
        private System.Windows.Forms.Button button123;
        private System.Windows.Forms.Panel panel36;
        private System.Windows.Forms.Button button103;
        private System.Windows.Forms.Button button104;
        private System.Windows.Forms.Button button105;
        private System.Windows.Forms.Panel panel30;
        private System.Windows.Forms.Button button85;
        private System.Windows.Forms.Button button86;
        private System.Windows.Forms.Button button87;
        private System.Windows.Forms.Panel panel47;
        private System.Windows.Forms.Button button136;
        private System.Windows.Forms.Button button137;
        private System.Windows.Forms.Button button138;
        private System.Windows.Forms.Panel panel41;
        private System.Windows.Forms.Button button118;
        private System.Windows.Forms.Button button119;
        private System.Windows.Forms.Button button120;
        private System.Windows.Forms.Panel panel35;
        private System.Windows.Forms.Button button100;
        private System.Windows.Forms.Button button101;
        private System.Windows.Forms.Button button102;
        private System.Windows.Forms.Panel panel29;
        private System.Windows.Forms.Button button82;
        private System.Windows.Forms.Button button83;
        private System.Windows.Forms.Button button84;
        private System.Windows.Forms.Panel panel46;
        private System.Windows.Forms.Button button133;
        private System.Windows.Forms.Button button134;
        private System.Windows.Forms.Button button135;
        private System.Windows.Forms.Panel panel40;
        private System.Windows.Forms.Button button115;
        private System.Windows.Forms.Button button116;
        private System.Windows.Forms.Button button117;
        private System.Windows.Forms.Panel panel34;
        private System.Windows.Forms.Button button97;
        private System.Windows.Forms.Button button98;
        private System.Windows.Forms.Button button99;
        private System.Windows.Forms.Panel panel27;
        private System.Windows.Forms.Button button79;
        private System.Windows.Forms.Button button80;
        private System.Windows.Forms.Button button81;
        private System.Windows.Forms.Panel panel45;
        private System.Windows.Forms.Button button130;
        private System.Windows.Forms.Button button131;
        private System.Windows.Forms.Button button132;
        private System.Windows.Forms.Panel panel39;
        private System.Windows.Forms.Button button112;
        private System.Windows.Forms.Button button113;
        private System.Windows.Forms.Button button114;
        private System.Windows.Forms.Panel panel33;
        private System.Windows.Forms.Button button94;
        private System.Windows.Forms.Button button95;
        private System.Windows.Forms.Button button96;
        private System.Windows.Forms.Panel panel26;
        private System.Windows.Forms.Button button76;
        private System.Windows.Forms.Button button77;
        private System.Windows.Forms.Button button78;
        private System.Windows.Forms.Panel panel44;
        private System.Windows.Forms.Button button127;
        private System.Windows.Forms.Button button128;
        private System.Windows.Forms.Button button129;
        private System.Windows.Forms.Panel panel38;
        private System.Windows.Forms.Button button109;
        private System.Windows.Forms.Button button110;
        private System.Windows.Forms.Button button111;
        private System.Windows.Forms.Panel panel32;
        private System.Windows.Forms.Button button91;
        private System.Windows.Forms.Button button92;
        private System.Windows.Forms.Button button93;
        private System.Windows.Forms.Panel panel25;
        private System.Windows.Forms.Button button73;
        private System.Windows.Forms.Button button74;
        private System.Windows.Forms.Button button75;
        private System.Windows.Forms.Button button144;
        private System.Windows.Forms.Panel panel61;
        private System.Windows.Forms.Button button178;
        private System.Windows.Forms.Button button179;
        private System.Windows.Forms.Button button180;
        private System.Windows.Forms.Panel panel55;
        private System.Windows.Forms.Button button160;
        private System.Windows.Forms.Button button161;
        private System.Windows.Forms.Button button162;
        private System.Windows.Forms.Panel panel60;
        private System.Windows.Forms.Button button175;
        private System.Windows.Forms.Button button176;
        private System.Windows.Forms.Button button177;
        private System.Windows.Forms.Panel panel54;
        private System.Windows.Forms.Button button157;
        private System.Windows.Forms.Button button158;
        private System.Windows.Forms.Button button159;
        private System.Windows.Forms.Panel panel65;
        private System.Windows.Forms.Button button190;
        private System.Windows.Forms.Button button191;
        private System.Windows.Forms.Button button192;
        private System.Windows.Forms.Panel panel59;
        private System.Windows.Forms.Button button172;
        private System.Windows.Forms.Button button173;
        private System.Windows.Forms.Button button174;
        private System.Windows.Forms.Panel panel53;
        private System.Windows.Forms.Button button154;
        private System.Windows.Forms.Button button155;
        private System.Windows.Forms.Button button156;
        private System.Windows.Forms.Panel panel64;
        private System.Windows.Forms.Button button187;
        private System.Windows.Forms.Button button188;
        private System.Windows.Forms.Button button189;
        private System.Windows.Forms.Panel panel58;
        private System.Windows.Forms.Button button169;
        private System.Windows.Forms.Button button170;
        private System.Windows.Forms.Button button171;
        private System.Windows.Forms.Panel panel52;
        private System.Windows.Forms.Button button151;
        private System.Windows.Forms.Button button152;
        private System.Windows.Forms.Button button153;
        private System.Windows.Forms.Panel panel63;
        private System.Windows.Forms.Button button184;
        private System.Windows.Forms.Button button185;
        private System.Windows.Forms.Button button186;
        private System.Windows.Forms.Panel panel57;
        private System.Windows.Forms.Button button166;
        private System.Windows.Forms.Button button167;
        private System.Windows.Forms.Button button168;
        private System.Windows.Forms.Panel panel51;
        private System.Windows.Forms.Button button148;
        private System.Windows.Forms.Button button149;
        private System.Windows.Forms.Button button150;
        private System.Windows.Forms.Panel panel62;
        private System.Windows.Forms.Button button181;
        private System.Windows.Forms.Button button182;
        private System.Windows.Forms.Button button183;
        private System.Windows.Forms.Panel panel56;
        private System.Windows.Forms.Button button163;
        private System.Windows.Forms.Button button164;
        private System.Windows.Forms.Button button165;
        private System.Windows.Forms.Panel panel50;
        private System.Windows.Forms.Button button145;
        private System.Windows.Forms.Button button146;
        private System.Windows.Forms.Button button147;
        private System.Windows.Forms.Panel panel67;
        private System.Windows.Forms.Button button196;
        private System.Windows.Forms.Button button197;
        private System.Windows.Forms.Button button198;
        private System.Windows.Forms.Panel panel66;
        private System.Windows.Forms.Button button193;
        private System.Windows.Forms.Button button194;
        private System.Windows.Forms.Button button195;
        private System.Windows.Forms.Panel panel70;
        private System.Windows.Forms.Button button205;
        private System.Windows.Forms.Button button206;
        private System.Windows.Forms.Button button207;
        private System.Windows.Forms.Panel panel69;
        private System.Windows.Forms.Button button202;
        private System.Windows.Forms.Button button203;
        private System.Windows.Forms.Button button204;
        private System.Windows.Forms.Panel panel68;
        private System.Windows.Forms.Button button199;
        private System.Windows.Forms.Button button200;
        private System.Windows.Forms.Button button201;
        private System.Windows.Forms.Panel panel71;
        private System.Windows.Forms.Button button208;
        private System.Windows.Forms.Button button209;
        private System.Windows.Forms.Button button210;
        private System.Windows.Forms.Panel panel73;
        private System.Windows.Forms.Button button214;
        private System.Windows.Forms.Button button215;
        private System.Windows.Forms.Button button216;
        private System.Windows.Forms.Panel panel72;
        private System.Windows.Forms.Button button211;
        private System.Windows.Forms.Button button212;
        private System.Windows.Forms.Button button213;
        private System.Windows.Forms.GroupBox groupBox35;
        private System.Windows.Forms.Panel panel79;
        private System.Windows.Forms.Button btnDaySumm16;
        private System.Windows.Forms.Button btnDaySumm17;
        private System.Windows.Forms.Button btnDaySumm18;
        private System.Windows.Forms.Panel panel78;
        private System.Windows.Forms.Button btnDaySumm13;
        private System.Windows.Forms.Button btnDaySumm14;
        private System.Windows.Forms.Button btnDaySumm15;
        private System.Windows.Forms.Panel panel77;
        private System.Windows.Forms.Button btnDaySumm10;
        private System.Windows.Forms.Button btnDaySumm11;
        private System.Windows.Forms.Button btnDaySumm12;
        private System.Windows.Forms.Panel panel76;
        private System.Windows.Forms.Button btnDaySumm7;
        private System.Windows.Forms.Button btnDaySumm8;
        private System.Windows.Forms.Button btnDaySumm9;
        private System.Windows.Forms.Panel panel75;
        private System.Windows.Forms.Button btnDaySumm4;
        private System.Windows.Forms.Button btnDaySumm5;
        private System.Windows.Forms.Button btnDaySumm6;
        private System.Windows.Forms.Panel panel74;
        private System.Windows.Forms.Button btnDaySumm1;
        private System.Windows.Forms.Button btnDaySumm2;
        private System.Windows.Forms.Button btnDaySumm3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Panel panel97;
        private System.Windows.Forms.Button button269;
        private System.Windows.Forms.Button button270;
        private System.Windows.Forms.Button button271;
        private System.Windows.Forms.Panel panel96;
        private System.Windows.Forms.Button button266;
        private System.Windows.Forms.Button button267;
        private System.Windows.Forms.Button button268;
        private System.Windows.Forms.Panel panel95;
        private System.Windows.Forms.Button button263;
        private System.Windows.Forms.Button button264;
        private System.Windows.Forms.Button button265;
        private System.Windows.Forms.Panel panel94;
        private System.Windows.Forms.Button button260;
        private System.Windows.Forms.Button button261;
        private System.Windows.Forms.Button button262;
        private System.Windows.Forms.Panel panel93;
        private System.Windows.Forms.Button button257;
        private System.Windows.Forms.Button button258;
        private System.Windows.Forms.Button button259;
        private System.Windows.Forms.Panel panel92;
        private System.Windows.Forms.Button button254;
        private System.Windows.Forms.Button button255;
        private System.Windows.Forms.Button button256;
        private System.Windows.Forms.Panel panel91;
        private System.Windows.Forms.Button button251;
        private System.Windows.Forms.Button button252;
        private System.Windows.Forms.Button button253;
        private System.Windows.Forms.Panel panel90;
        private System.Windows.Forms.Button button248;
        private System.Windows.Forms.Button button249;
        private System.Windows.Forms.Button button250;
        private System.Windows.Forms.Panel panel89;
        private System.Windows.Forms.Button button245;
        private System.Windows.Forms.Button button246;
        private System.Windows.Forms.Button button247;
        private System.Windows.Forms.Panel panel88;
        private System.Windows.Forms.Button button242;
        private System.Windows.Forms.Button button243;
        private System.Windows.Forms.Button button244;
        private System.Windows.Forms.Panel panel87;
        private System.Windows.Forms.Button button239;
        private System.Windows.Forms.Button button240;
        private System.Windows.Forms.Button button241;
        private System.Windows.Forms.Panel panel86;
        private System.Windows.Forms.Button button236;
        private System.Windows.Forms.Button button237;
        private System.Windows.Forms.Button button238;
        private System.Windows.Forms.Panel panel85;
        private System.Windows.Forms.Button button233;
        private System.Windows.Forms.Button button234;
        private System.Windows.Forms.Panel panel84;
        private System.Windows.Forms.Button button230;
        private System.Windows.Forms.Button button231;
        private System.Windows.Forms.Button button232;
        private System.Windows.Forms.Panel panel83;
        private System.Windows.Forms.Button button227;
        private System.Windows.Forms.Button button228;
        private System.Windows.Forms.Button button229;
        private System.Windows.Forms.Panel panel82;
        private System.Windows.Forms.Button button224;
        private System.Windows.Forms.Button button225;
        private System.Windows.Forms.Button button226;
        private System.Windows.Forms.Button button223;
        private System.Windows.Forms.Button button217;
        private System.Windows.Forms.Button button219;
        private System.Windows.Forms.Button button218;
        private System.Windows.Forms.Button button58;
        private System.Windows.Forms.Button button59;
        private System.Windows.Forms.Button button22;
        private System.Windows.Forms.Button button60;
        private System.Windows.Forms.Panel panel81;
        private System.Windows.Forms.Button button221;
        private System.Windows.Forms.Button button222;
        private System.Windows.Forms.Button button220;
        private System.Windows.Forms.Button button40;
        private System.Windows.Forms.Button button23;
        private System.Windows.Forms.Button button41;
        private System.Windows.Forms.Button button24;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button42;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Button button6;
    }
}