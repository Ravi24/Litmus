﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.ApplicationBlocks.Data;
using System.Data.SqlClient;
using CrystalDecisions.CrystalReports.Engine;
using Litmus.classes;
//using CrystalDecisions.ReportAppServer.DataDefModel;

using System.IO;
namespace Litmus.forms.reporting
{
    public partial class hourly_report_view : Form
    {
        DbConnections dbConn = new DbConnections();
        master_parameter_logic masterParam = new master_parameter_logic();
        System.Data.DataSet ds = null;
        public hourly_report_view()
        {
            InitializeComponent();
            this.Height = Screen.PrimaryScreen.Bounds.Height;
            this.Width = Screen.PrimaryScreen.Bounds.Width;
            crystalReportHourlyJuiceWater.Width = Screen.PrimaryScreen.Bounds.Width;
            crystalReportHourlyJuiceWater.Height = this.Height - 100; //Screen.PrimaryScreen.Bounds.Width - 250;
            dateTimePicker1.Text = masterParam.entryDate;
        }

        public System.Data.DataSet getData(string entry_date)
        {

            string sql = @"select entry_Date, " +
                " (case  when entry_time between 9 and 16 then 'Shift-A'  " +
                " when entry_time between 17 and 24 then 'Shift-B'  " +
                " when entry_time between 1 and 9 then 'Shift-C' else 'Invalid' end) shifts " +
                " , entry_time, new_mill_juice, new_mill_water, old_mill_juice, old_mill_water " +
                    " from transactions_hourly where entry_date = @entry_date";
            List<SqlParameter> param = new List<SqlParameter>();
            param.Add(new SqlParameter("@entry_date",entry_date));
            try
            {
                ds = SqlHelper.ExecuteDataset(dbConn.sqlConn(), CommandType.Text, sql,param.ToArray());
            }
            catch(SqlException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

            return ds;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            getData(dateTimePicker1.Text);
            ReportDocument crystalReportDoc = new ReportDocument();
            string path = Path.GetDirectoryName(Path.GetDirectoryName(Directory.GetCurrentDirectory()));
            crystalReportDoc.Load(path + "\\crystal_reports\\hourly_juice_water.rpt");
            crystal_reports.hourly_juice_water hourly_juice_water = new crystal_reports.hourly_juice_water();
           
            hourly_juice_water.SetDataSource(ds.Tables[0]);
            crystalReportHourlyJuiceWater.ReportSource = hourly_juice_water;
            crystalReportDoc.Refresh();
        }
    }
}
