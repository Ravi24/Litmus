﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using iTextSharp.text.pdf;
using System.Speech.Recognition;
using System.Drawing.Printing;

namespace Litmus.forms.reporting
{
    public partial class ledger : Form
    {
        classes.reports.ledger_logic ledger_logic = new classes.reports.ledger_logic();
        static Stream myStream;
        StreamWriter writer;
        
        public ledger()
        {
            InitializeComponent();
        }

        private async void btn_submit_Click(object sender, EventArgs e)
        {
            SaveFileDialog ledger_location = new SaveFileDialog();
            ledger_location.Filter = "txt files (*.txt)|*.txt| Pdf file(*.pdf)|*.pdf| Excel File(*.xlsx)|*.xlsx";
            ledger_location.RestoreDirectory = true;
            ledger_location.FilterIndex = 1;

            if (ledger_location.ShowDialog() == DialogResult.OK)
            {
                lblProgress.Visible = true;
                progressBarLedger.Visible = true;
                if ((myStream = ledger_location.OpenFile()) != null)
                {
                    try
                    {
                        Task task = new System.Threading.Tasks.Task(ledger_text);
                        task.Start();
                        //ledger_text();
                        await task; 
                        MessageBox.Show("Ledger generated", "Success", MessageBoxButtons.OK);
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show(ex.Message);
                    }
                }
                myStream.Close();
            }
        }

        private void ledger_text()
        {
            lblProgress.Text = "Please Wait...";
            using (writer = new StreamWriter(myStream))
            {
                string fromDate = txtFromDate.Text;
                string toDate = txtToDate.Text;
                try
                {
                    lblProgress.Text = "Page 1 Generating";
                    DataTable dt = ledger_logic.get_ledgerData(fromDate, toDate);
                    foreach (DataRow dr in dt.Rows)
                    {
                        writer.Write(dr[0].ToString() + Environment.NewLine);
                    }
                    writer.Write(" "); // page brak character (it is not visible in IDE)
                    progressBarLedger.Value = 1;
                    progressBarLedger.ResetText();
                    lblProgress.Text = "Page 1 generated";
                    //progressBarLedger.CreateGraphics().DrawString(lblProgress.Text, new System.Drawing.Font("Arial",(float)8.5,FontStyle.Regular),Brushes.Black,new PointF(progressBarLedger.Width / 2 - 10, progressBarLedger.Height / 2 - 7));

                }
                catch (Exception ex)
                {
                    throw ex;
                }
                // second page of ledger loop
                try
                {
                    lblProgress.Text = "Page 2 Generating";
                    DataTable dt_page_second = ledger_logic.get_ledger_second_page(fromDate, toDate);
                   
                    foreach (DataRow drPageTwo in dt_page_second.Rows)
                    {
                        writer.Write(drPageTwo[0].ToString() + Environment.NewLine);
                    }
                    writer.Write(" "); // page brak character (it is not visible in IDE)
                    progressBarLedger.Value = 2;
                    progressBarLedger.ResetText();
                    lblProgress.Text = "Page 2 Generated";
                    //progressBarLedger.CreateGraphics().DrawString(lblProgress.Text, new System.Drawing.Font("Arial",(float)8.5,FontStyle.Regular),Brushes.Black,new PointF(progressBarLedger.Width / 2 - 10, progressBarLedger.Height / 2 - 7));
                    
                }
                catch (Exception ex)
                {
                    throw ex;
                }
                // third page of ledger
                try
                {
                    lblProgress.Text = "Page 3 Generating";
                    DataTable dt_page_third = ledger_logic.get_ledger_third_page(fromDate, toDate);

                    foreach (DataRow drPageThree in dt_page_third.Rows)
                    {
                        writer.Write(drPageThree[0].ToString() + Environment.NewLine);
                    }
                    writer.Write(" "); // page brak character (it is not visible in IDE)
                    progressBarLedger.Value = 3;
                    progressBarLedger.ResetText();
                    lblProgress.Text = "Page 3 Generated";
                    //progressBarLedger.CreateGraphics().DrawString(lblProgress.Text, new System.Drawing.Font("Arial",(float)8.5,FontStyle.Regular),Brushes.Black,new PointF(progressBarLedger.Width / 2 - 10, progressBarLedger.Height / 2 - 7));
                    
                }
                catch (Exception ex)
                {
                    throw ex;
                }
                // fourth page of ledger
                try
                {
                    lblProgress.Text = "Page 4 Generating";
                    DataTable dt_page_second = ledger_logic.get_ledger_fourth_page(fromDate, toDate);

                    foreach (DataRow drPageTwo in dt_page_second.Rows)
                    {
                        writer.Write(drPageTwo[0].ToString() + Environment.NewLine);
                    }
                    writer.Write(" "); // page brak character (it is not visible in IDE)
                    progressBarLedger.Value = 4;
                    progressBarLedger.ResetText();
                    lblProgress.Text = "Page 4 Generated";
                    //progressBarLedger.CreateGraphics().DrawString(lblProgress.Text, new System.Drawing.Font("Arial",(float)8.5,FontStyle.Regular),Brushes.Black,new PointF(progressBarLedger.Width / 2 - 10, progressBarLedger.Height / 2 - 7));
                    
                }
                catch (Exception ex)
                {
                    throw ex;
                }

                // fifth page of ledger
                try
                {
                    lblProgress.Text = "Page 5 Generating";
                    DataTable dt_page_five = ledger_logic.get_ledger_fifth_page(fromDate, toDate);

                    foreach (DataRow drPagefive in dt_page_five.Rows)
                    {
                        writer.Write(drPagefive[0].ToString() + Environment.NewLine);
                    }
                    writer.Write(" "); // page brak character (it is not visible in IDE)
                    progressBarLedger.Value = 5;
                    progressBarLedger.ResetText();
                    lblProgress.Text = "Page 5 Generated";
                    //progressBarLedger.CreateGraphics().DrawString(lblProgress.Text, new System.Drawing.Font("Arial",(float)8.5,FontStyle.Regular),Brushes.Black,new PointF(progressBarLedger.Width / 2 - 10, progressBarLedger.Height / 2 - 7));
                    
                }
                catch (Exception ex)
                {
                    throw ex;
                }
                 //sixth page of ledger
                try
                {
                    lblProgress.Text = "Page 6 Generating";
                    DataTable dt_page_six = ledger_logic.get_ledger_sixth_page(fromDate, toDate);

                    foreach (DataRow drPageSix in dt_page_six.Rows)
                    {
                        writer.Write(drPageSix[0].ToString() + Environment.NewLine);
                    }
                    writer.Write(" "); // page brak character (it is not visible in IDE)
                    progressBarLedger.Value = 6;
                    progressBarLedger.ResetText();
                    lblProgress.Text = "Page 6 Generated";
                    //progressBarLedger.CreateGraphics().DrawString(lblProgress.Text, new System.Drawing.Font("Arial",(float)8.5,FontStyle.Regular),Brushes.Black,new PointF(progressBarLedger.Width / 2 - 10, progressBarLedger.Height / 2 - 7));
                    
                }
                catch (Exception ex)
                {
                    throw ex;
                }
                // Seventh page of ledger
                try
                {
                    lblProgress.Text = "Page 7 Generating";
                    DataTable dt_page_seven = ledger_logic.get_ledger_seventh_page(fromDate, toDate);

                    foreach (DataRow drPageSeven in dt_page_seven.Rows)
                    {
                        writer.Write(drPageSeven[0].ToString() + Environment.NewLine);
                    }
                    writer.Write(" "); // page brak character (it is not visible in IDE)
                    
                    progressBarLedger.Value = 7;
                    progressBarLedger.ResetText();
                    lblProgress.Text = "Page 7 Generated";
                    //progressBarLedger.CreateGraphics().DrawString(lblProgress.Text, new System.Drawing.Font("Arial",(float)8.5,FontStyle.Regular),Brushes.Black,new PointF(progressBarLedger.Width / 2 - 10, progressBarLedger.Height / 2 - 7));
                    
                }
                catch (Exception ex)
                {
                    throw ex;
                }

                // Eight page of ledger
                try
                {
                    lblProgress.Text = "Page 8 Generating";
                    DataTable dt_page_eight = ledger_logic.get_ledger_eight_page(fromDate, toDate);

                    foreach (DataRow drPageEight in dt_page_eight.Rows)
                    {
                        writer.Write(drPageEight[0].ToString() + Environment.NewLine);
                    }
                    writer.Write(" "); // page brak character (it is not visible in IDE)
                    progressBarLedger.Value = 8;
                    progressBarLedger.ResetText();
                    lblProgress.Text = "Page 8 Generated";

                    //progressBarLedger.CreateGraphics().DrawString(lblProgress.Text, new System.Drawing.Font("Arial",(float)8.5,FontStyle.Regular),Brushes.Black,new PointF(progressBarLedger.Width / 2 - 10, progressBarLedger.Height / 2 - 7));
                    
                }
                catch (Exception ex)
                {
                    throw ex;
                }

                // Nine page of ledger
                try
                {
                    lblProgress.Text = "Page 9 Generating";
                    DataTable dt_page_nine = ledger_logic.get_ledger_nine_page(fromDate, toDate);

                    foreach (DataRow drPageNine in dt_page_nine.Rows)
                    {
                        writer.Write(drPageNine[0].ToString() + Environment.NewLine);
                    }
                    writer.Write(" "); // page brak character (it is not visible in IDE)
                    progressBarLedger.Value = 9;
                    progressBarLedger.ResetText();
                    lblProgress.Text = "Page 9 Generated";
                    lblProgress.Text = "Ledger generated";
                    ////progressBarLedger.CreateGraphics().DrawString(lblProgress.Text, new System.Drawing.Font("Arial",(float)8.5,FontStyle.Regular),Brushes.Black,new PointF(progressBarLedger.Width / 2 - 10, progressBarLedger.Height / 2 - 7));
                    
                }
                catch (Exception ex)
                {
                    throw ex;
                }
                 // Ten page of ledger
                try
                {
                    lblProgress.Text = "Page 10 Generating";
                    DataTable dt_page_nine = ledger_logic.get_ledger_ten_page(fromDate, toDate);

                    foreach (DataRow drPageNine in dt_page_nine.Rows)
                    {
                        writer.Write(drPageNine[0].ToString() + Environment.NewLine);
                    }
                    writer.Write(" "); // page brak character (it is not visible in IDE)
                    progressBarLedger.Value = 10;
                    progressBarLedger.ResetText();
                    lblProgress.Text = "Page 10 Generated";
                    ////progressBarLedger.CreateGraphics().DrawString(lblProgress.Text, new System.Drawing.Font("Arial",(float)8.5,FontStyle.Regular),Brushes.Black,new PointF(progressBarLedger.Width / 2 - 10, progressBarLedger.Height / 2 - 7));
                    
                }
                catch (Exception ex)
                {
                    throw ex;
                }
                // Eleven page of ledger
                try
                {
                    lblProgress.Text = "Page 11 Generating";
                    DataTable dt_page_nine = ledger_logic.get_ledger_eleven_page(fromDate, toDate);

                    foreach (DataRow drPageNine in dt_page_nine.Rows)
                    {
                        writer.Write(drPageNine[0].ToString() + Environment.NewLine);
                    }
                    writer.Write(" "); // page brak character (it is not visible in IDE)
                    progressBarLedger.Value = 11;
                    progressBarLedger.ResetText();
                    lblProgress.Text = "Page 11 Generated";                    
                    ////progressBarLedger.CreateGraphics().DrawString(lblProgress.Text, new System.Drawing.Font("Arial",(float)8.5,FontStyle.Regular),Brushes.Black,new PointF(progressBarLedger.Width / 2 - 10, progressBarLedger.Height / 2 - 7));

                }
                catch (Exception ex)
                {
                    throw ex;
                }
                // Twelve page of ledger
                try
                {
                    lblProgress.Text = "Page 12 Generating";
                    DataTable dt_twelve = ledger_logic.get_ledger_twelve_page(fromDate, toDate);

                    foreach (DataRow drPageTwelve in dt_twelve.Rows)
                    {
                        writer.Write(drPageTwelve[0].ToString() + Environment.NewLine);
                    }
                    writer.Write(" "); // page brak character (it is not visible in IDE)
                    progressBarLedger.Value = 12;
                    progressBarLedger.ResetText();
                    lblProgress.Text = "Page 12 Generated";
                    progressBarLedger.CreateGraphics().DrawString(lblProgress.Text, new System.Drawing.Font("Arial",(float)8.5,FontStyle.Regular),Brushes.Black,new PointF(progressBarLedger.Width / 2 - 10, progressBarLedger.Height / 2 - 7));

                }
                catch (Exception ex)
                {
                    throw ex;
                }

                // Thirteenth page of ledger
                try
                {
                    lblProgress.Text = "Page 13 Generating";
                    DataTable dt_thirteen = ledger_logic.get_ledger_thirteen_page(fromDate, toDate);

                    foreach (DataRow drPagethirteen in dt_thirteen.Rows)
                    {
                        writer.Write(drPagethirteen[0].ToString() + Environment.NewLine);
                    }
                    writer.Write(" "); // page brak character (it is not visible in IDE)
                    progressBarLedger.Value = 13;
                    progressBarLedger.ResetText();
                    lblProgress.Text = "Page 13 Generated";
                    lblProgress.Text = "Ledger generated";
                    progressBarLedger.CreateGraphics().DrawString(lblProgress.Text, new System.Drawing.Font("Arial", (float)8.5, FontStyle.Regular), Brushes.Black, new PointF(progressBarLedger.Width / 2 - 10, progressBarLedger.Height / 2 - 7));

                }
                catch (Exception ex)
                {
                    throw ex;
                }
                writer.Close();
            } 
        }

        //private void btnVoice_Click(object sender, EventArgs e)
        //{
        //    MessageBox.Show("Speek");
        //    SpeechRecognizer recognizer = new SpeechRecognizer();
        //    PrintDocument printDocument = new PrintDocument();

        //    PrintDialog printdialog = new PrintDialog();
        //    printdialog.Document = printDocument;
        //    if (printdialog.ShowDialog() == DialogResult.OK)
        //    {
        //        //Print the page
        //        printDocument.Print();
        //    }

        //    Choices colors = new Choices();
        //    colors.Add(new string[] { "red", "green", "blue","Exit" });

        //    GrammarBuilder gb = new GrammarBuilder();
        //    gb.Append(colors);

        //    Grammar g = new Grammar(gb);
        //    recognizer.LoadGrammar(g);

        //    recognizer.SpeechRecognized += new EventHandler<SpeechRecognizedEventArgs>(sre_speechRecognized);
        //}
        void sre_speechRecognized(object sender, SpeechRecognizedEventArgs e)
        {
            if (e.Result.Text == "Exit")
            {
                this.Close();
            }
            MessageBox.Show("Message " + e.Result.Text);
        }
    }
}
