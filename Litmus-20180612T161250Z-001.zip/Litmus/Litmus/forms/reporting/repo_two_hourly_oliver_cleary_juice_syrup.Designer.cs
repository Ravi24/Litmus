﻿namespace Litmus.forms.reporting
{
    partial class repo_two_hourly_oliver_cleary_juice_syrup
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.groupBox14 = new System.Windows.Forms.GroupBox();
            this.groupBox15 = new System.Windows.Forms.GroupBox();
            this.ShiftC1 = new System.Windows.Forms.Button();
            this.ShiftC_Avg = new System.Windows.Forms.Button();
            this.time8 = new System.Windows.Forms.Button();
            this.time6 = new System.Windows.Forms.Button();
            this.time4 = new System.Windows.Forms.Button();
            this.time2 = new System.Windows.Forms.Button();
            this.groupBox16 = new System.Windows.Forms.GroupBox();
            this.ShiftC21 = new System.Windows.Forms.Button();
            this.ShiftC20 = new System.Windows.Forms.Button();
            this.ShiftC19 = new System.Windows.Forms.Button();
            this.ShiftC18 = new System.Windows.Forms.Button();
            this.ShiftC5 = new System.Windows.Forms.Button();
            this.groupBox17 = new System.Windows.Forms.GroupBox();
            this.ShiftC9 = new System.Windows.Forms.Button();
            this.ShiftC8 = new System.Windows.Forms.Button();
            this.ShiftC7 = new System.Windows.Forms.Button();
            this.ShiftC6 = new System.Windows.Forms.Button();
            this.ShiftC2 = new System.Windows.Forms.Button();
            this.groupBox18 = new System.Windows.Forms.GroupBox();
            this.ShiftC17 = new System.Windows.Forms.Button();
            this.ShiftC16 = new System.Windows.Forms.Button();
            this.ShiftC15 = new System.Windows.Forms.Button();
            this.ShiftC14 = new System.Windows.Forms.Button();
            this.ShiftC4 = new System.Windows.Forms.Button();
            this.groupBox19 = new System.Windows.Forms.GroupBox();
            this.ShiftC13 = new System.Windows.Forms.Button();
            this.ShiftC12 = new System.Windows.Forms.Button();
            this.ShiftC11 = new System.Windows.Forms.Button();
            this.ShiftC10 = new System.Windows.Forms.Button();
            this.ShiftC3 = new System.Windows.Forms.Button();
            this.groupBox8 = new System.Windows.Forms.GroupBox();
            this.groupBox9 = new System.Windows.Forms.GroupBox();
            this.ShiftB1 = new System.Windows.Forms.Button();
            this.ShiftB_Avg = new System.Windows.Forms.Button();
            this.time24 = new System.Windows.Forms.Button();
            this.time22 = new System.Windows.Forms.Button();
            this.time20 = new System.Windows.Forms.Button();
            this.time18 = new System.Windows.Forms.Button();
            this.groupBox10 = new System.Windows.Forms.GroupBox();
            this.ShiftB21 = new System.Windows.Forms.Button();
            this.ShiftB20 = new System.Windows.Forms.Button();
            this.ShiftB19 = new System.Windows.Forms.Button();
            this.ShiftB18 = new System.Windows.Forms.Button();
            this.ShiftB5 = new System.Windows.Forms.Button();
            this.groupBox11 = new System.Windows.Forms.GroupBox();
            this.b9 = new System.Windows.Forms.Button();
            this.ShiftB8 = new System.Windows.Forms.Button();
            this.ShiftB7 = new System.Windows.Forms.Button();
            this.ShiftB6 = new System.Windows.Forms.Button();
            this.ShiftB2 = new System.Windows.Forms.Button();
            this.groupBox12 = new System.Windows.Forms.GroupBox();
            this.ShiftB17 = new System.Windows.Forms.Button();
            this.ShiftB16 = new System.Windows.Forms.Button();
            this.ShiftB15 = new System.Windows.Forms.Button();
            this.ShiftB14 = new System.Windows.Forms.Button();
            this.ShiftB4 = new System.Windows.Forms.Button();
            this.groupBox13 = new System.Windows.Forms.GroupBox();
            this.ShiftB13 = new System.Windows.Forms.Button();
            this.ShiftB12 = new System.Windows.Forms.Button();
            this.ShiftB11 = new System.Windows.Forms.Button();
            this.ShiftB10 = new System.Windows.Forms.Button();
            this.ShiftB3 = new System.Windows.Forms.Button();
            this.groupBox7 = new System.Windows.Forms.GroupBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.SiftA5 = new System.Windows.Forms.Button();
            this.ShiftA_Avg = new System.Windows.Forms.Button();
            this.time16 = new System.Windows.Forms.Button();
            this.time14 = new System.Windows.Forms.Button();
            this.time12 = new System.Windows.Forms.Button();
            this.time10 = new System.Windows.Forms.Button();
            this.groupBox6 = new System.Windows.Forms.GroupBox();
            this.ShiftA21 = new System.Windows.Forms.Button();
            this.ShiftA20 = new System.Windows.Forms.Button();
            this.ShiftA19 = new System.Windows.Forms.Button();
            this.ShiftA18 = new System.Windows.Forms.Button();
            this.SiftA4 = new System.Windows.Forms.Button();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.button4 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.ShiftA9 = new System.Windows.Forms.Button();
            this.ShiftA8 = new System.Windows.Forms.Button();
            this.ShiftA7 = new System.Windows.Forms.Button();
            this.ShiftA6 = new System.Windows.Forms.Button();
            this.SiftA1 = new System.Windows.Forms.Button();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.ShiftA17 = new System.Windows.Forms.Button();
            this.ShiftA16 = new System.Windows.Forms.Button();
            this.ShiftA15 = new System.Windows.Forms.Button();
            this.ShiftA14 = new System.Windows.Forms.Button();
            this.SiftA3 = new System.Windows.Forms.Button();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.button5 = new System.Windows.Forms.Button();
            this.button6 = new System.Windows.Forms.Button();
            this.button7 = new System.Windows.Forms.Button();
            this.button8 = new System.Windows.Forms.Button();
            this.ShiftA13 = new System.Windows.Forms.Button();
            this.ShiftA12 = new System.Windows.Forms.Button();
            this.ShiftA11 = new System.Windows.Forms.Button();
            this.ShiftA10 = new System.Windows.Forms.Button();
            this.SiftA2 = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.button9 = new System.Windows.Forms.Button();
            this.button10 = new System.Windows.Forms.Button();
            this.button11 = new System.Windows.Forms.Button();
            this.button12 = new System.Windows.Forms.Button();
            this.button13 = new System.Windows.Forms.Button();
            this.button14 = new System.Windows.Forms.Button();
            this.button15 = new System.Windows.Forms.Button();
            this.button16 = new System.Windows.Forms.Button();
            this.button17 = new System.Windows.Forms.Button();
            this.button18 = new System.Windows.Forms.Button();
            this.button19 = new System.Windows.Forms.Button();
            this.button20 = new System.Windows.Forms.Button();
            this.button21 = new System.Windows.Forms.Button();
            this.button22 = new System.Windows.Forms.Button();
            this.button23 = new System.Windows.Forms.Button();
            this.button24 = new System.Windows.Forms.Button();
            this.button25 = new System.Windows.Forms.Button();
            this.button26 = new System.Windows.Forms.Button();
            this.button27 = new System.Windows.Forms.Button();
            this.button28 = new System.Windows.Forms.Button();
            this.button29 = new System.Windows.Forms.Button();
            this.button30 = new System.Windows.Forms.Button();
            this.button31 = new System.Windows.Forms.Button();
            this.button32 = new System.Windows.Forms.Button();
            this.button33 = new System.Windows.Forms.Button();
            this.button34 = new System.Windows.Forms.Button();
            this.button35 = new System.Windows.Forms.Button();
            this.button36 = new System.Windows.Forms.Button();
            this.button37 = new System.Windows.Forms.Button();
            this.button38 = new System.Windows.Forms.Button();
            this.button39 = new System.Windows.Forms.Button();
            this.button40 = new System.Windows.Forms.Button();
            this.button41 = new System.Windows.Forms.Button();
            this.button42 = new System.Windows.Forms.Button();
            this.button43 = new System.Windows.Forms.Button();
            this.button44 = new System.Windows.Forms.Button();
            this.button45 = new System.Windows.Forms.Button();
            this.button46 = new System.Windows.Forms.Button();
            this.button47 = new System.Windows.Forms.Button();
            this.button48 = new System.Windows.Forms.Button();
            this.button49 = new System.Windows.Forms.Button();
            this.button50 = new System.Windows.Forms.Button();
            this.button51 = new System.Windows.Forms.Button();
            this.button52 = new System.Windows.Forms.Button();
            this.button53 = new System.Windows.Forms.Button();
            this.button54 = new System.Windows.Forms.Button();
            this.button55 = new System.Windows.Forms.Button();
            this.button56 = new System.Windows.Forms.Button();
            this.button57 = new System.Windows.Forms.Button();
            this.button58 = new System.Windows.Forms.Button();
            this.button59 = new System.Windows.Forms.Button();
            this.button60 = new System.Windows.Forms.Button();
            this.button61 = new System.Windows.Forms.Button();
            this.button62 = new System.Windows.Forms.Button();
            this.button63 = new System.Windows.Forms.Button();
            this.button64 = new System.Windows.Forms.Button();
            this.button65 = new System.Windows.Forms.Button();
            this.button66 = new System.Windows.Forms.Button();
            this.button67 = new System.Windows.Forms.Button();
            this.button68 = new System.Windows.Forms.Button();
            this.button69 = new System.Windows.Forms.Button();
            this.button70 = new System.Windows.Forms.Button();
            this.button71 = new System.Windows.Forms.Button();
            this.button72 = new System.Windows.Forms.Button();
            this.button73 = new System.Windows.Forms.Button();
            this.button74 = new System.Windows.Forms.Button();
            this.button75 = new System.Windows.Forms.Button();
            this.button76 = new System.Windows.Forms.Button();
            this.button77 = new System.Windows.Forms.Button();
            this.button78 = new System.Windows.Forms.Button();
            this.button79 = new System.Windows.Forms.Button();
            this.button80 = new System.Windows.Forms.Button();
            this.button81 = new System.Windows.Forms.Button();
            this.button82 = new System.Windows.Forms.Button();
            this.button83 = new System.Windows.Forms.Button();
            this.button84 = new System.Windows.Forms.Button();
            this.button85 = new System.Windows.Forms.Button();
            this.button86 = new System.Windows.Forms.Button();
            this.button87 = new System.Windows.Forms.Button();
            this.button88 = new System.Windows.Forms.Button();
            this.button89 = new System.Windows.Forms.Button();
            this.button90 = new System.Windows.Forms.Button();
            this.button91 = new System.Windows.Forms.Button();
            this.button92 = new System.Windows.Forms.Button();
            this.button93 = new System.Windows.Forms.Button();
            this.button94 = new System.Windows.Forms.Button();
            this.button95 = new System.Windows.Forms.Button();
            this.button96 = new System.Windows.Forms.Button();
            this.button97 = new System.Windows.Forms.Button();
            this.button98 = new System.Windows.Forms.Button();
            this.button99 = new System.Windows.Forms.Button();
            this.button100 = new System.Windows.Forms.Button();
            this.button101 = new System.Windows.Forms.Button();
            this.button102 = new System.Windows.Forms.Button();
            this.button103 = new System.Windows.Forms.Button();
            this.button104 = new System.Windows.Forms.Button();
            this.button105 = new System.Windows.Forms.Button();
            this.button106 = new System.Windows.Forms.Button();
            this.button107 = new System.Windows.Forms.Button();
            this.button108 = new System.Windows.Forms.Button();
            this.button109 = new System.Windows.Forms.Button();
            this.button110 = new System.Windows.Forms.Button();
            this.button111 = new System.Windows.Forms.Button();
            this.button112 = new System.Windows.Forms.Button();
            this.button113 = new System.Windows.Forms.Button();
            this.button114 = new System.Windows.Forms.Button();
            this.button115 = new System.Windows.Forms.Button();
            this.button116 = new System.Windows.Forms.Button();
            this.button117 = new System.Windows.Forms.Button();
            this.button118 = new System.Windows.Forms.Button();
            this.button119 = new System.Windows.Forms.Button();
            this.button120 = new System.Windows.Forms.Button();
            this.button121 = new System.Windows.Forms.Button();
            this.button122 = new System.Windows.Forms.Button();
            this.button123 = new System.Windows.Forms.Button();
            this.button124 = new System.Windows.Forms.Button();
            this.button125 = new System.Windows.Forms.Button();
            this.button126 = new System.Windows.Forms.Button();
            this.button127 = new System.Windows.Forms.Button();
            this.button128 = new System.Windows.Forms.Button();
            this.button129 = new System.Windows.Forms.Button();
            this.button130 = new System.Windows.Forms.Button();
            this.button131 = new System.Windows.Forms.Button();
            this.button132 = new System.Windows.Forms.Button();
            this.button133 = new System.Windows.Forms.Button();
            this.button134 = new System.Windows.Forms.Button();
            this.button135 = new System.Windows.Forms.Button();
            this.button136 = new System.Windows.Forms.Button();
            this.button137 = new System.Windows.Forms.Button();
            this.button138 = new System.Windows.Forms.Button();
            this.button139 = new System.Windows.Forms.Button();
            this.button140 = new System.Windows.Forms.Button();
            this.button141 = new System.Windows.Forms.Button();
            this.button142 = new System.Windows.Forms.Button();
            this.button143 = new System.Windows.Forms.Button();
            this.button144 = new System.Windows.Forms.Button();
            this.button145 = new System.Windows.Forms.Button();
            this.button146 = new System.Windows.Forms.Button();
            this.button147 = new System.Windows.Forms.Button();
            this.button148 = new System.Windows.Forms.Button();
            this.button149 = new System.Windows.Forms.Button();
            this.button150 = new System.Windows.Forms.Button();
            this.button151 = new System.Windows.Forms.Button();
            this.button152 = new System.Windows.Forms.Button();
            this.button153 = new System.Windows.Forms.Button();
            this.button154 = new System.Windows.Forms.Button();
            this.button155 = new System.Windows.Forms.Button();
            this.button156 = new System.Windows.Forms.Button();
            this.button157 = new System.Windows.Forms.Button();
            this.button158 = new System.Windows.Forms.Button();
            this.button159 = new System.Windows.Forms.Button();
            this.button160 = new System.Windows.Forms.Button();
            this.button161 = new System.Windows.Forms.Button();
            this.button162 = new System.Windows.Forms.Button();
            this.button163 = new System.Windows.Forms.Button();
            this.button164 = new System.Windows.Forms.Button();
            this.button165 = new System.Windows.Forms.Button();
            this.button166 = new System.Windows.Forms.Button();
            this.button167 = new System.Windows.Forms.Button();
            this.button168 = new System.Windows.Forms.Button();
            this.button169 = new System.Windows.Forms.Button();
            this.button170 = new System.Windows.Forms.Button();
            this.button171 = new System.Windows.Forms.Button();
            this.button172 = new System.Windows.Forms.Button();
            this.button173 = new System.Windows.Forms.Button();
            this.button174 = new System.Windows.Forms.Button();
            this.button175 = new System.Windows.Forms.Button();
            this.button176 = new System.Windows.Forms.Button();
            this.button177 = new System.Windows.Forms.Button();
            this.button178 = new System.Windows.Forms.Button();
            this.button179 = new System.Windows.Forms.Button();
            this.button180 = new System.Windows.Forms.Button();
            this.button181 = new System.Windows.Forms.Button();
            this.button182 = new System.Windows.Forms.Button();
            this.button183 = new System.Windows.Forms.Button();
            this.button184 = new System.Windows.Forms.Button();
            this.button185 = new System.Windows.Forms.Button();
            this.button186 = new System.Windows.Forms.Button();
            this.button187 = new System.Windows.Forms.Button();
            this.button188 = new System.Windows.Forms.Button();
            this.button189 = new System.Windows.Forms.Button();
            this.button190 = new System.Windows.Forms.Button();
            this.button191 = new System.Windows.Forms.Button();
            this.button192 = new System.Windows.Forms.Button();
            this.panel1.SuspendLayout();
            this.groupBox14.SuspendLayout();
            this.groupBox15.SuspendLayout();
            this.groupBox16.SuspendLayout();
            this.groupBox17.SuspendLayout();
            this.groupBox18.SuspendLayout();
            this.groupBox19.SuspendLayout();
            this.groupBox8.SuspendLayout();
            this.groupBox9.SuspendLayout();
            this.groupBox10.SuspendLayout();
            this.groupBox11.SuspendLayout();
            this.groupBox12.SuspendLayout();
            this.groupBox13.SuspendLayout();
            this.groupBox7.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox6.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.groupBox5.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.AutoScroll = true;
            this.panel1.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.panel1.Controls.Add(this.groupBox14);
            this.panel1.Controls.Add(this.groupBox8);
            this.panel1.Controls.Add(this.groupBox7);
            this.panel1.Controls.Add(this.groupBox1);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1492, 725);
            this.panel1.TabIndex = 0;
            // 
            // groupBox14
            // 
            this.groupBox14.Controls.Add(this.groupBox15);
            this.groupBox14.Controls.Add(this.groupBox16);
            this.groupBox14.Controls.Add(this.groupBox17);
            this.groupBox14.Controls.Add(this.groupBox18);
            this.groupBox14.Controls.Add(this.groupBox19);
            this.groupBox14.Location = new System.Drawing.Point(12, 757);
            this.groupBox14.Name = "groupBox14";
            this.groupBox14.Size = new System.Drawing.Size(1477, 328);
            this.groupBox14.TabIndex = 8;
            this.groupBox14.TabStop = false;
            this.groupBox14.Text = "Shift- C";
            // 
            // groupBox15
            // 
            this.groupBox15.Controls.Add(this.ShiftC1);
            this.groupBox15.Controls.Add(this.ShiftC_Avg);
            this.groupBox15.Controls.Add(this.time8);
            this.groupBox15.Controls.Add(this.time6);
            this.groupBox15.Controls.Add(this.time4);
            this.groupBox15.Controls.Add(this.time2);
            this.groupBox15.Location = new System.Drawing.Point(6, 21);
            this.groupBox15.Name = "groupBox15";
            this.groupBox15.Size = new System.Drawing.Size(102, 297);
            this.groupBox15.TabIndex = 1;
            this.groupBox15.TabStop = false;
            // 
            // ShiftC1
            // 
            this.ShiftC1.Location = new System.Drawing.Point(6, 12);
            this.ShiftC1.Name = "ShiftC1";
            this.ShiftC1.Size = new System.Drawing.Size(90, 60);
            this.ShiftC1.TabIndex = 11;
            this.ShiftC1.Text = "Time";
            this.ShiftC1.UseVisualStyleBackColor = true;
            // 
            // ShiftC_Avg
            // 
            this.ShiftC_Avg.Location = new System.Drawing.Point(6, 248);
            this.ShiftC_Avg.Name = "ShiftC_Avg";
            this.ShiftC_Avg.Size = new System.Drawing.Size(90, 33);
            this.ShiftC_Avg.TabIndex = 9;
            this.ShiftC_Avg.Text = "Average";
            this.ShiftC_Avg.UseVisualStyleBackColor = true;
            // 
            // time8
            // 
            this.time8.Location = new System.Drawing.Point(6, 195);
            this.time8.Name = "time8";
            this.time8.Size = new System.Drawing.Size(90, 33);
            this.time8.TabIndex = 8;
            this.time8.Text = "8";
            this.time8.UseVisualStyleBackColor = true;
            // 
            // time6
            // 
            this.time6.Location = new System.Drawing.Point(6, 156);
            this.time6.Name = "time6";
            this.time6.Size = new System.Drawing.Size(90, 33);
            this.time6.TabIndex = 7;
            this.time6.Text = "6";
            this.time6.UseVisualStyleBackColor = true;
            // 
            // time4
            // 
            this.time4.Location = new System.Drawing.Point(5, 117);
            this.time4.Name = "time4";
            this.time4.Size = new System.Drawing.Size(90, 33);
            this.time4.TabIndex = 6;
            this.time4.Text = "4";
            this.time4.UseVisualStyleBackColor = true;
            // 
            // time2
            // 
            this.time2.Location = new System.Drawing.Point(5, 78);
            this.time2.Name = "time2";
            this.time2.Size = new System.Drawing.Size(90, 33);
            this.time2.TabIndex = 5;
            this.time2.Text = "2";
            this.time2.UseVisualStyleBackColor = true;
            // 
            // groupBox16
            // 
            this.groupBox16.Controls.Add(this.button189);
            this.groupBox16.Controls.Add(this.button190);
            this.groupBox16.Controls.Add(this.button191);
            this.groupBox16.Controls.Add(this.button192);
            this.groupBox16.Controls.Add(this.button173);
            this.groupBox16.Controls.Add(this.button174);
            this.groupBox16.Controls.Add(this.button175);
            this.groupBox16.Controls.Add(this.button176);
            this.groupBox16.Controls.Add(this.button157);
            this.groupBox16.Controls.Add(this.button158);
            this.groupBox16.Controls.Add(this.button159);
            this.groupBox16.Controls.Add(this.button160);
            this.groupBox16.Controls.Add(this.button141);
            this.groupBox16.Controls.Add(this.button142);
            this.groupBox16.Controls.Add(this.button143);
            this.groupBox16.Controls.Add(this.button144);
            this.groupBox16.Controls.Add(this.ShiftC21);
            this.groupBox16.Controls.Add(this.ShiftC20);
            this.groupBox16.Controls.Add(this.ShiftC19);
            this.groupBox16.Controls.Add(this.ShiftC18);
            this.groupBox16.Controls.Add(this.ShiftC5);
            this.groupBox16.Location = new System.Drawing.Point(1131, 21);
            this.groupBox16.Name = "groupBox16";
            this.groupBox16.Size = new System.Drawing.Size(333, 297);
            this.groupBox16.TabIndex = 5;
            this.groupBox16.TabStop = false;
            // 
            // ShiftC21
            // 
            this.ShiftC21.Location = new System.Drawing.Point(249, 49);
            this.ShiftC21.Name = "ShiftC21";
            this.ShiftC21.Size = new System.Drawing.Size(75, 29);
            this.ShiftC21.TabIndex = 8;
            this.ShiftC21.Text = "Purity";
            this.ShiftC21.UseVisualStyleBackColor = true;
            // 
            // ShiftC20
            // 
            this.ShiftC20.Location = new System.Drawing.Point(168, 49);
            this.ShiftC20.Name = "ShiftC20";
            this.ShiftC20.Size = new System.Drawing.Size(75, 29);
            this.ShiftC20.TabIndex = 7;
            this.ShiftC20.Text = "Ph";
            this.ShiftC20.UseVisualStyleBackColor = true;
            // 
            // ShiftC19
            // 
            this.ShiftC19.Location = new System.Drawing.Point(87, 49);
            this.ShiftC19.Name = "ShiftC19";
            this.ShiftC19.Size = new System.Drawing.Size(75, 29);
            this.ShiftC19.TabIndex = 6;
            this.ShiftC19.Text = "Pol";
            this.ShiftC19.UseVisualStyleBackColor = true;
            // 
            // ShiftC18
            // 
            this.ShiftC18.Location = new System.Drawing.Point(6, 49);
            this.ShiftC18.Name = "ShiftC18";
            this.ShiftC18.Size = new System.Drawing.Size(75, 29);
            this.ShiftC18.TabIndex = 5;
            this.ShiftC18.Text = "Brix";
            this.ShiftC18.UseVisualStyleBackColor = true;
            // 
            // ShiftC5
            // 
            this.ShiftC5.Location = new System.Drawing.Point(6, 12);
            this.ShiftC5.Name = "ShiftC5";
            this.ShiftC5.Size = new System.Drawing.Size(318, 31);
            this.ShiftC5.TabIndex = 0;
            this.ShiftC5.Text = "Sulphured Syrup";
            this.ShiftC5.UseVisualStyleBackColor = true;
            // 
            // groupBox17
            // 
            this.groupBox17.Controls.Add(this.button177);
            this.groupBox17.Controls.Add(this.button178);
            this.groupBox17.Controls.Add(this.button179);
            this.groupBox17.Controls.Add(this.button180);
            this.groupBox17.Controls.Add(this.button161);
            this.groupBox17.Controls.Add(this.button162);
            this.groupBox17.Controls.Add(this.button163);
            this.groupBox17.Controls.Add(this.button164);
            this.groupBox17.Controls.Add(this.button145);
            this.groupBox17.Controls.Add(this.button146);
            this.groupBox17.Controls.Add(this.button147);
            this.groupBox17.Controls.Add(this.button148);
            this.groupBox17.Controls.Add(this.button129);
            this.groupBox17.Controls.Add(this.button130);
            this.groupBox17.Controls.Add(this.button131);
            this.groupBox17.Controls.Add(this.button132);
            this.groupBox17.Controls.Add(this.ShiftC9);
            this.groupBox17.Controls.Add(this.ShiftC8);
            this.groupBox17.Controls.Add(this.ShiftC7);
            this.groupBox17.Controls.Add(this.ShiftC6);
            this.groupBox17.Controls.Add(this.ShiftC2);
            this.groupBox17.Location = new System.Drawing.Point(114, 21);
            this.groupBox17.Name = "groupBox17";
            this.groupBox17.Size = new System.Drawing.Size(333, 297);
            this.groupBox17.TabIndex = 2;
            this.groupBox17.TabStop = false;
            // 
            // ShiftC9
            // 
            this.ShiftC9.Location = new System.Drawing.Point(249, 49);
            this.ShiftC9.Name = "ShiftC9";
            this.ShiftC9.Size = new System.Drawing.Size(75, 29);
            this.ShiftC9.TabIndex = 8;
            this.ShiftC9.Text = "Purity";
            this.ShiftC9.UseVisualStyleBackColor = true;
            // 
            // ShiftC8
            // 
            this.ShiftC8.Location = new System.Drawing.Point(168, 49);
            this.ShiftC8.Name = "ShiftC8";
            this.ShiftC8.Size = new System.Drawing.Size(75, 29);
            this.ShiftC8.TabIndex = 7;
            this.ShiftC8.Text = "Ph";
            this.ShiftC8.UseVisualStyleBackColor = true;
            // 
            // ShiftC7
            // 
            this.ShiftC7.Location = new System.Drawing.Point(87, 49);
            this.ShiftC7.Name = "ShiftC7";
            this.ShiftC7.Size = new System.Drawing.Size(75, 29);
            this.ShiftC7.TabIndex = 6;
            this.ShiftC7.Text = "Pol";
            this.ShiftC7.UseVisualStyleBackColor = true;
            // 
            // ShiftC6
            // 
            this.ShiftC6.Location = new System.Drawing.Point(6, 49);
            this.ShiftC6.Name = "ShiftC6";
            this.ShiftC6.Size = new System.Drawing.Size(75, 29);
            this.ShiftC6.TabIndex = 5;
            this.ShiftC6.Text = "Brix";
            this.ShiftC6.UseVisualStyleBackColor = true;
            // 
            // ShiftC2
            // 
            this.ShiftC2.Location = new System.Drawing.Point(6, 12);
            this.ShiftC2.Name = "ShiftC2";
            this.ShiftC2.Size = new System.Drawing.Size(318, 31);
            this.ShiftC2.TabIndex = 0;
            this.ShiftC2.Text = "Oliver Filter Juice";
            this.ShiftC2.UseVisualStyleBackColor = true;
            // 
            // groupBox18
            // 
            this.groupBox18.Controls.Add(this.button185);
            this.groupBox18.Controls.Add(this.button186);
            this.groupBox18.Controls.Add(this.button187);
            this.groupBox18.Controls.Add(this.button188);
            this.groupBox18.Controls.Add(this.button169);
            this.groupBox18.Controls.Add(this.button170);
            this.groupBox18.Controls.Add(this.button171);
            this.groupBox18.Controls.Add(this.button172);
            this.groupBox18.Controls.Add(this.button153);
            this.groupBox18.Controls.Add(this.button154);
            this.groupBox18.Controls.Add(this.button155);
            this.groupBox18.Controls.Add(this.button156);
            this.groupBox18.Controls.Add(this.button137);
            this.groupBox18.Controls.Add(this.button138);
            this.groupBox18.Controls.Add(this.button139);
            this.groupBox18.Controls.Add(this.button140);
            this.groupBox18.Controls.Add(this.ShiftC17);
            this.groupBox18.Controls.Add(this.ShiftC16);
            this.groupBox18.Controls.Add(this.ShiftC15);
            this.groupBox18.Controls.Add(this.ShiftC14);
            this.groupBox18.Controls.Add(this.ShiftC4);
            this.groupBox18.Location = new System.Drawing.Point(792, 21);
            this.groupBox18.Name = "groupBox18";
            this.groupBox18.Size = new System.Drawing.Size(333, 297);
            this.groupBox18.TabIndex = 4;
            this.groupBox18.TabStop = false;
            // 
            // ShiftC17
            // 
            this.ShiftC17.Location = new System.Drawing.Point(249, 49);
            this.ShiftC17.Name = "ShiftC17";
            this.ShiftC17.Size = new System.Drawing.Size(75, 29);
            this.ShiftC17.TabIndex = 8;
            this.ShiftC17.Text = "Purity";
            this.ShiftC17.UseVisualStyleBackColor = true;
            // 
            // ShiftC16
            // 
            this.ShiftC16.Location = new System.Drawing.Point(168, 49);
            this.ShiftC16.Name = "ShiftC16";
            this.ShiftC16.Size = new System.Drawing.Size(75, 29);
            this.ShiftC16.TabIndex = 7;
            this.ShiftC16.Text = "Ph";
            this.ShiftC16.UseVisualStyleBackColor = true;
            // 
            // ShiftC15
            // 
            this.ShiftC15.Location = new System.Drawing.Point(87, 49);
            this.ShiftC15.Name = "ShiftC15";
            this.ShiftC15.Size = new System.Drawing.Size(75, 29);
            this.ShiftC15.TabIndex = 6;
            this.ShiftC15.Text = "Pol";
            this.ShiftC15.UseVisualStyleBackColor = true;
            // 
            // ShiftC14
            // 
            this.ShiftC14.Location = new System.Drawing.Point(6, 49);
            this.ShiftC14.Name = "ShiftC14";
            this.ShiftC14.Size = new System.Drawing.Size(75, 29);
            this.ShiftC14.TabIndex = 5;
            this.ShiftC14.Text = "Brix";
            this.ShiftC14.UseVisualStyleBackColor = true;
            // 
            // ShiftC4
            // 
            this.ShiftC4.Location = new System.Drawing.Point(6, 12);
            this.ShiftC4.Name = "ShiftC4";
            this.ShiftC4.Size = new System.Drawing.Size(318, 31);
            this.ShiftC4.TabIndex = 0;
            this.ShiftC4.Text = "Un-sulphured Syrup";
            this.ShiftC4.UseVisualStyleBackColor = true;
            // 
            // groupBox19
            // 
            this.groupBox19.Controls.Add(this.button181);
            this.groupBox19.Controls.Add(this.button182);
            this.groupBox19.Controls.Add(this.button183);
            this.groupBox19.Controls.Add(this.button184);
            this.groupBox19.Controls.Add(this.button165);
            this.groupBox19.Controls.Add(this.button166);
            this.groupBox19.Controls.Add(this.button167);
            this.groupBox19.Controls.Add(this.button168);
            this.groupBox19.Controls.Add(this.button149);
            this.groupBox19.Controls.Add(this.button150);
            this.groupBox19.Controls.Add(this.button151);
            this.groupBox19.Controls.Add(this.button152);
            this.groupBox19.Controls.Add(this.button133);
            this.groupBox19.Controls.Add(this.button134);
            this.groupBox19.Controls.Add(this.button135);
            this.groupBox19.Controls.Add(this.button136);
            this.groupBox19.Controls.Add(this.ShiftC13);
            this.groupBox19.Controls.Add(this.ShiftC12);
            this.groupBox19.Controls.Add(this.ShiftC11);
            this.groupBox19.Controls.Add(this.ShiftC10);
            this.groupBox19.Controls.Add(this.ShiftC3);
            this.groupBox19.Location = new System.Drawing.Point(453, 21);
            this.groupBox19.Name = "groupBox19";
            this.groupBox19.Size = new System.Drawing.Size(333, 297);
            this.groupBox19.TabIndex = 3;
            this.groupBox19.TabStop = false;
            // 
            // ShiftC13
            // 
            this.ShiftC13.Location = new System.Drawing.Point(249, 49);
            this.ShiftC13.Name = "ShiftC13";
            this.ShiftC13.Size = new System.Drawing.Size(75, 29);
            this.ShiftC13.TabIndex = 8;
            this.ShiftC13.Text = "Purity";
            this.ShiftC13.UseVisualStyleBackColor = true;
            // 
            // ShiftC12
            // 
            this.ShiftC12.Location = new System.Drawing.Point(168, 49);
            this.ShiftC12.Name = "ShiftC12";
            this.ShiftC12.Size = new System.Drawing.Size(75, 29);
            this.ShiftC12.TabIndex = 7;
            this.ShiftC12.Text = "Ph";
            this.ShiftC12.UseVisualStyleBackColor = true;
            // 
            // ShiftC11
            // 
            this.ShiftC11.Location = new System.Drawing.Point(87, 49);
            this.ShiftC11.Name = "ShiftC11";
            this.ShiftC11.Size = new System.Drawing.Size(75, 29);
            this.ShiftC11.TabIndex = 6;
            this.ShiftC11.Text = "Pol";
            this.ShiftC11.UseVisualStyleBackColor = true;
            // 
            // ShiftC10
            // 
            this.ShiftC10.Location = new System.Drawing.Point(6, 49);
            this.ShiftC10.Name = "ShiftC10";
            this.ShiftC10.Size = new System.Drawing.Size(75, 29);
            this.ShiftC10.TabIndex = 5;
            this.ShiftC10.Text = "Brix";
            this.ShiftC10.UseVisualStyleBackColor = true;
            // 
            // ShiftC3
            // 
            this.ShiftC3.Location = new System.Drawing.Point(6, 12);
            this.ShiftC3.Name = "ShiftC3";
            this.ShiftC3.Size = new System.Drawing.Size(318, 31);
            this.ShiftC3.TabIndex = 0;
            this.ShiftC3.Text = "Clear Juice";
            this.ShiftC3.UseVisualStyleBackColor = true;
            // 
            // groupBox8
            // 
            this.groupBox8.Controls.Add(this.groupBox9);
            this.groupBox8.Controls.Add(this.groupBox10);
            this.groupBox8.Controls.Add(this.groupBox11);
            this.groupBox8.Controls.Add(this.groupBox12);
            this.groupBox8.Controls.Add(this.groupBox13);
            this.groupBox8.Location = new System.Drawing.Point(12, 423);
            this.groupBox8.Name = "groupBox8";
            this.groupBox8.Size = new System.Drawing.Size(1477, 328);
            this.groupBox8.TabIndex = 7;
            this.groupBox8.TabStop = false;
            this.groupBox8.Text = "Shift- B";
            // 
            // groupBox9
            // 
            this.groupBox9.Controls.Add(this.ShiftB1);
            this.groupBox9.Controls.Add(this.ShiftB_Avg);
            this.groupBox9.Controls.Add(this.time24);
            this.groupBox9.Controls.Add(this.time22);
            this.groupBox9.Controls.Add(this.time20);
            this.groupBox9.Controls.Add(this.time18);
            this.groupBox9.Location = new System.Drawing.Point(6, 21);
            this.groupBox9.Name = "groupBox9";
            this.groupBox9.Size = new System.Drawing.Size(102, 297);
            this.groupBox9.TabIndex = 1;
            this.groupBox9.TabStop = false;
            // 
            // ShiftB1
            // 
            this.ShiftB1.Location = new System.Drawing.Point(6, 12);
            this.ShiftB1.Name = "ShiftB1";
            this.ShiftB1.Size = new System.Drawing.Size(90, 60);
            this.ShiftB1.TabIndex = 11;
            this.ShiftB1.Text = "Time";
            this.ShiftB1.UseVisualStyleBackColor = true;
            // 
            // ShiftB_Avg
            // 
            this.ShiftB_Avg.Location = new System.Drawing.Point(6, 248);
            this.ShiftB_Avg.Name = "ShiftB_Avg";
            this.ShiftB_Avg.Size = new System.Drawing.Size(90, 33);
            this.ShiftB_Avg.TabIndex = 9;
            this.ShiftB_Avg.Text = "Average";
            this.ShiftB_Avg.UseVisualStyleBackColor = true;
            // 
            // time24
            // 
            this.time24.Location = new System.Drawing.Point(6, 197);
            this.time24.Name = "time24";
            this.time24.Size = new System.Drawing.Size(90, 33);
            this.time24.TabIndex = 8;
            this.time24.Text = "24";
            this.time24.UseVisualStyleBackColor = true;
            // 
            // time22
            // 
            this.time22.Location = new System.Drawing.Point(6, 158);
            this.time22.Name = "time22";
            this.time22.Size = new System.Drawing.Size(90, 33);
            this.time22.TabIndex = 7;
            this.time22.Text = "22";
            this.time22.UseVisualStyleBackColor = true;
            // 
            // time20
            // 
            this.time20.Location = new System.Drawing.Point(5, 119);
            this.time20.Name = "time20";
            this.time20.Size = new System.Drawing.Size(90, 33);
            this.time20.TabIndex = 6;
            this.time20.Text = "20";
            this.time20.UseVisualStyleBackColor = true;
            // 
            // time18
            // 
            this.time18.Location = new System.Drawing.Point(5, 80);
            this.time18.Name = "time18";
            this.time18.Size = new System.Drawing.Size(90, 33);
            this.time18.TabIndex = 5;
            this.time18.Text = "18";
            this.time18.UseVisualStyleBackColor = true;
            // 
            // groupBox10
            // 
            this.groupBox10.Controls.Add(this.button125);
            this.groupBox10.Controls.Add(this.button126);
            this.groupBox10.Controls.Add(this.button127);
            this.groupBox10.Controls.Add(this.button128);
            this.groupBox10.Controls.Add(this.button109);
            this.groupBox10.Controls.Add(this.button110);
            this.groupBox10.Controls.Add(this.button111);
            this.groupBox10.Controls.Add(this.button112);
            this.groupBox10.Controls.Add(this.button93);
            this.groupBox10.Controls.Add(this.button94);
            this.groupBox10.Controls.Add(this.button95);
            this.groupBox10.Controls.Add(this.button96);
            this.groupBox10.Controls.Add(this.button77);
            this.groupBox10.Controls.Add(this.button78);
            this.groupBox10.Controls.Add(this.button79);
            this.groupBox10.Controls.Add(this.button80);
            this.groupBox10.Controls.Add(this.ShiftB21);
            this.groupBox10.Controls.Add(this.ShiftB20);
            this.groupBox10.Controls.Add(this.ShiftB19);
            this.groupBox10.Controls.Add(this.ShiftB18);
            this.groupBox10.Controls.Add(this.ShiftB5);
            this.groupBox10.Location = new System.Drawing.Point(1131, 21);
            this.groupBox10.Name = "groupBox10";
            this.groupBox10.Size = new System.Drawing.Size(333, 297);
            this.groupBox10.TabIndex = 5;
            this.groupBox10.TabStop = false;
            // 
            // ShiftB21
            // 
            this.ShiftB21.Location = new System.Drawing.Point(249, 49);
            this.ShiftB21.Name = "ShiftB21";
            this.ShiftB21.Size = new System.Drawing.Size(75, 29);
            this.ShiftB21.TabIndex = 8;
            this.ShiftB21.Text = "Purity";
            this.ShiftB21.UseVisualStyleBackColor = true;
            // 
            // ShiftB20
            // 
            this.ShiftB20.Location = new System.Drawing.Point(168, 49);
            this.ShiftB20.Name = "ShiftB20";
            this.ShiftB20.Size = new System.Drawing.Size(75, 29);
            this.ShiftB20.TabIndex = 7;
            this.ShiftB20.Text = "Ph";
            this.ShiftB20.UseVisualStyleBackColor = true;
            // 
            // ShiftB19
            // 
            this.ShiftB19.Location = new System.Drawing.Point(87, 49);
            this.ShiftB19.Name = "ShiftB19";
            this.ShiftB19.Size = new System.Drawing.Size(75, 29);
            this.ShiftB19.TabIndex = 6;
            this.ShiftB19.Text = "Pol";
            this.ShiftB19.UseVisualStyleBackColor = true;
            // 
            // ShiftB18
            // 
            this.ShiftB18.Location = new System.Drawing.Point(6, 49);
            this.ShiftB18.Name = "ShiftB18";
            this.ShiftB18.Size = new System.Drawing.Size(75, 29);
            this.ShiftB18.TabIndex = 5;
            this.ShiftB18.Text = "Brix";
            this.ShiftB18.UseVisualStyleBackColor = true;
            // 
            // ShiftB5
            // 
            this.ShiftB5.Location = new System.Drawing.Point(6, 12);
            this.ShiftB5.Name = "ShiftB5";
            this.ShiftB5.Size = new System.Drawing.Size(318, 31);
            this.ShiftB5.TabIndex = 0;
            this.ShiftB5.Text = "Sulphured Syrup";
            this.ShiftB5.UseVisualStyleBackColor = true;
            // 
            // groupBox11
            // 
            this.groupBox11.Controls.Add(this.button113);
            this.groupBox11.Controls.Add(this.button114);
            this.groupBox11.Controls.Add(this.button115);
            this.groupBox11.Controls.Add(this.button116);
            this.groupBox11.Controls.Add(this.button97);
            this.groupBox11.Controls.Add(this.button98);
            this.groupBox11.Controls.Add(this.button99);
            this.groupBox11.Controls.Add(this.button100);
            this.groupBox11.Controls.Add(this.button81);
            this.groupBox11.Controls.Add(this.button82);
            this.groupBox11.Controls.Add(this.button83);
            this.groupBox11.Controls.Add(this.button84);
            this.groupBox11.Controls.Add(this.button65);
            this.groupBox11.Controls.Add(this.button66);
            this.groupBox11.Controls.Add(this.button67);
            this.groupBox11.Controls.Add(this.button68);
            this.groupBox11.Controls.Add(this.b9);
            this.groupBox11.Controls.Add(this.ShiftB8);
            this.groupBox11.Controls.Add(this.ShiftB7);
            this.groupBox11.Controls.Add(this.ShiftB6);
            this.groupBox11.Controls.Add(this.ShiftB2);
            this.groupBox11.Location = new System.Drawing.Point(114, 21);
            this.groupBox11.Name = "groupBox11";
            this.groupBox11.Size = new System.Drawing.Size(333, 297);
            this.groupBox11.TabIndex = 2;
            this.groupBox11.TabStop = false;
            // 
            // b9
            // 
            this.b9.Location = new System.Drawing.Point(249, 49);
            this.b9.Name = "b9";
            this.b9.Size = new System.Drawing.Size(75, 29);
            this.b9.TabIndex = 8;
            this.b9.Text = "Purity";
            this.b9.UseVisualStyleBackColor = true;
            // 
            // ShiftB8
            // 
            this.ShiftB8.Location = new System.Drawing.Point(168, 49);
            this.ShiftB8.Name = "ShiftB8";
            this.ShiftB8.Size = new System.Drawing.Size(75, 29);
            this.ShiftB8.TabIndex = 7;
            this.ShiftB8.Text = "Ph";
            this.ShiftB8.UseVisualStyleBackColor = true;
            // 
            // ShiftB7
            // 
            this.ShiftB7.Location = new System.Drawing.Point(87, 49);
            this.ShiftB7.Name = "ShiftB7";
            this.ShiftB7.Size = new System.Drawing.Size(75, 29);
            this.ShiftB7.TabIndex = 6;
            this.ShiftB7.Text = "Pol";
            this.ShiftB7.UseVisualStyleBackColor = true;
            // 
            // ShiftB6
            // 
            this.ShiftB6.Location = new System.Drawing.Point(6, 49);
            this.ShiftB6.Name = "ShiftB6";
            this.ShiftB6.Size = new System.Drawing.Size(75, 29);
            this.ShiftB6.TabIndex = 5;
            this.ShiftB6.Text = "Brix";
            this.ShiftB6.UseVisualStyleBackColor = true;
            // 
            // ShiftB2
            // 
            this.ShiftB2.Location = new System.Drawing.Point(6, 12);
            this.ShiftB2.Name = "ShiftB2";
            this.ShiftB2.Size = new System.Drawing.Size(318, 31);
            this.ShiftB2.TabIndex = 0;
            this.ShiftB2.Text = "Oliver Filter Juice";
            this.ShiftB2.UseVisualStyleBackColor = true;
            // 
            // groupBox12
            // 
            this.groupBox12.Controls.Add(this.button121);
            this.groupBox12.Controls.Add(this.button122);
            this.groupBox12.Controls.Add(this.button123);
            this.groupBox12.Controls.Add(this.button124);
            this.groupBox12.Controls.Add(this.button105);
            this.groupBox12.Controls.Add(this.button106);
            this.groupBox12.Controls.Add(this.button107);
            this.groupBox12.Controls.Add(this.button108);
            this.groupBox12.Controls.Add(this.button89);
            this.groupBox12.Controls.Add(this.button90);
            this.groupBox12.Controls.Add(this.button91);
            this.groupBox12.Controls.Add(this.button92);
            this.groupBox12.Controls.Add(this.button73);
            this.groupBox12.Controls.Add(this.button74);
            this.groupBox12.Controls.Add(this.button75);
            this.groupBox12.Controls.Add(this.button76);
            this.groupBox12.Controls.Add(this.ShiftB17);
            this.groupBox12.Controls.Add(this.ShiftB16);
            this.groupBox12.Controls.Add(this.ShiftB15);
            this.groupBox12.Controls.Add(this.ShiftB14);
            this.groupBox12.Controls.Add(this.ShiftB4);
            this.groupBox12.Location = new System.Drawing.Point(792, 21);
            this.groupBox12.Name = "groupBox12";
            this.groupBox12.Size = new System.Drawing.Size(333, 297);
            this.groupBox12.TabIndex = 4;
            this.groupBox12.TabStop = false;
            // 
            // ShiftB17
            // 
            this.ShiftB17.Location = new System.Drawing.Point(249, 49);
            this.ShiftB17.Name = "ShiftB17";
            this.ShiftB17.Size = new System.Drawing.Size(75, 29);
            this.ShiftB17.TabIndex = 8;
            this.ShiftB17.Text = "Purity";
            this.ShiftB17.UseVisualStyleBackColor = true;
            // 
            // ShiftB16
            // 
            this.ShiftB16.Location = new System.Drawing.Point(168, 49);
            this.ShiftB16.Name = "ShiftB16";
            this.ShiftB16.Size = new System.Drawing.Size(75, 29);
            this.ShiftB16.TabIndex = 7;
            this.ShiftB16.Text = "Ph";
            this.ShiftB16.UseVisualStyleBackColor = true;
            // 
            // ShiftB15
            // 
            this.ShiftB15.Location = new System.Drawing.Point(87, 49);
            this.ShiftB15.Name = "ShiftB15";
            this.ShiftB15.Size = new System.Drawing.Size(75, 29);
            this.ShiftB15.TabIndex = 6;
            this.ShiftB15.Text = "Pol";
            this.ShiftB15.UseVisualStyleBackColor = true;
            // 
            // ShiftB14
            // 
            this.ShiftB14.Location = new System.Drawing.Point(6, 49);
            this.ShiftB14.Name = "ShiftB14";
            this.ShiftB14.Size = new System.Drawing.Size(75, 29);
            this.ShiftB14.TabIndex = 5;
            this.ShiftB14.Text = "Brix";
            this.ShiftB14.UseVisualStyleBackColor = true;
            // 
            // ShiftB4
            // 
            this.ShiftB4.Location = new System.Drawing.Point(6, 12);
            this.ShiftB4.Name = "ShiftB4";
            this.ShiftB4.Size = new System.Drawing.Size(318, 31);
            this.ShiftB4.TabIndex = 0;
            this.ShiftB4.Text = "Un-sulphured Syrup";
            this.ShiftB4.UseVisualStyleBackColor = true;
            // 
            // groupBox13
            // 
            this.groupBox13.Controls.Add(this.button117);
            this.groupBox13.Controls.Add(this.button118);
            this.groupBox13.Controls.Add(this.button119);
            this.groupBox13.Controls.Add(this.button120);
            this.groupBox13.Controls.Add(this.button101);
            this.groupBox13.Controls.Add(this.button102);
            this.groupBox13.Controls.Add(this.button103);
            this.groupBox13.Controls.Add(this.button104);
            this.groupBox13.Controls.Add(this.button85);
            this.groupBox13.Controls.Add(this.button86);
            this.groupBox13.Controls.Add(this.button87);
            this.groupBox13.Controls.Add(this.button88);
            this.groupBox13.Controls.Add(this.button69);
            this.groupBox13.Controls.Add(this.button70);
            this.groupBox13.Controls.Add(this.button71);
            this.groupBox13.Controls.Add(this.button72);
            this.groupBox13.Controls.Add(this.ShiftB13);
            this.groupBox13.Controls.Add(this.ShiftB12);
            this.groupBox13.Controls.Add(this.ShiftB11);
            this.groupBox13.Controls.Add(this.ShiftB10);
            this.groupBox13.Controls.Add(this.ShiftB3);
            this.groupBox13.Location = new System.Drawing.Point(453, 21);
            this.groupBox13.Name = "groupBox13";
            this.groupBox13.Size = new System.Drawing.Size(333, 297);
            this.groupBox13.TabIndex = 3;
            this.groupBox13.TabStop = false;
            // 
            // ShiftB13
            // 
            this.ShiftB13.Location = new System.Drawing.Point(249, 49);
            this.ShiftB13.Name = "ShiftB13";
            this.ShiftB13.Size = new System.Drawing.Size(75, 29);
            this.ShiftB13.TabIndex = 8;
            this.ShiftB13.Text = "Purity";
            this.ShiftB13.UseVisualStyleBackColor = true;
            // 
            // ShiftB12
            // 
            this.ShiftB12.Location = new System.Drawing.Point(168, 49);
            this.ShiftB12.Name = "ShiftB12";
            this.ShiftB12.Size = new System.Drawing.Size(75, 29);
            this.ShiftB12.TabIndex = 7;
            this.ShiftB12.Text = "Ph";
            this.ShiftB12.UseVisualStyleBackColor = true;
            // 
            // ShiftB11
            // 
            this.ShiftB11.Location = new System.Drawing.Point(87, 49);
            this.ShiftB11.Name = "ShiftB11";
            this.ShiftB11.Size = new System.Drawing.Size(75, 29);
            this.ShiftB11.TabIndex = 6;
            this.ShiftB11.Text = "Pol";
            this.ShiftB11.UseVisualStyleBackColor = true;
            // 
            // ShiftB10
            // 
            this.ShiftB10.Location = new System.Drawing.Point(6, 49);
            this.ShiftB10.Name = "ShiftB10";
            this.ShiftB10.Size = new System.Drawing.Size(75, 29);
            this.ShiftB10.TabIndex = 5;
            this.ShiftB10.Text = "Brix";
            this.ShiftB10.UseVisualStyleBackColor = true;
            // 
            // ShiftB3
            // 
            this.ShiftB3.Location = new System.Drawing.Point(6, 12);
            this.ShiftB3.Name = "ShiftB3";
            this.ShiftB3.Size = new System.Drawing.Size(318, 31);
            this.ShiftB3.TabIndex = 0;
            this.ShiftB3.Text = "Clear Juice";
            this.ShiftB3.UseVisualStyleBackColor = true;
            // 
            // groupBox7
            // 
            this.groupBox7.Controls.Add(this.groupBox2);
            this.groupBox7.Controls.Add(this.groupBox6);
            this.groupBox7.Controls.Add(this.groupBox3);
            this.groupBox7.Controls.Add(this.groupBox5);
            this.groupBox7.Controls.Add(this.groupBox4);
            this.groupBox7.Location = new System.Drawing.Point(12, 89);
            this.groupBox7.Name = "groupBox7";
            this.groupBox7.Size = new System.Drawing.Size(1477, 328);
            this.groupBox7.TabIndex = 6;
            this.groupBox7.TabStop = false;
            this.groupBox7.Text = "Shift- A";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.SiftA5);
            this.groupBox2.Controls.Add(this.ShiftA_Avg);
            this.groupBox2.Controls.Add(this.time16);
            this.groupBox2.Controls.Add(this.time14);
            this.groupBox2.Controls.Add(this.time12);
            this.groupBox2.Controls.Add(this.time10);
            this.groupBox2.Location = new System.Drawing.Point(6, 21);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(102, 297);
            this.groupBox2.TabIndex = 1;
            this.groupBox2.TabStop = false;
            // 
            // SiftA5
            // 
            this.SiftA5.Location = new System.Drawing.Point(5, 12);
            this.SiftA5.Name = "SiftA5";
            this.SiftA5.Size = new System.Drawing.Size(90, 60);
            this.SiftA5.TabIndex = 10;
            this.SiftA5.Text = "Time";
            this.SiftA5.UseVisualStyleBackColor = true;
            // 
            // ShiftA_Avg
            // 
            this.ShiftA_Avg.Location = new System.Drawing.Point(6, 248);
            this.ShiftA_Avg.Name = "ShiftA_Avg";
            this.ShiftA_Avg.Size = new System.Drawing.Size(90, 33);
            this.ShiftA_Avg.TabIndex = 9;
            this.ShiftA_Avg.Text = "Average";
            this.ShiftA_Avg.UseVisualStyleBackColor = true;
            // 
            // time16
            // 
            this.time16.Location = new System.Drawing.Point(6, 197);
            this.time16.Name = "time16";
            this.time16.Size = new System.Drawing.Size(90, 33);
            this.time16.TabIndex = 8;
            this.time16.Text = "16";
            this.time16.UseVisualStyleBackColor = true;
            // 
            // time14
            // 
            this.time14.Location = new System.Drawing.Point(6, 158);
            this.time14.Name = "time14";
            this.time14.Size = new System.Drawing.Size(90, 33);
            this.time14.TabIndex = 7;
            this.time14.Text = "14";
            this.time14.UseVisualStyleBackColor = true;
            // 
            // time12
            // 
            this.time12.Location = new System.Drawing.Point(5, 119);
            this.time12.Name = "time12";
            this.time12.Size = new System.Drawing.Size(90, 33);
            this.time12.TabIndex = 6;
            this.time12.Text = "12";
            this.time12.UseVisualStyleBackColor = true;
            // 
            // time10
            // 
            this.time10.Location = new System.Drawing.Point(5, 80);
            this.time10.Name = "time10";
            this.time10.Size = new System.Drawing.Size(90, 33);
            this.time10.TabIndex = 5;
            this.time10.Text = "10";
            this.time10.UseVisualStyleBackColor = true;
            // 
            // groupBox6
            // 
            this.groupBox6.Controls.Add(this.button61);
            this.groupBox6.Controls.Add(this.button62);
            this.groupBox6.Controls.Add(this.button63);
            this.groupBox6.Controls.Add(this.button64);
            this.groupBox6.Controls.Add(this.button45);
            this.groupBox6.Controls.Add(this.button46);
            this.groupBox6.Controls.Add(this.button47);
            this.groupBox6.Controls.Add(this.button48);
            this.groupBox6.Controls.Add(this.button29);
            this.groupBox6.Controls.Add(this.button30);
            this.groupBox6.Controls.Add(this.button31);
            this.groupBox6.Controls.Add(this.button32);
            this.groupBox6.Controls.Add(this.button13);
            this.groupBox6.Controls.Add(this.button14);
            this.groupBox6.Controls.Add(this.button15);
            this.groupBox6.Controls.Add(this.button16);
            this.groupBox6.Controls.Add(this.ShiftA21);
            this.groupBox6.Controls.Add(this.ShiftA20);
            this.groupBox6.Controls.Add(this.ShiftA19);
            this.groupBox6.Controls.Add(this.ShiftA18);
            this.groupBox6.Controls.Add(this.SiftA4);
            this.groupBox6.Location = new System.Drawing.Point(1131, 21);
            this.groupBox6.Name = "groupBox6";
            this.groupBox6.Size = new System.Drawing.Size(333, 297);
            this.groupBox6.TabIndex = 5;
            this.groupBox6.TabStop = false;
            // 
            // ShiftA21
            // 
            this.ShiftA21.Location = new System.Drawing.Point(249, 49);
            this.ShiftA21.Name = "ShiftA21";
            this.ShiftA21.Size = new System.Drawing.Size(75, 29);
            this.ShiftA21.TabIndex = 12;
            this.ShiftA21.Text = "Purity";
            this.ShiftA21.UseVisualStyleBackColor = true;
            // 
            // ShiftA20
            // 
            this.ShiftA20.Location = new System.Drawing.Point(168, 49);
            this.ShiftA20.Name = "ShiftA20";
            this.ShiftA20.Size = new System.Drawing.Size(75, 29);
            this.ShiftA20.TabIndex = 11;
            this.ShiftA20.Text = "Ph";
            this.ShiftA20.UseVisualStyleBackColor = true;
            // 
            // ShiftA19
            // 
            this.ShiftA19.Location = new System.Drawing.Point(87, 49);
            this.ShiftA19.Name = "ShiftA19";
            this.ShiftA19.Size = new System.Drawing.Size(75, 29);
            this.ShiftA19.TabIndex = 10;
            this.ShiftA19.Text = "Pol";
            this.ShiftA19.UseVisualStyleBackColor = true;
            // 
            // ShiftA18
            // 
            this.ShiftA18.Location = new System.Drawing.Point(6, 49);
            this.ShiftA18.Name = "ShiftA18";
            this.ShiftA18.Size = new System.Drawing.Size(75, 29);
            this.ShiftA18.TabIndex = 9;
            this.ShiftA18.Text = "Brix";
            this.ShiftA18.UseVisualStyleBackColor = true;
            // 
            // SiftA4
            // 
            this.SiftA4.Location = new System.Drawing.Point(6, 12);
            this.SiftA4.Name = "SiftA4";
            this.SiftA4.Size = new System.Drawing.Size(318, 31);
            this.SiftA4.TabIndex = 0;
            this.SiftA4.Text = "Sulphured Syrup";
            this.SiftA4.UseVisualStyleBackColor = true;
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.button49);
            this.groupBox3.Controls.Add(this.button50);
            this.groupBox3.Controls.Add(this.button51);
            this.groupBox3.Controls.Add(this.button52);
            this.groupBox3.Controls.Add(this.button33);
            this.groupBox3.Controls.Add(this.button34);
            this.groupBox3.Controls.Add(this.button35);
            this.groupBox3.Controls.Add(this.button36);
            this.groupBox3.Controls.Add(this.button17);
            this.groupBox3.Controls.Add(this.button18);
            this.groupBox3.Controls.Add(this.button19);
            this.groupBox3.Controls.Add(this.button20);
            this.groupBox3.Controls.Add(this.button4);
            this.groupBox3.Controls.Add(this.button3);
            this.groupBox3.Controls.Add(this.button2);
            this.groupBox3.Controls.Add(this.button1);
            this.groupBox3.Controls.Add(this.ShiftA9);
            this.groupBox3.Controls.Add(this.ShiftA8);
            this.groupBox3.Controls.Add(this.ShiftA7);
            this.groupBox3.Controls.Add(this.ShiftA6);
            this.groupBox3.Controls.Add(this.SiftA1);
            this.groupBox3.Location = new System.Drawing.Point(114, 21);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(333, 297);
            this.groupBox3.TabIndex = 2;
            this.groupBox3.TabStop = false;
            // 
            // button4
            // 
            this.button4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button4.Location = new System.Drawing.Point(249, 85);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(75, 28);
            this.button4.TabIndex = 8;
            this.button4.Text = "button4";
            this.button4.UseVisualStyleBackColor = true;
            // 
            // button3
            // 
            this.button3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button3.Location = new System.Drawing.Point(168, 85);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(75, 28);
            this.button3.TabIndex = 7;
            this.button3.Text = "button3";
            this.button3.UseVisualStyleBackColor = true;
            // 
            // button2
            // 
            this.button2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button2.Location = new System.Drawing.Point(87, 85);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(75, 28);
            this.button2.TabIndex = 6;
            this.button2.Text = "button2";
            this.button2.UseVisualStyleBackColor = true;
            // 
            // button1
            // 
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.Location = new System.Drawing.Point(6, 85);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 28);
            this.button1.TabIndex = 5;
            this.button1.Text = "button1";
            this.button1.UseVisualStyleBackColor = true;
            // 
            // ShiftA9
            // 
            this.ShiftA9.Location = new System.Drawing.Point(249, 49);
            this.ShiftA9.Name = "ShiftA9";
            this.ShiftA9.Size = new System.Drawing.Size(75, 29);
            this.ShiftA9.TabIndex = 4;
            this.ShiftA9.Text = "Purity";
            this.ShiftA9.UseVisualStyleBackColor = true;
            // 
            // ShiftA8
            // 
            this.ShiftA8.Location = new System.Drawing.Point(168, 49);
            this.ShiftA8.Name = "ShiftA8";
            this.ShiftA8.Size = new System.Drawing.Size(75, 29);
            this.ShiftA8.TabIndex = 3;
            this.ShiftA8.Text = "Ph";
            this.ShiftA8.UseVisualStyleBackColor = true;
            // 
            // ShiftA7
            // 
            this.ShiftA7.Location = new System.Drawing.Point(87, 49);
            this.ShiftA7.Name = "ShiftA7";
            this.ShiftA7.Size = new System.Drawing.Size(75, 29);
            this.ShiftA7.TabIndex = 2;
            this.ShiftA7.Text = "Pol";
            this.ShiftA7.UseVisualStyleBackColor = true;
            // 
            // ShiftA6
            // 
            this.ShiftA6.Location = new System.Drawing.Point(6, 49);
            this.ShiftA6.Name = "ShiftA6";
            this.ShiftA6.Size = new System.Drawing.Size(75, 29);
            this.ShiftA6.TabIndex = 1;
            this.ShiftA6.Text = "Brix";
            this.ShiftA6.UseVisualStyleBackColor = true;
            // 
            // SiftA1
            // 
            this.SiftA1.Location = new System.Drawing.Point(6, 12);
            this.SiftA1.Name = "SiftA1";
            this.SiftA1.Size = new System.Drawing.Size(318, 31);
            this.SiftA1.TabIndex = 0;
            this.SiftA1.Text = "Oliver Filter Juice";
            this.SiftA1.UseVisualStyleBackColor = true;
            // 
            // groupBox5
            // 
            this.groupBox5.Controls.Add(this.button57);
            this.groupBox5.Controls.Add(this.button58);
            this.groupBox5.Controls.Add(this.button59);
            this.groupBox5.Controls.Add(this.button60);
            this.groupBox5.Controls.Add(this.button41);
            this.groupBox5.Controls.Add(this.button42);
            this.groupBox5.Controls.Add(this.button43);
            this.groupBox5.Controls.Add(this.button44);
            this.groupBox5.Controls.Add(this.button25);
            this.groupBox5.Controls.Add(this.button26);
            this.groupBox5.Controls.Add(this.button27);
            this.groupBox5.Controls.Add(this.button28);
            this.groupBox5.Controls.Add(this.button9);
            this.groupBox5.Controls.Add(this.button10);
            this.groupBox5.Controls.Add(this.button11);
            this.groupBox5.Controls.Add(this.button12);
            this.groupBox5.Controls.Add(this.ShiftA17);
            this.groupBox5.Controls.Add(this.ShiftA16);
            this.groupBox5.Controls.Add(this.ShiftA15);
            this.groupBox5.Controls.Add(this.ShiftA14);
            this.groupBox5.Controls.Add(this.SiftA3);
            this.groupBox5.Location = new System.Drawing.Point(792, 21);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(333, 297);
            this.groupBox5.TabIndex = 4;
            this.groupBox5.TabStop = false;
            // 
            // ShiftA17
            // 
            this.ShiftA17.Location = new System.Drawing.Point(249, 49);
            this.ShiftA17.Name = "ShiftA17";
            this.ShiftA17.Size = new System.Drawing.Size(75, 29);
            this.ShiftA17.TabIndex = 12;
            this.ShiftA17.Text = "Purity";
            this.ShiftA17.UseVisualStyleBackColor = true;
            // 
            // ShiftA16
            // 
            this.ShiftA16.Location = new System.Drawing.Point(168, 49);
            this.ShiftA16.Name = "ShiftA16";
            this.ShiftA16.Size = new System.Drawing.Size(75, 29);
            this.ShiftA16.TabIndex = 11;
            this.ShiftA16.Text = "Ph";
            this.ShiftA16.UseVisualStyleBackColor = true;
            // 
            // ShiftA15
            // 
            this.ShiftA15.Location = new System.Drawing.Point(87, 49);
            this.ShiftA15.Name = "ShiftA15";
            this.ShiftA15.Size = new System.Drawing.Size(75, 29);
            this.ShiftA15.TabIndex = 10;
            this.ShiftA15.Text = "Pol";
            this.ShiftA15.UseVisualStyleBackColor = true;
            // 
            // ShiftA14
            // 
            this.ShiftA14.Location = new System.Drawing.Point(6, 49);
            this.ShiftA14.Name = "ShiftA14";
            this.ShiftA14.Size = new System.Drawing.Size(75, 29);
            this.ShiftA14.TabIndex = 9;
            this.ShiftA14.Text = "Brix";
            this.ShiftA14.UseVisualStyleBackColor = true;
            // 
            // SiftA3
            // 
            this.SiftA3.Location = new System.Drawing.Point(6, 12);
            this.SiftA3.Name = "SiftA3";
            this.SiftA3.Size = new System.Drawing.Size(318, 31);
            this.SiftA3.TabIndex = 0;
            this.SiftA3.Text = "Un-sulphured Syrup";
            this.SiftA3.UseVisualStyleBackColor = true;
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.button53);
            this.groupBox4.Controls.Add(this.button54);
            this.groupBox4.Controls.Add(this.button55);
            this.groupBox4.Controls.Add(this.button56);
            this.groupBox4.Controls.Add(this.button37);
            this.groupBox4.Controls.Add(this.button38);
            this.groupBox4.Controls.Add(this.button39);
            this.groupBox4.Controls.Add(this.button40);
            this.groupBox4.Controls.Add(this.button21);
            this.groupBox4.Controls.Add(this.button22);
            this.groupBox4.Controls.Add(this.button23);
            this.groupBox4.Controls.Add(this.button24);
            this.groupBox4.Controls.Add(this.button5);
            this.groupBox4.Controls.Add(this.button6);
            this.groupBox4.Controls.Add(this.button7);
            this.groupBox4.Controls.Add(this.button8);
            this.groupBox4.Controls.Add(this.ShiftA13);
            this.groupBox4.Controls.Add(this.ShiftA12);
            this.groupBox4.Controls.Add(this.ShiftA11);
            this.groupBox4.Controls.Add(this.ShiftA10);
            this.groupBox4.Controls.Add(this.SiftA2);
            this.groupBox4.Location = new System.Drawing.Point(453, 21);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(333, 297);
            this.groupBox4.TabIndex = 3;
            this.groupBox4.TabStop = false;
            // 
            // button5
            // 
            this.button5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button5.Location = new System.Drawing.Point(6, 85);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(75, 28);
            this.button5.TabIndex = 12;
            this.button5.Text = "button5";
            this.button5.UseVisualStyleBackColor = true;
            // 
            // button6
            // 
            this.button6.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button6.Location = new System.Drawing.Point(87, 85);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(75, 28);
            this.button6.TabIndex = 11;
            this.button6.Text = "button6";
            this.button6.UseVisualStyleBackColor = true;
            // 
            // button7
            // 
            this.button7.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button7.Location = new System.Drawing.Point(168, 85);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(75, 28);
            this.button7.TabIndex = 10;
            this.button7.Text = "button7";
            this.button7.UseVisualStyleBackColor = true;
            // 
            // button8
            // 
            this.button8.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button8.Location = new System.Drawing.Point(249, 85);
            this.button8.Name = "button8";
            this.button8.Size = new System.Drawing.Size(75, 28);
            this.button8.TabIndex = 9;
            this.button8.Text = "button8";
            this.button8.UseVisualStyleBackColor = true;
            // 
            // ShiftA13
            // 
            this.ShiftA13.Location = new System.Drawing.Point(249, 49);
            this.ShiftA13.Name = "ShiftA13";
            this.ShiftA13.Size = new System.Drawing.Size(75, 29);
            this.ShiftA13.TabIndex = 8;
            this.ShiftA13.Text = "Purity";
            this.ShiftA13.UseVisualStyleBackColor = true;
            // 
            // ShiftA12
            // 
            this.ShiftA12.Location = new System.Drawing.Point(168, 49);
            this.ShiftA12.Name = "ShiftA12";
            this.ShiftA12.Size = new System.Drawing.Size(75, 29);
            this.ShiftA12.TabIndex = 7;
            this.ShiftA12.Text = "Ph";
            this.ShiftA12.UseVisualStyleBackColor = true;
            // 
            // ShiftA11
            // 
            this.ShiftA11.Location = new System.Drawing.Point(87, 49);
            this.ShiftA11.Name = "ShiftA11";
            this.ShiftA11.Size = new System.Drawing.Size(75, 29);
            this.ShiftA11.TabIndex = 6;
            this.ShiftA11.Text = "Pol";
            this.ShiftA11.UseVisualStyleBackColor = true;
            // 
            // ShiftA10
            // 
            this.ShiftA10.Location = new System.Drawing.Point(6, 49);
            this.ShiftA10.Name = "ShiftA10";
            this.ShiftA10.Size = new System.Drawing.Size(75, 29);
            this.ShiftA10.TabIndex = 5;
            this.ShiftA10.Text = "Brix";
            this.ShiftA10.UseVisualStyleBackColor = true;
            // 
            // SiftA2
            // 
            this.SiftA2.Location = new System.Drawing.Point(6, 12);
            this.SiftA2.Name = "SiftA2";
            this.SiftA2.Size = new System.Drawing.Size(318, 31);
            this.SiftA2.TabIndex = 0;
            this.SiftA2.Text = "Clear Juice";
            this.SiftA2.UseVisualStyleBackColor = true;
            // 
            // groupBox1
            // 
            this.groupBox1.Location = new System.Drawing.Point(12, 12);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(1458, 71);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            // 
            // button9
            // 
            this.button9.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button9.Location = new System.Drawing.Point(6, 85);
            this.button9.Name = "button9";
            this.button9.Size = new System.Drawing.Size(75, 28);
            this.button9.TabIndex = 16;
            this.button9.Text = "button9";
            this.button9.UseVisualStyleBackColor = true;
            // 
            // button10
            // 
            this.button10.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button10.Location = new System.Drawing.Point(87, 85);
            this.button10.Name = "button10";
            this.button10.Size = new System.Drawing.Size(75, 28);
            this.button10.TabIndex = 15;
            this.button10.Text = "button10";
            this.button10.UseVisualStyleBackColor = true;
            // 
            // button11
            // 
            this.button11.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button11.Location = new System.Drawing.Point(168, 85);
            this.button11.Name = "button11";
            this.button11.Size = new System.Drawing.Size(75, 28);
            this.button11.TabIndex = 14;
            this.button11.Text = "button11";
            this.button11.UseVisualStyleBackColor = true;
            // 
            // button12
            // 
            this.button12.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button12.Location = new System.Drawing.Point(249, 85);
            this.button12.Name = "button12";
            this.button12.Size = new System.Drawing.Size(75, 28);
            this.button12.TabIndex = 13;
            this.button12.Text = "button12";
            this.button12.UseVisualStyleBackColor = true;
            // 
            // button13
            // 
            this.button13.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button13.Location = new System.Drawing.Point(6, 85);
            this.button13.Name = "button13";
            this.button13.Size = new System.Drawing.Size(75, 28);
            this.button13.TabIndex = 16;
            this.button13.Text = "button13";
            this.button13.UseVisualStyleBackColor = true;
            // 
            // button14
            // 
            this.button14.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button14.Location = new System.Drawing.Point(87, 85);
            this.button14.Name = "button14";
            this.button14.Size = new System.Drawing.Size(75, 28);
            this.button14.TabIndex = 15;
            this.button14.Text = "button14";
            this.button14.UseVisualStyleBackColor = true;
            // 
            // button15
            // 
            this.button15.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button15.Location = new System.Drawing.Point(168, 85);
            this.button15.Name = "button15";
            this.button15.Size = new System.Drawing.Size(75, 28);
            this.button15.TabIndex = 14;
            this.button15.Text = "button15";
            this.button15.UseVisualStyleBackColor = true;
            // 
            // button16
            // 
            this.button16.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button16.Location = new System.Drawing.Point(249, 85);
            this.button16.Name = "button16";
            this.button16.Size = new System.Drawing.Size(75, 28);
            this.button16.TabIndex = 13;
            this.button16.Text = "button16";
            this.button16.UseVisualStyleBackColor = true;
            // 
            // button17
            // 
            this.button17.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button17.Location = new System.Drawing.Point(6, 121);
            this.button17.Name = "button17";
            this.button17.Size = new System.Drawing.Size(75, 28);
            this.button17.TabIndex = 16;
            this.button17.Text = "button17";
            this.button17.UseVisualStyleBackColor = true;
            // 
            // button18
            // 
            this.button18.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button18.Location = new System.Drawing.Point(87, 121);
            this.button18.Name = "button18";
            this.button18.Size = new System.Drawing.Size(75, 28);
            this.button18.TabIndex = 15;
            this.button18.Text = "button18";
            this.button18.UseVisualStyleBackColor = true;
            // 
            // button19
            // 
            this.button19.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button19.Location = new System.Drawing.Point(168, 121);
            this.button19.Name = "button19";
            this.button19.Size = new System.Drawing.Size(75, 28);
            this.button19.TabIndex = 14;
            this.button19.Text = "button19";
            this.button19.UseVisualStyleBackColor = true;
            // 
            // button20
            // 
            this.button20.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button20.Location = new System.Drawing.Point(249, 121);
            this.button20.Name = "button20";
            this.button20.Size = new System.Drawing.Size(75, 28);
            this.button20.TabIndex = 13;
            this.button20.Text = "button20";
            this.button20.UseVisualStyleBackColor = true;
            // 
            // button21
            // 
            this.button21.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button21.Location = new System.Drawing.Point(6, 121);
            this.button21.Name = "button21";
            this.button21.Size = new System.Drawing.Size(75, 28);
            this.button21.TabIndex = 16;
            this.button21.Text = "button21";
            this.button21.UseVisualStyleBackColor = true;
            // 
            // button22
            // 
            this.button22.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button22.Location = new System.Drawing.Point(87, 121);
            this.button22.Name = "button22";
            this.button22.Size = new System.Drawing.Size(75, 28);
            this.button22.TabIndex = 15;
            this.button22.Text = "button22";
            this.button22.UseVisualStyleBackColor = true;
            // 
            // button23
            // 
            this.button23.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button23.Location = new System.Drawing.Point(168, 121);
            this.button23.Name = "button23";
            this.button23.Size = new System.Drawing.Size(75, 28);
            this.button23.TabIndex = 14;
            this.button23.Text = "button23";
            this.button23.UseVisualStyleBackColor = true;
            // 
            // button24
            // 
            this.button24.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button24.Location = new System.Drawing.Point(249, 121);
            this.button24.Name = "button24";
            this.button24.Size = new System.Drawing.Size(75, 28);
            this.button24.TabIndex = 13;
            this.button24.Text = "button24";
            this.button24.UseVisualStyleBackColor = true;
            // 
            // button25
            // 
            this.button25.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button25.Location = new System.Drawing.Point(6, 121);
            this.button25.Name = "button25";
            this.button25.Size = new System.Drawing.Size(75, 28);
            this.button25.TabIndex = 20;
            this.button25.Text = "button25";
            this.button25.UseVisualStyleBackColor = true;
            // 
            // button26
            // 
            this.button26.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button26.Location = new System.Drawing.Point(87, 121);
            this.button26.Name = "button26";
            this.button26.Size = new System.Drawing.Size(75, 28);
            this.button26.TabIndex = 19;
            this.button26.Text = "button26";
            this.button26.UseVisualStyleBackColor = true;
            // 
            // button27
            // 
            this.button27.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button27.Location = new System.Drawing.Point(168, 121);
            this.button27.Name = "button27";
            this.button27.Size = new System.Drawing.Size(75, 28);
            this.button27.TabIndex = 18;
            this.button27.Text = "button27";
            this.button27.UseVisualStyleBackColor = true;
            // 
            // button28
            // 
            this.button28.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button28.Location = new System.Drawing.Point(249, 121);
            this.button28.Name = "button28";
            this.button28.Size = new System.Drawing.Size(75, 28);
            this.button28.TabIndex = 17;
            this.button28.Text = "button28";
            this.button28.UseVisualStyleBackColor = true;
            // 
            // button29
            // 
            this.button29.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button29.Location = new System.Drawing.Point(6, 124);
            this.button29.Name = "button29";
            this.button29.Size = new System.Drawing.Size(75, 28);
            this.button29.TabIndex = 20;
            this.button29.Text = "button29";
            this.button29.UseVisualStyleBackColor = true;
            // 
            // button30
            // 
            this.button30.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button30.Location = new System.Drawing.Point(87, 124);
            this.button30.Name = "button30";
            this.button30.Size = new System.Drawing.Size(75, 28);
            this.button30.TabIndex = 19;
            this.button30.Text = "button30";
            this.button30.UseVisualStyleBackColor = true;
            // 
            // button31
            // 
            this.button31.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button31.Location = new System.Drawing.Point(168, 124);
            this.button31.Name = "button31";
            this.button31.Size = new System.Drawing.Size(75, 28);
            this.button31.TabIndex = 18;
            this.button31.Text = "button31";
            this.button31.UseVisualStyleBackColor = true;
            // 
            // button32
            // 
            this.button32.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button32.Location = new System.Drawing.Point(249, 124);
            this.button32.Name = "button32";
            this.button32.Size = new System.Drawing.Size(75, 28);
            this.button32.TabIndex = 17;
            this.button32.Text = "button32";
            this.button32.UseVisualStyleBackColor = true;
            // 
            // button33
            // 
            this.button33.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button33.Location = new System.Drawing.Point(6, 160);
            this.button33.Name = "button33";
            this.button33.Size = new System.Drawing.Size(75, 28);
            this.button33.TabIndex = 20;
            this.button33.Text = "button33";
            this.button33.UseVisualStyleBackColor = true;
            // 
            // button34
            // 
            this.button34.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button34.Location = new System.Drawing.Point(87, 160);
            this.button34.Name = "button34";
            this.button34.Size = new System.Drawing.Size(75, 28);
            this.button34.TabIndex = 19;
            this.button34.Text = "button34";
            this.button34.UseVisualStyleBackColor = true;
            // 
            // button35
            // 
            this.button35.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button35.Location = new System.Drawing.Point(168, 160);
            this.button35.Name = "button35";
            this.button35.Size = new System.Drawing.Size(75, 28);
            this.button35.TabIndex = 18;
            this.button35.Text = "button35";
            this.button35.UseVisualStyleBackColor = true;
            // 
            // button36
            // 
            this.button36.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button36.Location = new System.Drawing.Point(249, 160);
            this.button36.Name = "button36";
            this.button36.Size = new System.Drawing.Size(75, 28);
            this.button36.TabIndex = 17;
            this.button36.Text = "button36";
            this.button36.UseVisualStyleBackColor = true;
            // 
            // button37
            // 
            this.button37.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button37.Location = new System.Drawing.Point(6, 160);
            this.button37.Name = "button37";
            this.button37.Size = new System.Drawing.Size(75, 28);
            this.button37.TabIndex = 20;
            this.button37.Text = "button37";
            this.button37.UseVisualStyleBackColor = true;
            // 
            // button38
            // 
            this.button38.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button38.Location = new System.Drawing.Point(87, 160);
            this.button38.Name = "button38";
            this.button38.Size = new System.Drawing.Size(75, 28);
            this.button38.TabIndex = 19;
            this.button38.Text = "button38";
            this.button38.UseVisualStyleBackColor = true;
            // 
            // button39
            // 
            this.button39.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button39.Location = new System.Drawing.Point(168, 160);
            this.button39.Name = "button39";
            this.button39.Size = new System.Drawing.Size(75, 28);
            this.button39.TabIndex = 18;
            this.button39.Text = "button39";
            this.button39.UseVisualStyleBackColor = true;
            // 
            // button40
            // 
            this.button40.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button40.Location = new System.Drawing.Point(249, 160);
            this.button40.Name = "button40";
            this.button40.Size = new System.Drawing.Size(75, 28);
            this.button40.TabIndex = 17;
            this.button40.Text = "button40";
            this.button40.UseVisualStyleBackColor = true;
            // 
            // button41
            // 
            this.button41.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button41.Location = new System.Drawing.Point(6, 160);
            this.button41.Name = "button41";
            this.button41.Size = new System.Drawing.Size(75, 28);
            this.button41.TabIndex = 24;
            this.button41.Text = "button41";
            this.button41.UseVisualStyleBackColor = true;
            // 
            // button42
            // 
            this.button42.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button42.Location = new System.Drawing.Point(87, 160);
            this.button42.Name = "button42";
            this.button42.Size = new System.Drawing.Size(75, 28);
            this.button42.TabIndex = 23;
            this.button42.Text = "button42";
            this.button42.UseVisualStyleBackColor = true;
            // 
            // button43
            // 
            this.button43.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button43.Location = new System.Drawing.Point(168, 160);
            this.button43.Name = "button43";
            this.button43.Size = new System.Drawing.Size(75, 28);
            this.button43.TabIndex = 22;
            this.button43.Text = "button43";
            this.button43.UseVisualStyleBackColor = true;
            // 
            // button44
            // 
            this.button44.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button44.Location = new System.Drawing.Point(249, 160);
            this.button44.Name = "button44";
            this.button44.Size = new System.Drawing.Size(75, 28);
            this.button44.TabIndex = 21;
            this.button44.Text = "button44";
            this.button44.UseVisualStyleBackColor = true;
            // 
            // button45
            // 
            this.button45.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button45.Location = new System.Drawing.Point(6, 160);
            this.button45.Name = "button45";
            this.button45.Size = new System.Drawing.Size(75, 28);
            this.button45.TabIndex = 24;
            this.button45.Text = "button45";
            this.button45.UseVisualStyleBackColor = true;
            // 
            // button46
            // 
            this.button46.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button46.Location = new System.Drawing.Point(87, 160);
            this.button46.Name = "button46";
            this.button46.Size = new System.Drawing.Size(75, 28);
            this.button46.TabIndex = 23;
            this.button46.Text = "button46";
            this.button46.UseVisualStyleBackColor = true;
            // 
            // button47
            // 
            this.button47.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button47.Location = new System.Drawing.Point(168, 160);
            this.button47.Name = "button47";
            this.button47.Size = new System.Drawing.Size(75, 28);
            this.button47.TabIndex = 22;
            this.button47.Text = "button47";
            this.button47.UseVisualStyleBackColor = true;
            // 
            // button48
            // 
            this.button48.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button48.Location = new System.Drawing.Point(249, 160);
            this.button48.Name = "button48";
            this.button48.Size = new System.Drawing.Size(75, 28);
            this.button48.TabIndex = 21;
            this.button48.Text = "button48";
            this.button48.UseVisualStyleBackColor = true;
            // 
            // button49
            // 
            this.button49.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button49.Location = new System.Drawing.Point(6, 199);
            this.button49.Name = "button49";
            this.button49.Size = new System.Drawing.Size(75, 28);
            this.button49.TabIndex = 24;
            this.button49.Text = "button49";
            this.button49.UseVisualStyleBackColor = true;
            // 
            // button50
            // 
            this.button50.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button50.Location = new System.Drawing.Point(87, 199);
            this.button50.Name = "button50";
            this.button50.Size = new System.Drawing.Size(75, 28);
            this.button50.TabIndex = 23;
            this.button50.Text = "button50";
            this.button50.UseVisualStyleBackColor = true;
            // 
            // button51
            // 
            this.button51.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button51.Location = new System.Drawing.Point(168, 199);
            this.button51.Name = "button51";
            this.button51.Size = new System.Drawing.Size(75, 28);
            this.button51.TabIndex = 22;
            this.button51.Text = "button51";
            this.button51.UseVisualStyleBackColor = true;
            // 
            // button52
            // 
            this.button52.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button52.Location = new System.Drawing.Point(249, 199);
            this.button52.Name = "button52";
            this.button52.Size = new System.Drawing.Size(75, 28);
            this.button52.TabIndex = 21;
            this.button52.Text = "button52";
            this.button52.UseVisualStyleBackColor = true;
            // 
            // button53
            // 
            this.button53.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button53.Location = new System.Drawing.Point(6, 199);
            this.button53.Name = "button53";
            this.button53.Size = new System.Drawing.Size(75, 28);
            this.button53.TabIndex = 24;
            this.button53.Text = "button53";
            this.button53.UseVisualStyleBackColor = true;
            // 
            // button54
            // 
            this.button54.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button54.Location = new System.Drawing.Point(87, 199);
            this.button54.Name = "button54";
            this.button54.Size = new System.Drawing.Size(75, 28);
            this.button54.TabIndex = 23;
            this.button54.Text = "button54";
            this.button54.UseVisualStyleBackColor = true;
            // 
            // button55
            // 
            this.button55.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button55.Location = new System.Drawing.Point(168, 199);
            this.button55.Name = "button55";
            this.button55.Size = new System.Drawing.Size(75, 28);
            this.button55.TabIndex = 22;
            this.button55.Text = "button55";
            this.button55.UseVisualStyleBackColor = true;
            // 
            // button56
            // 
            this.button56.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button56.Location = new System.Drawing.Point(249, 199);
            this.button56.Name = "button56";
            this.button56.Size = new System.Drawing.Size(75, 28);
            this.button56.TabIndex = 21;
            this.button56.Text = "button56";
            this.button56.UseVisualStyleBackColor = true;
            // 
            // button57
            // 
            this.button57.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button57.Location = new System.Drawing.Point(6, 199);
            this.button57.Name = "button57";
            this.button57.Size = new System.Drawing.Size(75, 28);
            this.button57.TabIndex = 28;
            this.button57.Text = "button57";
            this.button57.UseVisualStyleBackColor = true;
            // 
            // button58
            // 
            this.button58.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button58.Location = new System.Drawing.Point(87, 199);
            this.button58.Name = "button58";
            this.button58.Size = new System.Drawing.Size(75, 28);
            this.button58.TabIndex = 27;
            this.button58.Text = "button58";
            this.button58.UseVisualStyleBackColor = true;
            // 
            // button59
            // 
            this.button59.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button59.Location = new System.Drawing.Point(168, 199);
            this.button59.Name = "button59";
            this.button59.Size = new System.Drawing.Size(75, 28);
            this.button59.TabIndex = 26;
            this.button59.Text = "button59";
            this.button59.UseVisualStyleBackColor = true;
            // 
            // button60
            // 
            this.button60.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button60.Location = new System.Drawing.Point(249, 199);
            this.button60.Name = "button60";
            this.button60.Size = new System.Drawing.Size(75, 28);
            this.button60.TabIndex = 25;
            this.button60.Text = "button60";
            this.button60.UseVisualStyleBackColor = true;
            // 
            // button61
            // 
            this.button61.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button61.Location = new System.Drawing.Point(6, 197);
            this.button61.Name = "button61";
            this.button61.Size = new System.Drawing.Size(75, 28);
            this.button61.TabIndex = 28;
            this.button61.Text = "button61";
            this.button61.UseVisualStyleBackColor = true;
            // 
            // button62
            // 
            this.button62.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button62.Location = new System.Drawing.Point(87, 197);
            this.button62.Name = "button62";
            this.button62.Size = new System.Drawing.Size(75, 28);
            this.button62.TabIndex = 27;
            this.button62.Text = "button62";
            this.button62.UseVisualStyleBackColor = true;
            // 
            // button63
            // 
            this.button63.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button63.Location = new System.Drawing.Point(168, 197);
            this.button63.Name = "button63";
            this.button63.Size = new System.Drawing.Size(75, 28);
            this.button63.TabIndex = 26;
            this.button63.Text = "button63";
            this.button63.UseVisualStyleBackColor = true;
            // 
            // button64
            // 
            this.button64.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button64.Location = new System.Drawing.Point(249, 197);
            this.button64.Name = "button64";
            this.button64.Size = new System.Drawing.Size(75, 28);
            this.button64.TabIndex = 25;
            this.button64.Text = "button64";
            this.button64.UseVisualStyleBackColor = true;
            // 
            // button65
            // 
            this.button65.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button65.Location = new System.Drawing.Point(6, 85);
            this.button65.Name = "button65";
            this.button65.Size = new System.Drawing.Size(75, 28);
            this.button65.TabIndex = 16;
            this.button65.Text = "button65";
            this.button65.UseVisualStyleBackColor = true;
            // 
            // button66
            // 
            this.button66.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button66.Location = new System.Drawing.Point(87, 85);
            this.button66.Name = "button66";
            this.button66.Size = new System.Drawing.Size(75, 28);
            this.button66.TabIndex = 15;
            this.button66.Text = "button66";
            this.button66.UseVisualStyleBackColor = true;
            // 
            // button67
            // 
            this.button67.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button67.Location = new System.Drawing.Point(168, 85);
            this.button67.Name = "button67";
            this.button67.Size = new System.Drawing.Size(75, 28);
            this.button67.TabIndex = 14;
            this.button67.Text = "button67";
            this.button67.UseVisualStyleBackColor = true;
            // 
            // button68
            // 
            this.button68.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button68.Location = new System.Drawing.Point(249, 85);
            this.button68.Name = "button68";
            this.button68.Size = new System.Drawing.Size(75, 28);
            this.button68.TabIndex = 13;
            this.button68.Text = "button68";
            this.button68.UseVisualStyleBackColor = true;
            // 
            // button69
            // 
            this.button69.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button69.Location = new System.Drawing.Point(6, 85);
            this.button69.Name = "button69";
            this.button69.Size = new System.Drawing.Size(75, 28);
            this.button69.TabIndex = 16;
            this.button69.Text = "button69";
            this.button69.UseVisualStyleBackColor = true;
            // 
            // button70
            // 
            this.button70.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button70.Location = new System.Drawing.Point(87, 85);
            this.button70.Name = "button70";
            this.button70.Size = new System.Drawing.Size(75, 28);
            this.button70.TabIndex = 15;
            this.button70.Text = "button70";
            this.button70.UseVisualStyleBackColor = true;
            // 
            // button71
            // 
            this.button71.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button71.Location = new System.Drawing.Point(168, 85);
            this.button71.Name = "button71";
            this.button71.Size = new System.Drawing.Size(75, 28);
            this.button71.TabIndex = 14;
            this.button71.Text = "button71";
            this.button71.UseVisualStyleBackColor = true;
            // 
            // button72
            // 
            this.button72.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button72.Location = new System.Drawing.Point(249, 85);
            this.button72.Name = "button72";
            this.button72.Size = new System.Drawing.Size(75, 28);
            this.button72.TabIndex = 13;
            this.button72.Text = "button72";
            this.button72.UseVisualStyleBackColor = true;
            // 
            // button73
            // 
            this.button73.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button73.Location = new System.Drawing.Point(6, 85);
            this.button73.Name = "button73";
            this.button73.Size = new System.Drawing.Size(75, 28);
            this.button73.TabIndex = 16;
            this.button73.Text = "button73";
            this.button73.UseVisualStyleBackColor = true;
            // 
            // button74
            // 
            this.button74.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button74.Location = new System.Drawing.Point(87, 85);
            this.button74.Name = "button74";
            this.button74.Size = new System.Drawing.Size(75, 28);
            this.button74.TabIndex = 15;
            this.button74.Text = "button74";
            this.button74.UseVisualStyleBackColor = true;
            // 
            // button75
            // 
            this.button75.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button75.Location = new System.Drawing.Point(168, 85);
            this.button75.Name = "button75";
            this.button75.Size = new System.Drawing.Size(75, 28);
            this.button75.TabIndex = 14;
            this.button75.Text = "button75";
            this.button75.UseVisualStyleBackColor = true;
            // 
            // button76
            // 
            this.button76.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button76.Location = new System.Drawing.Point(249, 85);
            this.button76.Name = "button76";
            this.button76.Size = new System.Drawing.Size(75, 28);
            this.button76.TabIndex = 13;
            this.button76.Text = "button76";
            this.button76.UseVisualStyleBackColor = true;
            // 
            // button77
            // 
            this.button77.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button77.Location = new System.Drawing.Point(6, 85);
            this.button77.Name = "button77";
            this.button77.Size = new System.Drawing.Size(75, 28);
            this.button77.TabIndex = 16;
            this.button77.Text = "button77";
            this.button77.UseVisualStyleBackColor = true;
            // 
            // button78
            // 
            this.button78.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button78.Location = new System.Drawing.Point(87, 85);
            this.button78.Name = "button78";
            this.button78.Size = new System.Drawing.Size(75, 28);
            this.button78.TabIndex = 15;
            this.button78.Text = "button78";
            this.button78.UseVisualStyleBackColor = true;
            // 
            // button79
            // 
            this.button79.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button79.Location = new System.Drawing.Point(168, 85);
            this.button79.Name = "button79";
            this.button79.Size = new System.Drawing.Size(75, 28);
            this.button79.TabIndex = 14;
            this.button79.Text = "button79";
            this.button79.UseVisualStyleBackColor = true;
            // 
            // button80
            // 
            this.button80.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button80.Location = new System.Drawing.Point(249, 85);
            this.button80.Name = "button80";
            this.button80.Size = new System.Drawing.Size(75, 28);
            this.button80.TabIndex = 13;
            this.button80.Text = "button80";
            this.button80.UseVisualStyleBackColor = true;
            // 
            // button81
            // 
            this.button81.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button81.Location = new System.Drawing.Point(6, 121);
            this.button81.Name = "button81";
            this.button81.Size = new System.Drawing.Size(75, 28);
            this.button81.TabIndex = 20;
            this.button81.Text = "button81";
            this.button81.UseVisualStyleBackColor = true;
            // 
            // button82
            // 
            this.button82.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button82.Location = new System.Drawing.Point(87, 121);
            this.button82.Name = "button82";
            this.button82.Size = new System.Drawing.Size(75, 28);
            this.button82.TabIndex = 19;
            this.button82.Text = "button82";
            this.button82.UseVisualStyleBackColor = true;
            // 
            // button83
            // 
            this.button83.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button83.Location = new System.Drawing.Point(168, 121);
            this.button83.Name = "button83";
            this.button83.Size = new System.Drawing.Size(75, 28);
            this.button83.TabIndex = 18;
            this.button83.Text = "button83";
            this.button83.UseVisualStyleBackColor = true;
            // 
            // button84
            // 
            this.button84.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button84.Location = new System.Drawing.Point(249, 121);
            this.button84.Name = "button84";
            this.button84.Size = new System.Drawing.Size(75, 28);
            this.button84.TabIndex = 17;
            this.button84.Text = "button84";
            this.button84.UseVisualStyleBackColor = true;
            // 
            // button85
            // 
            this.button85.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button85.Location = new System.Drawing.Point(6, 121);
            this.button85.Name = "button85";
            this.button85.Size = new System.Drawing.Size(75, 28);
            this.button85.TabIndex = 20;
            this.button85.Text = "button85";
            this.button85.UseVisualStyleBackColor = true;
            // 
            // button86
            // 
            this.button86.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button86.Location = new System.Drawing.Point(87, 121);
            this.button86.Name = "button86";
            this.button86.Size = new System.Drawing.Size(75, 28);
            this.button86.TabIndex = 19;
            this.button86.Text = "button86";
            this.button86.UseVisualStyleBackColor = true;
            // 
            // button87
            // 
            this.button87.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button87.Location = new System.Drawing.Point(168, 121);
            this.button87.Name = "button87";
            this.button87.Size = new System.Drawing.Size(75, 28);
            this.button87.TabIndex = 18;
            this.button87.Text = "button87";
            this.button87.UseVisualStyleBackColor = true;
            // 
            // button88
            // 
            this.button88.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button88.Location = new System.Drawing.Point(249, 121);
            this.button88.Name = "button88";
            this.button88.Size = new System.Drawing.Size(75, 28);
            this.button88.TabIndex = 17;
            this.button88.Text = "button88";
            this.button88.UseVisualStyleBackColor = true;
            // 
            // button89
            // 
            this.button89.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button89.Location = new System.Drawing.Point(6, 121);
            this.button89.Name = "button89";
            this.button89.Size = new System.Drawing.Size(75, 28);
            this.button89.TabIndex = 20;
            this.button89.Text = "button89";
            this.button89.UseVisualStyleBackColor = true;
            // 
            // button90
            // 
            this.button90.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button90.Location = new System.Drawing.Point(87, 121);
            this.button90.Name = "button90";
            this.button90.Size = new System.Drawing.Size(75, 28);
            this.button90.TabIndex = 19;
            this.button90.Text = "button90";
            this.button90.UseVisualStyleBackColor = true;
            // 
            // button91
            // 
            this.button91.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button91.Location = new System.Drawing.Point(168, 121);
            this.button91.Name = "button91";
            this.button91.Size = new System.Drawing.Size(75, 28);
            this.button91.TabIndex = 18;
            this.button91.Text = "button91";
            this.button91.UseVisualStyleBackColor = true;
            // 
            // button92
            // 
            this.button92.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button92.Location = new System.Drawing.Point(249, 121);
            this.button92.Name = "button92";
            this.button92.Size = new System.Drawing.Size(75, 28);
            this.button92.TabIndex = 17;
            this.button92.Text = "button92";
            this.button92.UseVisualStyleBackColor = true;
            // 
            // button93
            // 
            this.button93.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button93.Location = new System.Drawing.Point(6, 119);
            this.button93.Name = "button93";
            this.button93.Size = new System.Drawing.Size(75, 28);
            this.button93.TabIndex = 20;
            this.button93.Text = "button93";
            this.button93.UseVisualStyleBackColor = true;
            // 
            // button94
            // 
            this.button94.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button94.Location = new System.Drawing.Point(87, 119);
            this.button94.Name = "button94";
            this.button94.Size = new System.Drawing.Size(75, 28);
            this.button94.TabIndex = 19;
            this.button94.Text = "button94";
            this.button94.UseVisualStyleBackColor = true;
            // 
            // button95
            // 
            this.button95.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button95.Location = new System.Drawing.Point(168, 119);
            this.button95.Name = "button95";
            this.button95.Size = new System.Drawing.Size(75, 28);
            this.button95.TabIndex = 18;
            this.button95.Text = "button95";
            this.button95.UseVisualStyleBackColor = true;
            // 
            // button96
            // 
            this.button96.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button96.Location = new System.Drawing.Point(249, 119);
            this.button96.Name = "button96";
            this.button96.Size = new System.Drawing.Size(75, 28);
            this.button96.TabIndex = 17;
            this.button96.Text = "button96";
            this.button96.UseVisualStyleBackColor = true;
            // 
            // button97
            // 
            this.button97.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button97.Location = new System.Drawing.Point(6, 160);
            this.button97.Name = "button97";
            this.button97.Size = new System.Drawing.Size(75, 28);
            this.button97.TabIndex = 24;
            this.button97.Text = "button97";
            this.button97.UseVisualStyleBackColor = true;
            // 
            // button98
            // 
            this.button98.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button98.Location = new System.Drawing.Point(87, 160);
            this.button98.Name = "button98";
            this.button98.Size = new System.Drawing.Size(75, 28);
            this.button98.TabIndex = 23;
            this.button98.Text = "button98";
            this.button98.UseVisualStyleBackColor = true;
            // 
            // button99
            // 
            this.button99.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button99.Location = new System.Drawing.Point(168, 160);
            this.button99.Name = "button99";
            this.button99.Size = new System.Drawing.Size(75, 28);
            this.button99.TabIndex = 22;
            this.button99.Text = "button99";
            this.button99.UseVisualStyleBackColor = true;
            // 
            // button100
            // 
            this.button100.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button100.Location = new System.Drawing.Point(249, 160);
            this.button100.Name = "button100";
            this.button100.Size = new System.Drawing.Size(75, 28);
            this.button100.TabIndex = 21;
            this.button100.Text = "button100";
            this.button100.UseVisualStyleBackColor = true;
            // 
            // button101
            // 
            this.button101.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button101.Location = new System.Drawing.Point(6, 160);
            this.button101.Name = "button101";
            this.button101.Size = new System.Drawing.Size(75, 28);
            this.button101.TabIndex = 24;
            this.button101.Text = "button101";
            this.button101.UseVisualStyleBackColor = true;
            // 
            // button102
            // 
            this.button102.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button102.Location = new System.Drawing.Point(87, 160);
            this.button102.Name = "button102";
            this.button102.Size = new System.Drawing.Size(75, 28);
            this.button102.TabIndex = 23;
            this.button102.Text = "button102";
            this.button102.UseVisualStyleBackColor = true;
            // 
            // button103
            // 
            this.button103.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button103.Location = new System.Drawing.Point(168, 160);
            this.button103.Name = "button103";
            this.button103.Size = new System.Drawing.Size(75, 28);
            this.button103.TabIndex = 22;
            this.button103.Text = "button103";
            this.button103.UseVisualStyleBackColor = true;
            // 
            // button104
            // 
            this.button104.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button104.Location = new System.Drawing.Point(249, 160);
            this.button104.Name = "button104";
            this.button104.Size = new System.Drawing.Size(75, 28);
            this.button104.TabIndex = 21;
            this.button104.Text = "button104";
            this.button104.UseVisualStyleBackColor = true;
            // 
            // button105
            // 
            this.button105.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button105.Location = new System.Drawing.Point(6, 160);
            this.button105.Name = "button105";
            this.button105.Size = new System.Drawing.Size(75, 28);
            this.button105.TabIndex = 24;
            this.button105.Text = "button105";
            this.button105.UseVisualStyleBackColor = true;
            // 
            // button106
            // 
            this.button106.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button106.Location = new System.Drawing.Point(87, 160);
            this.button106.Name = "button106";
            this.button106.Size = new System.Drawing.Size(75, 28);
            this.button106.TabIndex = 23;
            this.button106.Text = "button106";
            this.button106.UseVisualStyleBackColor = true;
            // 
            // button107
            // 
            this.button107.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button107.Location = new System.Drawing.Point(168, 160);
            this.button107.Name = "button107";
            this.button107.Size = new System.Drawing.Size(75, 28);
            this.button107.TabIndex = 22;
            this.button107.Text = "button107";
            this.button107.UseVisualStyleBackColor = true;
            // 
            // button108
            // 
            this.button108.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button108.Location = new System.Drawing.Point(249, 160);
            this.button108.Name = "button108";
            this.button108.Size = new System.Drawing.Size(75, 28);
            this.button108.TabIndex = 21;
            this.button108.Text = "button108";
            this.button108.UseVisualStyleBackColor = true;
            // 
            // button109
            // 
            this.button109.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button109.Location = new System.Drawing.Point(6, 160);
            this.button109.Name = "button109";
            this.button109.Size = new System.Drawing.Size(75, 28);
            this.button109.TabIndex = 24;
            this.button109.Text = "button109";
            this.button109.UseVisualStyleBackColor = true;
            // 
            // button110
            // 
            this.button110.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button110.Location = new System.Drawing.Point(87, 160);
            this.button110.Name = "button110";
            this.button110.Size = new System.Drawing.Size(75, 28);
            this.button110.TabIndex = 23;
            this.button110.Text = "button110";
            this.button110.UseVisualStyleBackColor = true;
            // 
            // button111
            // 
            this.button111.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button111.Location = new System.Drawing.Point(168, 160);
            this.button111.Name = "button111";
            this.button111.Size = new System.Drawing.Size(75, 28);
            this.button111.TabIndex = 22;
            this.button111.Text = "button111";
            this.button111.UseVisualStyleBackColor = true;
            // 
            // button112
            // 
            this.button112.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button112.Location = new System.Drawing.Point(249, 160);
            this.button112.Name = "button112";
            this.button112.Size = new System.Drawing.Size(75, 28);
            this.button112.TabIndex = 21;
            this.button112.Text = "button112";
            this.button112.UseVisualStyleBackColor = true;
            // 
            // button113
            // 
            this.button113.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button113.Location = new System.Drawing.Point(6, 199);
            this.button113.Name = "button113";
            this.button113.Size = new System.Drawing.Size(75, 28);
            this.button113.TabIndex = 28;
            this.button113.Text = "button113";
            this.button113.UseVisualStyleBackColor = true;
            // 
            // button114
            // 
            this.button114.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button114.Location = new System.Drawing.Point(87, 199);
            this.button114.Name = "button114";
            this.button114.Size = new System.Drawing.Size(75, 28);
            this.button114.TabIndex = 27;
            this.button114.Text = "button114";
            this.button114.UseVisualStyleBackColor = true;
            // 
            // button115
            // 
            this.button115.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button115.Location = new System.Drawing.Point(168, 199);
            this.button115.Name = "button115";
            this.button115.Size = new System.Drawing.Size(75, 28);
            this.button115.TabIndex = 26;
            this.button115.Text = "button115";
            this.button115.UseVisualStyleBackColor = true;
            // 
            // button116
            // 
            this.button116.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button116.Location = new System.Drawing.Point(249, 199);
            this.button116.Name = "button116";
            this.button116.Size = new System.Drawing.Size(75, 28);
            this.button116.TabIndex = 25;
            this.button116.Text = "button116";
            this.button116.UseVisualStyleBackColor = true;
            // 
            // button117
            // 
            this.button117.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button117.Location = new System.Drawing.Point(6, 199);
            this.button117.Name = "button117";
            this.button117.Size = new System.Drawing.Size(75, 28);
            this.button117.TabIndex = 28;
            this.button117.Text = "button117";
            this.button117.UseVisualStyleBackColor = true;
            // 
            // button118
            // 
            this.button118.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button118.Location = new System.Drawing.Point(87, 199);
            this.button118.Name = "button118";
            this.button118.Size = new System.Drawing.Size(75, 28);
            this.button118.TabIndex = 27;
            this.button118.Text = "button118";
            this.button118.UseVisualStyleBackColor = true;
            // 
            // button119
            // 
            this.button119.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button119.Location = new System.Drawing.Point(168, 199);
            this.button119.Name = "button119";
            this.button119.Size = new System.Drawing.Size(75, 28);
            this.button119.TabIndex = 26;
            this.button119.Text = "button119";
            this.button119.UseVisualStyleBackColor = true;
            // 
            // button120
            // 
            this.button120.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button120.Location = new System.Drawing.Point(249, 199);
            this.button120.Name = "button120";
            this.button120.Size = new System.Drawing.Size(75, 28);
            this.button120.TabIndex = 25;
            this.button120.Text = "button120";
            this.button120.UseVisualStyleBackColor = true;
            // 
            // button121
            // 
            this.button121.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button121.Location = new System.Drawing.Point(6, 199);
            this.button121.Name = "button121";
            this.button121.Size = new System.Drawing.Size(75, 28);
            this.button121.TabIndex = 28;
            this.button121.Text = "button121";
            this.button121.UseVisualStyleBackColor = true;
            // 
            // button122
            // 
            this.button122.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button122.Location = new System.Drawing.Point(87, 199);
            this.button122.Name = "button122";
            this.button122.Size = new System.Drawing.Size(75, 28);
            this.button122.TabIndex = 27;
            this.button122.Text = "button122";
            this.button122.UseVisualStyleBackColor = true;
            // 
            // button123
            // 
            this.button123.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button123.Location = new System.Drawing.Point(168, 199);
            this.button123.Name = "button123";
            this.button123.Size = new System.Drawing.Size(75, 28);
            this.button123.TabIndex = 26;
            this.button123.Text = "button123";
            this.button123.UseVisualStyleBackColor = true;
            // 
            // button124
            // 
            this.button124.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button124.Location = new System.Drawing.Point(249, 199);
            this.button124.Name = "button124";
            this.button124.Size = new System.Drawing.Size(75, 28);
            this.button124.TabIndex = 25;
            this.button124.Text = "button124";
            this.button124.UseVisualStyleBackColor = true;
            // 
            // button125
            // 
            this.button125.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button125.Location = new System.Drawing.Point(6, 199);
            this.button125.Name = "button125";
            this.button125.Size = new System.Drawing.Size(75, 28);
            this.button125.TabIndex = 28;
            this.button125.Text = "button125";
            this.button125.UseVisualStyleBackColor = true;
            // 
            // button126
            // 
            this.button126.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button126.Location = new System.Drawing.Point(87, 199);
            this.button126.Name = "button126";
            this.button126.Size = new System.Drawing.Size(75, 28);
            this.button126.TabIndex = 27;
            this.button126.Text = "button126";
            this.button126.UseVisualStyleBackColor = true;
            // 
            // button127
            // 
            this.button127.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button127.Location = new System.Drawing.Point(168, 199);
            this.button127.Name = "button127";
            this.button127.Size = new System.Drawing.Size(75, 28);
            this.button127.TabIndex = 26;
            this.button127.Text = "button127";
            this.button127.UseVisualStyleBackColor = true;
            // 
            // button128
            // 
            this.button128.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button128.Location = new System.Drawing.Point(249, 199);
            this.button128.Name = "button128";
            this.button128.Size = new System.Drawing.Size(75, 28);
            this.button128.TabIndex = 25;
            this.button128.Text = "button128";
            this.button128.UseVisualStyleBackColor = true;
            // 
            // button129
            // 
            this.button129.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button129.Location = new System.Drawing.Point(6, 84);
            this.button129.Name = "button129";
            this.button129.Size = new System.Drawing.Size(75, 28);
            this.button129.TabIndex = 16;
            this.button129.Text = "button129";
            this.button129.UseVisualStyleBackColor = true;
            // 
            // button130
            // 
            this.button130.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button130.Location = new System.Drawing.Point(87, 84);
            this.button130.Name = "button130";
            this.button130.Size = new System.Drawing.Size(75, 28);
            this.button130.TabIndex = 15;
            this.button130.Text = "button130";
            this.button130.UseVisualStyleBackColor = true;
            // 
            // button131
            // 
            this.button131.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button131.Location = new System.Drawing.Point(168, 84);
            this.button131.Name = "button131";
            this.button131.Size = new System.Drawing.Size(75, 28);
            this.button131.TabIndex = 14;
            this.button131.Text = "button131";
            this.button131.UseVisualStyleBackColor = true;
            // 
            // button132
            // 
            this.button132.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button132.Location = new System.Drawing.Point(249, 84);
            this.button132.Name = "button132";
            this.button132.Size = new System.Drawing.Size(75, 28);
            this.button132.TabIndex = 13;
            this.button132.Text = "button132";
            this.button132.UseVisualStyleBackColor = true;
            // 
            // button133
            // 
            this.button133.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button133.Location = new System.Drawing.Point(6, 84);
            this.button133.Name = "button133";
            this.button133.Size = new System.Drawing.Size(75, 28);
            this.button133.TabIndex = 16;
            this.button133.Text = "button133";
            this.button133.UseVisualStyleBackColor = true;
            // 
            // button134
            // 
            this.button134.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button134.Location = new System.Drawing.Point(87, 84);
            this.button134.Name = "button134";
            this.button134.Size = new System.Drawing.Size(75, 28);
            this.button134.TabIndex = 15;
            this.button134.Text = "button134";
            this.button134.UseVisualStyleBackColor = true;
            // 
            // button135
            // 
            this.button135.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button135.Location = new System.Drawing.Point(168, 84);
            this.button135.Name = "button135";
            this.button135.Size = new System.Drawing.Size(75, 28);
            this.button135.TabIndex = 14;
            this.button135.Text = "button135";
            this.button135.UseVisualStyleBackColor = true;
            // 
            // button136
            // 
            this.button136.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button136.Location = new System.Drawing.Point(249, 84);
            this.button136.Name = "button136";
            this.button136.Size = new System.Drawing.Size(75, 28);
            this.button136.TabIndex = 13;
            this.button136.Text = "button136";
            this.button136.UseVisualStyleBackColor = true;
            // 
            // button137
            // 
            this.button137.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button137.Location = new System.Drawing.Point(6, 84);
            this.button137.Name = "button137";
            this.button137.Size = new System.Drawing.Size(75, 28);
            this.button137.TabIndex = 16;
            this.button137.Text = "button137";
            this.button137.UseVisualStyleBackColor = true;
            // 
            // button138
            // 
            this.button138.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button138.Location = new System.Drawing.Point(87, 84);
            this.button138.Name = "button138";
            this.button138.Size = new System.Drawing.Size(75, 28);
            this.button138.TabIndex = 15;
            this.button138.Text = "button138";
            this.button138.UseVisualStyleBackColor = true;
            // 
            // button139
            // 
            this.button139.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button139.Location = new System.Drawing.Point(168, 84);
            this.button139.Name = "button139";
            this.button139.Size = new System.Drawing.Size(75, 28);
            this.button139.TabIndex = 14;
            this.button139.Text = "button139";
            this.button139.UseVisualStyleBackColor = true;
            // 
            // button140
            // 
            this.button140.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button140.Location = new System.Drawing.Point(249, 84);
            this.button140.Name = "button140";
            this.button140.Size = new System.Drawing.Size(75, 28);
            this.button140.TabIndex = 13;
            this.button140.Text = "button140";
            this.button140.UseVisualStyleBackColor = true;
            // 
            // button141
            // 
            this.button141.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button141.Location = new System.Drawing.Point(6, 84);
            this.button141.Name = "button141";
            this.button141.Size = new System.Drawing.Size(75, 28);
            this.button141.TabIndex = 16;
            this.button141.Text = "button141";
            this.button141.UseVisualStyleBackColor = true;
            // 
            // button142
            // 
            this.button142.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button142.Location = new System.Drawing.Point(87, 84);
            this.button142.Name = "button142";
            this.button142.Size = new System.Drawing.Size(75, 28);
            this.button142.TabIndex = 15;
            this.button142.Text = "button142";
            this.button142.UseVisualStyleBackColor = true;
            // 
            // button143
            // 
            this.button143.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button143.Location = new System.Drawing.Point(168, 84);
            this.button143.Name = "button143";
            this.button143.Size = new System.Drawing.Size(75, 28);
            this.button143.TabIndex = 14;
            this.button143.Text = "button143";
            this.button143.UseVisualStyleBackColor = true;
            // 
            // button144
            // 
            this.button144.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button144.Location = new System.Drawing.Point(249, 84);
            this.button144.Name = "button144";
            this.button144.Size = new System.Drawing.Size(75, 28);
            this.button144.TabIndex = 13;
            this.button144.Text = "button144";
            this.button144.UseVisualStyleBackColor = true;
            // 
            // button145
            // 
            this.button145.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button145.Location = new System.Drawing.Point(6, 119);
            this.button145.Name = "button145";
            this.button145.Size = new System.Drawing.Size(75, 28);
            this.button145.TabIndex = 20;
            this.button145.Text = "button145";
            this.button145.UseVisualStyleBackColor = true;
            // 
            // button146
            // 
            this.button146.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button146.Location = new System.Drawing.Point(87, 119);
            this.button146.Name = "button146";
            this.button146.Size = new System.Drawing.Size(75, 28);
            this.button146.TabIndex = 19;
            this.button146.Text = "button146";
            this.button146.UseVisualStyleBackColor = true;
            // 
            // button147
            // 
            this.button147.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button147.Location = new System.Drawing.Point(168, 119);
            this.button147.Name = "button147";
            this.button147.Size = new System.Drawing.Size(75, 28);
            this.button147.TabIndex = 18;
            this.button147.Text = "button147";
            this.button147.UseVisualStyleBackColor = true;
            // 
            // button148
            // 
            this.button148.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button148.Location = new System.Drawing.Point(249, 119);
            this.button148.Name = "button148";
            this.button148.Size = new System.Drawing.Size(75, 28);
            this.button148.TabIndex = 17;
            this.button148.Text = "button148";
            this.button148.UseVisualStyleBackColor = true;
            // 
            // button149
            // 
            this.button149.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button149.Location = new System.Drawing.Point(6, 122);
            this.button149.Name = "button149";
            this.button149.Size = new System.Drawing.Size(75, 28);
            this.button149.TabIndex = 20;
            this.button149.Text = "button149";
            this.button149.UseVisualStyleBackColor = true;
            // 
            // button150
            // 
            this.button150.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button150.Location = new System.Drawing.Point(87, 122);
            this.button150.Name = "button150";
            this.button150.Size = new System.Drawing.Size(75, 28);
            this.button150.TabIndex = 19;
            this.button150.Text = "button150";
            this.button150.UseVisualStyleBackColor = true;
            // 
            // button151
            // 
            this.button151.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button151.Location = new System.Drawing.Point(168, 122);
            this.button151.Name = "button151";
            this.button151.Size = new System.Drawing.Size(75, 28);
            this.button151.TabIndex = 18;
            this.button151.Text = "button151";
            this.button151.UseVisualStyleBackColor = true;
            // 
            // button152
            // 
            this.button152.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button152.Location = new System.Drawing.Point(249, 122);
            this.button152.Name = "button152";
            this.button152.Size = new System.Drawing.Size(75, 28);
            this.button152.TabIndex = 17;
            this.button152.Text = "button152";
            this.button152.UseVisualStyleBackColor = true;
            // 
            // button153
            // 
            this.button153.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button153.Location = new System.Drawing.Point(6, 122);
            this.button153.Name = "button153";
            this.button153.Size = new System.Drawing.Size(75, 28);
            this.button153.TabIndex = 20;
            this.button153.Text = "button153";
            this.button153.UseVisualStyleBackColor = true;
            // 
            // button154
            // 
            this.button154.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button154.Location = new System.Drawing.Point(87, 122);
            this.button154.Name = "button154";
            this.button154.Size = new System.Drawing.Size(75, 28);
            this.button154.TabIndex = 19;
            this.button154.Text = "button154";
            this.button154.UseVisualStyleBackColor = true;
            // 
            // button155
            // 
            this.button155.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button155.Location = new System.Drawing.Point(168, 122);
            this.button155.Name = "button155";
            this.button155.Size = new System.Drawing.Size(75, 28);
            this.button155.TabIndex = 18;
            this.button155.Text = "button155";
            this.button155.UseVisualStyleBackColor = true;
            // 
            // button156
            // 
            this.button156.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button156.Location = new System.Drawing.Point(249, 122);
            this.button156.Name = "button156";
            this.button156.Size = new System.Drawing.Size(75, 28);
            this.button156.TabIndex = 17;
            this.button156.Text = "button156";
            this.button156.UseVisualStyleBackColor = true;
            // 
            // button157
            // 
            this.button157.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button157.Location = new System.Drawing.Point(6, 122);
            this.button157.Name = "button157";
            this.button157.Size = new System.Drawing.Size(75, 28);
            this.button157.TabIndex = 20;
            this.button157.Text = "button157";
            this.button157.UseVisualStyleBackColor = true;
            // 
            // button158
            // 
            this.button158.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button158.Location = new System.Drawing.Point(87, 122);
            this.button158.Name = "button158";
            this.button158.Size = new System.Drawing.Size(75, 28);
            this.button158.TabIndex = 19;
            this.button158.Text = "button158";
            this.button158.UseVisualStyleBackColor = true;
            // 
            // button159
            // 
            this.button159.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button159.Location = new System.Drawing.Point(168, 122);
            this.button159.Name = "button159";
            this.button159.Size = new System.Drawing.Size(75, 28);
            this.button159.TabIndex = 18;
            this.button159.Text = "button159";
            this.button159.UseVisualStyleBackColor = true;
            // 
            // button160
            // 
            this.button160.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button160.Location = new System.Drawing.Point(249, 122);
            this.button160.Name = "button160";
            this.button160.Size = new System.Drawing.Size(75, 28);
            this.button160.TabIndex = 17;
            this.button160.Text = "button160";
            this.button160.UseVisualStyleBackColor = true;
            // 
            // button161
            // 
            this.button161.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button161.Location = new System.Drawing.Point(6, 161);
            this.button161.Name = "button161";
            this.button161.Size = new System.Drawing.Size(75, 28);
            this.button161.TabIndex = 24;
            this.button161.Text = "button161";
            this.button161.UseVisualStyleBackColor = true;
            // 
            // button162
            // 
            this.button162.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button162.Location = new System.Drawing.Point(87, 161);
            this.button162.Name = "button162";
            this.button162.Size = new System.Drawing.Size(75, 28);
            this.button162.TabIndex = 23;
            this.button162.Text = "button162";
            this.button162.UseVisualStyleBackColor = true;
            // 
            // button163
            // 
            this.button163.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button163.Location = new System.Drawing.Point(168, 161);
            this.button163.Name = "button163";
            this.button163.Size = new System.Drawing.Size(75, 28);
            this.button163.TabIndex = 22;
            this.button163.Text = "button163";
            this.button163.UseVisualStyleBackColor = true;
            // 
            // button164
            // 
            this.button164.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button164.Location = new System.Drawing.Point(249, 161);
            this.button164.Name = "button164";
            this.button164.Size = new System.Drawing.Size(75, 28);
            this.button164.TabIndex = 21;
            this.button164.Text = "button164";
            this.button164.UseVisualStyleBackColor = true;
            // 
            // button165
            // 
            this.button165.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button165.Location = new System.Drawing.Point(6, 158);
            this.button165.Name = "button165";
            this.button165.Size = new System.Drawing.Size(75, 28);
            this.button165.TabIndex = 24;
            this.button165.Text = "button165";
            this.button165.UseVisualStyleBackColor = true;
            // 
            // button166
            // 
            this.button166.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button166.Location = new System.Drawing.Point(87, 158);
            this.button166.Name = "button166";
            this.button166.Size = new System.Drawing.Size(75, 28);
            this.button166.TabIndex = 23;
            this.button166.Text = "button166";
            this.button166.UseVisualStyleBackColor = true;
            // 
            // button167
            // 
            this.button167.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button167.Location = new System.Drawing.Point(168, 158);
            this.button167.Name = "button167";
            this.button167.Size = new System.Drawing.Size(75, 28);
            this.button167.TabIndex = 22;
            this.button167.Text = "button167";
            this.button167.UseVisualStyleBackColor = true;
            // 
            // button168
            // 
            this.button168.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button168.Location = new System.Drawing.Point(249, 158);
            this.button168.Name = "button168";
            this.button168.Size = new System.Drawing.Size(75, 28);
            this.button168.TabIndex = 21;
            this.button168.Text = "button168";
            this.button168.UseVisualStyleBackColor = true;
            // 
            // button169
            // 
            this.button169.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button169.Location = new System.Drawing.Point(6, 158);
            this.button169.Name = "button169";
            this.button169.Size = new System.Drawing.Size(75, 28);
            this.button169.TabIndex = 24;
            this.button169.Text = "button169";
            this.button169.UseVisualStyleBackColor = true;
            // 
            // button170
            // 
            this.button170.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button170.Location = new System.Drawing.Point(87, 158);
            this.button170.Name = "button170";
            this.button170.Size = new System.Drawing.Size(75, 28);
            this.button170.TabIndex = 23;
            this.button170.Text = "button170";
            this.button170.UseVisualStyleBackColor = true;
            // 
            // button171
            // 
            this.button171.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button171.Location = new System.Drawing.Point(168, 158);
            this.button171.Name = "button171";
            this.button171.Size = new System.Drawing.Size(75, 28);
            this.button171.TabIndex = 22;
            this.button171.Text = "button171";
            this.button171.UseVisualStyleBackColor = true;
            // 
            // button172
            // 
            this.button172.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button172.Location = new System.Drawing.Point(249, 158);
            this.button172.Name = "button172";
            this.button172.Size = new System.Drawing.Size(75, 28);
            this.button172.TabIndex = 21;
            this.button172.Text = "button172";
            this.button172.UseVisualStyleBackColor = true;
            // 
            // button173
            // 
            this.button173.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button173.Location = new System.Drawing.Point(6, 161);
            this.button173.Name = "button173";
            this.button173.Size = new System.Drawing.Size(75, 28);
            this.button173.TabIndex = 24;
            this.button173.Text = "button173";
            this.button173.UseVisualStyleBackColor = true;
            // 
            // button174
            // 
            this.button174.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button174.Location = new System.Drawing.Point(87, 161);
            this.button174.Name = "button174";
            this.button174.Size = new System.Drawing.Size(75, 28);
            this.button174.TabIndex = 23;
            this.button174.Text = "button174";
            this.button174.UseVisualStyleBackColor = true;
            // 
            // button175
            // 
            this.button175.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button175.Location = new System.Drawing.Point(168, 161);
            this.button175.Name = "button175";
            this.button175.Size = new System.Drawing.Size(75, 28);
            this.button175.TabIndex = 22;
            this.button175.Text = "button175";
            this.button175.UseVisualStyleBackColor = true;
            // 
            // button176
            // 
            this.button176.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button176.Location = new System.Drawing.Point(249, 161);
            this.button176.Name = "button176";
            this.button176.Size = new System.Drawing.Size(75, 28);
            this.button176.TabIndex = 21;
            this.button176.Text = "button176";
            this.button176.UseVisualStyleBackColor = true;
            // 
            // button177
            // 
            this.button177.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button177.Location = new System.Drawing.Point(6, 200);
            this.button177.Name = "button177";
            this.button177.Size = new System.Drawing.Size(75, 28);
            this.button177.TabIndex = 28;
            this.button177.Text = "button177";
            this.button177.UseVisualStyleBackColor = true;
            // 
            // button178
            // 
            this.button178.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button178.Location = new System.Drawing.Point(87, 200);
            this.button178.Name = "button178";
            this.button178.Size = new System.Drawing.Size(75, 28);
            this.button178.TabIndex = 27;
            this.button178.Text = "button178";
            this.button178.UseVisualStyleBackColor = true;
            // 
            // button179
            // 
            this.button179.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button179.Location = new System.Drawing.Point(168, 200);
            this.button179.Name = "button179";
            this.button179.Size = new System.Drawing.Size(75, 28);
            this.button179.TabIndex = 26;
            this.button179.Text = "button179";
            this.button179.UseVisualStyleBackColor = true;
            // 
            // button180
            // 
            this.button180.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button180.Location = new System.Drawing.Point(249, 200);
            this.button180.Name = "button180";
            this.button180.Size = new System.Drawing.Size(75, 28);
            this.button180.TabIndex = 25;
            this.button180.Text = "button180";
            this.button180.UseVisualStyleBackColor = true;
            // 
            // button181
            // 
            this.button181.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button181.Location = new System.Drawing.Point(6, 197);
            this.button181.Name = "button181";
            this.button181.Size = new System.Drawing.Size(75, 28);
            this.button181.TabIndex = 28;
            this.button181.Text = "button181";
            this.button181.UseVisualStyleBackColor = true;
            // 
            // button182
            // 
            this.button182.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button182.Location = new System.Drawing.Point(87, 197);
            this.button182.Name = "button182";
            this.button182.Size = new System.Drawing.Size(75, 28);
            this.button182.TabIndex = 27;
            this.button182.Text = "button182";
            this.button182.UseVisualStyleBackColor = true;
            // 
            // button183
            // 
            this.button183.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button183.Location = new System.Drawing.Point(168, 197);
            this.button183.Name = "button183";
            this.button183.Size = new System.Drawing.Size(75, 28);
            this.button183.TabIndex = 26;
            this.button183.Text = "button183";
            this.button183.UseVisualStyleBackColor = true;
            // 
            // button184
            // 
            this.button184.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button184.Location = new System.Drawing.Point(249, 197);
            this.button184.Name = "button184";
            this.button184.Size = new System.Drawing.Size(75, 28);
            this.button184.TabIndex = 25;
            this.button184.Text = "button184";
            this.button184.UseVisualStyleBackColor = true;
            // 
            // button185
            // 
            this.button185.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button185.Location = new System.Drawing.Point(6, 197);
            this.button185.Name = "button185";
            this.button185.Size = new System.Drawing.Size(75, 28);
            this.button185.TabIndex = 28;
            this.button185.Text = "button185";
            this.button185.UseVisualStyleBackColor = true;
            // 
            // button186
            // 
            this.button186.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button186.Location = new System.Drawing.Point(87, 197);
            this.button186.Name = "button186";
            this.button186.Size = new System.Drawing.Size(75, 28);
            this.button186.TabIndex = 27;
            this.button186.Text = "button186";
            this.button186.UseVisualStyleBackColor = true;
            // 
            // button187
            // 
            this.button187.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button187.Location = new System.Drawing.Point(168, 197);
            this.button187.Name = "button187";
            this.button187.Size = new System.Drawing.Size(75, 28);
            this.button187.TabIndex = 26;
            this.button187.Text = "button187";
            this.button187.UseVisualStyleBackColor = true;
            // 
            // button188
            // 
            this.button188.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button188.Location = new System.Drawing.Point(249, 197);
            this.button188.Name = "button188";
            this.button188.Size = new System.Drawing.Size(75, 28);
            this.button188.TabIndex = 25;
            this.button188.Text = "button188";
            this.button188.UseVisualStyleBackColor = true;
            // 
            // button189
            // 
            this.button189.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button189.Location = new System.Drawing.Point(6, 195);
            this.button189.Name = "button189";
            this.button189.Size = new System.Drawing.Size(75, 28);
            this.button189.TabIndex = 28;
            this.button189.Text = "button189";
            this.button189.UseVisualStyleBackColor = true;
            // 
            // button190
            // 
            this.button190.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button190.Location = new System.Drawing.Point(87, 195);
            this.button190.Name = "button190";
            this.button190.Size = new System.Drawing.Size(75, 28);
            this.button190.TabIndex = 27;
            this.button190.Text = "button190";
            this.button190.UseVisualStyleBackColor = true;
            // 
            // button191
            // 
            this.button191.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button191.Location = new System.Drawing.Point(168, 195);
            this.button191.Name = "button191";
            this.button191.Size = new System.Drawing.Size(75, 28);
            this.button191.TabIndex = 26;
            this.button191.Text = "button191";
            this.button191.UseVisualStyleBackColor = true;
            // 
            // button192
            // 
            this.button192.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button192.Location = new System.Drawing.Point(249, 195);
            this.button192.Name = "button192";
            this.button192.Size = new System.Drawing.Size(75, 28);
            this.button192.TabIndex = 25;
            this.button192.Text = "button192";
            this.button192.UseVisualStyleBackColor = true;
            // 
            // repo_two_hourly_oliver_cleary_juice_syrup
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1492, 725);
            this.Controls.Add(this.panel1);
            this.Name = "repo_two_hourly_oliver_cleary_juice_syrup";
            this.Text = "repo_two_hourly_oliver_cleary_juice_syrup";
            this.panel1.ResumeLayout(false);
            this.groupBox14.ResumeLayout(false);
            this.groupBox15.ResumeLayout(false);
            this.groupBox16.ResumeLayout(false);
            this.groupBox17.ResumeLayout(false);
            this.groupBox18.ResumeLayout(false);
            this.groupBox19.ResumeLayout(false);
            this.groupBox8.ResumeLayout(false);
            this.groupBox9.ResumeLayout(false);
            this.groupBox10.ResumeLayout(false);
            this.groupBox11.ResumeLayout(false);
            this.groupBox12.ResumeLayout(false);
            this.groupBox13.ResumeLayout(false);
            this.groupBox7.ResumeLayout(false);
            this.groupBox2.ResumeLayout(false);
            this.groupBox6.ResumeLayout(false);
            this.groupBox3.ResumeLayout(false);
            this.groupBox5.ResumeLayout(false);
            this.groupBox4.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.GroupBox groupBox6;
        private System.Windows.Forms.Button SiftA4;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.Button SiftA3;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.Button SiftA2;
        private System.Windows.Forms.Button ShiftA9;
        private System.Windows.Forms.Button ShiftA8;
        private System.Windows.Forms.Button ShiftA7;
        private System.Windows.Forms.Button ShiftA6;
        private System.Windows.Forms.Button SiftA1;
        private System.Windows.Forms.Button ShiftA_Avg;
        private System.Windows.Forms.Button time16;
        private System.Windows.Forms.Button time14;
        private System.Windows.Forms.Button time12;
        private System.Windows.Forms.Button time10;
        private System.Windows.Forms.GroupBox groupBox7;
        private System.Windows.Forms.GroupBox groupBox14;
        private System.Windows.Forms.GroupBox groupBox15;
        private System.Windows.Forms.Button ShiftC1;
        private System.Windows.Forms.Button ShiftC_Avg;
        private System.Windows.Forms.Button time8;
        private System.Windows.Forms.Button time6;
        private System.Windows.Forms.Button time4;
        private System.Windows.Forms.Button time2;
        private System.Windows.Forms.GroupBox groupBox16;
        private System.Windows.Forms.Button ShiftC21;
        private System.Windows.Forms.Button ShiftC20;
        private System.Windows.Forms.Button ShiftC19;
        private System.Windows.Forms.Button ShiftC18;
        private System.Windows.Forms.Button ShiftC5;
        private System.Windows.Forms.GroupBox groupBox17;
        private System.Windows.Forms.Button ShiftC9;
        private System.Windows.Forms.Button ShiftC8;
        private System.Windows.Forms.Button ShiftC7;
        private System.Windows.Forms.Button ShiftC6;
        private System.Windows.Forms.Button ShiftC2;
        private System.Windows.Forms.GroupBox groupBox18;
        private System.Windows.Forms.Button ShiftC17;
        private System.Windows.Forms.Button ShiftC16;
        private System.Windows.Forms.Button ShiftC15;
        private System.Windows.Forms.Button ShiftC14;
        private System.Windows.Forms.Button ShiftC4;
        private System.Windows.Forms.GroupBox groupBox19;
        private System.Windows.Forms.Button ShiftC13;
        private System.Windows.Forms.Button ShiftC12;
        private System.Windows.Forms.Button ShiftC11;
        private System.Windows.Forms.Button ShiftC10;
        private System.Windows.Forms.Button ShiftC3;
        private System.Windows.Forms.GroupBox groupBox8;
        private System.Windows.Forms.GroupBox groupBox9;
        private System.Windows.Forms.Button ShiftB1;
        private System.Windows.Forms.Button ShiftB_Avg;
        private System.Windows.Forms.Button time24;
        private System.Windows.Forms.Button time22;
        private System.Windows.Forms.Button time20;
        private System.Windows.Forms.Button time18;
        private System.Windows.Forms.GroupBox groupBox10;
        private System.Windows.Forms.Button ShiftB21;
        private System.Windows.Forms.Button ShiftB20;
        private System.Windows.Forms.Button ShiftB19;
        private System.Windows.Forms.Button ShiftB18;
        private System.Windows.Forms.Button ShiftB5;
        private System.Windows.Forms.GroupBox groupBox11;
        private System.Windows.Forms.Button b9;
        private System.Windows.Forms.Button ShiftB8;
        private System.Windows.Forms.Button ShiftB7;
        private System.Windows.Forms.Button ShiftB6;
        private System.Windows.Forms.Button ShiftB2;
        private System.Windows.Forms.GroupBox groupBox12;
        private System.Windows.Forms.Button ShiftB17;
        private System.Windows.Forms.Button ShiftB16;
        private System.Windows.Forms.Button ShiftB15;
        private System.Windows.Forms.Button ShiftB14;
        private System.Windows.Forms.Button ShiftB4;
        private System.Windows.Forms.GroupBox groupBox13;
        private System.Windows.Forms.Button ShiftB13;
        private System.Windows.Forms.Button ShiftB12;
        private System.Windows.Forms.Button ShiftB11;
        private System.Windows.Forms.Button ShiftB10;
        private System.Windows.Forms.Button ShiftB3;
        private System.Windows.Forms.Button SiftA5;
        private System.Windows.Forms.Button ShiftA21;
        private System.Windows.Forms.Button ShiftA20;
        private System.Windows.Forms.Button ShiftA19;
        private System.Windows.Forms.Button ShiftA18;
        private System.Windows.Forms.Button ShiftA17;
        private System.Windows.Forms.Button ShiftA16;
        private System.Windows.Forms.Button ShiftA15;
        private System.Windows.Forms.Button ShiftA14;
        private System.Windows.Forms.Button ShiftA13;
        private System.Windows.Forms.Button ShiftA12;
        private System.Windows.Forms.Button ShiftA11;
        private System.Windows.Forms.Button ShiftA10;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.Button button8;
        private System.Windows.Forms.Button button189;
        private System.Windows.Forms.Button button190;
        private System.Windows.Forms.Button button191;
        private System.Windows.Forms.Button button192;
        private System.Windows.Forms.Button button173;
        private System.Windows.Forms.Button button174;
        private System.Windows.Forms.Button button175;
        private System.Windows.Forms.Button button176;
        private System.Windows.Forms.Button button157;
        private System.Windows.Forms.Button button158;
        private System.Windows.Forms.Button button159;
        private System.Windows.Forms.Button button160;
        private System.Windows.Forms.Button button141;
        private System.Windows.Forms.Button button142;
        private System.Windows.Forms.Button button143;
        private System.Windows.Forms.Button button144;
        private System.Windows.Forms.Button button177;
        private System.Windows.Forms.Button button178;
        private System.Windows.Forms.Button button179;
        private System.Windows.Forms.Button button180;
        private System.Windows.Forms.Button button161;
        private System.Windows.Forms.Button button162;
        private System.Windows.Forms.Button button163;
        private System.Windows.Forms.Button button164;
        private System.Windows.Forms.Button button145;
        private System.Windows.Forms.Button button146;
        private System.Windows.Forms.Button button147;
        private System.Windows.Forms.Button button148;
        private System.Windows.Forms.Button button129;
        private System.Windows.Forms.Button button130;
        private System.Windows.Forms.Button button131;
        private System.Windows.Forms.Button button132;
        private System.Windows.Forms.Button button185;
        private System.Windows.Forms.Button button186;
        private System.Windows.Forms.Button button187;
        private System.Windows.Forms.Button button188;
        private System.Windows.Forms.Button button169;
        private System.Windows.Forms.Button button170;
        private System.Windows.Forms.Button button171;
        private System.Windows.Forms.Button button172;
        private System.Windows.Forms.Button button153;
        private System.Windows.Forms.Button button154;
        private System.Windows.Forms.Button button155;
        private System.Windows.Forms.Button button156;
        private System.Windows.Forms.Button button137;
        private System.Windows.Forms.Button button138;
        private System.Windows.Forms.Button button139;
        private System.Windows.Forms.Button button140;
        private System.Windows.Forms.Button button181;
        private System.Windows.Forms.Button button182;
        private System.Windows.Forms.Button button183;
        private System.Windows.Forms.Button button184;
        private System.Windows.Forms.Button button165;
        private System.Windows.Forms.Button button166;
        private System.Windows.Forms.Button button167;
        private System.Windows.Forms.Button button168;
        private System.Windows.Forms.Button button149;
        private System.Windows.Forms.Button button150;
        private System.Windows.Forms.Button button151;
        private System.Windows.Forms.Button button152;
        private System.Windows.Forms.Button button133;
        private System.Windows.Forms.Button button134;
        private System.Windows.Forms.Button button135;
        private System.Windows.Forms.Button button136;
        private System.Windows.Forms.Button button125;
        private System.Windows.Forms.Button button126;
        private System.Windows.Forms.Button button127;
        private System.Windows.Forms.Button button128;
        private System.Windows.Forms.Button button109;
        private System.Windows.Forms.Button button110;
        private System.Windows.Forms.Button button111;
        private System.Windows.Forms.Button button112;
        private System.Windows.Forms.Button button93;
        private System.Windows.Forms.Button button94;
        private System.Windows.Forms.Button button95;
        private System.Windows.Forms.Button button96;
        private System.Windows.Forms.Button button77;
        private System.Windows.Forms.Button button78;
        private System.Windows.Forms.Button button79;
        private System.Windows.Forms.Button button80;
        private System.Windows.Forms.Button button113;
        private System.Windows.Forms.Button button114;
        private System.Windows.Forms.Button button115;
        private System.Windows.Forms.Button button116;
        private System.Windows.Forms.Button button97;
        private System.Windows.Forms.Button button98;
        private System.Windows.Forms.Button button99;
        private System.Windows.Forms.Button button100;
        private System.Windows.Forms.Button button81;
        private System.Windows.Forms.Button button82;
        private System.Windows.Forms.Button button83;
        private System.Windows.Forms.Button button84;
        private System.Windows.Forms.Button button65;
        private System.Windows.Forms.Button button66;
        private System.Windows.Forms.Button button67;
        private System.Windows.Forms.Button button68;
        private System.Windows.Forms.Button button121;
        private System.Windows.Forms.Button button122;
        private System.Windows.Forms.Button button123;
        private System.Windows.Forms.Button button124;
        private System.Windows.Forms.Button button105;
        private System.Windows.Forms.Button button106;
        private System.Windows.Forms.Button button107;
        private System.Windows.Forms.Button button108;
        private System.Windows.Forms.Button button89;
        private System.Windows.Forms.Button button90;
        private System.Windows.Forms.Button button91;
        private System.Windows.Forms.Button button92;
        private System.Windows.Forms.Button button73;
        private System.Windows.Forms.Button button74;
        private System.Windows.Forms.Button button75;
        private System.Windows.Forms.Button button76;
        private System.Windows.Forms.Button button117;
        private System.Windows.Forms.Button button118;
        private System.Windows.Forms.Button button119;
        private System.Windows.Forms.Button button120;
        private System.Windows.Forms.Button button101;
        private System.Windows.Forms.Button button102;
        private System.Windows.Forms.Button button103;
        private System.Windows.Forms.Button button104;
        private System.Windows.Forms.Button button85;
        private System.Windows.Forms.Button button86;
        private System.Windows.Forms.Button button87;
        private System.Windows.Forms.Button button88;
        private System.Windows.Forms.Button button69;
        private System.Windows.Forms.Button button70;
        private System.Windows.Forms.Button button71;
        private System.Windows.Forms.Button button72;
        private System.Windows.Forms.Button button61;
        private System.Windows.Forms.Button button62;
        private System.Windows.Forms.Button button63;
        private System.Windows.Forms.Button button64;
        private System.Windows.Forms.Button button45;
        private System.Windows.Forms.Button button46;
        private System.Windows.Forms.Button button47;
        private System.Windows.Forms.Button button48;
        private System.Windows.Forms.Button button29;
        private System.Windows.Forms.Button button30;
        private System.Windows.Forms.Button button31;
        private System.Windows.Forms.Button button32;
        private System.Windows.Forms.Button button13;
        private System.Windows.Forms.Button button14;
        private System.Windows.Forms.Button button15;
        private System.Windows.Forms.Button button16;
        private System.Windows.Forms.Button button49;
        private System.Windows.Forms.Button button50;
        private System.Windows.Forms.Button button51;
        private System.Windows.Forms.Button button52;
        private System.Windows.Forms.Button button33;
        private System.Windows.Forms.Button button34;
        private System.Windows.Forms.Button button35;
        private System.Windows.Forms.Button button36;
        private System.Windows.Forms.Button button17;
        private System.Windows.Forms.Button button18;
        private System.Windows.Forms.Button button19;
        private System.Windows.Forms.Button button20;
        private System.Windows.Forms.Button button57;
        private System.Windows.Forms.Button button58;
        private System.Windows.Forms.Button button59;
        private System.Windows.Forms.Button button60;
        private System.Windows.Forms.Button button41;
        private System.Windows.Forms.Button button42;
        private System.Windows.Forms.Button button43;
        private System.Windows.Forms.Button button44;
        private System.Windows.Forms.Button button25;
        private System.Windows.Forms.Button button26;
        private System.Windows.Forms.Button button27;
        private System.Windows.Forms.Button button28;
        private System.Windows.Forms.Button button9;
        private System.Windows.Forms.Button button10;
        private System.Windows.Forms.Button button11;
        private System.Windows.Forms.Button button12;
        private System.Windows.Forms.Button button53;
        private System.Windows.Forms.Button button54;
        private System.Windows.Forms.Button button55;
        private System.Windows.Forms.Button button56;
        private System.Windows.Forms.Button button37;
        private System.Windows.Forms.Button button38;
        private System.Windows.Forms.Button button39;
        private System.Windows.Forms.Button button40;
        private System.Windows.Forms.Button button21;
        private System.Windows.Forms.Button button22;
        private System.Windows.Forms.Button button23;
        private System.Windows.Forms.Button button24;
    }
}