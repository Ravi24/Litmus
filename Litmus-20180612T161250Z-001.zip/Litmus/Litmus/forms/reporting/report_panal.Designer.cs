﻿namespace Litmus.forms.reporting
{
    partial class report_panal
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.lblCropDayValue = new System.Windows.Forms.Label();
            this.lblCropDayLabel = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.btnJuiceWater = new System.Windows.Forms.Button();
            this.btnSugarBags = new System.Windows.Forms.Button();
            this.btnJuice = new System.Windows.Forms.Button();
            this.btnBagassePressCake = new System.Windows.Forms.Button();
            this.btnSyrupFinalMolasses = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.lblCropDayValue);
            this.groupBox1.Controls.Add(this.lblCropDayLabel);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.dateTimePicker1);
            this.groupBox1.Location = new System.Drawing.Point(12, 12);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(1167, 57);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            // 
            // lblCropDayValue
            // 
            this.lblCropDayValue.AutoSize = true;
            this.lblCropDayValue.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCropDayValue.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.lblCropDayValue.Location = new System.Drawing.Point(1082, 26);
            this.lblCropDayValue.Name = "lblCropDayValue";
            this.lblCropDayValue.Size = new System.Drawing.Size(75, 17);
            this.lblCropDayValue.TabIndex = 3;
            this.lblCropDayValue.Text = "Crop Day";
            // 
            // lblCropDayLabel
            // 
            this.lblCropDayLabel.AutoSize = true;
            this.lblCropDayLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCropDayLabel.Location = new System.Drawing.Point(1000, 26);
            this.lblCropDayLabel.Name = "lblCropDayLabel";
            this.lblCropDayLabel.Size = new System.Drawing.Size(75, 17);
            this.lblCropDayLabel.TabIndex = 2;
            this.lblCropDayLabel.Text = "Crop Day";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(6, 31);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(85, 17);
            this.label1.TabIndex = 1;
            this.label1.Text = "Report Date";
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.CustomFormat = "yyyy-MM-dd";
            this.dateTimePicker1.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dateTimePicker1.Location = new System.Drawing.Point(97, 26);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(124, 22);
            this.dateTimePicker1.TabIndex = 0;
            this.dateTimePicker1.ValueChanged += new System.EventHandler(this.dateTimePicker1_ValueChanged);
            // 
            // btnJuiceWater
            // 
            this.btnJuiceWater.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(203)))), ((int)(((byte)(222)))), ((int)(((byte)(233)))));
            this.btnJuiceWater.FlatAppearance.BorderColor = System.Drawing.Color.DarkTurquoise;
            this.btnJuiceWater.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.btnJuiceWater.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.btnJuiceWater.ForeColor = System.Drawing.Color.Black;
            this.btnJuiceWater.Location = new System.Drawing.Point(376, 119);
            this.btnJuiceWater.Name = "btnJuiceWater";
            this.btnJuiceWater.Size = new System.Drawing.Size(299, 56);
            this.btnJuiceWater.TabIndex = 1;
            this.btnJuiceWater.Text = "JUICE && WATER FLOW";
            this.btnJuiceWater.UseVisualStyleBackColor = false;
            this.btnJuiceWater.Click += new System.EventHandler(this.btnJuiceWater_Click);
            // 
            // btnSugarBags
            // 
            this.btnSugarBags.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(203)))), ((int)(((byte)(222)))), ((int)(((byte)(233)))));
            this.btnSugarBags.FlatAppearance.BorderColor = System.Drawing.Color.DarkTurquoise;
            this.btnSugarBags.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.btnSugarBags.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.btnSugarBags.ForeColor = System.Drawing.Color.Black;
            this.btnSugarBags.Location = new System.Drawing.Point(48, 119);
            this.btnSugarBags.Name = "btnSugarBags";
            this.btnSugarBags.Size = new System.Drawing.Size(299, 56);
            this.btnSugarBags.TabIndex = 2;
            this.btnSugarBags.Text = "SUGAR BAGS";
            this.btnSugarBags.UseVisualStyleBackColor = false;
            this.btnSugarBags.Click += new System.EventHandler(this.btnSugarBags_Click);
            // 
            // btnJuice
            // 
            this.btnJuice.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(203)))), ((int)(((byte)(222)))), ((int)(((byte)(233)))));
            this.btnJuice.FlatAppearance.BorderColor = System.Drawing.Color.DarkTurquoise;
            this.btnJuice.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.btnJuice.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.btnJuice.ForeColor = System.Drawing.Color.Black;
            this.btnJuice.Location = new System.Drawing.Point(48, 218);
            this.btnJuice.Name = "btnJuice";
            this.btnJuice.Size = new System.Drawing.Size(299, 56);
            this.btnJuice.TabIndex = 3;
            this.btnJuice.Text = "JUICE ANALYSIS";
            this.btnJuice.UseVisualStyleBackColor = false;
            this.btnJuice.Click += new System.EventHandler(this.btnJuice_Click);
            // 
            // btnBagassePressCake
            // 
            this.btnBagassePressCake.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(203)))), ((int)(((byte)(222)))), ((int)(((byte)(233)))));
            this.btnBagassePressCake.Enabled = false;
            this.btnBagassePressCake.FlatAppearance.BorderColor = System.Drawing.Color.DarkTurquoise;
            this.btnBagassePressCake.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.btnBagassePressCake.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.btnBagassePressCake.ForeColor = System.Drawing.Color.Black;
            this.btnBagassePressCake.Location = new System.Drawing.Point(842, 609);
            this.btnBagassePressCake.Name = "btnBagassePressCake";
            this.btnBagassePressCake.Size = new System.Drawing.Size(299, 56);
            this.btnBagassePressCake.TabIndex = 4;
            this.btnBagassePressCake.Text = "BAGGASE && PRESS CAKE";
            this.btnBagassePressCake.UseVisualStyleBackColor = false;
            this.btnBagassePressCake.Visible = false;
            this.btnBagassePressCake.Click += new System.EventHandler(this.btnBagassePressCake_Click);
            // 
            // btnSyrupFinalMolasses
            // 
            this.btnSyrupFinalMolasses.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(203)))), ((int)(((byte)(222)))), ((int)(((byte)(233)))));
            this.btnSyrupFinalMolasses.FlatAppearance.BorderColor = System.Drawing.Color.DarkTurquoise;
            this.btnSyrupFinalMolasses.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.btnSyrupFinalMolasses.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.btnSyrupFinalMolasses.ForeColor = System.Drawing.Color.Black;
            this.btnSyrupFinalMolasses.Location = new System.Drawing.Point(690, 218);
            this.btnSyrupFinalMolasses.Name = "btnSyrupFinalMolasses";
            this.btnSyrupFinalMolasses.Size = new System.Drawing.Size(299, 56);
            this.btnSyrupFinalMolasses.TabIndex = 5;
            this.btnSyrupFinalMolasses.Text = "SYRUPS && FINAL MOLASSES";
            this.btnSyrupFinalMolasses.UseVisualStyleBackColor = false;
            this.btnSyrupFinalMolasses.Click += new System.EventHandler(this.btnSyrupFinalMolasses_Click);
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(203)))), ((int)(((byte)(222)))), ((int)(((byte)(233)))));
            this.button1.FlatAppearance.BorderColor = System.Drawing.Color.DarkTurquoise;
            this.button1.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.button1.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.button1.ForeColor = System.Drawing.Color.Black;
            this.button1.Location = new System.Drawing.Point(376, 218);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(299, 56);
            this.button1.TabIndex = 6;
            this.button1.Text = "BAGGASE && PRESS CAKE";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // report_panal
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1191, 721);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.btnSyrupFinalMolasses);
            this.Controls.Add(this.btnBagassePressCake);
            this.Controls.Add(this.btnJuice);
            this.Controls.Add(this.btnSugarBags);
            this.Controls.Add(this.btnJuiceWater);
            this.Controls.Add(this.groupBox1);
            this.Name = "report_panal";
            this.Text = "report_panal";
            this.Load += new System.EventHandler(this.report_panal_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label lblCropDayValue;
        private System.Windows.Forms.Label lblCropDayLabel;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.DateTimePicker dateTimePicker1;
        private System.Windows.Forms.Button btnJuiceWater;
        private System.Windows.Forms.Button btnSugarBags;
        private System.Windows.Forms.Button btnJuice;
        private System.Windows.Forms.Button btnBagassePressCake;
        private System.Windows.Forms.Button btnSyrupFinalMolasses;
        private System.Windows.Forms.Button button1;
    }
}