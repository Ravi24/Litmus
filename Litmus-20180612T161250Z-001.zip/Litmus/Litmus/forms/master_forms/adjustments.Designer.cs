﻿namespace Litmus.forms.master_forms
{
    partial class adjustments
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.txtEstimatedMolasses = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.txtEstimatedSugar = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label30 = new System.Windows.Forms.Label();
            this.txtStorePhosphoric = new System.Windows.Forms.TextBox();
            this.txTransDate = new System.Windows.Forms.DateTimePicker();
            this.label29 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.txtStoreViscocty = new System.Windows.Forms.TextBox();
            this.txtStoreBoilerChemical = new System.Windows.Forms.TextBox();
            this.txtStoreMegnafloe = new System.Windows.Forms.TextBox();
            this.txtStoreBioeide = new System.Windows.Forms.TextBox();
            this.label26 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.txtStoreColorReducer = new System.Windows.Forms.TextBox();
            this.txtStoreLubOil = new System.Windows.Forms.TextBox();
            this.label28 = new System.Windows.Forms.Label();
            this.txtStoreLime = new System.Windows.Forms.TextBox();
            this.label21 = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.txtStoreLubGreece = new System.Windows.Forms.TextBox();
            this.label27 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.txtStoreSulpher = new System.Windows.Forms.TextBox();
            this.btnSave = new System.Windows.Forms.Button();
            this.btnClear = new System.Windows.Forms.Button();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.txtEstimatedMolasses);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.txtEstimatedSugar);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.label30);
            this.groupBox1.Controls.Add(this.txtStorePhosphoric);
            this.groupBox1.Controls.Add(this.txTransDate);
            this.groupBox1.Controls.Add(this.label29);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.label24);
            this.groupBox1.Controls.Add(this.txtStoreViscocty);
            this.groupBox1.Controls.Add(this.txtStoreBoilerChemical);
            this.groupBox1.Controls.Add(this.txtStoreMegnafloe);
            this.groupBox1.Controls.Add(this.txtStoreBioeide);
            this.groupBox1.Controls.Add(this.label26);
            this.groupBox1.Controls.Add(this.label23);
            this.groupBox1.Controls.Add(this.txtStoreColorReducer);
            this.groupBox1.Controls.Add(this.txtStoreLubOil);
            this.groupBox1.Controls.Add(this.label28);
            this.groupBox1.Controls.Add(this.txtStoreLime);
            this.groupBox1.Controls.Add(this.label21);
            this.groupBox1.Controls.Add(this.label25);
            this.groupBox1.Controls.Add(this.txtStoreLubGreece);
            this.groupBox1.Controls.Add(this.label27);
            this.groupBox1.Controls.Add(this.label22);
            this.groupBox1.Controls.Add(this.txtStoreSulpher);
            this.groupBox1.Location = new System.Drawing.Point(9, 12);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(1270, 242);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            // 
            // txtEstimatedMolasses
            // 
            this.txtEstimatedMolasses.Location = new System.Drawing.Point(406, 178);
            this.txtEstimatedMolasses.Name = "txtEstimatedMolasses";
            this.txtEstimatedMolasses.Size = new System.Drawing.Size(100, 22);
            this.txtEstimatedMolasses.TabIndex = 13;
            this.txtEstimatedMolasses.Text = "0";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(283, 181);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(95, 17);
            this.label3.TabIndex = 33;
            this.label3.Text = "Est. Molasses";
            // 
            // txtEstimatedSugar
            // 
            this.txtEstimatedSugar.Location = new System.Drawing.Point(143, 178);
            this.txtEstimatedSugar.Name = "txtEstimatedSugar";
            this.txtEstimatedSugar.Size = new System.Drawing.Size(100, 22);
            this.txtEstimatedSugar.TabIndex = 12;
            this.txtEstimatedSugar.Text = "0";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(68, 178);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(74, 17);
            this.label2.TabIndex = 31;
            this.label2.Text = "Est. Sugar";
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Location = new System.Drawing.Point(534, 84);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(110, 17);
            this.label30.TabIndex = 20;
            this.label30.Text = "Phosphoric Acid";
            // 
            // txtStorePhosphoric
            // 
            this.txtStorePhosphoric.Location = new System.Drawing.Point(659, 81);
            this.txtStorePhosphoric.Name = "txtStorePhosphoric";
            this.txtStorePhosphoric.Size = new System.Drawing.Size(100, 22);
            this.txtStorePhosphoric.TabIndex = 4;
            this.txtStorePhosphoric.Text = "0";
            // 
            // txTransDate
            // 
            this.txTransDate.CustomFormat = "yyyy-MM-dd";
            this.txTransDate.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.txTransDate.Location = new System.Drawing.Point(143, 34);
            this.txTransDate.Name = "txTransDate";
            this.txTransDate.Size = new System.Drawing.Size(100, 22);
            this.txTransDate.TabIndex = 1;

            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Location = new System.Drawing.Point(1016, 130);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(105, 17);
            this.label29.TabIndex = 18;
            this.label29.Text = "Boiler Chemical";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(84, 34);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(38, 17);
            this.label1.TabIndex = 0;
            this.label1.Text = "Date";
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Location = new System.Drawing.Point(582, 130);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(54, 17);
            this.label24.TabIndex = 8;
            this.label24.Text = "Biocide";
            // 
            // txtStoreViscocty
            // 
            this.txtStoreViscocty.Location = new System.Drawing.Point(406, 130);
            this.txtStoreViscocty.Name = "txtStoreViscocty";
            this.txtStoreViscocty.Size = new System.Drawing.Size(100, 22);
            this.txtStoreViscocty.TabIndex = 8;
            this.txtStoreViscocty.Text = "0";
            // 
            // txtStoreBoilerChemical
            // 
            this.txtStoreBoilerChemical.Location = new System.Drawing.Point(1143, 127);
            this.txtStoreBoilerChemical.Name = "txtStoreBoilerChemical";
            this.txtStoreBoilerChemical.Size = new System.Drawing.Size(100, 22);
            this.txtStoreBoilerChemical.TabIndex = 11;
            this.txtStoreBoilerChemical.Text = "0";
            // 
            // txtStoreMegnafloe
            // 
            this.txtStoreMegnafloe.Location = new System.Drawing.Point(1143, 81);
            this.txtStoreMegnafloe.Name = "txtStoreMegnafloe";
            this.txtStoreMegnafloe.Size = new System.Drawing.Size(100, 22);
            this.txtStoreMegnafloe.TabIndex = 6;
            this.txtStoreMegnafloe.Text = "0";
            // 
            // txtStoreBioeide
            // 
            this.txtStoreBioeide.Location = new System.Drawing.Point(659, 127);
            this.txtStoreBioeide.Name = "txtStoreBioeide";
            this.txtStoreBioeide.Size = new System.Drawing.Size(100, 22);
            this.txtStoreBioeide.TabIndex = 9;
            this.txtStoreBioeide.Text = "0";
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Location = new System.Drawing.Point(1033, 82);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(74, 17);
            this.label26.TabIndex = 12;
            this.label26.Text = "Megnafloe";
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Location = new System.Drawing.Point(266, 130);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(121, 17);
            this.label23.TabIndex = 6;
            this.label23.Text = "Viscosity Reducer";
            // 
            // txtStoreColorReducer
            // 
            this.txtStoreColorReducer.Location = new System.Drawing.Point(890, 81);
            this.txtStoreColorReducer.Name = "txtStoreColorReducer";
            this.txtStoreColorReducer.Size = new System.Drawing.Size(100, 22);
            this.txtStoreColorReducer.TabIndex = 5;
            this.txtStoreColorReducer.Text = "0";
            // 
            // txtStoreLubOil
            // 
            this.txtStoreLubOil.Location = new System.Drawing.Point(143, 130);
            this.txtStoreLubOil.Name = "txtStoreLubOil";
            this.txtStoreLubOil.Size = new System.Drawing.Size(100, 22);
            this.txtStoreLubOil.TabIndex = 7;
            this.txtStoreLubOil.Text = "0";
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Location = new System.Drawing.Point(786, 130);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(83, 17);
            this.label28.TabIndex = 16;
            this.label28.Text = "Lub Greace";
            // 
            // txtStoreLime
            // 
            this.txtStoreLime.Location = new System.Drawing.Point(406, 81);
            this.txtStoreLime.Name = "txtStoreLime";
            this.txtStoreLime.Size = new System.Drawing.Size(100, 22);
            this.txtStoreLime.TabIndex = 3;
            this.txtStoreLime.Text = "0";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(349, 84);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(38, 17);
            this.label21.TabIndex = 4;
            this.label21.Text = "Lime";
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Location = new System.Drawing.Point(777, 81);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(107, 17);
            this.label25.TabIndex = 10;
            this.label25.Text = "Colour Reducer";
            // 
            // txtStoreLubGreece
            // 
            this.txtStoreLubGreece.Location = new System.Drawing.Point(890, 130);
            this.txtStoreLubGreece.Name = "txtStoreLubGreece";
            this.txtStoreLubGreece.Size = new System.Drawing.Size(100, 22);
            this.txtStoreLubGreece.TabIndex = 10;
            this.txtStoreLubGreece.Text = "0";
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Location = new System.Drawing.Point(72, 130);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(50, 17);
            this.label27.TabIndex = 14;
            this.label27.Text = "Lub oil";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Location = new System.Drawing.Point(65, 81);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(57, 17);
            this.label22.TabIndex = 3;
            this.label22.Text = "Sulpher";
            // 
            // txtStoreSulpher
            // 
            this.txtStoreSulpher.Location = new System.Drawing.Point(143, 81);
            this.txtStoreSulpher.Name = "txtStoreSulpher";
            this.txtStoreSulpher.Size = new System.Drawing.Size(100, 22);
            this.txtStoreSulpher.TabIndex = 2;
            this.txtStoreSulpher.Text = "0";
            // 
            // btnSave
            // 
            this.btnSave.Location = new System.Drawing.Point(1048, 260);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(104, 36);
            this.btnSave.TabIndex = 1;
            this.btnSave.Text = "Save";
            this.btnSave.UseVisualStyleBackColor = true;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // btnClear
            // 
            this.btnClear.Location = new System.Drawing.Point(1175, 260);
            this.btnClear.Name = "btnClear";
            this.btnClear.Size = new System.Drawing.Size(104, 36);
            this.btnClear.TabIndex = 2;
            this.btnClear.Text = "Clear";
            this.btnClear.UseVisualStyleBackColor = true;
            // 
            // adjustments
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.ClientSize = new System.Drawing.Size(1300, 307);
            this.Controls.Add(this.btnClear);
            this.Controls.Add(this.btnSave);
            this.Controls.Add(this.groupBox1);
            this.Name = "adjustments";
            this.Text = "To-Dates";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.DateTimePicker txTransDate;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtEstimatedMolasses;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtEstimatedSugar;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.TextBox txtStorePhosphoric;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.TextBox txtStoreViscocty;
        private System.Windows.Forms.TextBox txtStoreBoilerChemical;
        private System.Windows.Forms.TextBox txtStoreMegnafloe;
        private System.Windows.Forms.TextBox txtStoreBioeide;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.TextBox txtStoreColorReducer;
        private System.Windows.Forms.TextBox txtStoreLubOil;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.TextBox txtStoreLime;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.TextBox txtStoreLubGreece;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.TextBox txtStoreSulpher;
        private System.Windows.Forms.Button btnSave;
        private System.Windows.Forms.Button btnClear;
    }
}