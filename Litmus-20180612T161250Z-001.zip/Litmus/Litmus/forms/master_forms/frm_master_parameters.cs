﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Litmus.forms.master_forms
{
    public partial class frm_master_parameters : Form
    {
        Litmus.classes.DbHelper dbHelper = new classes.DbHelper();
        Litmus.classes.ExceptionHelper expHelper = new classes.ExceptionHelper();
        Litmus.classes.generalFunctions genFunc = new classes.generalFunctions();
        Litmus.classes.master_parameter_logic parameterLogic = new classes.master_parameter_logic();

        public frm_master_parameters()
        {
            InitializeComponent();
            lblUserName.Text = string.Empty;
            basicParameters();
        }

       
        #region user Rights Tab
        private void txtUsercodeLostFocus(object sender, EventArgs e)
        {
            lblUserName.Text = dbHelper.username(txtUserCode.Text);
            if (lblUserName.Text.Length > 0)
            {
                // bind Master menu list only when user name fetches in lblUserName i.e. user exists in database.

                bindMasterMenuListToDropDown();
                //ddlMasterMenuList.SelectedIndex = 1;
            }
            else
            {
                // clear Menu list drop down if user does not exists
                ddlMasterMenuList.DataSource = null;
            }
        }

        private void bindMasterMenuListToDropDown()
        {
            ddlMasterMenuList.DataSource = dbHelper.getActiveMasterMenuList();
            ddlMasterMenuList.ValueMember = "mm_code";
            ddlMasterMenuList.DisplayMember = "mm_name";
            this.ddlMasterMenuList.SelectedIndexChanged += new System.EventHandler(this.ddlMasterMenuList_SelectedIndexChanged);
        }

        private void ddlMasterMenuList_SelectedIndexChanged(object sender, EventArgs e)
        {
            DataSet ds = new DataSet();
            ds = dbHelper.getSubMenuList(Convert.ToInt16(ddlMasterMenuList.SelectedValue.ToString()), txtUserCode.Text.ToString());
            DataTable dt = ds.Tables[0];
            dataGridSubMenuRights.DataSource = dt;
            dataGridSubMenuRights.Columns[0].Name = "mr_sub_menu_name";
            dataGridSubMenuRights.Columns[0].HeaderText = "Menu Name";
            dataGridSubMenuRights.Columns[0].DataPropertyName = "mr_sub_menu_name";

            dataGridSubMenuRights.Columns[1].Name = "isActive";
            dataGridSubMenuRights.Columns[1].HeaderText = "Active/De-active";
            dataGridSubMenuRights.Columns[1].DataPropertyName = "isActive";

            dataGridSubMenuRights.Columns[2].Name = "Create";
            dataGridSubMenuRights.Columns[2].HeaderText = "Create";
            dataGridSubMenuRights.Columns[2].DataPropertyName = "create";

            dataGridSubMenuRights.Columns[3].Name = "Read";
            dataGridSubMenuRights.Columns[3].HeaderText = "Read";
            dataGridSubMenuRights.Columns[3].DataPropertyName = "read";

            dataGridSubMenuRights.Columns[4].Name = "Update";
            dataGridSubMenuRights.Columns[4].HeaderText = "Update";
            dataGridSubMenuRights.Columns[4].DataPropertyName = "update";

            dataGridSubMenuRights.Columns[5].Name = "Delete";
            dataGridSubMenuRights.Columns[5].HeaderText = "Delete";
            dataGridSubMenuRights.Columns[5].DataPropertyName = "delete";
        }
        #endregion

        #region Basic Parameter Tab
        public void basicParameters()
        {
            parameterLogic.setParameters();
            txtCompanyName.Text = parameterLogic.unitName;
            txtReportTime.Text = parameterLogic.reportStartTime;
            dateTimeCrushingStartDate.Text = parameterLogic.crushingStartDate;
            dateTimeCrushingEndDate.Text = parameterLogic.crushingEndDate;
            txtDayHours.Text = parameterLogic.dayHours.ToString();
            dateTimeEntryDate.Text = parameterLogic.entryDate;
            dateTimeProcessDate.Text = parameterLogic.processDate;
            txtNewMillCapacity.Text = parameterLogic.newMillCapacity.ToString();
            txtOldMillCapacity.Text = parameterLogic.oldMillCapacity.ToString();
            txtDesignition1.Text = parameterLogic.designation1;
            txtDesignition2.Text = parameterLogic.designation2;
            txtDesignition3.Text = parameterLogic.designation3;
            txtDesignition4.Text = parameterLogic.designation4;
            txtDesignition5.Text = parameterLogic.designation5;

            txtSignName1.Text = parameterLogic.name1;
            txtSignName2.Text = parameterLogic.name2;
            txtSignName3.Text = parameterLogic.name3;
            txtSignName4.Text = parameterLogic.name4;
            txtSignName5.Text = parameterLogic.name5;
        }
        public void updateBasicParameter()
        {
            
        }
        #endregion

        private void btnApply_Click(object sender, EventArgs e)
        {
            if (tabControl1.SelectedTab == tabControl1.TabPages[1])
            {
                foreach (DataGridViewRow row in dataGridSubMenuRights.Rows) // User codes
                {
                    int isActive = Convert.ToInt16(row.Cells["isActive"].Value);
                    int create = Convert.ToInt16(row.Cells["create"].Value);
                    int read = Convert.ToInt16(row.Cells["read"].Value);
                    int update = Convert.ToInt16(row.Cells["update"].Value);
                    int delete = Convert.ToInt16(row.Cells["delete"].Value);
                    
                    dbHelper.updateMenuRights(row.Cells["mr_unique_menu"].Value.ToString(),isActive, create,read,update,delete);
                }
                MessageBox.Show("User rights updated", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else if (tabControl1.SelectedTab == tabControl1.TabPages[0]) // Litmus parameter tabs
            {
                try
                {
                    DataSet ds = parameterLogic.setParameters();
                    if (ds.Tables[0].Rows.Count > 0)
                    {
                        ds.Tables[0].Rows[0][2] = txtCompanyName.Text;
                        ds.Tables[0].Rows[1][2] = txtReportTime.Text;
                        ds.Tables[0].Rows[2][2] = dateTimeCrushingStartDate.Text;
                        ds.Tables[0].Rows[3][2] = dateTimeCrushingEndDate.Text;
                        ds.Tables[0].Rows[4][2] = txtDayHours.Text;
                        ds.Tables[0].Rows[5][2] = dateTimeEntryDate.Text;
                        ds.Tables[0].Rows[6][2] = dateTimeProcessDate.Text;
                        ds.Tables[0].Rows[7][2] = txtNewMillCapacity.Text;
                        ds.Tables[0].Rows[8][2] = txtOldMillCapacity.Text;
                        ds.Tables[0].Rows[9][2] = txtSignName1.Text;
                        ds.Tables[0].Rows[10][2] = txtSignName2.Text;
                        ds.Tables[0].Rows[11][2] = txtSignName3.Text;
                        ds.Tables[0].Rows[12][2] = txtSignName4.Text;

                        ds.Tables[0].Rows[13][2] = txtDesignition1.Text;
                        ds.Tables[0].Rows[14][2] = txtDesignition2.Text;
                        ds.Tables[0].Rows[15][2] = txtDesignition3.Text;
                        ds.Tables[0].Rows[16][2] = txtDesignition4.Text;

                        parameterLogic.updateDataset(ds);
                    }
                    else
                    {
                        parameterLogic.insertFormData(txtCompanyName.Text, txtReportTime.Text, dateTimeCrushingStartDate.Text, dateTimeCrushingEndDate.Text,
                            txtDayHours.Text, dateTimeEntryDate.Text, dateTimeProcessDate.Text, txtNewMillCapacity.Text, txtOldMillCapacity.Text, txtDesignition1.Text,
                            txtDesignition2.Text, txtDesignition3.Text, txtDesignition4.Text, txtDesignition5.Text, txtSignName1.Text, txtSignName2.Text,
                            txtSignName3.Text, txtSignName4.Text, txtSignName5.Text);
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error while updaing master parameters.\nError Message"+ex.Message, "Error!", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    expHelper.statusMsg = "Error while updaing master parameters.\nError Message" + ex.Message + "\nStack Trace -" + ex.StackTrace;
                }

            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }

       

    }
}
