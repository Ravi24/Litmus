﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Collections;
using Litmus;
namespace Litmus.forms.master_forms
{
    public partial class frm_master_menu : Form
    {
        Litmus.classes.DbHelper dbHelper = new classes.DbHelper();
        Litmus.classes.generalFunctions genFunc = new classes.generalFunctions();
        Litmus.classes.ExceptionHelper expHelper = new classes.ExceptionHelper();

        ListBox listBox;
        /* mode could be insert or update. if mode is insert 'submit' button will act for insert record, 
         * if it is 'update' then 'Submit' button wil act for update records
         */ 
        string formMode = "insert";
        Form helpForm;
        public frm_master_menu()
        {
            InitializeComponent();
            btnSubmit.Enabled = false;
           
        }
        private void formClosingEvent(object sender, FormClosingEventArgs e)
        {
            this.Close();
            this.Dispose();
        }
        private void keypressed(Object o, KeyEventArgs e)
        {
            if (txtMenuname.Focused == true &&  e.KeyData == Keys.F9)
            {
                masterMenuHelp();
            }
        }
        public void masterMenuHelp()
        {
            listBox = new ListBox();
            listBox.DataSource = dbHelper.getAllMasterMenuList();
            listBox.DisplayMember = "mm_name";
            listBox.ValueMember = "mm_code";
            listBox.HorizontalScrollbar = true;
            listBox.ScrollAlwaysVisible = true;
            
            helpForm = new Form();
            helpForm.Text = "Availale Options";
            helpForm.Controls.Add(listBox);
            helpForm.Height = listBox.Height+100;
            helpForm.AutoScroll = true;
            helpForm.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            helpForm.MinimizeBox = false;
            helpForm.MaximizeBox = false;
            listBox.Width = helpForm.Width;
            listBox.DoubleClick += new EventHandler(helperMenuClicked);
            helpForm.ShowDialog();
            
        }
        private void helperMenuClicked(object o, EventArgs e)
        {
            txtMenuname.Text = listBox.GetItemText(listBox.SelectedItem);
            txtMenuCode.Text = listBox.SelectedValue.ToString();
            listBox.Dispose();  
            helpForm.Close();
        }

        private void toolStripAddRecord_Click(object sender, EventArgs e)
        {
            formMode = "insert";
            btnSubmit.Text = "&Submit";
            btnSubmit.Enabled = true;
            txtMenuname.Text = string.Empty;
            txtMenuCode.Text = dbHelper.getMaxMasterMenuId().ToString();
        }
        #region Update Existing Record
        private void toolEditRecord_Click(object sender, EventArgs e)
        {
            btnSubmit.Text = "Update";
            btnSubmit.Enabled = true;
            formMode = "update";
            txtMenuCode.Text = string.Empty;
            txtMenuname.Text = string.Empty;
        }
        #endregion

        private void btnSubmit_Click(object sender, EventArgs e)
        {
                string menuCode = txtMenuCode.Text.Trim();
                string menuname = txtMenuname.Text.Trim();
                int isActive;
                if (radioActive.Checked == true)
                {
                    isActive = 1;
                }
                else
                {
                    isActive = 0;
                }
                try
                {
                    switch (formMode)
                    {
                        case "insert":
                                    dbHelper.insertNewMasterMenu(menuCode, menuname, isActive, genFunc.userCode);
                                    txtMenuCode.Text = dbHelper.getMaxMasterMenuId().ToString();
                        break;
                        case "update":
                                    dbHelper.updateNewMasterMenu(menuCode, menuname, isActive);
                        break;
                        default:
                        MessageBox.Show("Invalid form mode, form mode could be 'insert' or 'update' only", "Error- Form Mode!!", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                        break;
                    }
                    
                }
                catch (Exception ex)
                {
                    expHelper.statusMsg = "ERR: " + ex.Message + " " + ex.HelpLink;
                }
            }
           
        
    }
}
