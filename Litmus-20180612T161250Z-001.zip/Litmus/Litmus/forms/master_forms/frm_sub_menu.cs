﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Litmus.forms.master_forms
{
    public partial class frm_sub_menu : Form
    {
        Litmus.classes.DbHelper dbHelper = new classes.DbHelper();
        Litmus.classes.generalFunctions genFunc = new classes.generalFunctions();
        public frm_sub_menu()
        {
            InitializeComponent();
            bindMasterMenuList();
        }
        private void formClosingEvent(object sender, FormClosingEventArgs e)
        {
            
            this.Dispose();
        }
        private void createNewSubMenu(int msterMenuCode, int subMenuCode, string subMenuname, int isActive)
        {
        }
        private void bindMasterMenuList()
        {
            txtSubMenuCode.Text = dbHelper.getMaxSubMenuCode().ToString();
            try
            {
                ddlMasterMenuList.DataSource = dbHelper.getActiveMasterMenuList();
                ddlMasterMenuList.DisplayMember = "mm_name";
                ddlMasterMenuList.ValueMember = "mm_code";
            }
            catch (Exception ex)
            {
                MessageBox.Show("Unable to load 'Master Menu List. \nException Details: " + ex.Message, "Error!", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            Boolean formValidated = false;
            int isActive = 0;
            int masterMenuCode = Convert.ToInt16(ddlMasterMenuList.SelectedValue);

            
            if (radioIsActiveTrue.Checked == true)
            {
                isActive = 1;
            }
            else
            {
                isActive = 0;
            }

            foreach(Control ctrl in groupSubMenu.Controls)
            {
                if (ctrl.GetType() == typeof(TextBox))
                {
                    if (ctrl.Text.Length == 0)
                    {
                        formValidated = false;
                    }
                    else
                    {
                        formValidated = true;
                    }
                }
            }
            switch(formValidated)
            {
                case true:
                    dbHelper.insertNewSubMenu(masterMenuCode, txtSubMenuCode.Text, txtSubMenuname.Text, isActive, genFunc.userCode, txtFormname.Text);
                        break;
                case false :
                        MessageBox.Show("Sub menu form validation failed, please check all input data", "Form Validation faild", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                        break;
                default:
                        MessageBox.Show("Can't submit data, form is in default state", "Form Validation faild", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                        break;
            }
        }
    }
}
