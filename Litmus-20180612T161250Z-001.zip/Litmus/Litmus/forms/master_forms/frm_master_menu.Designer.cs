﻿namespace Litmus.forms.master_forms
{
    partial class frm_master_menu
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.radioInActive = new System.Windows.Forms.RadioButton();
            this.radioActive = new System.Windows.Forms.RadioButton();
            this.label3 = new System.Windows.Forms.Label();
            this.btnClear = new System.Windows.Forms.Button();
            this.btnSubmit = new System.Windows.Forms.Button();
            this.txtMenuname = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.txtMenuCode = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.toolStrip1 = new System.Windows.Forms.ToolStrip();
            this.toolStripAddRecord = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripEditRecord = new System.Windows.Forms.ToolStripButton();
            this.groupBox1.SuspendLayout();
            this.panel1.SuspendLayout();
            this.toolStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.panel1);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.btnClear);
            this.groupBox1.Controls.Add(this.btnSubmit);
            this.groupBox1.Controls.Add(this.txtMenuname);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.txtMenuCode);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Location = new System.Drawing.Point(11, 44);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(396, 195);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Master Menu Control";
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.radioInActive);
            this.panel1.Controls.Add(this.radioActive);
            this.panel1.Location = new System.Drawing.Point(124, 106);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(205, 30);
            this.panel1.TabIndex = 8;
            // 
            // radioInActive
            // 
            this.radioInActive.AutoSize = true;
            this.radioInActive.Location = new System.Drawing.Point(91, 6);
            this.radioInActive.Name = "radioInActive";
            this.radioInActive.Size = new System.Drawing.Size(82, 21);
            this.radioInActive.TabIndex = 1;
            this.radioInActive.TabStop = true;
            this.radioInActive.Text = "In-active";
            this.radioInActive.UseVisualStyleBackColor = true;
            // 
            // radioActive
            // 
            this.radioActive.AutoSize = true;
            this.radioActive.Checked = true;
            this.radioActive.Location = new System.Drawing.Point(4, 6);
            this.radioActive.Name = "radioActive";
            this.radioActive.Size = new System.Drawing.Size(67, 21);
            this.radioActive.TabIndex = 0;
            this.radioActive.TabStop = true;
            this.radioActive.Text = "Active";
            this.radioActive.UseVisualStyleBackColor = true;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(7, 114);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(111, 17);
            this.label3.TabIndex = 7;
            this.label3.Text = "Active / In-active";
            // 
            // btnClear
            // 
            this.btnClear.Location = new System.Drawing.Point(234, 142);
            this.btnClear.Name = "btnClear";
            this.btnClear.Size = new System.Drawing.Size(75, 38);
            this.btnClear.TabIndex = 6;
            this.btnClear.Text = "&Clear";
            this.btnClear.UseVisualStyleBackColor = true;
            // 
            // btnSubmit
            // 
            this.btnSubmit.Location = new System.Drawing.Point(138, 142);
            this.btnSubmit.Name = "btnSubmit";
            this.btnSubmit.Size = new System.Drawing.Size(75, 38);
            this.btnSubmit.TabIndex = 5;
            this.btnSubmit.Text = "Submit";
            this.btnSubmit.UseVisualStyleBackColor = true;
            this.btnSubmit.Click += new System.EventHandler(this.btnSubmit_Click);
            // 
            // txtMenu.Name
            // 
            this.txtMenuname.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.txtMenuname.Location = new System.Drawing.Point(122, 72);
            this.txtMenuname.Name = "txtMenuname";
            this.txtMenuname.Size = new System.Drawing.Size(205, 22);
            this.txtMenuname.TabIndex = 3;
            this.txtMenuname.KeyDown += new System.Windows.Forms.KeyEventHandler(this.keypressed);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(34, 75);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(84, 17);
            this.label2.TabIndex = 2;
            this.label2.Text = "Menu name";
            // 
            // txtMenuCode
            // 
            this.txtMenuCode.Enabled = false;
            this.txtMenuCode.Location = new System.Drawing.Point(124, 32);
            this.txtMenuCode.Name = "txtMenuCode";
            this.txtMenuCode.Size = new System.Drawing.Size(96, 22);
            this.txtMenuCode.TabIndex = 1;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(38, 35);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(80, 17);
            this.label1.TabIndex = 0;
            this.label1.Text = "Menu Code";
            // 
            // toolStrip1
            // 
            this.toolStrip1.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.toolStrip1.GripStyle = System.Windows.Forms.ToolStripGripStyle.Hidden;
            this.toolStrip1.ImageScalingSize = new System.Drawing.Size(21, 20);
            this.toolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripAddRecord,
            this.toolStripSeparator1,
            this.toolStripEditRecord});
            this.toolStrip1.Location = new System.Drawing.Point(0, 0);
            this.toolStrip1.Name = "toolStrip1";
            this.toolStrip1.RenderMode = System.Windows.Forms.ToolStripRenderMode.Professional;
            this.toolStrip1.Size = new System.Drawing.Size(419, 27);
            this.toolStrip1.TabIndex = 1;
            this.toolStrip1.Text = "toolStrip1";
            // 
            // toolStripAddRecord
            // 
            this.toolStripAddRecord.Image = global::Litmus.Properties.Resources.add_record_black;
            this.toolStripAddRecord.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripAddRecord.Name = "toolStripAddRecord";
            this.toolStripAddRecord.Size = new System.Drawing.Size(119, 29);
            this.toolStripAddRecord.Text = "New Record";
            this.toolStripAddRecord.Click += new System.EventHandler(this.toolStripAddRecord_Click);
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(6, 32);
            // 
            // toolStripEditRecord
            // 
            this.toolStripEditRecord.Image = global::Litmus.Properties.Resources.edit_record;
            this.toolStripEditRecord.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripEditRecord.Name = "toolStripEditRecord";
            this.toolStripEditRecord.Size = new System.Drawing.Size(115, 29);
            this.toolStripEditRecord.Text = "Edit Record";
            this.toolStripEditRecord.Click += new System.EventHandler(this.toolEditRecord_Click);
            // 
            // frm_master_menu_creation
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(419, 245);
            this.Controls.Add(this.toolStrip1);
            this.Controls.Add(this.groupBox1);
            this.Name = "frm_master_menu_creation";
            this.Text = "Master Menu ";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.toolStrip1.ResumeLayout(false);
            this.toolStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TextBox txtMenuname;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtMenuCode;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ToolStrip toolStrip1;
        private System.Windows.Forms.ToolStripButton toolStripAddRecord;
        private System.Windows.Forms.Button btnClear;
        private System.Windows.Forms.Button btnSubmit;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.RadioButton radioInActive;
        private System.Windows.Forms.RadioButton radioActive;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.ToolStripButton toolStripEditRecord;
    }
}