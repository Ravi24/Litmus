﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using Litmus.classes;

namespace Litmus.forms.master_forms
{
    public partial class frm_stoppage_master : Form
    {
        generalFunctions genFunc = new generalFunctions();
        ExceptionHelper expHelper = new ExceptionHelper();
        stoppage_master_logic stoppageMasterLogic = new stoppage_master_logic();
        DbHelper dbHelper = new DbHelper();
        string sessionFormCode;
        IDictionary<int, string> formModeDict = new Dictionary<int, string>();
        int recordCounts = 0;
        int currentRecordNumber = 0;
        int stoppage_code;
        int stoppage_sub_head_code;
        string formMode;

        DataTable stoppage_sub_head_datatable = null;

        public frm_stoppage_master()
        {
            InitializeComponent();
            formModeDict.Add(1, "create");
            formModeDict.Add(2, "read");
            formModeDict.Add(3, "update");
            formModeDict.Add(4, "delete");

            formMode = "create";
            sessionFormCode = genFunc.uniqueFormCode;

            if (genFunc.userRights.Contains('U'))
            {
                panelStoppageHeadAdmin.Enabled = true;
                panelStoppageSubHeadAdmin.Enabled = true;
                btnSave.Enabled = true;
            }
            else
            {
                panelStoppageHeadAdmin.Enabled = false;
                panelStoppageSubHeadAdmin.Enabled = false;
                btnSave.Enabled = false;
            }
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            switch (tabStoppages.SelectedIndex)
            {
                case 0:
                    stoppageHeadOperations();
                    break;
                case 1:
                    stoppageSubHeadOperations();
                    break;
                default:
                    MessageBox.Show("Invalid stoppage head selection", "Stoppage Heads", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                    break;

            }
        }

        #region Stoppage sub head 
        private void ddlStoppageHead_clicked(object sender, EventArgs e)
        {
           
                DataTable ddlTable = stoppageMasterLogic.get_stoppage_head_list();
                ddlStoppageHead.DataSource = ddlTable;
                ddlStoppageHead.ValueMember = "sh_code"; 
                ddlStoppageHead.DisplayMember = "sh_name";
        }
        #endregion

        #region Stoppage head scrolling code
        private void btnQuery_Click(object sender, EventArgs e)
        {
            formMode = formModeDict[3];
            btnSave.Text = "&Update";
            btnQuery.Enabled = false;
            btnExecute.Enabled = true;
        }

        private void btnReset_Click(object sender, EventArgs e)
        {
            formMode = formModeDict[1];
            btnSave.Text = "&Save";
            btnExecute.Enabled = false;
            btnQuery.Enabled = true;
            txtStoppageHead.Text = string.Empty;
            txtStoppageHeadDesc.Text = string.Empty;
            txtStoppageSubHead.Text = string.Empty;
            txtStoppageSubHeadDesc.Text = string.Empty;

        }

        private void btnExecute_Click(object sender, EventArgs e)
        {
            DataTable dt = stoppageMasterLogic.stoppage_head_details_all();
            recordCounts = dt.Rows.Count;
            if (dt.Rows.Count > 0)
            {
                stoppage_code = Convert.ToInt16(dt.Rows[currentRecordNumber]["sh_code"]);
                txtStoppageHead.Text = dt.Rows[currentRecordNumber]["sh_name"].ToString();
                txtStoppageHeadDesc.Text = dt.Rows[currentRecordNumber]["sh_description"].ToString();
                if (dt.Rows[currentRecordNumber]["sh_is_active"].ToString() == "True")
                {
                    radioYes.Checked = true;
                }
                else
                {
                    radioNo.Checked = true;
                }
                lblRecordCounter.Text = currentRecordNumber + 1 + " of " + recordCounts;
                btnExecute.Enabled = false;
            }
            else
            {
                MessageBox.Show("No record exist for Stoppage head", "No Records", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }
        }

        private void btnFirstRecord_Click(object sender, EventArgs e)
        {
            DataTable dt = stoppageMasterLogic.stoppage_head_details_all();
            

            if (currentRecordNumber != 0)
            {
                currentRecordNumber = 0;
                txtStoppageHead.Text = dt.Rows[currentRecordNumber]["sh_name"].ToString();
                txtStoppageHeadDesc.Text = dt.Rows[currentRecordNumber]["sh_description"].ToString();
                if (dt.Rows[currentRecordNumber]["sh_is_active"].ToString() == "True")
                {
                    radioYes.Checked = true;
                }
                else
                {
                    radioNo.Checked = true;
                }

                lblRecordCounter.Text = currentRecordNumber + 1 + " of " + recordCounts;
            }
            else
            {
                MessageBox.Show("This is first record", "First Record", MessageBoxButtons.OK, MessageBoxIcon.Stop);
            }
        }

        private void btnPreviousRecord_Click(object sender, EventArgs e)
        {
            DataTable dt = stoppageMasterLogic.stoppage_head_details_all();

            if (currentRecordNumber != 0)
            {
                txtStoppageHead.Text = dt.Rows[currentRecordNumber - 1]["sh_name"].ToString();
                txtStoppageHeadDesc.Text = dt.Rows[currentRecordNumber - 1]["sh_description"].ToString();
                if (dt.Rows[currentRecordNumber - 1]["sh_is_active"].ToString() == "True")
                {
                    radioYes.Checked = true;
                }
                else
                {
                    radioNo.Checked = true;
                }
                currentRecordNumber = currentRecordNumber - 1;
                lblRecordCounter.Text = currentRecordNumber + 1 + " of " + recordCounts;
            }
            else
            {
                MessageBox.Show("This is first record", "First Record", MessageBoxButtons.OK, MessageBoxIcon.Hand);

            }
        }

        private void btnNextRecord_Click(object sender, EventArgs e)
        {
            DataTable dt = stoppageMasterLogic.stoppage_head_details_all();
            if (currentRecordNumber != recordCounts-1)
            {
                txtStoppageHead.Text = dt.Rows[currentRecordNumber + 1]["sh_name"].ToString();
                txtStoppageHeadDesc.Text = dt.Rows[currentRecordNumber + 1]["sh_description"].ToString();

                if (dt.Rows[currentRecordNumber + 1]["sh_is_active"].ToString() == "True")
                {
                    radioYes.Checked = true;
                }
                else
                {
                    radioNo.Checked = true;
                }
                currentRecordNumber = currentRecordNumber + 1;
                lblRecordCounter.Text = currentRecordNumber + 1 + " of " + recordCounts;
            }
            else
            {
                MessageBox.Show("This is last record", "Last Record!!", MessageBoxButtons.OK, MessageBoxIcon.Stop);
            }
        }

        private void btnLastRecord_Click(object sender, EventArgs e)
        {
            DataTable dt = stoppageMasterLogic.stoppage_head_details_all();
            if (currentRecordNumber != recordCounts-1)
            {
                txtStoppageHead.Text = dt.Rows[recordCounts - 1]["sh_name"].ToString();
                txtStoppageHeadDesc.Text = dt.Rows[recordCounts - 1]["sh_description"].ToString();

                if (dt.Rows[recordCounts - 1]["sh_is_active"].ToString() == "True")
                {
                    radioYes.Checked = true;
                }
                else
                {
                    radioNo.Checked = true;
                }
                currentRecordNumber = recordCounts - 1;
                lblRecordCounter.Text = currentRecordNumber + 1 + " of " + recordCounts;
            }
            else
            {
                MessageBox.Show("This is last record", "Last Record!!", MessageBoxButtons.OK, MessageBoxIcon.Stop);
            }
        }
        #endregion

        #region Stoppage sub head itteration
        private void btnSubHeadQuery_Click(object sender, EventArgs e)
        {
            formMode = "update";
            btnSave.Text = "&Update";
            btnSubHeadExecute.Enabled = true;

        }
        private void btnSubHeadExecute_Click(object sender, EventArgs e)
        {
            int selectedHead = Convert.ToInt16(ddlStoppageHead.SelectedValue);
            stoppage_sub_head_datatable = stoppageMasterLogic.stoppage_sub_head_details_all(selectedHead);
            if (stoppage_sub_head_datatable.Rows.Count <= 0)
            {
                MessageBox.Show("No record exists,\nmake sure you have selected Stoppage Head", "No record", MessageBoxButtons.OK, MessageBoxIcon.Stop);
            }
            else
            {
                recordCounts = stoppage_sub_head_datatable.Rows.Count;
                currentRecordNumber = 0;

                stoppage_sub_head_code = Convert.ToInt16(stoppage_sub_head_datatable.Rows[currentRecordNumber]["ss_code"]);
                txtStoppageSubHead.Text = stoppage_sub_head_datatable.Rows[currentRecordNumber]["ss_name"].ToString();
                txtStoppageSubHeadDesc.Text = stoppage_sub_head_datatable.Rows[currentRecordNumber]["ss_description"].ToString();

                if (stoppage_sub_head_datatable.Rows[currentRecordNumber]["ss_is_active"].ToString() == "True")
                {
                    RadioStoppageSubYes.Checked = true;
                }
                else
                {
                    radioStoppageSubNo.Checked = true;
                }
            }
        }
        #endregion

        private void btnSubHeadReset_Click(object sender, EventArgs e)
        {
            formMode = "create";
            btnSubHeadExecute.Enabled = false;
            btnSave.Text = "&Save";
            if (stoppage_sub_head_datatable != null && stoppage_sub_head_datatable.Rows.Count > 0)
            {
                stoppage_sub_head_datatable.Clear();
            }
        }

        private void btnSubHeadFirstRecord_Click(object sender, EventArgs e)
        {
            if (currentRecordNumber != 0)
            {
                currentRecordNumber = 0;
                txtStoppageSubHead.Text = stoppage_sub_head_datatable.Rows[currentRecordNumber]["ss_name"].ToString();
                txtStoppageSubHeadDesc.Text = stoppage_sub_head_datatable.Rows[currentRecordNumber]["ss_description"].ToString();

                if (stoppage_sub_head_datatable.Rows[currentRecordNumber]["ss_is_active"].ToString() == "True")
                {
                    RadioStoppageSubYes.Checked = true;
                }
                else
                {
                    radioStoppageSubNo.Checked = true;
                }
            }
            else
            {
                MessageBox.Show("This is first record", "First Record", MessageBoxButtons.OK, MessageBoxIcon.Hand);
            }
        }

        private void btnSubHeadPreviousRecord_Click(object sender, EventArgs e)
        {
            if (currentRecordNumber != 0)
            {
                currentRecordNumber = currentRecordNumber - 1;
                txtStoppageSubHead.Text = stoppage_sub_head_datatable.Rows[currentRecordNumber]["ss_name"].ToString();
                txtStoppageSubHeadDesc.Text = stoppage_sub_head_datatable.Rows[currentRecordNumber]["ss_description"].ToString();

                if (stoppage_sub_head_datatable.Rows[currentRecordNumber]["ss_is_active"].ToString() == "True")
                {
                    RadioStoppageSubYes.Checked = true;
                }
                else
                {
                    radioStoppageSubNo.Checked = true;
                }
            }
            else
            {
                MessageBox.Show("This is first record", "First Record", MessageBoxButtons.OK, MessageBoxIcon.Hand);
            }
            
        }

        private void btnSubHeadNextRecord_Click(object sender, EventArgs e)
        {
            if (currentRecordNumber != recordCounts -1)
            {
                currentRecordNumber = currentRecordNumber + 1;
                txtStoppageSubHead.Text = stoppage_sub_head_datatable.Rows[currentRecordNumber]["ss_name"].ToString();
                txtStoppageSubHeadDesc.Text = stoppage_sub_head_datatable.Rows[currentRecordNumber]["ss_description"].ToString();

                if (stoppage_sub_head_datatable.Rows[currentRecordNumber]["ss_is_active"].ToString() == "True")
                {
                    RadioStoppageSubYes.Checked = true;
                }
                else
                {
                    radioStoppageSubNo.Checked = true;
                }
            }
            else
            {
                MessageBox.Show("This is Last record", "First Record", MessageBoxButtons.OK, MessageBoxIcon.Hand);
            }
        }

        private void btnSubHeadLastRecord_Click(object sender, EventArgs e)
        {
            if (currentRecordNumber !=  recordCounts-1)
            {
                currentRecordNumber = recordCounts;
                txtStoppageSubHead.Text = stoppage_sub_head_datatable.Rows[currentRecordNumber]["ss_name"].ToString();
                txtStoppageSubHeadDesc.Text = stoppage_sub_head_datatable.Rows[currentRecordNumber]["ss_description"].ToString();

                if (stoppage_sub_head_datatable.Rows[currentRecordNumber]["ss_is_active"].ToString() == "True")
                {
                    RadioStoppageSubYes.Checked = true;
                }
                else
                {
                    radioStoppageSubNo.Checked = true;
                }
            }
            else
            {
                MessageBox.Show("This is Last record", "First Record", MessageBoxButtons.OK, MessageBoxIcon.Hand);
            }
        }

        private void ddlStoppageHead_SelectedIndexChanged(object sender, EventArgs e)
        {
            txtStoppageSubHead.Text = string.Empty;
            txtStoppageSubHeadDesc.Text = string.Empty;
        }
        #region Stoppage Head Tab
        private void stoppageHeadOperations()
        {
            
                string stoppage_head = txtStoppageHead.Text.Trim();
                string stoppage_head_desc = txtStoppageHeadDesc.Text.Trim();
                int isActive = 0;
                if (radioYes.Checked == true)
                {
                    isActive = 1;
                }
                switch (formMode)
                {
                    case "create":
                        if (stoppageMasterLogic.insert_stoppage_head(stoppage_head, isActive, stoppage_head_desc) == true)
                        {
                            MessageBox.Show("Stoppage Head created", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);

                            txtStoppageHead.Text = string.Empty;
                            txtStoppageHeadDesc.Text = string.Empty;

                        }
                        else
                        {
                            MessageBox.Show("Stoppage Head 'Not' created", "Failed!!", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                        }
                        break;
                    case "update":
                        if (stoppageMasterLogic.update_stoppage_head(stoppage_code, stoppage_head, isActive, stoppage_head_desc) == true)
                        {
                            MessageBox.Show("Stoppage Head updated", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        }
                        break;
                }
        }
        #endregion

        #region stoppage sub head operations
        private void stoppageSubHeadOperations()
        {
                int stoppage_head = Convert.ToInt16(ddlStoppageHead.SelectedValue);
                string stoppage_sub_head = txtStoppageSubHead.Text.Trim();
                int sub_head_isActive = 0;
                string sub_head_description = txtStoppageSubHeadDesc.Text.Trim();
                if (RadioStoppageSubYes.Checked == true)
                {
                    sub_head_isActive = 1;
                }
                switch (formMode)
                {
                    case "create":
                        if (stoppageMasterLogic.insert_stoppage_Sub_head(stoppage_head, stoppage_sub_head, sub_head_isActive, sub_head_description) == true)
                        {
                            MessageBox.Show("Stoppage Sub Sub Head created", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            txtStoppageSubHead.Text = string.Empty;
                            txtStoppageSubHeadDesc.Text = string.Empty;
                        }
                        else
                        {
                            MessageBox.Show("Stoppage Sub Sub Head 'Not' created", "Failed!!", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                        }
                        break;
                        
                    case "update":
                        if (stoppageMasterLogic.update_stoppage_Sub_head(stoppage_head, stoppage_sub_head_code, stoppage_sub_head, sub_head_isActive, sub_head_description) == true)
                        {
                            MessageBox.Show("Stoppage Sub Head updated", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            txtStoppageSubHead.Text = string.Empty;
                            txtStoppageSubHeadDesc.Text = string.Empty;

                        }
                        else
                        {
                            MessageBox.Show("Stoppage Sub Head 'Not' updated", "Failed!!", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                        }
                        break;
                    default:
                        MessageBox.Show("Invalid form mode", "Error", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                        break;
                }
        }
        #endregion
    }
}
