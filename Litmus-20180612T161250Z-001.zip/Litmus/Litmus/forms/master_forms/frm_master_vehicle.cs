﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Litmus.forms.master_forms
{
    public partial class frm_master_vehicle : Form
    {
        classes.vehicle_master_logic vehicleMasterLogic = new classes.vehicle_master_logic();
        classes.generalFunctions genFunc = new classes.generalFunctions();
        IDictionary<int, string> formModeDict = new Dictionary<int, string>();
        DataTable queryDataTable = null;
        int rowindex = 0;
        int record_count_in_table = 0;
        string formMode;
        int vehicleCode = 0;
        string vehicleName = string.Empty;
        float averageWeight = 0;
        //bool isActive = true;

        public frm_master_vehicle()
        {
            InitializeComponent();
            formModeDict.Add(1, "create");
            formModeDict.Add(2, "read");
            formModeDict.Add(3, "update");
        }
        private void enableFields()
        {
            txtVehicleCode.Enabled = true;
            txtVehicleName.Enabled = true;
            txtAverageWeght.Enabled = true;
            btnSave.Enabled = true;
            btnQuery.Enabled = true;

        }
        private void disableFields()
        {
            txtVehicleCode.Enabled = false;
            txtVehicleName.Enabled = false;
            txtAverageWeght.Enabled = false;
            btnSave.Enabled = false;
            btnAdd.Enabled = true;
            btnQuery.Enabled = true;
            btnExecute.Enabled = false;

        }
        private void visibleFields()
        {
            btnFirstRecord.Visible = true;
            btnPreviousRecord.Visible = true;
            btnNextRecord.Visible = true;
            btnLastRecord.Visible = true;
            labelRecordStatus.Visible = true;
        }
        private void invisibleFields()
        {
            btnFirstRecord.Visible = false;
            btnPreviousRecord.Visible = false;
            btnNextRecord.Visible = false;
            btnLastRecord.Visible = false;
            labelRecordStatus.Visible = false;
        }
        private void reset_fields()
        {
            txtVehicleCode.Text = string.Empty;
            txtVehicleName.Text = string.Empty;
            txtAverageWeght.Text = string.Empty;
            radioIsActiveTrue.Checked = true;
        }
        private void btnAdd_Click(object sender, EventArgs e)
        {
            formMode = formModeDict[1]; // formmode is set to create i.e. add new record
            enableFields();
            btnQuery.Enabled = false;
        }

        private void btnQuery_Click(object sender, EventArgs e)
        {
            formMode = formModeDict[2]; // read mode
            btnExecute.Enabled = true;
            enableFields();
            btnAdd.Enabled = false;
            btnSave.Enabled = false;
            
        }

        private void btnExecute_Click(object sender, EventArgs e)
        {
            formMode = formModeDict[3]; // update mode
            btnAdd.Enabled = false;
            btnSave.Enabled = true;
            btnQuery.Enabled = false;
            queryResult();
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            bool isActive = true;
            if(radioIsActiveFalse.Checked == true)
            {
                isActive = false;
            }
            switch (formMode)
            {
                case "create":
                    vehicleMasterLogic.insertVehicleDetails(Convert.ToInt16(txtVehicleCode.Text), txtVehicleName.Text.ToString(), float.Parse(txtAverageWeght.Text), isActive, genFunc.userCode);
                    break;
                case "read":
                    DataTable dt = vehicleMasterLogic.getVehicleDetails().Tables[0];
                    txtVehicleCode.Text = dt.Rows[0]["v_code"].ToString();
                    txtVehicleName.Text = dt.Rows[0]["v_name"].ToString();
                    txtAverageWeght.Text = dt.Rows[0]["v_average_weight"].ToString();
                    
                    break;
                case "update":
                    vehicleCode = Convert.ToInt16(txtVehicleCode.Text);
                    vehicleName = txtVehicleName.Text;
                    averageWeight = float.Parse(txtAverageWeght.Text);
                    if(radioIsActiveFalse.Checked == true)
                    {
                        isActive = false;
                    }
                    
                     vehicleMasterLogic.updateVehicleDetails(vehicleCode, vehicleName, averageWeight, isActive);
                    
                    break;
                default:
                    MessageBox.Show("Form mode unspecified", "Unknown form mode", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    break;
            }
            reset_fields();
            disableFields();
        }

        private void queryResult()
        {
            queryDataTable  = vehicleMasterLogic.getVehicleDetails().Tables[0];
            record_count_in_table = queryDataTable.Rows.Count;
            if (record_count_in_table > 1)
            {
                visibleFields();
                rowindex = 1;
                txtVehicleCode.Text = queryDataTable.Rows[rowindex - 1]["v_code"].ToString();
                txtVehicleName.Text = queryDataTable.Rows[rowindex - 1]["v_name"].ToString();
                txtAverageWeght.Text = queryDataTable.Rows[rowindex - 1]["v_average_weight"].ToString();
                if (bool.Parse(queryDataTable.Rows[rowindex - 1]["v_is_active"].ToString()) == false)
                {
                    radioIsActiveFalse.Checked = true;
                }
                else
                {
                    radioIsActiveTrue.Checked = true;
                }

                labelRecordStatus.Text = rowindex + " of " + record_count_in_table;
            }
            else
            {
                invisibleFields();
            }

        }

        private void btnFirstRecord_Click(object sender, EventArgs e)
        {

            rowindex = 1;
            txtVehicleCode.Text = queryDataTable.Rows[rowindex-1]["v_code"].ToString();
            txtVehicleName.Text = queryDataTable.Rows[rowindex-1]["v_name"].ToString();
            txtAverageWeght.Text = queryDataTable.Rows[rowindex-1]["v_average_weight"].ToString();
            if (bool.Parse(queryDataTable.Rows[rowindex - 1]["v_is_active"].ToString()) == false)
            {
                radioIsActiveFalse.Checked = true;
            }
            else
            {
                radioIsActiveTrue.Checked = true;
            }
            labelRecordStatus.Text = rowindex + " of " + record_count_in_table;
        }

        private void btnPreviousRecord_Click(object sender, EventArgs e)
        {
           
            if (rowindex > 1)
            {
                rowindex--;
                txtVehicleCode.Text = queryDataTable.Rows[rowindex-1]["v_code"].ToString();
                txtVehicleName.Text = queryDataTable.Rows[rowindex-1]["v_name"].ToString();
                txtAverageWeght.Text = queryDataTable.Rows[rowindex-1]["v_average_weight"].ToString();
                if (bool.Parse(queryDataTable.Rows[rowindex - 1]["v_is_active"].ToString()) == false)
                {
                    radioIsActiveFalse.Checked = true;
                }
                labelRecordStatus.Text = rowindex + " of " + record_count_in_table;
            }
            else
            {
                MessageBox.Show("No more record exist", "No record", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                rowindex = 0;
            }
        }

        private void btnNextRecord_Click(object sender, EventArgs e)
        {

            if (rowindex <= record_count_in_table - 1)
            {
                rowindex++;
                txtVehicleCode.Text = queryDataTable.Rows[rowindex-1]["v_code"].ToString();
                txtVehicleName.Text = queryDataTable.Rows[rowindex-1]["v_name"].ToString();
                txtAverageWeght.Text = queryDataTable.Rows[rowindex-1]["v_average_weight"].ToString();
                if (bool.Parse(queryDataTable.Rows[rowindex - 1]["v_is_active"].ToString()) == false)
                {
                    radioIsActiveFalse.Checked = true;
                }
                else
                {
                    radioIsActiveTrue.Checked = true;
                }
                labelRecordStatus.Text = rowindex + " of " + record_count_in_table;
            }
            else
            {
                MessageBox.Show("No more record exist", "No record", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                rowindex--;
            }
        }

        private void btnLastRecord_Click(object sender, EventArgs e)
        {

            if (rowindex <= record_count_in_table)
            {
                rowindex = queryDataTable.Rows.Count;
                txtVehicleCode.Text = queryDataTable.Rows[rowindex-1]["v_code"].ToString();
                txtVehicleName.Text = queryDataTable.Rows[rowindex-1]["v_name"].ToString();
                txtAverageWeght.Text = queryDataTable.Rows[rowindex-1]["v_average_weight"].ToString();
                if (bool.Parse(queryDataTable.Rows[rowindex - 1]["v_is_active"].ToString()) == false)
                {
                    radioIsActiveFalse.Checked = true;
                }
                else
                {
                    radioIsActiveTrue.Checked = true;
                }
                labelRecordStatus.Text = rowindex + " of " + record_count_in_table;
            }
            else
            {
                MessageBox.Show("No more record exist", "No record", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                rowindex = queryDataTable.Rows.Count;
            }
        }

        private void btnReset_Click(object sender, EventArgs e)
        {
            invisibleFields();
            disableFields();
            reset_fields();
        }
    }
}
