﻿namespace Litmus.forms.master_forms
{
    partial class frm_stoppage_master
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnCancel = new System.Windows.Forms.Button();
            this.btnSave = new System.Windows.Forms.Button();
            this.tabStoppages = new System.Windows.Forms.TabControl();
            this.tabStoppageHead = new System.Windows.Forms.TabPage();
            this.panelStoppageHeadAdmin = new System.Windows.Forms.GroupBox();
            this.lblRecordCounter = new System.Windows.Forms.Label();
            this.btnQuery = new System.Windows.Forms.Button();
            this.btnLastRecord = new System.Windows.Forms.Button();
            this.btnExecute = new System.Windows.Forms.Button();
            this.btnNextRecord = new System.Windows.Forms.Button();
            this.btnReset = new System.Windows.Forms.Button();
            this.btnPreviousRecord = new System.Windows.Forms.Button();
            this.btnFirstRecord = new System.Windows.Forms.Button();
            this.txtStoppageHeadDesc = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.radioNo = new System.Windows.Forms.RadioButton();
            this.radioYes = new System.Windows.Forms.RadioButton();
            this.label2 = new System.Windows.Forms.Label();
            this.txtStoppageHead = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.tabStoppageSubHead = new System.Windows.Forms.TabPage();
            this.panelStoppageSubHeadAdmin = new System.Windows.Forms.GroupBox();
            this.label8 = new System.Windows.Forms.Label();
            this.btnSubHeadQuery = new System.Windows.Forms.Button();
            this.btnSubHeadLastRecord = new System.Windows.Forms.Button();
            this.btnSubHeadExecute = new System.Windows.Forms.Button();
            this.btnSubHeadNextRecord = new System.Windows.Forms.Button();
            this.btnSubHeadReset = new System.Windows.Forms.Button();
            this.btnSubHeadPreviousRecord = new System.Windows.Forms.Button();
            this.btnSubHeadFirstRecord = new System.Windows.Forms.Button();
            this.txtStoppageSubHeadDesc = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.radioStoppageSubNo = new System.Windows.Forms.RadioButton();
            this.RadioStoppageSubYes = new System.Windows.Forms.RadioButton();
            this.label6 = new System.Windows.Forms.Label();
            this.txtStoppageSubHead = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.ddlStoppageHead = new System.Windows.Forms.ComboBox();
            this.label4 = new System.Windows.Forms.Label();
            this.tabStoppages.SuspendLayout();
            this.tabStoppageHead.SuspendLayout();
            this.panelStoppageHeadAdmin.SuspendLayout();
            this.panel1.SuspendLayout();
            this.tabStoppageSubHead.SuspendLayout();
            this.panelStoppageSubHeadAdmin.SuspendLayout();
            this.panel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // btnCancel
            // 
            this.btnCancel.Location = new System.Drawing.Point(677, 230);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(120, 32);
            this.btnCancel.TabIndex = 5;
            this.btnCancel.Text = "&Cancel";
            this.btnCancel.UseVisualStyleBackColor = true;
            this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
            // 
            // btnSave
            // 
            this.btnSave.Location = new System.Drawing.Point(551, 230);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(120, 32);
            this.btnSave.TabIndex = 4;
            this.btnSave.Text = "&Save";
            this.btnSave.UseVisualStyleBackColor = true;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // tabStoppages
            // 
            this.tabStoppages.Controls.Add(this.tabStoppageHead);
            this.tabStoppages.Controls.Add(this.tabStoppageSubHead);
            this.tabStoppages.Location = new System.Drawing.Point(-1, 1);
            this.tabStoppages.Name = "tabStoppages";
            this.tabStoppages.SelectedIndex = 0;
            this.tabStoppages.Size = new System.Drawing.Size(811, 227);
            this.tabStoppages.TabIndex = 3;
            // 
            // tabStoppageHead
            // 
            this.tabStoppageHead.Controls.Add(this.panelStoppageHeadAdmin);
            this.tabStoppageHead.Controls.Add(this.txtStoppageHeadDesc);
            this.tabStoppageHead.Controls.Add(this.label3);
            this.tabStoppageHead.Controls.Add(this.panel1);
            this.tabStoppageHead.Controls.Add(this.label2);
            this.tabStoppageHead.Controls.Add(this.txtStoppageHead);
            this.tabStoppageHead.Controls.Add(this.label1);
            this.tabStoppageHead.Location = new System.Drawing.Point(4, 25);
            this.tabStoppageHead.Name = "tabStoppageHead";
            this.tabStoppageHead.Padding = new System.Windows.Forms.Padding(3);
            this.tabStoppageHead.Size = new System.Drawing.Size(803, 198);
            this.tabStoppageHead.TabIndex = 0;
            this.tabStoppageHead.Text = "Stoppage Head";
            this.tabStoppageHead.UseVisualStyleBackColor = true;
            // 
            // panelStoppageHeadAdmin
            // 
            this.panelStoppageHeadAdmin.Controls.Add(this.lblRecordCounter);
            this.panelStoppageHeadAdmin.Controls.Add(this.btnQuery);
            this.panelStoppageHeadAdmin.Controls.Add(this.btnLastRecord);
            this.panelStoppageHeadAdmin.Controls.Add(this.btnExecute);
            this.panelStoppageHeadAdmin.Controls.Add(this.btnNextRecord);
            this.panelStoppageHeadAdmin.Controls.Add(this.btnReset);
            this.panelStoppageHeadAdmin.Controls.Add(this.btnPreviousRecord);
            this.panelStoppageHeadAdmin.Controls.Add(this.btnFirstRecord);
            this.panelStoppageHeadAdmin.Location = new System.Drawing.Point(9, 6);
            this.panelStoppageHeadAdmin.Name = "panelStoppageHeadAdmin";
            this.panelStoppageHeadAdmin.Size = new System.Drawing.Size(785, 49);
            this.panelStoppageHeadAdmin.TabIndex = 6;
            this.panelStoppageHeadAdmin.TabStop = false;
            // 
            // lblRecordCounter
            // 
            this.lblRecordCounter.AutoSize = true;
            this.lblRecordCounter.Location = new System.Drawing.Point(574, 19);
            this.lblRecordCounter.Name = "lblRecordCounter";
            this.lblRecordCounter.Size = new System.Drawing.Size(18, 17);
            this.lblRecordCounter.TabIndex = 7;
            this.lblRecordCounter.Text = "--";
            // 
            // btnQuery
            // 
            this.btnQuery.Location = new System.Drawing.Point(6, 12);
            this.btnQuery.Name = "btnQuery";
            this.btnQuery.Size = new System.Drawing.Size(93, 31);
            this.btnQuery.TabIndex = 0;
            this.btnQuery.Text = "Query";
            this.btnQuery.UseVisualStyleBackColor = true;
            this.btnQuery.Click += new System.EventHandler(this.btnQuery_Click);
            // 
            // btnLastRecord
            // 
            this.btnLastRecord.Location = new System.Drawing.Point(718, 12);
            this.btnLastRecord.Name = "btnLastRecord";
            this.btnLastRecord.Size = new System.Drawing.Size(61, 31);
            this.btnLastRecord.TabIndex = 6;
            this.btnLastRecord.Text = ">>|";
            this.btnLastRecord.UseVisualStyleBackColor = true;
            this.btnLastRecord.Click += new System.EventHandler(this.btnLastRecord_Click);
            // 
            // btnExecute
            // 
            this.btnExecute.Enabled = false;
            this.btnExecute.Location = new System.Drawing.Point(109, 12);
            this.btnExecute.Name = "btnExecute";
            this.btnExecute.Size = new System.Drawing.Size(93, 31);
            this.btnExecute.TabIndex = 1;
            this.btnExecute.Text = "Execute";
            this.btnExecute.UseVisualStyleBackColor = true;
            this.btnExecute.Click += new System.EventHandler(this.btnExecute_Click);
            // 
            // btnNextRecord
            // 
            this.btnNextRecord.Location = new System.Drawing.Point(651, 12);
            this.btnNextRecord.Name = "btnNextRecord";
            this.btnNextRecord.Size = new System.Drawing.Size(61, 31);
            this.btnNextRecord.TabIndex = 5;
            this.btnNextRecord.Text = ">";
            this.btnNextRecord.UseVisualStyleBackColor = true;
            this.btnNextRecord.Click += new System.EventHandler(this.btnNextRecord_Click);
            // 
            // btnReset
            // 
            this.btnReset.Location = new System.Drawing.Point(209, 12);
            this.btnReset.Name = "btnReset";
            this.btnReset.Size = new System.Drawing.Size(93, 31);
            this.btnReset.TabIndex = 2;
            this.btnReset.Text = "Reset";
            this.btnReset.UseVisualStyleBackColor = true;
            this.btnReset.Click += new System.EventHandler(this.btnReset_Click);
            // 
            // btnPreviousRecord
            // 
            this.btnPreviousRecord.Location = new System.Drawing.Point(489, 12);
            this.btnPreviousRecord.Name = "btnPreviousRecord";
            this.btnPreviousRecord.Size = new System.Drawing.Size(61, 31);
            this.btnPreviousRecord.TabIndex = 4;
            this.btnPreviousRecord.Text = "<";
            this.btnPreviousRecord.UseVisualStyleBackColor = true;
            this.btnPreviousRecord.Click += new System.EventHandler(this.btnPreviousRecord_Click);
            // 
            // btnFirstRecord
            // 
            this.btnFirstRecord.Location = new System.Drawing.Point(422, 12);
            this.btnFirstRecord.Name = "btnFirstRecord";
            this.btnFirstRecord.Size = new System.Drawing.Size(61, 31);
            this.btnFirstRecord.TabIndex = 3;
            this.btnFirstRecord.Text = "|<<";
            this.btnFirstRecord.UseVisualStyleBackColor = true;
            this.btnFirstRecord.Click += new System.EventHandler(this.btnFirstRecord_Click);
            // 
            // txtStoppageHeadDesc
            // 
            this.txtStoppageHeadDesc.Location = new System.Drawing.Point(160, 112);
            this.txtStoppageHeadDesc.Multiline = true;
            this.txtStoppageHeadDesc.Name = "txtStoppageHeadDesc";
            this.txtStoppageHeadDesc.Size = new System.Drawing.Size(282, 74);
            this.txtStoppageHeadDesc.TabIndex = 3;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(50, 137);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(79, 17);
            this.label3.TabIndex = 4;
            this.label3.Text = "Description";
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.radioNo);
            this.panel1.Controls.Add(this.radioYes);
            this.panel1.Location = new System.Drawing.Point(554, 63);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(153, 29);
            this.panel1.TabIndex = 2;
            // 
            // radioNo
            // 
            this.radioNo.AutoSize = true;
            this.radioNo.Location = new System.Drawing.Point(81, 4);
            this.radioNo.Name = "radioNo";
            this.radioNo.Size = new System.Drawing.Size(47, 21);
            this.radioNo.TabIndex = 1;
            this.radioNo.TabStop = true;
            this.radioNo.Text = "No";
            this.radioNo.UseVisualStyleBackColor = true;
            // 
            // radioYes
            // 
            this.radioYes.AutoSize = true;
            this.radioYes.Checked = true;
            this.radioYes.Location = new System.Drawing.Point(4, 4);
            this.radioYes.Name = "radioYes";
            this.radioYes.Size = new System.Drawing.Size(53, 21);
            this.radioYes.TabIndex = 0;
            this.radioYes.TabStop = true;
            this.radioYes.Text = "Yes";
            this.radioYes.UseVisualStyleBackColor = true;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(471, 66);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(60, 17);
            this.label2.TabIndex = 2;
            this.label2.Text = "Is Active";
            // 
            // txtStoppageHead
            // 
            this.txtStoppageHead.Location = new System.Drawing.Point(160, 63);
            this.txtStoppageHead.Name = "txtStoppageHead";
            this.txtStoppageHead.Size = new System.Drawing.Size(282, 22);
            this.txtStoppageHead.TabIndex = 1;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(22, 63);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(107, 17);
            this.label1.TabIndex = 0;
            this.label1.Text = "Stoppage Head";
            // 
            // tabStoppageSubHead
            // 
            this.tabStoppageSubHead.Controls.Add(this.panelStoppageSubHeadAdmin);
            this.tabStoppageSubHead.Controls.Add(this.txtStoppageSubHeadDesc);
            this.tabStoppageSubHead.Controls.Add(this.label7);
            this.tabStoppageSubHead.Controls.Add(this.panel2);
            this.tabStoppageSubHead.Controls.Add(this.label6);
            this.tabStoppageSubHead.Controls.Add(this.txtStoppageSubHead);
            this.tabStoppageSubHead.Controls.Add(this.label5);
            this.tabStoppageSubHead.Controls.Add(this.ddlStoppageHead);
            this.tabStoppageSubHead.Controls.Add(this.label4);
            this.tabStoppageSubHead.Location = new System.Drawing.Point(4, 25);
            this.tabStoppageSubHead.Name = "tabStoppageSubHead";
            this.tabStoppageSubHead.Padding = new System.Windows.Forms.Padding(3);
            this.tabStoppageSubHead.Size = new System.Drawing.Size(803, 198);
            this.tabStoppageSubHead.TabIndex = 1;
            this.tabStoppageSubHead.Text = "Stoppage Sub Head";
            this.tabStoppageSubHead.UseVisualStyleBackColor = true;
            // 
            // panelStoppageSubHeadAdmin
            // 
            this.panelStoppageSubHeadAdmin.Controls.Add(this.label8);
            this.panelStoppageSubHeadAdmin.Controls.Add(this.btnSubHeadQuery);
            this.panelStoppageSubHeadAdmin.Controls.Add(this.btnSubHeadLastRecord);
            this.panelStoppageSubHeadAdmin.Controls.Add(this.btnSubHeadExecute);
            this.panelStoppageSubHeadAdmin.Controls.Add(this.btnSubHeadNextRecord);
            this.panelStoppageSubHeadAdmin.Controls.Add(this.btnSubHeadReset);
            this.panelStoppageSubHeadAdmin.Controls.Add(this.btnSubHeadPreviousRecord);
            this.panelStoppageSubHeadAdmin.Controls.Add(this.btnSubHeadFirstRecord);
            this.panelStoppageSubHeadAdmin.Location = new System.Drawing.Point(12, 3);
            this.panelStoppageSubHeadAdmin.Name = "panelStoppageSubHeadAdmin";
            this.panelStoppageSubHeadAdmin.Size = new System.Drawing.Size(785, 49);
            this.panelStoppageSubHeadAdmin.TabIndex = 7;
            this.panelStoppageSubHeadAdmin.TabStop = false;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(574, 19);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(18, 17);
            this.label8.TabIndex = 7;
            this.label8.Text = "--";
            // 
            // btnSubHeadQuery
            // 
            this.btnSubHeadQuery.Location = new System.Drawing.Point(6, 12);
            this.btnSubHeadQuery.Name = "btnSubHeadQuery";
            this.btnSubHeadQuery.Size = new System.Drawing.Size(93, 31);
            this.btnSubHeadQuery.TabIndex = 0;
            this.btnSubHeadQuery.Text = "Query";
            this.btnSubHeadQuery.UseVisualStyleBackColor = true;
            this.btnSubHeadQuery.Click += new System.EventHandler(this.btnSubHeadQuery_Click);
            // 
            // btnSubHeadLastRecord
            // 
            this.btnSubHeadLastRecord.Location = new System.Drawing.Point(718, 12);
            this.btnSubHeadLastRecord.Name = "btnSubHeadLastRecord";
            this.btnSubHeadLastRecord.Size = new System.Drawing.Size(61, 31);
            this.btnSubHeadLastRecord.TabIndex = 6;
            this.btnSubHeadLastRecord.Text = ">>|";
            this.btnSubHeadLastRecord.UseVisualStyleBackColor = true;
            this.btnSubHeadLastRecord.Click += new System.EventHandler(this.btnSubHeadLastRecord_Click);
            // 
            // btnSubHeadExecute
            // 
            this.btnSubHeadExecute.Enabled = false;
            this.btnSubHeadExecute.Location = new System.Drawing.Point(109, 12);
            this.btnSubHeadExecute.Name = "btnSubHeadExecute";
            this.btnSubHeadExecute.Size = new System.Drawing.Size(93, 31);
            this.btnSubHeadExecute.TabIndex = 1;
            this.btnSubHeadExecute.Text = "Execute";
            this.btnSubHeadExecute.UseVisualStyleBackColor = true;
            this.btnSubHeadExecute.Click += new System.EventHandler(this.btnSubHeadExecute_Click);
            // 
            // btnSubHeadNextRecord
            // 
            this.btnSubHeadNextRecord.Location = new System.Drawing.Point(651, 12);
            this.btnSubHeadNextRecord.Name = "btnSubHeadNextRecord";
            this.btnSubHeadNextRecord.Size = new System.Drawing.Size(61, 31);
            this.btnSubHeadNextRecord.TabIndex = 5;
            this.btnSubHeadNextRecord.Text = ">";
            this.btnSubHeadNextRecord.UseVisualStyleBackColor = true;
            this.btnSubHeadNextRecord.Click += new System.EventHandler(this.btnSubHeadNextRecord_Click);
            // 
            // btnSubHeadReset
            // 
            this.btnSubHeadReset.Location = new System.Drawing.Point(209, 12);
            this.btnSubHeadReset.Name = "btnSubHeadReset";
            this.btnSubHeadReset.Size = new System.Drawing.Size(93, 31);
            this.btnSubHeadReset.TabIndex = 2;
            this.btnSubHeadReset.Text = "Reset";
            this.btnSubHeadReset.UseVisualStyleBackColor = true;
            this.btnSubHeadReset.Click += new System.EventHandler(this.btnSubHeadReset_Click);
            // 
            // btnSubHeadPreviousRecord
            // 
            this.btnSubHeadPreviousRecord.Location = new System.Drawing.Point(489, 12);
            this.btnSubHeadPreviousRecord.Name = "btnSubHeadPreviousRecord";
            this.btnSubHeadPreviousRecord.Size = new System.Drawing.Size(61, 31);
            this.btnSubHeadPreviousRecord.TabIndex = 4;
            this.btnSubHeadPreviousRecord.Text = "<";
            this.btnSubHeadPreviousRecord.UseVisualStyleBackColor = true;
            this.btnSubHeadPreviousRecord.Click += new System.EventHandler(this.btnSubHeadPreviousRecord_Click);
            // 
            // btnSubHeadFirstRecord
            // 
            this.btnSubHeadFirstRecord.Location = new System.Drawing.Point(422, 12);
            this.btnSubHeadFirstRecord.Name = "btnSubHeadFirstRecord";
            this.btnSubHeadFirstRecord.Size = new System.Drawing.Size(61, 31);
            this.btnSubHeadFirstRecord.TabIndex = 3;
            this.btnSubHeadFirstRecord.Text = "|<<";
            this.btnSubHeadFirstRecord.UseVisualStyleBackColor = true;
            this.btnSubHeadFirstRecord.Click += new System.EventHandler(this.btnSubHeadFirstRecord_Click);
            // 
            // txtStoppageSubHeadDesc
            // 
            this.txtStoppageSubHeadDesc.Location = new System.Drawing.Point(548, 113);
            this.txtStoppageSubHeadDesc.Multiline = true;
            this.txtStoppageSubHeadDesc.Name = "txtStoppageSubHeadDesc";
            this.txtStoppageSubHeadDesc.Size = new System.Drawing.Size(243, 74);
            this.txtStoppageSubHeadDesc.TabIndex = 7;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(453, 141);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(79, 17);
            this.label7.TabIndex = 6;
            this.label7.Text = "Description";
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.radioStoppageSubNo);
            this.panel2.Controls.Add(this.RadioStoppageSubYes);
            this.panel2.Location = new System.Drawing.Point(138, 138);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(153, 29);
            this.panel2.TabIndex = 5;
            // 
            // radioStoppageSubNo
            // 
            this.radioStoppageSubNo.AutoSize = true;
            this.radioStoppageSubNo.Location = new System.Drawing.Point(81, 4);
            this.radioStoppageSubNo.Name = "radioStoppageSubNo";
            this.radioStoppageSubNo.Size = new System.Drawing.Size(47, 21);
            this.radioStoppageSubNo.TabIndex = 1;
            this.radioStoppageSubNo.TabStop = true;
            this.radioStoppageSubNo.Text = "No";
            this.radioStoppageSubNo.UseVisualStyleBackColor = true;
            // 
            // RadioStoppageSubYes
            // 
            this.RadioStoppageSubYes.AutoSize = true;
            this.RadioStoppageSubYes.Location = new System.Drawing.Point(4, 4);
            this.RadioStoppageSubYes.Name = "RadioStoppageSubYes";
            this.RadioStoppageSubYes.Size = new System.Drawing.Size(53, 21);
            this.RadioStoppageSubYes.TabIndex = 0;
            this.RadioStoppageSubYes.TabStop = true;
            this.RadioStoppageSubYes.Text = "Yes";
            this.RadioStoppageSubYes.UseVisualStyleBackColor = true;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(55, 141);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(60, 17);
            this.label6.TabIndex = 4;
            this.label6.Text = "Is Active";
            // 
            // txtStoppageSubHead
            // 
            this.txtStoppageSubHead.Location = new System.Drawing.Point(548, 75);
            this.txtStoppageSubHead.Name = "txtStoppageSubHead";
            this.txtStoppageSubHead.Size = new System.Drawing.Size(243, 22);
            this.txtStoppageSubHead.TabIndex = 3;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(396, 78);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(136, 17);
            this.label5.TabIndex = 2;
            this.label5.Text = "Stoppage Sub Head";
            // 
            // ddlStoppageHead
            // 
            this.ddlStoppageHead.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.ddlStoppageHead.FormattingEnabled = true;
            this.ddlStoppageHead.Location = new System.Drawing.Point(138, 75);
            this.ddlStoppageHead.Name = "ddlStoppageHead";
            this.ddlStoppageHead.Size = new System.Drawing.Size(235, 24);
            this.ddlStoppageHead.TabIndex = 1;
            this.ddlStoppageHead.SelectedIndexChanged += new System.EventHandler(this.ddlStoppageHead_SelectedIndexChanged);
            this.ddlStoppageHead.Click += new System.EventHandler(this.ddlStoppageHead_clicked);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(13, 78);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(107, 17);
            this.label4.TabIndex = 0;
            this.label4.Text = "Stoppage Head";
            // 
            // frm_stoppage_master
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(809, 267);
            this.Controls.Add(this.tabStoppages);
            this.Controls.Add(this.btnSave);
            this.Controls.Add(this.btnCancel);
            this.Name = "frm_stoppage_master";
            this.Text = "Stoppage Master";
            this.tabStoppages.ResumeLayout(false);
            this.tabStoppageHead.ResumeLayout(false);
            this.tabStoppageHead.PerformLayout();
            this.panelStoppageHeadAdmin.ResumeLayout(false);
            this.panelStoppageHeadAdmin.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.tabStoppageSubHead.ResumeLayout(false);
            this.tabStoppageSubHead.PerformLayout();
            this.panelStoppageSubHeadAdmin.ResumeLayout(false);
            this.panelStoppageSubHeadAdmin.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnCancel;
        private System.Windows.Forms.Button btnSave;
        private System.Windows.Forms.TabControl tabStoppages;
        private System.Windows.Forms.TabPage tabStoppageHead;
        private System.Windows.Forms.TextBox txtStoppageHeadDesc;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.RadioButton radioNo;
        private System.Windows.Forms.RadioButton radioYes;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtStoppageHead;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TabPage tabStoppageSubHead;
        private System.Windows.Forms.TextBox txtStoppageSubHeadDesc;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.RadioButton radioStoppageSubNo;
        private System.Windows.Forms.RadioButton RadioStoppageSubYes;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox txtStoppageSubHead;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.ComboBox ddlStoppageHead;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button btnReset;
        private System.Windows.Forms.Button btnExecute;
        private System.Windows.Forms.Button btnQuery;
        private System.Windows.Forms.Button btnLastRecord;
        private System.Windows.Forms.Button btnNextRecord;
        private System.Windows.Forms.Button btnPreviousRecord;
        private System.Windows.Forms.Button btnFirstRecord;
        private System.Windows.Forms.Label lblRecordCounter;
        private System.Windows.Forms.GroupBox panelStoppageHeadAdmin;
        private System.Windows.Forms.GroupBox panelStoppageSubHeadAdmin;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Button btnSubHeadQuery;
        private System.Windows.Forms.Button btnSubHeadLastRecord;
        private System.Windows.Forms.Button btnSubHeadExecute;
        private System.Windows.Forms.Button btnSubHeadNextRecord;
        private System.Windows.Forms.Button btnSubHeadReset;
        private System.Windows.Forms.Button btnSubHeadPreviousRecord;
        private System.Windows.Forms.Button btnSubHeadFirstRecord;
    }
}