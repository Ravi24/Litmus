﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Configuration;


namespace Litmus.forms.master_forms
{
    public partial class frm_db_configuration : Form
    {
        classes.ExceptionHelper expHelper = new classes.ExceptionHelper();
        public frm_db_configuration()
        {
            InitializeComponent();
            loadSavedCredentials();
        }

        private void btnApply_Click(object sender, EventArgs e)
        {
            try
            {

                Properties.Settings.Default.serverName = txtServerName.Text.Trim();
                Properties.Settings.Default.initialCatalog = txtInitialCatalog.Text.Trim();
                Properties.Settings.Default.userName = txtUserName.Text.Trim();
                Properties.Settings.Default.password = txtPassword.Text.Trim();
                Properties.Settings.Default.Save();
                Properties.Settings.Default.Reload();
                
                MessageBox.Show("Database credentials changed for this machine\nApplication will restart it self.", "Database Credentials Saved", MessageBoxButtons.OK, MessageBoxIcon.Information);
                Application.Restart();
                

            }
            catch (Exception ex)
            {
                MessageBox.Show("Error- while setting databse credentials \n Error message" + ex.Message);
                expHelper.statusMsg = "ERROR while setting databse credentials \n Error message" + ex.Message + "\nStack Trace -" + ex.StackTrace;

            }
            finally
            {
                this.Close();
            }
        }
        private void loadSavedCredentials()
        {
            txtServerName.Text = Properties.Settings.Default.serverName;
            txtUserName.Text = Properties.Settings.Default.userName;
            txtInitialCatalog.Text = Properties.Settings.Default.initialCatalog;
            
        }
    }
}
