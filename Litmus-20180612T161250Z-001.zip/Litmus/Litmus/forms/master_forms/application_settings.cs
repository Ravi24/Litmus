﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Litmus.forms.master_forms
{
    public partial class application_settings : Form
    {
        public application_settings()
        {
            InitializeComponent();
        }
    }
}
