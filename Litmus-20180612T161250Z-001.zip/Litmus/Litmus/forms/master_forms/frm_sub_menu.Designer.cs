﻿namespace Litmus.forms.master_forms
{
    partial class frm_sub_menu
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frm_sub_menu));
            this.groupSubMenu = new System.Windows.Forms.GroupBox();
            this.txtFormname = new System.Windows.Forms.TextBox();
            this.lblFormname = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.radioIsActiveFalse = new System.Windows.Forms.RadioButton();
            this.radioIsActiveTrue = new System.Windows.Forms.RadioButton();
            this.label4 = new System.Windows.Forms.Label();
            this.txtSubMenuname = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.txtSubMenuCode = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.ddlMasterMenuList = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.toolStrip1 = new System.Windows.Forms.ToolStrip();
            this.toolStripButton1 = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripButton2 = new System.Windows.Forms.ToolStripButton();
            this.btnSave = new System.Windows.Forms.Button();
            this.btnClear = new System.Windows.Forms.Button();
            this.groupSubMenu.SuspendLayout();
            this.panel1.SuspendLayout();
            this.toolStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupSubMenu
            // 
            this.groupSubMenu.BackColor = System.Drawing.Color.White;
            this.groupSubMenu.Controls.Add(this.txtFormname);
            this.groupSubMenu.Controls.Add(this.lblFormname);
            this.groupSubMenu.Controls.Add(this.panel1);
            this.groupSubMenu.Controls.Add(this.label4);
            this.groupSubMenu.Controls.Add(this.txtSubMenuname);
            this.groupSubMenu.Controls.Add(this.label3);
            this.groupSubMenu.Controls.Add(this.txtSubMenuCode);
            this.groupSubMenu.Controls.Add(this.label2);
            this.groupSubMenu.Controls.Add(this.ddlMasterMenuList);
            this.groupSubMenu.Controls.Add(this.label1);
            this.groupSubMenu.Location = new System.Drawing.Point(0, 34);
            this.groupSubMenu.Name = "groupSubMenu";
            this.groupSubMenu.Size = new System.Drawing.Size(355, 244);
            this.groupSubMenu.TabIndex = 0;
            this.groupSubMenu.TabStop = false;
            this.groupSubMenu.Text = "Sub Menu Creation/Modification";
            // 
            // txtFormname
            // 
            this.txtFormname.Location = new System.Drawing.Point(158, 153);
            this.txtFormname.Name = "txtFormname";
            this.txtFormname.Size = new System.Drawing.Size(186, 22);
            this.txtFormname.TabIndex = 9;
            // 
            // lblFormname
            // 
            this.lblFormname.AutoSize = true;
            this.lblFormname.Location = new System.Drawing.Point(56, 153);
            this.lblFormname.Name = "lblFormname";
            this.lblFormname.Size = new System.Drawing.Size(91, 17);
            this.lblFormname.TabIndex = 8;
            this.lblFormname.Text = "FORM name";
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.radioIsActiveFalse);
            this.panel1.Controls.Add(this.radioIsActiveTrue);
            this.panel1.Location = new System.Drawing.Point(155, 190);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(185, 35);
            this.panel1.TabIndex = 7;
            // 
            // radioIsActiveFalse
            // 
            this.radioIsActiveFalse.AutoSize = true;
            this.radioIsActiveFalse.Location = new System.Drawing.Point(86, 6);
            this.radioIsActiveFalse.Name = "radioIsActiveFalse";
            this.radioIsActiveFalse.Size = new System.Drawing.Size(83, 21);
            this.radioIsActiveFalse.TabIndex = 1;
            this.radioIsActiveFalse.TabStop = true;
            this.radioIsActiveFalse.Text = "In-Active";
            this.radioIsActiveFalse.UseVisualStyleBackColor = true;
            // 
            // radioIsActiveTrue
            // 
            this.radioIsActiveTrue.AutoSize = true;
            this.radioIsActiveTrue.Checked = true;
            this.radioIsActiveTrue.Location = new System.Drawing.Point(3, 6);
            this.radioIsActiveTrue.Name = "radioIsActiveTrue";
            this.radioIsActiveTrue.Size = new System.Drawing.Size(67, 21);
            this.radioIsActiveTrue.TabIndex = 0;
            this.radioIsActiveTrue.TabStop = true;
            this.radioIsActiveTrue.Text = "Active";
            this.radioIsActiveTrue.UseVisualStyleBackColor = true;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(75, 196);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(72, 17);
            this.label4.TabIndex = 6;
            this.label4.Text = "IS ACTIVE";
            // 
            // txtSubMenuName
            // 
            this.txtSubMenuname.Location = new System.Drawing.Point(158, 118);
            this.txtSubMenuname.Name = "txtSubMenuName";
            this.txtSubMenuname.Size = new System.Drawing.Size(185, 22);
            this.txtSubMenuname.TabIndex = 5;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(24, 121);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(123, 17);
            this.label3.TabIndex = 4;
            this.label3.Text = "SUB MENU Name";
            // 
            // txtSubMenuCode
            // 
            this.txtSubMenuCode.Enabled = false;
            this.txtSubMenuCode.Location = new System.Drawing.Point(158, 78);
            this.txtSubMenuCode.Name = "txtSubMenuCode";
            this.txtSubMenuCode.Size = new System.Drawing.Size(185, 22);
            this.txtSubMenuCode.TabIndex = 3;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(24, 78);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(123, 17);
            this.label2.TabIndex = 2;
            this.label2.Text = "SUB MENU CODE";
            // 
            // ddlMasterMenuList
            // 
            this.ddlMasterMenuList.FormattingEnabled = true;
            this.ddlMasterMenuList.Location = new System.Drawing.Point(158, 34);
            this.ddlMasterMenuList.Name = "ddlMasterMenuList";
            this.ddlMasterMenuList.Size = new System.Drawing.Size(185, 24);
            this.ddlMasterMenuList.TabIndex = 1;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(21, 37);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(109, 17);
            this.label1.TabIndex = 0;
            this.label1.Text = "MASTER MENU";
            // 
            // toolStrip1
            // 
            this.toolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripButton1,
            this.toolStripSeparator1,
            this.toolStripButton2});
            this.toolStrip1.Location = new System.Drawing.Point(0, 0);
            this.toolStrip1.Name = "toolStrip1";
            this.toolStrip1.Size = new System.Drawing.Size(357, 25);
            this.toolStrip1.TabIndex = 1;
            this.toolStrip1.Text = "toolStrip1";
            // 
            // toolStripButton1
            // 
            this.toolStripButton1.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton1.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton1.Image")));
            this.toolStripButton1.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton1.Name = "toolStripButton1";
            this.toolStripButton1.Size = new System.Drawing.Size(23, 22);
            this.toolStripButton1.Text = "toolStripAddSubMenu";
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(6, 25);
            // 
            // toolStripButton2
            // 
            this.toolStripButton2.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton2.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton2.Image")));
            this.toolStripButton2.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton2.Name = "toolStripButton2";
            this.toolStripButton2.Size = new System.Drawing.Size(23, 22);
            this.toolStripButton2.Text = "toolStripEditSubMenu";
            // 
            // btnSave
            // 
            this.btnSave.Location = new System.Drawing.Point(279, 284);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(75, 23);
            this.btnSave.TabIndex = 2;
            this.btnSave.Text = "&Save";
            this.btnSave.UseVisualStyleBackColor = true;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // btnClear
            // 
            this.btnClear.Location = new System.Drawing.Point(198, 284);
            this.btnClear.Name = "btnClear";
            this.btnClear.Size = new System.Drawing.Size(75, 23);
            this.btnClear.TabIndex = 3;
            this.btnClear.Text = "&Clear";
            this.btnClear.UseVisualStyleBackColor = true;
            // 
            // frm_sub_menu
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(357, 314);
            this.Controls.Add(this.btnClear);
            this.Controls.Add(this.btnSave);
            this.Controls.Add(this.toolStrip1);
            this.Controls.Add(this.groupSubMenu);
            this.Name = "frm_sub_menu";
            this.Text = "Sub Menu Creation";
            this.groupSubMenu.ResumeLayout(false);
            this.groupSubMenu.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.toolStrip1.ResumeLayout(false);
            this.toolStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox groupSubMenu;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.RadioButton radioIsActiveFalse;
        private System.Windows.Forms.RadioButton radioIsActiveTrue;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txtSubMenuname;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtSubMenuCode;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ComboBox ddlMasterMenuList;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ToolStrip toolStrip1;
        private System.Windows.Forms.ToolStripButton toolStripButton1;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.ToolStripButton toolStripButton2;
        private System.Windows.Forms.TextBox txtFormname;
        private System.Windows.Forms.Label lblFormname;
        private System.Windows.Forms.Button btnSave;
        private System.Windows.Forms.Button btnClear;
    }
}