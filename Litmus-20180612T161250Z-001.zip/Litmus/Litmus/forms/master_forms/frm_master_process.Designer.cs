﻿namespace Litmus.forms.master_forms
{
    partial class frm_master_process
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnProcess = new System.Windows.Forms.Button();
            this.txtProcessDate = new System.Windows.Forms.DateTimePicker();
            this.label1 = new System.Windows.Forms.Label();
            this.statusStripProcess = new System.Windows.Forms.StatusStrip();
            this.labelFinalProcessStatus = new System.Windows.Forms.ToolStripStatusLabel();
            this.lblStatus = new System.Windows.Forms.Label();
            this.txtProcessEndDate = new System.Windows.Forms.DateTimePicker();
            this.statusStripProcess.SuspendLayout();
            this.SuspendLayout();
            // 
            // btnProcess
            // 
            this.btnProcess.Location = new System.Drawing.Point(502, 36);
            this.btnProcess.Name = "btnProcess";
            this.btnProcess.Size = new System.Drawing.Size(75, 23);
            this.btnProcess.TabIndex = 0;
            this.btnProcess.Text = "Process";
            this.btnProcess.UseVisualStyleBackColor = true;
            this.btnProcess.Click += new System.EventHandler(this.btnProcess_Click);
            // 
            // txtProcessDate
            // 
            this.txtProcessDate.CustomFormat = "yyyy-MM-dd";
            this.txtProcessDate.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.txtProcessDate.Location = new System.Drawing.Point(165, 36);
            this.txtProcessDate.Name = "txtProcessDate";
            this.txtProcessDate.Size = new System.Drawing.Size(100, 22);
            this.txtProcessDate.TabIndex = 9;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(46, 41);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(93, 17);
            this.label1.TabIndex = 10;
            this.label1.Text = "Process Date";
            // 
            // statusStripProcess
            // 
            this.statusStripProcess.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.labelFinalProcessStatus});
            this.statusStripProcess.Location = new System.Drawing.Point(0, 111);
            this.statusStripProcess.Name = "statusStripProcess";
            this.statusStripProcess.Size = new System.Drawing.Size(614, 22);
            this.statusStripProcess.TabIndex = 11;
            this.statusStripProcess.Text = "statusStrip1";
            // 
            // labelFinalProcessStatus
            // 
            this.labelFinalProcessStatus.Name = "labelFinalProcessStatus";
            this.labelFinalProcessStatus.Size = new System.Drawing.Size(0, 17);
            // 
            // lblStatus
            // 
            this.lblStatus.AutoSize = true;
            this.lblStatus.Location = new System.Drawing.Point(12, 82);
            this.lblStatus.Name = "lblStatus";
            this.lblStatus.Size = new System.Drawing.Size(99, 17);
            this.lblStatus.TabIndex = 12;
            this.lblStatus.Text = "Current Status";
            // 
            // txtProcessEndDate
            // 
            this.txtProcessEndDate.CustomFormat = "yyyy-MM-dd";
            this.txtProcessEndDate.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.txtProcessEndDate.Location = new System.Drawing.Point(312, 37);
            this.txtProcessEndDate.Name = "txtProcessEndDate";
            this.txtProcessEndDate.Size = new System.Drawing.Size(100, 22);
            this.txtProcessEndDate.TabIndex = 13;
            // 
            // frm_master_process
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(614, 133);
            this.Controls.Add(this.txtProcessEndDate);
            this.Controls.Add(this.lblStatus);
            this.Controls.Add(this.statusStripProcess);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.txtProcessDate);
            this.Controls.Add(this.btnProcess);
            this.Name = "frm_master_process";
            this.Text = "Final Data Processing";
            this.statusStripProcess.ResumeLayout(false);
            this.statusStripProcess.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnProcess;
        private System.Windows.Forms.DateTimePicker txtProcessDate;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.StatusStrip statusStripProcess;
        private System.Windows.Forms.ToolStripStatusLabel labelFinalProcessStatus;
        private System.Windows.Forms.Label lblStatus;
        private System.Windows.Forms.DateTimePicker txtProcessEndDate;
    }
}