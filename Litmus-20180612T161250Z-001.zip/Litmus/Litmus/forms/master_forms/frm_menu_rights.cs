﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Litmus.classes;

namespace Litmus.forms.master_forms
{
    public partial class frm_menu_rights : Form
    {
        DbHelper dbHelper = new DbHelper();
        public frm_menu_rights()
        {
            InitializeComponent();
            bindMasterMenuList();
        }
        public void bindMasterMenuList()
        {
            ddlMasterMenuList.DataSource = dbHelper.getMasterMenuList();
            ddlMasterMenuList.DisplayMember = "mm_name";
            ddlMasterMenuList.ValueMember = "mm_code";
        }
        private void ddlMasterMenuList_SelectedIndexChanged(object sender, EventArgs e)
        {
            //bingSubMenuRights(ddlMasterMenuList.SelectedIndex);

        }
        public void bindSubMenuRights(int mainMenuCode)
        {
           // dataGridView1.DataSource = dbHelper.getMenuRightsOptions(mainMenuCode,textBox1.Text);   
        }

       
    }
}
