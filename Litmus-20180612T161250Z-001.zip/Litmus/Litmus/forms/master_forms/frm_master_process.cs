﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Diagnostics;


namespace Litmus.forms.master_forms
{
    
    public partial class frm_master_process : Form
    {
        classes.bihourly_entry_logic biHourlyLogic = new classes.bihourly_entry_logic();
        classes.process_ledger process_leder_data = new classes.process_ledger();
        classes.master_parameter_logic masterParam = new classes.master_parameter_logic();
        classes.generalFunctions genFunc = new classes.generalFunctions();

        
        public frm_master_process()
        {
            InitializeComponent();
            txtProcessDate.Text = masterParam.processDate;
            txtProcessEndDate.Text = masterParam.processDate;
        }

        private async void btnProcess_Click(object sender, EventArgs e)
        {
            bool is_data_exists = process_leder_data.data_exist_for_date(txtProcessDate.Text, txtProcessEndDate.Text);
             if (validate_process_date(DateTime.Parse(txtProcessDate.Text), DateTime.Parse(txtProcessEndDate.Text)) == true)
            {
                if (is_data_exists == true)
                {
                    DialogResult dialog_reprocess = MessageBox.Show("Data is already processed for the date.\nDo you want to re-process?", "Warning", MessageBoxButtons.YesNo, MessageBoxIcon.Warning, MessageBoxDefaultButton.Button2);
                    if (dialog_reprocess == DialogResult.Yes)
                    {
                        DialogResult confirm_reporcess = MessageBox.Show("If you re-process for this date, previous data will be vanished.\nDo you still want to continue?", "Confirm to continue", MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2);
                        if (confirm_reporcess == DialogResult.Yes)
                        {
                            //if (Convert.ToDateTime(txtProcessDate.Text.ToString()) != Convert.ToDateTime(masterParam.processDate))
                            //{
                            //    MessageBox.Show("Check your process date", "Wrong date selected", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                            //}
                            //else
                            //{
                            Task task = new Task(processData);
                            Process currentProcess = Process.GetCurrentProcess();
                            task.Start();
                            await task;
                            //}
                        }
                    }
                
                }
                else
                {
                    //if (Convert.ToDateTime(txtProcessDate.Text.ToString()) != Convert.ToDateTime(masterParam.processDate))
                    //{
                    //    MessageBox.Show("Check your process date", "Wrong date selected", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                    //}
                    //else
                    //{
                    Task task = new Task(processData);
                    task.Start();

                    await task;
                    MessageBox.Show("Process Complete", "Done!", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    //}

                }
            }
            else
            {
                MessageBox.Show("Invalid selection of dates", "Invalid Dates", MessageBoxButtons.OK, MessageBoxIcon.Hand);
            }
        }

        private bool validate_process_date( DateTime process_start_date, DateTime process_end_date)
        {
         
   
            bool date_validated = false;
            DateTime season_start_date = Convert.ToDateTime(masterParam.crushingStartDate);
            DateTime process_date = Convert.ToDateTime(masterParam.processDate);
            if (((process_start_date < season_start_date) || (process_end_date > process_date) || (process_end_date < season_start_date) || (process_end_date > process_date) || (process_start_date > process_end_date))== false)
            {
                date_validated = true;
            }
           
            else
            {
                date_validated = false;
            }

            return date_validated;
        }

        private void processData()
        {
            
            //process_leder_data.delete_data_for_date(txtProcessDate.Text);

            //process_leder_data.transfer_ledgerData(txtProcessDate.Text);
           
                process_leder_data.transfer_ledger_data_multiple_dates(txtProcessDate.Text, txtProcessEndDate.Text, lblStatus);
            
        }
    }
}
