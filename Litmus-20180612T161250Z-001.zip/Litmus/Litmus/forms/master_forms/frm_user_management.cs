﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Litmus.classes;
namespace Litmus.forms.master_forms
{
    public partial class frm_user_management : Form
    {
        generalFunctions genFunc = new generalFunctions();
        DbHelper dbHelper = new DbHelper();
        user_management_logic userLogic = new user_management_logic();
        string formname = "";
        bool is_user_logged_in = false;
        public frm_user_management()
        {
            InitializeComponent();
            tabCreateUser.Controls.Add(toolStrip());
            lblUserCode.Text = genFunc.userCode;
            formname= this.Name.ToString();
            txtReleaseUserCode.LostFocus += new EventHandler(getUserSessionDetails);
            txtModiUserCode.LostFocus += new EventHandler(getUserDetails);
           
        }

        #region Customised Tool Strip for user
        ///<summary>
        /// Creating a toolstrip containg 'Create','Read','Update' and 'Delete' buttons these buttons will be enabled/disabled based on user rights
        /// CRUD means all rights
        ///</sumary>
        ///
        public ToolStrip toolStrip()
        {
            ToolStrip topToolStrip = new ToolStrip();
            string rights = genFunc.userRights;
            
            if (rights.Contains("R"))
            {
                ToolStripMenuItem queryMenuItem = new ToolStripMenuItem("Query", null, new EventHandler(QueryClick), "Query");
                ToolStripMenuItem queryExecuteMenuItem = new ToolStripMenuItem("Execute", null, new EventHandler(ExecutQuery), "ExecuteQuery");
                topToolStrip.Items.Add(queryMenuItem);
                topToolStrip.Items.Add(queryExecuteMenuItem);
                topToolStrip.Items.Add(new ToolStripSeparator());
            }
            if (rights.Contains("C"))
            {
                ToolStripMenuItem saveRecordMenuItem = new ToolStripMenuItem("Save", null, new EventHandler(saveRecords), "Save Records");
                topToolStrip.Items.Add(saveRecordMenuItem);
            }
            if (rights.Contains("U"))
            {
                ToolStripMenuItem updateRecordMenuItem = new ToolStripMenuItem("Update", null, new EventHandler(updateRecords), "Update Records");
                topToolStrip.Items.Add(updateRecordMenuItem);
            }
            if (rights.Contains("D"))
            {
                ToolStripMenuItem deleteRecordMenuItem = new ToolStripMenuItem("Delete", null, new EventHandler(deleteRecords), "Delete Records");
                topToolStrip.Items.Add(deleteRecordMenuItem);
            }
  

            topToolStrip.Dock = DockStyle.Top;
            return topToolStrip;
        }
        public void QueryClick(object sender, EventArgs e)
        {
            MessageBox.Show("Query Clicked");
        }
        public void ExecutQuery(object sender, EventArgs e)
        {
            MessageBox.Show("Query Executed");
        }
        public void saveRecords(object sender, EventArgs e)
        {

            string firstname = txtFirstname.Text.Trim();
            string lastname = txtLastname.Text.Trim();
            string userCode = txtUserCode.Text.Trim();
            bool isActive =true;
            string password = txtPassword.Text.Trim();
            string mobileNo = txtMobileNo.Text.Trim();
            string emailAddress = txtEmailAddress.Text.Trim();
            if (radioIsActiveFalse.Checked == true)
            {
                isActive = false;
            }


            if (txtPassword.Text == txtReTypePassword.Text)
            {
                dbHelper.insertUser(firstname,lastname,userCode,isActive,password,mobileNo,emailAddress);
            }
            else
            {
                MessageBox.Show("Password mismatch", "Password mismatch", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }
        }
        public void updateRecords(object sender, EventArgs e)
        {
            MessageBox.Show("update Executed");
        }
        public void deleteRecords(object sender, EventArgs e)
        {
            MessageBox.Show("delete Executed");
        }


        #endregion

        private void getUserSessionDetails(object sender, EventArgs e)
        {
             DataTable dt = null;
            string user_code = txtReleaseUserCode.Text.ToString();
            dt = genFunc.user_session_check(user_code);
            if (dt != null && dt.Rows.Count > 0)
            {
                txtReleaseHostName.Text = dt.Rows[0]["host_name"].ToString();
                txtReleaseIpAddress.Text = dt.Rows[0]["ip_address"].ToString();
                txtReleaseUserName.Text = dt.Rows[0]["user_name"].ToString();
                is_user_logged_in = true;
            }
            else
            {
                MessageBox.Show("User is not logged-in at any machine", "Message", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                is_user_logged_in = false;
            }
        }

        private void btnRelease_Click(object sender, EventArgs e)
        {
            if (txtReleaseUserCode.Text != string.Empty && is_user_logged_in == true)
            {
                genFunc.user_session_end(txtReleaseUserCode.Text.Trim(),false);
                
            }
        }

        private void getUserDetails(object sender, EventArgs e)
        {
            DataTable dt = userLogic.getUserDetails(txtModiUserCode.Text);
            bool user_active = false, user_admin = false, allow_multilogin = false;
            if (dt != null && dt.Rows.Count == 1)
            {
                txtModiUserName.Text = dt.Rows[0]["user_name"].ToString();
                txtModMobileNo.Text = dt.Rows[0]["mobile_no"].ToString();
                txtModiEmail.Text = dt.Rows[0]["email_address"].ToString();

                if (dt.Rows[0]["isActive"].ToString() == "true")
                {
                    radioModiIsActiveYes.Checked = true;
                }
                else
                {
                    radioModiIsActiveNo.Checked = true;
                }

                if(dt.Rows[0]["is_admin"].ToString() == "true")
                {
                    radioModiIsAdminYes.Checked = true;
                }
                else
                {
                    radioModiIsAdminNo.Checked = true;
                }

                if (dt.Rows[0]["multiple_login"].ToString() == "true")
                {
                    radioModiMultiLoginYes.Checked = true;
                }
                else
                {
                    radioModiMultiLoginNo.Checked = true;
                }

            }
        }
    }
}
