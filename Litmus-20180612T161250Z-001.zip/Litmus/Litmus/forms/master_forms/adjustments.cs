﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Litmus.classes;
using System.Data.SqlClient;
namespace Litmus.forms.master_forms
{
    public partial class adjustments : Form
    {
        generalFunctions genFunc = new generalFunctions();
        ExceptionHelper expHelper = new ExceptionHelper();
        adjustment_logic adjustmentLogic = new adjustment_logic();

        string trans_date, crtd_by, updt_by;
        decimal a_sulpher, a_lime, a_phosphoric_acid, a_color_reducer, a_megnafloe, a_lub_oil, a_viscosity_reducer, a_biocide, a_lub_greace,
            a_boiler_chemical, a_estimated_sugar, a_estimated_molasses;

        bool is_data_exist_for_date = false;
        public adjustments()
        {
            InitializeComponent();
            txTransDate.LostFocus += new EventHandler(transaction_date_changed);
            trans_date = txTransDate.Text;
            is_data_exist_for_date = adjustmentLogic.data_exists_for_the_day(trans_date);
        }

        private void value_assignment()
        {
            trans_date = txTransDate.Text;
            crtd_by = genFunc.userCode;
            updt_by = genFunc.userCode;
            a_sulpher = Convert.ToDecimal(txtStoreSulpher.Text);
            a_lime = Convert.ToDecimal(txtStoreLime.Text);
            a_phosphoric_acid = Convert.ToDecimal(txtStorePhosphoric.Text);
            a_color_reducer = Convert.ToDecimal(txtStoreColorReducer.Text);
            a_megnafloe = Convert.ToDecimal(txtStoreMegnafloe.Text);
            a_lub_oil = Convert.ToDecimal(txtStoreLubOil.Text);
            a_viscosity_reducer = Convert.ToDecimal(txtStoreViscocty.Text);
            a_biocide = Convert.ToDecimal(txtStoreBioeide.Text);
            a_lub_greace = Convert.ToDecimal(txtStoreLubGreece.Text);
            a_boiler_chemical = Convert.ToDecimal(txtStoreBoilerChemical.Text);
            a_estimated_sugar = Convert.ToDecimal(txtEstimatedSugar.Text);
            a_estimated_molasses = Convert.ToDecimal(txtEstimatedMolasses.Text);
        }
        private void btnSave_Click(object sender, EventArgs e)
        {
            value_assignment();
            switch (is_data_exist_for_date)
            {
                case true:
                    adjustmentLogic.update_adjustment_records(trans_date, a_sulpher, a_lime, a_phosphoric_acid, a_color_reducer, a_megnafloe
                     , a_lub_greace, a_viscosity_reducer, a_biocide, a_lub_greace, a_boiler_chemical, a_estimated_sugar
                     , a_estimated_molasses, 1, updt_by);
                break;
                case false:
                     
                        try
                        {
                            adjustmentLogic.insert_adjustment_records(trans_date, a_sulpher, a_lime, a_phosphoric_acid, a_color_reducer, a_megnafloe
                                , a_lub_greace, a_viscosity_reducer, a_biocide, a_lub_greace, a_boiler_chemical, a_estimated_sugar
                                , a_estimated_molasses, 1, crtd_by);
                        }
                        catch (SqlException ex)
                        {
                            MessageBox.Show("Error occured while inserting records for to-date adjustment.\n"+ex.Message, "Data Insertion Error", MessageBoxButtons.OK, MessageBoxIcon.Error);

                        }
                break;
                
            }
           
        }

        private void transaction_date_changed(object sender, EventArgs e)
        {
            is_data_exist_for_date = adjustmentLogic.data_exists_for_the_day(txTransDate.Text);
            txtStoreSulpher.Text = adjustmentLogic.a_suplpher.ToString();
            txtStoreLime.Text = adjustmentLogic.a_lime.ToString();
            txtStorePhosphoric.Text = adjustmentLogic.a_phosphoric_acid.ToString();
            txtStoreColorReducer.Text = adjustmentLogic.a_color_reducer.ToString();
            txtStoreMegnafloe.Text = adjustmentLogic.a_megnafloe.ToString();
            txtStoreLubOil.Text = adjustmentLogic.a_lub_oil.ToString();
            txtStoreViscocty.Text = adjustmentLogic.a_viscosity_reducer.ToString();
            txtStoreBioeide.Text = adjustmentLogic.a_biocide.ToString();
            txtStoreLubGreece.Text = adjustmentLogic.a_lub_greace.ToString();
            txtStoreBoilerChemical.Text = adjustmentLogic.a_boiler_chemical.ToString();
            txtEstimatedSugar.Text = adjustmentLogic.a_estimated_sugar.ToString();
            txtEstimatedMolasses.Text = adjustmentLogic.a_estimated_molasses.ToString();

        }
     
    }
}
