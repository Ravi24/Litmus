﻿namespace Litmus.forms.master_forms
{
    partial class frm_user_management
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tabUserCreation = new System.Windows.Forms.TabControl();
            this.tabCreateUser = new System.Windows.Forms.TabPage();
            this.lblUserCode = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.radioIsActiveFalse = new System.Windows.Forms.RadioButton();
            this.radioIsActiveTrue = new System.Windows.Forms.RadioButton();
            this.label3 = new System.Windows.Forms.Label();
            this.txtPassword = new System.Windows.Forms.TextBox();
            this.txtEmailAddress = new System.Windows.Forms.TextBox();
            this.txtReTypePassword = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.txtMobileNo = new System.Windows.Forms.TextBox();
            this.txtUserCode = new System.Windows.Forms.TextBox();
            this.txtLastname = new System.Windows.Forms.TextBox();
            this.txtFirstname = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.lblUsername = new System.Windows.Forms.Label();
            this.tabModifyUser = new System.Windows.Forms.TabPage();
            this.tabPageReleaseUser = new System.Windows.Forms.TabPage();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.btnRelease = new System.Windows.Forms.Button();
            this.txtReleaseIpAddress = new System.Windows.Forms.TextBox();
            this.txtReleaseHostName = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.txtReleaseUserName = new System.Windows.Forms.TextBox();
            this.txtReleaseUserCode = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.label11 = new System.Windows.Forms.Label();
            this.txtModiUserCode = new System.Windows.Forms.TextBox();
            this.txtModiUserName = new System.Windows.Forms.TextBox();
            this.txtModiNewPwd = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.txtModiConfirmPassword = new System.Windows.Forms.TextBox();
            this.label14 = new System.Windows.Forms.Label();
            this.txtModMobileNo = new System.Windows.Forms.TextBox();
            this.lblModiEmail = new System.Windows.Forms.Label();
            this.txtModiEmail = new System.Windows.Forms.TextBox();
            this.label16 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.panel3 = new System.Windows.Forms.Panel();
            this.radioModiIsActiveYes = new System.Windows.Forms.RadioButton();
            this.radioModiIsActiveNo = new System.Windows.Forms.RadioButton();
            this.radioModiIsAdminNo = new System.Windows.Forms.RadioButton();
            this.radioModiIsAdminYes = new System.Windows.Forms.RadioButton();
            this.btnModiSave = new System.Windows.Forms.Button();
            this.panel4 = new System.Windows.Forms.Panel();
            this.radioModiMultiLoginNo = new System.Windows.Forms.RadioButton();
            this.radioModiMultiLoginYes = new System.Windows.Forms.RadioButton();
            this.label15 = new System.Windows.Forms.Label();
            this.tabUserCreation.SuspendLayout();
            this.tabCreateUser.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.panel1.SuspendLayout();
            this.tabModifyUser.SuspendLayout();
            this.tabPageReleaseUser.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel3.SuspendLayout();
            this.panel4.SuspendLayout();
            this.SuspendLayout();
            // 
            // tabUserCreation
            // 
            this.tabUserCreation.Controls.Add(this.tabCreateUser);
            this.tabUserCreation.Controls.Add(this.tabModifyUser);
            this.tabUserCreation.Controls.Add(this.tabPageReleaseUser);
            this.tabUserCreation.Location = new System.Drawing.Point(13, 13);
            this.tabUserCreation.Name = "tabUserCreation";
            this.tabUserCreation.SelectedIndex = 0;
            this.tabUserCreation.Size = new System.Drawing.Size(682, 317);
            this.tabUserCreation.TabIndex = 0;
            // 
            // tabCreateUser
            // 
            this.tabCreateUser.Controls.Add(this.lblUserCode);
            this.tabCreateUser.Controls.Add(this.label8);
            this.tabCreateUser.Controls.Add(this.groupBox1);
            this.tabCreateUser.Location = new System.Drawing.Point(4, 25);
            this.tabCreateUser.Name = "tabCreateUser";
            this.tabCreateUser.Padding = new System.Windows.Forms.Padding(3);
            this.tabCreateUser.Size = new System.Drawing.Size(674, 288);
            this.tabCreateUser.TabIndex = 0;
            this.tabCreateUser.Text = "Create User";
            this.tabCreateUser.UseVisualStyleBackColor = true;
            // 
            // lblUserCode
            // 
            this.lblUserCode.AutoSize = true;
            this.lblUserCode.Location = new System.Drawing.Point(119, 260);
            this.lblUserCode.Name = "lblUserCode";
            this.lblUserCode.Size = new System.Drawing.Size(75, 17);
            this.lblUserCode.TabIndex = 3;
            this.lblUserCode.Text = "User Code";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(12, 260);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(101, 17);
            this.label8.TabIndex = 2;
            this.label8.Text = "Current User : ";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.panel1);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.txtPassword);
            this.groupBox1.Controls.Add(this.txtEmailAddress);
            this.groupBox1.Controls.Add(this.txtReTypePassword);
            this.groupBox1.Controls.Add(this.label7);
            this.groupBox1.Controls.Add(this.txtMobileNo);
            this.groupBox1.Controls.Add(this.txtUserCode);
            this.groupBox1.Controls.Add(this.txtLastname);
            this.groupBox1.Controls.Add(this.txtFirstname);
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.lblUsername);
            this.groupBox1.Location = new System.Drawing.Point(3, 38);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(658, 219);
            this.groupBox1.TabIndex = 1;
            this.groupBox1.TabStop = false;
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.radioIsActiveFalse);
            this.panel1.Controls.Add(this.radioIsActiveTrue);
            this.panel1.Location = new System.Drawing.Point(437, 85);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(189, 28);
            this.panel1.TabIndex = 2;
            // 
            // radioIsActiveFalse
            // 
            this.radioIsActiveFalse.AutoSize = true;
            this.radioIsActiveFalse.Location = new System.Drawing.Point(123, 4);
            this.radioIsActiveFalse.Name = "radioIsActiveFalse";
            this.radioIsActiveFalse.Size = new System.Drawing.Size(47, 21);
            this.radioIsActiveFalse.TabIndex = 1;
            this.radioIsActiveFalse.Text = "No";
            this.radioIsActiveFalse.UseVisualStyleBackColor = true;
            // 
            // radioIsActiveTrue
            // 
            this.radioIsActiveTrue.AutoSize = true;
            this.radioIsActiveTrue.Checked = true;
            this.radioIsActiveTrue.Location = new System.Drawing.Point(14, 4);
            this.radioIsActiveTrue.Name = "radioIsActiveTrue";
            this.radioIsActiveTrue.Size = new System.Drawing.Size(53, 21);
            this.radioIsActiveTrue.TabIndex = 4;
            this.radioIsActiveTrue.TabStop = true;
            this.radioIsActiveTrue.Text = "Yes";
            this.radioIsActiveTrue.UseVisualStyleBackColor = true;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(9, 131);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(69, 17);
            this.label3.TabIndex = 3;
            this.label3.Text = "Password";
            // 
            // txtPassword
            // 
            this.txtPassword.Location = new System.Drawing.Point(84, 128);
            this.txtPassword.Name = "txtPassword";
            this.txtPassword.Size = new System.Drawing.Size(189, 22);
            this.txtPassword.TabIndex = 5;
            // 
            // txtEmailAddress
            // 
            this.txtEmailAddress.Location = new System.Drawing.Point(437, 164);
            this.txtEmailAddress.Name = "txtEmailAddress";
            this.txtEmailAddress.Size = new System.Drawing.Size(189, 22);
            this.txtEmailAddress.TabIndex = 8;
            // 
            // txtReTypePassword
            // 
            this.txtReTypePassword.Location = new System.Drawing.Point(437, 123);
            this.txtReTypePassword.Name = "txtReTypePassword";
            this.txtReTypePassword.Size = new System.Drawing.Size(189, 22);
            this.txtReTypePassword.TabIndex = 6;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(305, 127);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(123, 17);
            this.label7.TabIndex = 13;
            this.label7.Text = "Re-type Password";
            // 
            // txtMobileNo
            // 
            this.txtMobileNo.Location = new System.Drawing.Point(84, 171);
            this.txtMobileNo.Name = "txtMobileNo";
            this.txtMobileNo.Size = new System.Drawing.Size(189, 22);
            this.txtMobileNo.TabIndex = 7;
            // 
            // txtUserCode
            // 
            this.txtUserCode.Location = new System.Drawing.Point(84, 85);
            this.txtUserCode.Name = "txtUserCode";
            this.txtUserCode.Size = new System.Drawing.Size(189, 22);
            this.txtUserCode.TabIndex = 3;
            // 
            // txtLastname
            // 
            this.txtLastname.Location = new System.Drawing.Point(434, 42);
            this.txtLastname.Name = "txtLastname";
            this.txtLastname.Size = new System.Drawing.Size(189, 22);
            this.txtLastname.TabIndex = 2;
            // 
            // txtFirstname
            // 
            this.txtFirstname.Location = new System.Drawing.Point(84, 42);
            this.txtFirstname.Name = "txtFirstname";
            this.txtFirstname.Size = new System.Drawing.Size(189, 22);
            this.txtFirstname.TabIndex = 1;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(330, 169);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(98, 17);
            this.label6.TabIndex = 6;
            this.label6.Text = "Email Address";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(7, 174);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(71, 17);
            this.label5.TabIndex = 5;
            this.label5.Text = "Mobile No";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(368, 91);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(60, 17);
            this.label4.TabIndex = 4;
            this.label4.Text = "Is Active";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(3, 88);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(75, 17);
            this.label2.TabIndex = 2;
            this.label2.Text = "User Code";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(352, 45);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(76, 17);
            this.label1.TabIndex = 1;
            this.label1.Text = "Last Name";
            // 
            // lblUsername
            // 
            this.lblUsername.AutoSize = true;
            this.lblUsername.Location = new System.Drawing.Point(2, 45);
            this.lblUsername.Name = "lblUsername";
            this.lblUsername.Size = new System.Drawing.Size(76, 17);
            this.lblUsername.TabIndex = 0;
            this.lblUsername.Text = "First Name";
            // 
            // tabModifyUser
            // 
            this.tabModifyUser.Controls.Add(this.groupBox4);
            this.tabModifyUser.Controls.Add(this.groupBox3);
            this.tabModifyUser.Location = new System.Drawing.Point(4, 25);
            this.tabModifyUser.Name = "tabModifyUser";
            this.tabModifyUser.Padding = new System.Windows.Forms.Padding(3);
            this.tabModifyUser.Size = new System.Drawing.Size(674, 288);
            this.tabModifyUser.TabIndex = 1;
            this.tabModifyUser.Text = "Modify User";
            this.tabModifyUser.UseVisualStyleBackColor = true;
            // 
            // tabPageReleaseUser
            // 
            this.tabPageReleaseUser.Controls.Add(this.groupBox2);
            this.tabPageReleaseUser.Location = new System.Drawing.Point(4, 25);
            this.tabPageReleaseUser.Name = "tabPageReleaseUser";
            this.tabPageReleaseUser.Padding = new System.Windows.Forms.Padding(3);
            this.tabPageReleaseUser.Size = new System.Drawing.Size(674, 288);
            this.tabPageReleaseUser.TabIndex = 2;
            this.tabPageReleaseUser.Text = "Release User";
            this.tabPageReleaseUser.UseVisualStyleBackColor = true;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.btnRelease);
            this.groupBox2.Controls.Add(this.txtReleaseIpAddress);
            this.groupBox2.Controls.Add(this.txtReleaseHostName);
            this.groupBox2.Controls.Add(this.label10);
            this.groupBox2.Controls.Add(this.txtReleaseUserName);
            this.groupBox2.Controls.Add(this.txtReleaseUserCode);
            this.groupBox2.Controls.Add(this.label9);
            this.groupBox2.Location = new System.Drawing.Point(6, 6);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(662, 276);
            this.groupBox2.TabIndex = 0;
            this.groupBox2.TabStop = false;
            // 
            // btnRelease
            // 
            this.btnRelease.Location = new System.Drawing.Point(479, 146);
            this.btnRelease.Name = "btnRelease";
            this.btnRelease.Size = new System.Drawing.Size(136, 33);
            this.btnRelease.TabIndex = 6;
            this.btnRelease.Text = "Release";
            this.btnRelease.UseVisualStyleBackColor = true;
            this.btnRelease.Click += new System.EventHandler(this.btnRelease_Click);
            // 
            // txtReleaseIpAddress
            // 
            this.txtReleaseIpAddress.Location = new System.Drawing.Point(351, 107);
            this.txtReleaseIpAddress.Name = "txtReleaseIpAddress";
            this.txtReleaseIpAddress.ReadOnly = true;
            this.txtReleaseIpAddress.Size = new System.Drawing.Size(264, 22);
            this.txtReleaseIpAddress.TabIndex = 5;
            // 
            // txtReleaseHostName
            // 
            this.txtReleaseHostName.Location = new System.Drawing.Point(155, 107);
            this.txtReleaseHostName.Name = "txtReleaseHostName";
            this.txtReleaseHostName.ReadOnly = true;
            this.txtReleaseHostName.Size = new System.Drawing.Size(173, 22);
            this.txtReleaseHostName.TabIndex = 4;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(37, 110);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(108, 17);
            this.label10.TabIndex = 3;
            this.label10.Text = "Machine Details";
            // 
            // txtReleaseUserName
            // 
            this.txtReleaseUserName.Location = new System.Drawing.Point(351, 65);
            this.txtReleaseUserName.Name = "txtReleaseUserName";
            this.txtReleaseUserName.ReadOnly = true;
            this.txtReleaseUserName.Size = new System.Drawing.Size(264, 22);
            this.txtReleaseUserName.TabIndex = 2;
            // 
            // txtReleaseUserCode
            // 
            this.txtReleaseUserCode.Location = new System.Drawing.Point(155, 65);
            this.txtReleaseUserCode.Name = "txtReleaseUserCode";
            this.txtReleaseUserCode.Size = new System.Drawing.Size(173, 22);
            this.txtReleaseUserCode.TabIndex = 1;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(37, 68);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(75, 17);
            this.label9.TabIndex = 0;
            this.label9.Text = "User Code";
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.txtModiUserName);
            this.groupBox3.Controls.Add(this.txtModiUserCode);
            this.groupBox3.Controls.Add(this.label11);
            this.groupBox3.Location = new System.Drawing.Point(6, 6);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(662, 52);
            this.groupBox3.TabIndex = 0;
            this.groupBox3.TabStop = false;
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.panel4);
            this.groupBox4.Controls.Add(this.label15);
            this.groupBox4.Controls.Add(this.btnModiSave);
            this.groupBox4.Controls.Add(this.panel3);
            this.groupBox4.Controls.Add(this.panel2);
            this.groupBox4.Controls.Add(this.label17);
            this.groupBox4.Controls.Add(this.label16);
            this.groupBox4.Controls.Add(this.lblModiEmail);
            this.groupBox4.Controls.Add(this.txtModiEmail);
            this.groupBox4.Controls.Add(this.label14);
            this.groupBox4.Controls.Add(this.txtModMobileNo);
            this.groupBox4.Controls.Add(this.label13);
            this.groupBox4.Controls.Add(this.txtModiConfirmPassword);
            this.groupBox4.Controls.Add(this.label12);
            this.groupBox4.Controls.Add(this.txtModiNewPwd);
            this.groupBox4.Location = new System.Drawing.Point(6, 61);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(662, 224);
            this.groupBox4.TabIndex = 1;
            this.groupBox4.TabStop = false;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(6, 18);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(75, 17);
            this.label11.TabIndex = 0;
            this.label11.Text = "User Code";
            // 
            // txtModiUserCode
            // 
            this.txtModiUserCode.Location = new System.Drawing.Point(87, 15);
            this.txtModiUserCode.Name = "txtModiUserCode";
            this.txtModiUserCode.Size = new System.Drawing.Size(200, 22);
            this.txtModiUserCode.TabIndex = 1;
            // 
            // txtModiUserName
            // 
            this.txtModiUserName.Location = new System.Drawing.Point(293, 15);
            this.txtModiUserName.Name = "txtModiUserName";
            this.txtModiUserName.ReadOnly = true;
            this.txtModiUserName.Size = new System.Drawing.Size(295, 22);
            this.txtModiUserName.TabIndex = 2;
            // 
            // txtModiNewPwd
            // 
            this.txtModiNewPwd.Location = new System.Drawing.Point(136, 16);
            this.txtModiNewPwd.Name = "txtModiNewPwd";
            this.txtModiNewPwd.PasswordChar = '*';
            this.txtModiNewPwd.Size = new System.Drawing.Size(175, 22);
            this.txtModiNewPwd.TabIndex = 0;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(18, 19);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(100, 17);
            this.label12.TabIndex = 1;
            this.label12.Text = "New Password";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(328, 19);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(121, 17);
            this.label13.TabIndex = 3;
            this.label13.Text = "Confirm Password";
            // 
            // txtModiConfirmPassword
            // 
            this.txtModiConfirmPassword.Location = new System.Drawing.Point(468, 16);
            this.txtModiConfirmPassword.Name = "txtModiConfirmPassword";
            this.txtModiConfirmPassword.Size = new System.Drawing.Size(175, 22);
            this.txtModiConfirmPassword.TabIndex = 2;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(43, 61);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(75, 17);
            this.label14.TabIndex = 5;
            this.label14.Text = "Mobile No.";
            // 
            // txtModMobileNo
            // 
            this.txtModMobileNo.Location = new System.Drawing.Point(136, 56);
            this.txtModMobileNo.Name = "txtModMobileNo";
            this.txtModMobileNo.Size = new System.Drawing.Size(175, 22);
            this.txtModMobileNo.TabIndex = 4;
            // 
            // lblModiEmail
            // 
            this.lblModiEmail.AutoSize = true;
            this.lblModiEmail.Location = new System.Drawing.Point(407, 61);
            this.lblModiEmail.Name = "lblModiEmail";
            this.lblModiEmail.Size = new System.Drawing.Size(42, 17);
            this.lblModiEmail.TabIndex = 7;
            this.lblModiEmail.Text = "Email";
            // 
            // txtModiEmail
            // 
            this.txtModiEmail.Location = new System.Drawing.Point(468, 56);
            this.txtModiEmail.Name = "txtModiEmail";
            this.txtModiEmail.Size = new System.Drawing.Size(175, 22);
            this.txtModiEmail.TabIndex = 6;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(58, 103);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(60, 17);
            this.label16.TabIndex = 8;
            this.label16.Text = "Is Active";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(388, 103);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(61, 17);
            this.label17.TabIndex = 9;
            this.label17.Text = "Is Admin";
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.radioModiIsActiveNo);
            this.panel2.Controls.Add(this.radioModiIsActiveYes);
            this.panel2.Location = new System.Drawing.Point(136, 94);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(175, 32);
            this.panel2.TabIndex = 10;
            // 
            // panel3
            // 
            this.panel3.Controls.Add(this.radioModiIsAdminNo);
            this.panel3.Controls.Add(this.radioModiIsAdminYes);
            this.panel3.Location = new System.Drawing.Point(468, 94);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(176, 32);
            this.panel3.TabIndex = 11;
            // 
            // radioModiIsActiveYes
            // 
            this.radioModiIsActiveYes.AutoSize = true;
            this.radioModiIsActiveYes.Location = new System.Drawing.Point(7, 5);
            this.radioModiIsActiveYes.Name = "radioModiIsActiveYes";
            this.radioModiIsActiveYes.Size = new System.Drawing.Size(53, 21);
            this.radioModiIsActiveYes.TabIndex = 12;
            this.radioModiIsActiveYes.TabStop = true;
            this.radioModiIsActiveYes.Text = "Yes";
            this.radioModiIsActiveYes.UseVisualStyleBackColor = true;
            // 
            // radioModiIsActiveNo
            // 
            this.radioModiIsActiveNo.AutoSize = true;
            this.radioModiIsActiveNo.Location = new System.Drawing.Point(93, 5);
            this.radioModiIsActiveNo.Name = "radioModiIsActiveNo";
            this.radioModiIsActiveNo.Size = new System.Drawing.Size(47, 21);
            this.radioModiIsActiveNo.TabIndex = 13;
            this.radioModiIsActiveNo.TabStop = true;
            this.radioModiIsActiveNo.Text = "No";
            this.radioModiIsActiveNo.UseVisualStyleBackColor = true;
            // 
            // radioModiIsAdminNo
            // 
            this.radioModiIsAdminNo.AutoSize = true;
            this.radioModiIsAdminNo.Location = new System.Drawing.Point(93, 6);
            this.radioModiIsAdminNo.Name = "radioModiIsAdminNo";
            this.radioModiIsAdminNo.Size = new System.Drawing.Size(47, 21);
            this.radioModiIsAdminNo.TabIndex = 15;
            this.radioModiIsAdminNo.TabStop = true;
            this.radioModiIsAdminNo.Text = "No";
            this.radioModiIsAdminNo.UseVisualStyleBackColor = true;
            // 
            // radioModiIsAdminYes
            // 
            this.radioModiIsAdminYes.AutoSize = true;
            this.radioModiIsAdminYes.Location = new System.Drawing.Point(7, 6);
            this.radioModiIsAdminYes.Name = "radioModiIsAdminYes";
            this.radioModiIsAdminYes.Size = new System.Drawing.Size(53, 21);
            this.radioModiIsAdminYes.TabIndex = 14;
            this.radioModiIsAdminYes.TabStop = true;
            this.radioModiIsAdminYes.Text = "Yes";
            this.radioModiIsAdminYes.UseVisualStyleBackColor = true;
            // 
            // btnModiSave
            // 
            this.btnModiSave.Location = new System.Drawing.Point(541, 180);
            this.btnModiSave.Name = "btnModiSave";
            this.btnModiSave.Size = new System.Drawing.Size(115, 36);
            this.btnModiSave.TabIndex = 12;
            this.btnModiSave.Text = "&Save";
            this.btnModiSave.UseVisualStyleBackColor = true;
            // 
            // panel4
            // 
            this.panel4.Controls.Add(this.radioModiMultiLoginNo);
            this.panel4.Controls.Add(this.radioModiMultiLoginYes);
            this.panel4.Location = new System.Drawing.Point(136, 143);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(175, 32);
            this.panel4.TabIndex = 14;
            // 
            // radioModiMultiLoginNo
            // 
            this.radioModiMultiLoginNo.AutoSize = true;
            this.radioModiMultiLoginNo.Location = new System.Drawing.Point(93, 5);
            this.radioModiMultiLoginNo.Name = "radioModiMultiLoginNo";
            this.radioModiMultiLoginNo.Size = new System.Drawing.Size(47, 21);
            this.radioModiMultiLoginNo.TabIndex = 13;
            this.radioModiMultiLoginNo.TabStop = true;
            this.radioModiMultiLoginNo.Text = "No";
            this.radioModiMultiLoginNo.UseVisualStyleBackColor = true;
            // 
            // radioModiMultiLoginYes
            // 
            this.radioModiMultiLoginYes.AutoSize = true;
            this.radioModiMultiLoginYes.Location = new System.Drawing.Point(7, 5);
            this.radioModiMultiLoginYes.Name = "radioModiMultiLoginYes";
            this.radioModiMultiLoginYes.Size = new System.Drawing.Size(53, 21);
            this.radioModiMultiLoginYes.TabIndex = 12;
            this.radioModiMultiLoginYes.TabStop = true;
            this.radioModiMultiLoginYes.Text = "Yes";
            this.radioModiMultiLoginYes.UseVisualStyleBackColor = true;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(6, 150);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(112, 17);
            this.label15.TabIndex = 13;
            this.label15.Text = "Allow Multi Login";
            // 
            // frm_user_management
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(697, 342);
            this.Controls.Add(this.tabUserCreation);
            this.Name = "frm_user_management";
            this.Text = "User Management";
            this.tabUserCreation.ResumeLayout(false);
            this.tabCreateUser.ResumeLayout(false);
            this.tabCreateUser.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.tabModifyUser.ResumeLayout(false);
            this.tabPageReleaseUser.ResumeLayout(false);
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl tabUserCreation;
        private System.Windows.Forms.TabPage tabCreateUser;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtPassword;
        private System.Windows.Forms.TextBox txtEmailAddress;
        private System.Windows.Forms.TextBox txtReTypePassword;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox txtMobileNo;
        private System.Windows.Forms.TextBox txtUserCode;
        private System.Windows.Forms.TextBox txtLastname;
        private System.Windows.Forms.TextBox txtFirstname;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label lblUsername;
        private System.Windows.Forms.TabPage tabModifyUser;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.RadioButton radioIsActiveFalse;
        private System.Windows.Forms.RadioButton radioIsActiveTrue;
        private System.Windows.Forms.Label lblUserCode;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TabPage tabPageReleaseUser;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.TextBox txtReleaseUserName;
        private System.Windows.Forms.TextBox txtReleaseUserCode;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Button btnRelease;
        private System.Windows.Forms.TextBox txtReleaseIpAddress;
        private System.Windows.Forms.TextBox txtReleaseHostName;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.TextBox txtModiUserCode;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox txtModiUserName;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label lblModiEmail;
        private System.Windows.Forms.TextBox txtModiEmail;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.TextBox txtModMobileNo;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.TextBox txtModiConfirmPassword;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox txtModiNewPwd;
        private System.Windows.Forms.RadioButton radioModiIsAdminNo;
        private System.Windows.Forms.RadioButton radioModiIsAdminYes;
        private System.Windows.Forms.RadioButton radioModiIsActiveNo;
        private System.Windows.Forms.RadioButton radioModiIsActiveYes;
        private System.Windows.Forms.Button btnModiSave;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.RadioButton radioModiMultiLoginNo;
        private System.Windows.Forms.RadioButton radioModiMultiLoginYes;
        private System.Windows.Forms.Label label15;
    }
}