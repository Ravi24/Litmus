﻿namespace Litmus.forms.master_forms
{
    partial class frm_master_parameters
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            this.btnApply = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.dataGridSubMenuRights = new System.Windows.Forms.DataGridView();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.ddlMasterMenuList = new System.Windows.Forms.ComboBox();
            this.label15 = new System.Windows.Forms.Label();
            this.lblUserName = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.txtUserCode = new System.Windows.Forms.TextBox();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.txtSignName5 = new System.Windows.Forms.TextBox();
            this.txtDesignition5 = new System.Windows.Forms.TextBox();
            this.txtSignName4 = new System.Windows.Forms.TextBox();
            this.txtDesignition4 = new System.Windows.Forms.TextBox();
            this.txtSignName3 = new System.Windows.Forms.TextBox();
            this.txtDesignition3 = new System.Windows.Forms.TextBox();
            this.txtSignName2 = new System.Windows.Forms.TextBox();
            this.txtDesignition2 = new System.Windows.Forms.TextBox();
            this.txtSignName1 = new System.Windows.Forms.TextBox();
            this.txtDesignition1 = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.txtOldMillCapacity = new System.Windows.Forms.TextBox();
            this.txtNewMillCapacity = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.checkBoxOldMill = new System.Windows.Forms.CheckBox();
            this.checkBoxNewMill = new System.Windows.Forms.CheckBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.txtReportTime = new System.Windows.Forms.MaskedTextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.dateTimeProcessDate = new System.Windows.Forms.DateTimePicker();
            this.dateTimeEntryDate = new System.Windows.Forms.DateTimePicker();
            this.txtDayHours = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.ddlCrushingSeason = new System.Windows.Forms.ComboBox();
            this.label5 = new System.Windows.Forms.Label();
            this.dateTimeCrushingEndDate = new System.Windows.Forms.DateTimePicker();
            this.dateTimeCrushingStartDate = new System.Windows.Forms.DateTimePicker();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.txtCompanyName = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.groupBox6 = new System.Windows.Forms.GroupBox();
            this.tabPage2.SuspendLayout();
            this.groupBox5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridSubMenuRights)).BeginInit();
            this.groupBox2.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.tabControl1.SuspendLayout();
            this.tabPage3.SuspendLayout();
            this.SuspendLayout();
            // 
            // btnApply
            // 
            this.btnApply.Location = new System.Drawing.Point(716, 562);
            this.btnApply.Name = "btnApply";
            this.btnApply.Size = new System.Drawing.Size(130, 26);
            this.btnApply.TabIndex = 1;
            this.btnApply.Text = "&Apply";
            this.btnApply.UseVisualStyleBackColor = true;
            this.btnApply.Click += new System.EventHandler(this.btnApply_Click);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(580, 562);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(130, 26);
            this.button2.TabIndex = 2;
            this.button2.Text = "&Cancel";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.groupBox5);
            this.tabPage2.Controls.Add(this.groupBox2);
            this.tabPage2.Location = new System.Drawing.Point(4, 25);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(852, 527);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "User Rights";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // groupBox5
            // 
            this.groupBox5.Controls.Add(this.dataGridSubMenuRights);
            this.groupBox5.Location = new System.Drawing.Point(7, 89);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(832, 432);
            this.groupBox5.TabIndex = 1;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "Available Menu Options";
            // 
            // dataGridSubMenuRights
            // 
            this.dataGridSubMenuRights.AllowUserToAddRows = false;
            this.dataGridSubMenuRights.AllowUserToDeleteRows = false;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.PowderBlue;
            this.dataGridSubMenuRights.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            this.dataGridSubMenuRights.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridSubMenuRights.Location = new System.Drawing.Point(7, 22);
            this.dataGridSubMenuRights.Name = "dataGridSubMenuRights";
            this.dataGridSubMenuRights.RowTemplate.Height = 24;
            this.dataGridSubMenuRights.Size = new System.Drawing.Size(819, 404);
            this.dataGridSubMenuRights.TabIndex = 0;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.ddlMasterMenuList);
            this.groupBox2.Controls.Add(this.label15);
            this.groupBox2.Controls.Add(this.lblUserName);
            this.groupBox2.Controls.Add(this.label13);
            this.groupBox2.Controls.Add(this.txtUserCode);
            this.groupBox2.Location = new System.Drawing.Point(7, 19);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(832, 63);
            this.groupBox2.TabIndex = 0;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "groupBox2";
            // 
            // ddlMasterMenuList
            // 
            this.ddlMasterMenuList.FormattingEnabled = true;
            this.ddlMasterMenuList.Location = new System.Drawing.Point(607, 27);
            this.ddlMasterMenuList.Name = "ddlMasterMenuList";
            this.ddlMasterMenuList.Size = new System.Drawing.Size(186, 24);
            this.ddlMasterMenuList.TabIndex = 4;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(511, 32);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(90, 17);
            this.label15.TabIndex = 3;
            this.label15.Text = "Master Menu";
            // 
            // lblUserName
            // 
            this.lblUserName.AutoSize = true;
            this.lblUserName.Location = new System.Drawing.Point(267, 32);
            this.lblUserName.Name = "lblUserName";
            this.lblUserName.Size = new System.Drawing.Size(75, 17);
            this.lblUserName.TabIndex = 2;
            this.lblUserName.Text = "user name";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(19, 32);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(75, 17);
            this.label13.TabIndex = 1;
            this.label13.Text = "User Code";
            // 
            // txtUserCode
            // 
            this.txtUserCode.Location = new System.Drawing.Point(100, 29);
            this.txtUserCode.Name = "txtUserCode";
            this.txtUserCode.Size = new System.Drawing.Size(161, 22);
            this.txtUserCode.TabIndex = 0;
            this.txtUserCode.LostFocus += new System.EventHandler(this.txtUsercodeLostFocus);
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.groupBox4);
            this.tabPage1.Controls.Add(this.groupBox3);
            this.tabPage1.Controls.Add(this.groupBox1);
            this.tabPage1.Location = new System.Drawing.Point(4, 25);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(852, 527);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Litmus Parameters";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.txtSignName5);
            this.groupBox4.Controls.Add(this.txtDesignition5);
            this.groupBox4.Controls.Add(this.txtSignName4);
            this.groupBox4.Controls.Add(this.txtDesignition4);
            this.groupBox4.Controls.Add(this.txtSignName3);
            this.groupBox4.Controls.Add(this.txtDesignition3);
            this.groupBox4.Controls.Add(this.txtSignName2);
            this.groupBox4.Controls.Add(this.txtDesignition2);
            this.groupBox4.Controls.Add(this.txtSignName1);
            this.groupBox4.Controls.Add(this.txtDesignition1);
            this.groupBox4.Controls.Add(this.label11);
            this.groupBox4.Controls.Add(this.label10);
            this.groupBox4.Location = new System.Drawing.Point(374, 273);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(465, 217);
            this.groupBox4.TabIndex = 3;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Signing Authorities";
            // 
            // txtSignName5
            // 
            this.txtSignName5.Location = new System.Drawing.Point(239, 180);
            this.txtSignName5.Name = "txtSignName5";
            this.txtSignName5.Size = new System.Drawing.Size(187, 22);
            this.txtSignName5.TabIndex = 11;
            // 
            // txtDesignition5
            // 
            this.txtDesignition5.Location = new System.Drawing.Point(46, 180);
            this.txtDesignition5.Name = "txtDesignition5";
            this.txtDesignition5.Size = new System.Drawing.Size(187, 22);
            this.txtDesignition5.TabIndex = 10;
            // 
            // txtSignName4
            // 
            this.txtSignName4.Location = new System.Drawing.Point(239, 152);
            this.txtSignName4.Name = "txtSignName4";
            this.txtSignName4.Size = new System.Drawing.Size(187, 22);
            this.txtSignName4.TabIndex = 9;
            // 
            // txtDesignition4
            // 
            this.txtDesignition4.Location = new System.Drawing.Point(46, 152);
            this.txtDesignition4.Name = "txtDesignition4";
            this.txtDesignition4.Size = new System.Drawing.Size(187, 22);
            this.txtDesignition4.TabIndex = 8;
            // 
            // txtSignName3
            // 
            this.txtSignName3.Location = new System.Drawing.Point(239, 124);
            this.txtSignName3.Name = "txtSignName3";
            this.txtSignName3.Size = new System.Drawing.Size(187, 22);
            this.txtSignName3.TabIndex = 7;
            // 
            // txtDesignition3
            // 
            this.txtDesignition3.Location = new System.Drawing.Point(46, 124);
            this.txtDesignition3.Name = "txtDesignition3";
            this.txtDesignition3.Size = new System.Drawing.Size(187, 22);
            this.txtDesignition3.TabIndex = 6;
            // 
            // txtSignName2
            // 
            this.txtSignName2.Location = new System.Drawing.Point(239, 88);
            this.txtSignName2.Name = "txtSignName2";
            this.txtSignName2.Size = new System.Drawing.Size(187, 22);
            this.txtSignName2.TabIndex = 5;
            // 
            // txtDesignition2
            // 
            this.txtDesignition2.Location = new System.Drawing.Point(46, 88);
            this.txtDesignition2.Name = "txtDesignition2";
            this.txtDesignition2.Size = new System.Drawing.Size(187, 22);
            this.txtDesignition2.TabIndex = 4;
            // 
            // txtSignName1
            // 
            this.txtSignName1.Location = new System.Drawing.Point(239, 54);
            this.txtSignName1.Name = "txtSignName1";
            this.txtSignName1.Size = new System.Drawing.Size(187, 22);
            this.txtSignName1.TabIndex = 3;
            // 
            // txtDesignition1
            // 
            this.txtDesignition1.Location = new System.Drawing.Point(46, 54);
            this.txtDesignition1.Name = "txtDesignition1";
            this.txtDesignition1.Size = new System.Drawing.Size(187, 22);
            this.txtDesignition1.TabIndex = 2;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(310, 34);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(45, 17);
            this.label11.TabIndex = 1;
            this.label11.Text = "Name";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(100, 34);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(83, 17);
            this.label10.TabIndex = 0;
            this.label10.Text = "Designation";
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.txtOldMillCapacity);
            this.groupBox3.Controls.Add(this.txtNewMillCapacity);
            this.groupBox3.Controls.Add(this.label9);
            this.groupBox3.Controls.Add(this.label8);
            this.groupBox3.Controls.Add(this.checkBoxOldMill);
            this.groupBox3.Controls.Add(this.checkBoxNewMill);
            this.groupBox3.Location = new System.Drawing.Point(16, 273);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(316, 156);
            this.groupBox3.TabIndex = 2;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Mill house Parameters";
            // 
            // txtOldMillCapacity
            // 
            this.txtOldMillCapacity.Location = new System.Drawing.Point(147, 100);
            this.txtOldMillCapacity.Name = "txtOldMillCapacity";
            this.txtOldMillCapacity.Size = new System.Drawing.Size(100, 22);
            this.txtOldMillCapacity.TabIndex = 5;
            // 
            // txtNewMillCapacity
            // 
            this.txtNewMillCapacity.Location = new System.Drawing.Point(147, 62);
            this.txtNewMillCapacity.Name = "txtNewMillCapacity";
            this.txtNewMillCapacity.Size = new System.Drawing.Size(100, 22);
            this.txtNewMillCapacity.TabIndex = 4;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(160, 34);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(74, 17);
            this.label9.TabIndex = 3;
            this.label9.Text = "CAPACITY";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(27, 34);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(91, 17);
            this.label8.TabIndex = 2;
            this.label8.Text = "MILL HOUSE";
            // 
            // checkBoxOldMill
            // 
            this.checkBoxOldMill.AutoSize = true;
            this.checkBoxOldMill.Location = new System.Drawing.Point(26, 100);
            this.checkBoxOldMill.Name = "checkBoxOldMill";
            this.checkBoxOldMill.Size = new System.Drawing.Size(76, 21);
            this.checkBoxOldMill.TabIndex = 1;
            this.checkBoxOldMill.Text = "Old Mill";
            this.checkBoxOldMill.UseVisualStyleBackColor = true;
            // 
            // checkBoxNewMill
            // 
            this.checkBoxNewMill.AutoSize = true;
            this.checkBoxNewMill.Location = new System.Drawing.Point(26, 64);
            this.checkBoxNewMill.Name = "checkBoxNewMill";
            this.checkBoxNewMill.Size = new System.Drawing.Size(81, 21);
            this.checkBoxNewMill.TabIndex = 0;
            this.checkBoxNewMill.Text = "New Mill";
            this.checkBoxNewMill.UseVisualStyleBackColor = true;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.txtReportTime);
            this.groupBox1.Controls.Add(this.label12);
            this.groupBox1.Controls.Add(this.dateTimeProcessDate);
            this.groupBox1.Controls.Add(this.dateTimeEntryDate);
            this.groupBox1.Controls.Add(this.txtDayHours);
            this.groupBox1.Controls.Add(this.label7);
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Controls.Add(this.ddlCrushingSeason);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.dateTimeCrushingEndDate);
            this.groupBox1.Controls.Add(this.dateTimeCrushingStartDate);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.txtCompanyName);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Location = new System.Drawing.Point(16, 22);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(823, 245);
            this.groupBox1.TabIndex = 1;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Basic Pramaters";
            // 
            // txtReportTime
            // 
            this.txtReportTime.Location = new System.Drawing.Point(611, 71);
            this.txtReportTime.Name = "txtReportTime";
            this.txtReportTime.Size = new System.Drawing.Size(100, 22);
            this.txtReportTime.TabIndex = 15;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(485, 74);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(120, 17);
            this.label12.TabIndex = 14;
            this.label12.Text = "Report Start Time";
            // 
            // dateTimeProcessDate
            // 
            this.dateTimeProcessDate.CustomFormat = "yyyy-MM-dd";
            this.dateTimeProcessDate.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dateTimeProcessDate.Location = new System.Drawing.Point(611, 206);
            this.dateTimeProcessDate.Name = "dateTimeProcessDate";
            this.dateTimeProcessDate.Size = new System.Drawing.Size(200, 22);
            this.dateTimeProcessDate.TabIndex = 13;
            // 
            // dateTimeEntryDate
            // 
            this.dateTimeEntryDate.CustomFormat = "yyyy-MM-dd";
            this.dateTimeEntryDate.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dateTimeEntryDate.Location = new System.Drawing.Point(216, 206);
            this.dateTimeEntryDate.Name = "dateTimeEntryDate";
            this.dateTimeEntryDate.Size = new System.Drawing.Size(200, 22);
            this.dateTimeEntryDate.TabIndex = 12;
            // 
            // txtDayHours
            // 
            this.txtDayHours.Location = new System.Drawing.Point(216, 160);
            this.txtDayHours.Name = "txtDayHours";
            this.txtDayHours.Size = new System.Drawing.Size(100, 22);
            this.txtDayHours.TabIndex = 11;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(490, 211);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(93, 17);
            this.label7.TabIndex = 10;
            this.label7.Text = "Process Date";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(113, 211);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(75, 17);
            this.label6.TabIndex = 9;
            this.label6.Text = "Entry Date";
            // 
            // ddlCrushingSeason
            // 
            this.ddlCrushingSeason.FormattingEnabled = true;
            this.ddlCrushingSeason.Location = new System.Drawing.Point(215, 71);
            this.ddlCrushingSeason.Name = "ddlCrushingSeason";
            this.ddlCrushingSeason.Size = new System.Drawing.Size(189, 24);
            this.ddlCrushingSeason.TabIndex = 8;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(68, 78);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(116, 17);
            this.label5.TabIndex = 7;
            this.label5.Text = "Crushing Season";
            // 
            // dateTimeCrushingEndDate
            // 
            this.dateTimeCrushingEndDate.CustomFormat = "yyyy-MM-dd";
            this.dateTimeCrushingEndDate.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dateTimeCrushingEndDate.Location = new System.Drawing.Point(611, 118);
            this.dateTimeCrushingEndDate.Name = "dateTimeCrushingEndDate";
            this.dateTimeCrushingEndDate.Size = new System.Drawing.Size(200, 22);
            this.dateTimeCrushingEndDate.TabIndex = 6;
            // 
            // dateTimeCrushingStartDate
            // 
            this.dateTimeCrushingStartDate.CustomFormat = "yyyy-MM-dd";
            this.dateTimeCrushingStartDate.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dateTimeCrushingStartDate.Location = new System.Drawing.Point(215, 118);
            this.dateTimeCrushingStartDate.Name = "dateTimeCrushingStartDate";
            this.dateTimeCrushingStartDate.Size = new System.Drawing.Size(200, 22);
            this.dateTimeCrushingStartDate.TabIndex = 5;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(451, 123);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(127, 17);
            this.label4.TabIndex = 4;
            this.label4.Text = "Crushing End Date";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(38, 123);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(132, 17);
            this.label3.TabIndex = 3;
            this.label3.Text = "Crushing Start Date";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(119, 163);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(75, 17);
            this.label2.TabIndex = 2;
            this.label2.Text = "Day Hours";
            // 
            // txtCompanyName
            // 
            this.txtCompanyName.Location = new System.Drawing.Point(215, 32);
            this.txtCompanyName.Name = "txtCompanyName";
            this.txtCompanyName.Size = new System.Drawing.Size(596, 22);
            this.txtCompanyName.TabIndex = 1;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(126, 37);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(74, 17);
            this.label1.TabIndex = 0;
            this.label1.Text = "Unit Name";
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Controls.Add(this.tabPage3);
            this.tabControl1.Location = new System.Drawing.Point(3, 4);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(860, 556);
            this.tabControl1.TabIndex = 0;
            // 
            // tabPage3
            // 
            this.tabPage3.Controls.Add(this.groupBox6);
            this.tabPage3.Location = new System.Drawing.Point(4, 25);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage3.Size = new System.Drawing.Size(852, 527);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "Cane Yard Param";
            this.tabPage3.UseVisualStyleBackColor = true;
            // 
            // groupBox6
            // 
            this.groupBox6.Location = new System.Drawing.Point(6, 17);
            this.groupBox6.Name = "groupBox6";
            this.groupBox6.Size = new System.Drawing.Size(833, 100);
            this.groupBox6.TabIndex = 0;
            this.groupBox6.TabStop = false;
            this.groupBox6.Text = "Average Weights";
            // 
            // frm_master_parameters
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(864, 593);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.btnApply);
            this.Controls.Add(this.tabControl1);
            this.Name = "frm_master_parameters";
            this.Text = "Master Parameters";
            this.TopMost = true;
            this.tabPage2.ResumeLayout(false);
            this.groupBox5.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridSubMenuRights)).EndInit();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.tabPage1.ResumeLayout(false);
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.tabControl1.ResumeLayout(false);
            this.tabPage3.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnApply;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.DataGridView dataGridSubMenuRights;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.ComboBox ddlMasterMenuList;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label lblUserName;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.TextBox txtUserCode;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.TextBox txtSignName5;
        private System.Windows.Forms.TextBox txtDesignition5;
        private System.Windows.Forms.TextBox txtSignName4;
        private System.Windows.Forms.TextBox txtDesignition4;
        private System.Windows.Forms.TextBox txtSignName3;
        private System.Windows.Forms.TextBox txtDesignition3;
        private System.Windows.Forms.TextBox txtSignName2;
        private System.Windows.Forms.TextBox txtDesignition2;
        private System.Windows.Forms.TextBox txtSignName1;
        private System.Windows.Forms.TextBox txtDesignition1;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.TextBox txtOldMillCapacity;
        private System.Windows.Forms.TextBox txtNewMillCapacity;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.CheckBox checkBoxOldMill;
        private System.Windows.Forms.CheckBox checkBoxNewMill;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.MaskedTextBox txtReportTime;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.DateTimePicker dateTimeProcessDate;
        private System.Windows.Forms.DateTimePicker dateTimeEntryDate;
        private System.Windows.Forms.TextBox txtDayHours;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.ComboBox ddlCrushingSeason;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.DateTimePicker dateTimeCrushingEndDate;
        private System.Windows.Forms.DateTimePicker dateTimeCrushingStartDate;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtCompanyName;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.GroupBox groupBox6;
    }
}