﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using Microsoft.ApplicationBlocks.Data;
using Litmus.classes;
namespace Litmus.classes
{
    class user_management_logic
    {
        generalFunctions genfunc = new generalFunctions();
        DbConnections dbConn = new DbConnections();
        ExceptionHelper expHelper = new ExceptionHelper();
        public DataTable getUserDetails(string user_code)
        {
            string sql = @"select first_name +' '+last_name as 'user_name', isActive, mobile_no, email_address, is_admin, multiple_login from user_master where user_code = @user_code";
            DataTable dt = null;

            try
            {
                List<SqlParameter> param = new List<SqlParameter>();
                param.Add(new SqlParameter("@user_code", user_code));

                dt = SqlHelper.ExecuteDataset(dbConn.sqlConn(), CommandType.Text, sql, param.ToArray()).Tables[0];
            }
            catch (SqlException ex)
            {
                expHelper.statusMsg = "ERROR: occured while getting user details.\nError message" + ex.Message + "\nStack Trace= " + ex.StackTrace;
                Console.Write("ERROR: occured while getting user details.\nError message" + ex.Message + "\nStack Trace= " + ex.StackTrace);
            }
            catch (Exception ex)
            {
                expHelper.statusMsg = "ERROR: occured while getting user details.\nError message" + ex.Message + "\nStack Trace= " + ex.StackTrace;
                Console.Write("ERROR: occured while getting user details.\nError message" + ex.Message + "\nStack Trace= " + ex.StackTrace);
            }
            return dt;

        }
    }
}
