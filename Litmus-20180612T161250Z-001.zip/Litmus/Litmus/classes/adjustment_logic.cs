﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.SqlClient;
using Microsoft.ApplicationBlocks.Data;
namespace Litmus.classes
{
    class adjustment_logic
    {
        DbConnections dbConn = new DbConnections();

        /// <summary>
        /// After selecting a date on form, check data for that day exists or not
        /// </summary>
        /// <param name="date"></param>
        /// 

        public decimal a_suplpher { get; set; }
        public decimal a_lime { get; set; }
        public decimal a_phosphoric_acid { get; set; }
        public decimal a_color_reducer { get; set; }
        public decimal a_megnafloe  { get; set; }
        public decimal a_lub_oil { get; set; }
        public decimal a_viscosity_reducer { get; set; }
        public decimal a_biocide { get; set; }
        public decimal a_lub_greace { get; set; }
        public decimal a_boiler_chemical { get; set; }
        public decimal a_estimated_sugar { get; set; }
        public decimal a_estimated_molasses { get; set; }
        public int    a_is_active { get; set; }
        public string  updt_dt { get; set; }
        public string  crtd_by { get; set; }
        public string  updt_by { get; set; }
        public bool data_exists_for_the_day(string date)
        {
            bool is_data_exists = false;
            string sql = @"select a_sulpher, a_lime, a_phosphoric_acid, a_color_reducer, a_megnafloe, a_lub_oil, " +
                " a_viscosity_reducer, a_biocide " +
                    " ,a_lub_greace, a_boiler_chemical, a_estimated_sugar, a_estimated_molasses	" +
                    " from adjustment_data where trans_date = @trans_date";

            List<SqlParameter> param = new List<SqlParameter>();
            param.Add(new SqlParameter("@trans_date", date));
            DataTable dt = null;
             dt = SqlHelper.ExecuteDataset(dbConn.sqlConn(), CommandType.Text, sql, param.ToArray()).Tables[0];
             if (dt.Rows.Count == 1)
             {
                 is_data_exists = true;
                 a_suplpher = Convert.ToDecimal(dt.Rows[0]["a_sulpher"]);
                 a_lime = Convert.ToDecimal(dt.Rows[0]["a_lime"]);
                 a_phosphoric_acid = Convert.ToDecimal(dt.Rows[0]["a_phosphoric_acid"]);
                 a_color_reducer = Convert.ToDecimal(dt.Rows[0]["a_color_reducer"]);
                 a_megnafloe = Convert.ToDecimal(dt.Rows[0]["a_megnafloe"]);
                 a_lub_oil = Convert.ToDecimal(dt.Rows[0]["a_lub_oil"]);
                 a_viscosity_reducer = Convert.ToDecimal(dt.Rows[0]["a_viscosity_reducer"]);
                 a_biocide = Convert.ToDecimal(dt.Rows[0]["a_viscosity_reducer"]);
                 a_estimated_sugar = Convert.ToDecimal(dt.Rows[0]["a_biocide"]);
                 a_lub_greace = Convert.ToDecimal(dt.Rows[0]["a_lub_greace"]);
                 a_boiler_chemical = Convert.ToDecimal(dt.Rows[0]["a_boiler_chemical"]);
                 a_estimated_sugar = Convert.ToDecimal(dt.Rows[0]["a_estimated_sugar"]);
                 a_estimated_molasses = Convert.ToDecimal(dt.Rows[0]["a_estimated_molasses"]);
             }
             else
             {
                 a_suplpher = 0;
                 a_lime = 0;
                 a_phosphoric_acid = 0;
                 a_color_reducer = 0;
                 a_megnafloe = 0;
                 a_lub_oil = 0;
                 a_viscosity_reducer = 0;
                 a_biocide = 0;
                 a_estimated_sugar = 0;
                 a_lub_greace = 0;
                 a_boiler_chemical = 0;
                 a_estimated_sugar = 0;
                 a_estimated_molasses = 0;
             }
            return is_data_exists;
           
        }

        /// <summary>
        /// Insert new records
        /// </summary>
        /// <param name="trans_date"></param>
        /// <param name="a_sulpher"></param>
        /// <param name="a_lime"></param>
        /// <param name="a_phosphoric_acid"></param>
        /// <param name="a_color_reducer"></param>
        /// <param name="a_megnafloe"></param>
        /// <param name="a_lub_oil"></param>
        /// <param name="a_viscosity_reducer"></param>
        /// <param name="a_biocide"></param>
        /// <param name="a_lub_greace"></param>
        /// <param name="a_boiler_chemical"></param>
        /// <param name="a_estimated_sugar"></param>
        /// <param name="a_estimated_molasses"></param>
        /// <param name="a_is_active"></param>
        /// <param name="crtd_by"></param>
        public void insert_adjustment_records(string trans_date, decimal a_sulpher, decimal a_lime, decimal a_phosphoric_acid, decimal a_color_reducer,
            decimal a_megnafloe, decimal a_lub_oil, decimal a_viscosity_reducer, decimal a_biocide, decimal a_lub_greace, decimal a_boiler_chemical,
            decimal a_estimated_sugar, decimal a_estimated_molasses, int a_is_active, string crtd_by)
        {
            string sql = @"insert into adjustment_data(trans_date, a_sulpher, a_lime, a_phosphoric_acid, a_color_reducer, a_megnafloe, a_lub_oil, " +
            "a_viscosity_reducer, a_biocide, a_lub_greace, a_boiler_chemical, a_estimated_sugar, a_estimated_molasses, a_is_active, crtd_by )" +
            " values (@trans_date, @a_sulpher, @a_lime, @a_phosphoric_acid, @a_color_reducer, @a_megnafloe, @a_lub_oil, @a_viscosity_reducer, @a_biocide, " +
            " @a_lub_greace, @a_boiler_chemical, @a_estimated_sugar, @a_estimated_molasses, @a_is_active, @crtd_by) ";

            List<SqlParameter> param = new List<SqlParameter>();
            param.Add(new SqlParameter("@trans_date", trans_date));
            param.Add(new SqlParameter("@a_sulpher", a_sulpher));
            param.Add(new SqlParameter("@a_lime", a_lime));
            param.Add(new SqlParameter("@a_phosphoric_acid", a_phosphoric_acid));
            param.Add(new SqlParameter("@a_color_reducer", a_color_reducer));
            param.Add(new SqlParameter("@a_megnafloe", a_megnafloe));
            param.Add(new SqlParameter("@a_lub_oil", a_lub_oil));
            param.Add(new SqlParameter("@a_viscosity_reducer", a_viscosity_reducer));
            param.Add(new SqlParameter("@a_biocide", a_biocide));
            param.Add(new SqlParameter("@a_lub_greace", a_lub_greace));
            param.Add(new SqlParameter("@a_boiler_chemical", a_boiler_chemical));
            param.Add(new SqlParameter("@a_estimated_sugar", a_estimated_sugar));
            param.Add(new SqlParameter("@a_estimated_molasses", a_estimated_molasses));
            param.Add(new SqlParameter("@a_is_active", a_is_active));
            param.Add(new SqlParameter("@crtd_by", crtd_by));

            // inserting data
            int insertedRecords = 0;
            insertedRecords = SqlHelper.ExecuteNonQuery(dbConn.sqlConn(), CommandType.Text, sql, param.ToArray());

        }
        /// <summary>
        /// Update records for selected date
        /// </summary>
        /// <param name="trans_date"></param>
        /// <param name="a_sulpher"></param>
        /// <param name="a_lime"></param>
        /// <param name="a_phosphoric_acid"></param>
        /// <param name="a_color_reducer"></param>
        /// <param name="a_megnafloe"></param>
        /// <param name="a_lub_oil"></param>
        /// <param name="a_viscosity_reducer"></param>
        /// <param name="a_biocide"></param>
        /// <param name="a_lub_greace"></param>
        /// <param name="a_boiler_chemical"></param>
        /// <param name="a_estimated_sugar"></param>
        /// <param name="a_estimated_molasses"></param>
        /// <param name="a_is_active"></param>
        /// <param name="updt_by"></param>
        public void update_adjustment_records(string trans_date, decimal a_sulpher, decimal a_lime, decimal a_phosphoric_acid, decimal a_color_reducer,
            decimal a_megnafloe, decimal a_lub_oil, decimal a_viscosity_reducer, decimal a_biocide, decimal a_lub_greace, decimal a_boiler_chemical,
            decimal a_estimated_sugar, decimal a_estimated_molasses, int a_is_active, string updt_by)
        {
            string sql = @"update adjustment_data set a_sulpher = @a_sulpher, a_lime = @a_lime, a_phosphoric_acid = @a_phosphoric_acid " +
                " , a_color_reducer = @a_color_reducer, a_megnafloe = @a_megnafloe, a_lub_oil = @a_lub_oil, a_viscosity_reducer = @a_viscosity_reducer " +
                " , a_biocide = @a_biocide, a_lub_greace = @a_lub_greace, a_boiler_chemical = @a_boiler_chemical, a_estimated_sugar = @a_estimated_sugar " +
                " , a_estimated_molasses = @a_estimated_molasses, updt_by = @updt_by, updt_dt = "+DateTime.Now.ToString("yyyy-MM-dd") + " where trans_date = @trans_date"; 

            List<SqlParameter> param = new List<SqlParameter>();
            param.Add(new SqlParameter("@trans_date", trans_date));
            param.Add(new SqlParameter("@a_sulpher", a_sulpher));
            param.Add(new SqlParameter("@a_lime", a_lime));
            param.Add(new SqlParameter("@a_phosphoric_acid", a_phosphoric_acid));
            param.Add(new SqlParameter("@a_color_reducer", a_color_reducer));
            param.Add(new SqlParameter("@a_megnafloe", a_megnafloe));
            param.Add(new SqlParameter("@a_lub_oil", a_lub_oil));
            param.Add(new SqlParameter("@a_viscosity_reducer", a_viscosity_reducer));
            param.Add(new SqlParameter("@a_biocide", a_biocide));
            param.Add(new SqlParameter("@a_lub_greace", a_lub_greace));
            param.Add(new SqlParameter("@a_boiler_chemical", a_boiler_chemical));
            param.Add(new SqlParameter("@a_estimated_sugar", a_estimated_sugar));
            param.Add(new SqlParameter("@a_estimated_molasses", a_estimated_molasses));
            param.Add(new SqlParameter("@a_is_active", a_is_active));
            param.Add(new SqlParameter("@updt_by", updt_by ));

            // inserting data
            int updated_records = 0;
            updated_records = SqlHelper.ExecuteNonQuery(dbConn.sqlConn(), CommandType.Text, sql, param.ToArray());
        }
    }
}
