﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using Microsoft.ApplicationBlocks.Data;
using System.Windows.Forms;
namespace Litmus.classes
{
    class bihourly_entry_logic
    {
        DbConnections dbConn = new DbConnections();
        classes.master_parameter_logic masterParameters = new master_parameter_logic();
        classes.ExceptionHelper expHelper = new ExceptionHelper();
        classes.generalFunctions genFunc = new generalFunctions();
        public static int _entryTime;
        //public DataTable _twoHourlyDataTable;
        public int entryTime { get { return _entryTime; } set { _entryTime = value; } }
        //public DataTable twoHourlyDataTable { get { return _twoHourlyDataTable; } set { twoHourlyDataTable = value; } }
        #region composing entry time for hourly transactions
        public void CurrentEntryTime(string entryDate)
        {
            string sql = @"select entry_time from transactions_two_hourly where id = (select max(id) from transactions_two_hourly) and entry_date = @date";
            List<SqlParameter> param = new List<SqlParameter>();
            param.Add(new SqlParameter("@date", entryDate));
            DataSet ds = new DataSet();
            try
            {

                ds = SqlHelper.ExecuteDataset(dbConn.sqlConn(), CommandType.Text, sql, param.ToArray());
                if (ds.Tables[0].Rows.Count > 0)
                {
                    if (ds.Tables[0].Rows.Count > 0 & Convert.ToInt16(ds.Tables[0].Rows[0]["entry_time"]) < 24)
                    {
                        entryTime = (Convert.ToInt16(ds.Tables[0].Rows[0]["entry_time"]) + 2);
                    }
                    else
                    {
                        // after 12:00 am time will be 2 AM because it is two hourly entry
                        entryTime = 2;
                    }

                }
                else
                {
                    entryTime = Convert.ToInt16(masterParameters.reportStartTime) + 2;
                }

            }
            catch (Exception ex)
            {
                MessageBox.Show("Execption - " + ex.Message + "\n For more details please check log file", "Exception", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                expHelper.statusMsg = "ERR: could not get entry time for bi-hourly transactions.\nException Message " + ex.Message + "\nStack Trace - " + ex.StackTrace;
            }


        }
        #endregion

        #region insert new entry in database(Table- two_hourly_transaction)

        public int insertTwoHourlyData(string entryDate, int entryTime, float nmPjBrix, float nmPjPol, float nmPjPurity,
            float omPjBrix, float omPjPol, float omPjPurity,
            float nmMjBrix, float nmMjPol, float nmMjPurity,
            float omMjBrix, float omMjPol, float omMjPurity,
            float nmLjBrix, float nmLjPol, float nmLjPurity,
            float omLjBrix, float omLjPol, float omLjPurity,
            float filteredJuiceBrix, float filteredJuicePol, float filteredJuicePh, float filteredJuicePurity,
            float clearedJuiceBrix, float clearedJuicePol, float clearedJuicePh, float clearedJuicePurity,
            float unSulphuredJuiceBrix, float unSulphuredJuicePol, float unSulphuredJuicePh, float unSulphuredJuicePurity,
            float sulphuredJuiceBrix, float sulphuredJuicePol, float sulphuredJuicePh, float sulphuredJuicePurity,
            float finalMolassesBrix, float finalMolassesPol, float finalMolassesTemp, float finalMolassesTanks, float finalMolassesPurity,
            float bagasseNmPol, float bagasseNmMoisture,
            float bagasseOmPol, float bagasseOmMoisture,
            float pressCakeSample1, float pressCakeSample2, float pressCakeSample3, float pressCakeSample4, float pressCakeSample5,
            float pressCakeSampleAverage, float pressCakeMoisture, float pressCakeComposite,
            float unCrushedCane, float crushedCane,
            int standingTrucks, int standingTrolley, int standingTripplers, int standingCart)
        {
            int insertedRows = 0;
            try
            {
                string insertionSql = @"insert into transactions_two_hourly (entry_date,entry_time,nm_primary_juice_brix, " +
                                    " nm_primary_juice_pol,nm_primary_juice_purity,om_primary_juice_brix,om_primary_juice_pol,om_primary_juice_purity, nm_mixed_juice_brix, " +
                                    " nm_mixed_juice_pol,nm_mixed_juice_purity,om_mixed_juice_brix,om_mixed_juice_pol,om_mixed_juice_purity," +
                                    " nm_last_juice_brix, nm_last_juice_pol, nm_last_juice_purity, om_last_juice_brix, om_last_juice_pol, om_last_juice_purity, " +
                                    " oliver_juice_brix,oliver_juice_pol,oliver_juice_ph,oliver_juice_purity, " +
                                    " clear_juice_brix,clear_juice_pol,clear_juice_ph,clear_juice_purity, " +
                                    " unsulphured_syrup_brix,unsulphured_syrup_pol,unsulphured_syrup_ph,unsulphured_syrup_purity, " +
                                    " sulphured_syrup_brix,sulphured_syrup_pol,sulphured_syrup_ph,sulphured_syrup_purity, " +
                                    " final_molasses_brix,final_molasses_pol,final_molasses_purity, final_molasses_temp, final_molasses_tanks, " +
                                    " nm_bagasse_pol,nm_bagasse_moisture,om_bagasse_pol,om_bagasse_moisture, " +
                                    " pol_pressure_cake_sample1,pol_pressure_cake_sample2,pol_pressure_cake_sample3,pol_pressure_cake_sample4, " +
                                    " pol_pressure_cake_sample5,pol_pressure_cake_average,pol_pressure_cake_moisture,pol_pressure_cake_composite, " +
                                    " standing_trucks,standing_trolleys,standing_triplers,standing_cart, " +
                                    " uncrushed_cane,crushed_cane,crtd_by)  " +

                                    "  values (@entry_date,@entry_time,@nm_primary_juice_brix, " +
                                    " @nm_primary_juice_pol,@nm_primary_juice_purity,@om_primary_juice_brix,@om_primary_juice_pol,@om_primary_juice_purity, @nm_mixed_juice_brix," +
                                    " @nm_mixed_juice_pol,@nm_mixed_juice_purity,@om_mixed_juice_brix,@om_mixed_juice_pol,@om_mixed_juice_purity," +
                                    " @nm_last_juice_brix,@nm_last_juice_pol,@nm_last_juice_purity,@om_last_juice_brix,@om_last_juice_pol,@om_last_juice_purity, " +
                                    " @oliver_juice_brix,@oliver_juice_pol,@oliver_juice_ph,@oliver_juice_purity," +
                                    " @clear_juice_brix,@clear_juice_pol,@clear_juice_ph,@clear_juice_purity, " +
                                    " @unsulphured_syrup_brix,@unsulphured_syrup_pol,@unsulphured_syrup_ph,@unsulphured_syrup_purity, " +
                                    " @sulphured_syrup_brix,@sulphured_syrup_pol,@sulphured_syrup_ph,@sulphured_syrup_purity, " +
                                    " @final_molasses_brix,@final_molasses_pol,@final_molasses_purity, @final_molasses_temp, @final_molasses_tanks , " +
                                    " @nm_bagasse_pol,@nm_bagasse_moisture,@om_bagasse_pol,@om_bagasse_moisture, " +
                                    " @pol_pressure_cake_sample1,@pol_pressure_cake_sample2,@pol_pressure_cake_sample3,@pol_pressure_cake_sample4, " +
                                    " @pol_pressure_cake_sample5,@pol_pressure_cake_average,@pol_pressure_cake_moisture,@pol_pressure_cake_composite, " +
                                    " @standing_trucks,@standing_trolleys,@standing_triplers,@standing_cart, " +
                                    " @uncrushed_cane,@crushed_cane,@crtd_by) ";
                List<SqlParameter> param = new List<SqlParameter>();
                param.Add(new SqlParameter("@entry_date", entryDate));
                param.Add(new SqlParameter("@entry_time", entryTime));
                param.Add(new SqlParameter("@nm_primary_juice_brix", nmPjBrix));
                param.Add(new SqlParameter("@nm_primary_juice_pol", nmPjPol));
                param.Add(new SqlParameter("@nm_primary_juice_purity", nmPjPurity));
                param.Add(new SqlParameter("@om_primary_juice_brix", omPjBrix));
                param.Add(new SqlParameter("@om_primary_juice_pol", omPjPol));
                param.Add(new SqlParameter("@om_primary_juice_purity", omPjPurity ));
                param.Add(new SqlParameter("@nm_mixed_juice_brix", nmMjBrix ));
                param.Add(new SqlParameter("@nm_mixed_juice_pol", nmMjPol ));
                param.Add(new SqlParameter("@nm_mixed_juice_purity", nmMjPurity ));
                param.Add(new SqlParameter("@om_mixed_juice_brix", omMjBrix ));
                param.Add(new SqlParameter("@om_mixed_juice_pol", omMjPol));
                param.Add(new SqlParameter("@om_mixed_juice_purity", omMjPurity));
                param.Add(new SqlParameter("@nm_last_juice_brix", nmLjBrix));
                param.Add(new SqlParameter("@nm_last_juice_pol", nmLjPol ));
                param.Add(new SqlParameter("@nm_last_juice_purity", nmLjPurity ));
                param.Add(new SqlParameter("@om_last_juice_brix", omLjBrix ));
                param.Add(new SqlParameter("@om_last_juice_pol", omLjPol ));
                param.Add(new SqlParameter("@om_last_juice_purity", omLjPurity));
                param.Add(new SqlParameter("@oliver_juice_brix", filteredJuiceBrix ));
                param.Add(new SqlParameter("@oliver_juice_pol", filteredJuicePol ));
                param.Add(new SqlParameter("@oliver_juice_ph", filteredJuicePh ));
                param.Add(new SqlParameter("@oliver_juice_purity", filteredJuicePurity ));
                param.Add(new SqlParameter("@clear_juice_brix", clearedJuiceBrix ));
                param.Add(new SqlParameter("@clear_juice_pol", clearedJuicePol ));
                param.Add(new SqlParameter("@clear_juice_ph", clearedJuicePh ));
                param.Add(new SqlParameter("@clear_juice_purity", clearedJuicePurity ));
                param.Add(new SqlParameter("@unsulphured_syrup_brix", unSulphuredJuiceBrix ));
                param.Add(new SqlParameter("@unsulphured_syrup_pol", unSulphuredJuicePol ));
                param.Add(new SqlParameter("@unsulphured_syrup_ph", unSulphuredJuicePh ));
                param.Add(new SqlParameter("@unsulphured_syrup_purity",unSulphuredJuicePurity ));
                param.Add(new SqlParameter("@sulphured_syrup_brix", sulphuredJuiceBrix ));
                param.Add(new SqlParameter("@sulphured_syrup_pol", sulphuredJuicePol ));
                param.Add(new SqlParameter("@sulphured_syrup_ph", sulphuredJuicePh ));
                param.Add(new SqlParameter("@sulphured_syrup_purity", sulphuredJuicePurity ));
                param.Add(new SqlParameter("@final_molasses_brix", finalMolassesBrix ));
                param.Add(new SqlParameter("@final_molasses_pol", finalMolassesPol ));
                //param.Add(new SqlParameter("@final_molasses_ph", ));
                param.Add(new SqlParameter("@final_molasses_purity", finalMolassesPurity ));
                param.Add(new SqlParameter("@final_molasses_tanks", finalMolassesTanks));
                param.Add(new SqlParameter("@final_molasses_temp", finalMolassesTemp));
                param.Add(new SqlParameter("@nm_bagasse_pol", bagasseNmPol ));
                param.Add(new SqlParameter("@nm_bagasse_moisture", bagasseNmMoisture ));
                param.Add(new SqlParameter("@om_bagasse_pol", bagasseOmPol ));
                param.Add(new SqlParameter("@om_bagasse_moisture", bagasseOmMoisture ));
                param.Add(new SqlParameter("@pol_pressure_cake_sample1", pressCakeSample1 ));
                param.Add(new SqlParameter("@pol_pressure_cake_sample2", pressCakeSample2 ));
                param.Add(new SqlParameter("@pol_pressure_cake_sample3", pressCakeSample3));
                param.Add(new SqlParameter("@pol_pressure_cake_sample4", pressCakeSample4));
                param.Add(new SqlParameter("@pol_pressure_cake_sample5", pressCakeSample5));
                param.Add(new SqlParameter("@pol_pressure_cake_average", pressCakeSampleAverage ));
                param.Add(new SqlParameter("@pol_pressure_cake_moisture", pressCakeMoisture ));
                param.Add(new SqlParameter("@pol_pressure_cake_composite", pressCakeComposite));
                param.Add(new SqlParameter("@standing_trucks", standingTrucks ));
                param.Add(new SqlParameter("@standing_trolleys", standingTrolley ));
                param.Add(new SqlParameter("@standing_triplers", standingTripplers));
                param.Add(new SqlParameter("@standing_cart", standingCart ));
                param.Add(new SqlParameter("@uncrushed_cane", unCrushedCane ));
                param.Add(new SqlParameter("@crushed_cane", crushedCane ));
                param.Add(new SqlParameter("@crtd_by", genFunc.userCode));

                insertedRows = SqlHelper.ExecuteNonQuery(dbConn.sqlConn(), CommandType.Text, insertionSql, param.ToArray());
                if (insertedRows > 0)
                {
                    CurrentEntryTime(masterParameters.entryDate);
                }

            }
            catch (SqlException ex)
            {
                MessageBox.Show(ex.Message, "Failed", MessageBoxButtons.OK, MessageBoxIcon.Error);
                expHelper.statusMsg = "ERROR - while trying to insert record in two hourly table "+ex.Message +"\n" + ex.StackTrace;
            }

            return insertedRows;
        }

        #endregion

        #region update records in database( table - transactions_two_hourly)
        public int updateTwoHourlyData(string entryDate, int entryTime, float nmPjBrix, float nmPjPol, float nmPjPurity,
            float omPjBrix, float omPjPol, float omPjPurity,
            float nmMjBrix, float nmMjPol, float nmMjPurity,
            float omMjBrix, float omMjPol, float omMjPurity,
            float nmLjBrix, float nmLjPol, float nmLjPurity,
            float omLjBrix, float omLjPol, float omLjPurity,
            float filteredJuiceBrix, float filteredJuicePol, float filteredJuicePh, float filteredJuicePurity,
            float clearedJuiceBrix, float clearedJuicePol, float clearedJuicePh, float clearedJuicePurity,
            float unSulphuredJuiceBrix, float unSulphuredJuicePol, float unSulphuredJuicePh, float unSulphuredJuicePurity,
            float sulphuredJuiceBrix, float sulphuredJuicePol, float sulphuredJuicePh, float sulphuredJuicePurity,
            float finalMolassesBrix, float finalMolassesPol, float finalMolassesTemp, float finalMolassesTanks, float finalMolassesPurity,
            float bagasseNmPol, float bagasseNmMoisture,
            float bagasseOmPol, float bagasseOmMoisture,
            float pressCakeSample1, float pressCakeSample2, float pressCakeSample3, float pressCakeSample4, float pressCakeSample5,
            float pressCakeSampleAverage, float pressCakeMoisture, float pressCakeComposite,
            float unCrushedCane, float crushedCane,
            int standingTrucks, int standingTrolley, int standingTripplers, int standingCart)
        {
            int updated_record_count = 0;

            string update_sql = @" update transactions_two_hourly set " +
                " nm_primary_juice_brix = @nm_primary_juice_brix, nm_primary_juice_pol = @nm_primary_juice_pol, nm_primary_juice_purity = @nm_primary_juice_purity " +
                " , om_primary_juice_brix =@om_primary_juice_brix, om_primary_juice_pol=@om_primary_juice_pol, om_primary_juice_purity = @om_primary_juice_purity " +
                " , nm_mixed_juice_brix = @nm_mixed_juice_brix, nm_mixed_juice_pol = @nm_mixed_juice_pol, nm_mixed_juice_purity = @nm_mixed_juice_purity " +
                " , om_mixed_juice_brix = @om_mixed_juice_brix, om_mixed_juice_pol=@om_mixed_juice_pol, om_mixed_juice_purity = @om_mixed_juice_purity " +
                " , nm_last_juice_brix =@nm_last_juice_brix, nm_last_juice_pol =@nm_last_juice_pol, nm_last_juice_purity=@nm_last_juice_purity" +
                " , om_last_juice_brix=@om_last_juice_brix, om_last_juice_pol=@om_last_juice_pol, om_last_juice_purity=@om_last_juice_purity " +
                " , oliver_juice_brix =@oliver_juice_brix, oliver_juice_pol=@oliver_juice_pol, oliver_juice_ph=@oliver_juice_ph, oliver_juice_purity=@oliver_juice_purity" +
                " , clear_juice_brix=@clear_juice_brix, clear_juice_pol=@clear_juice_pol, clear_juice_ph =@clear_juice_ph, clear_juice_purity=@clear_juice_purity " +
                " , unsulphured_syrup_brix=@unsulphured_syrup_brix, unsulphured_syrup_pol=@unsulphured_syrup_pol, unsulphured_syrup_ph=@unsulphured_syrup_ph, unsulphured_syrup_purity=@unsulphured_syrup_purity " +
                " , sulphured_syrup_brix= @sulphured_syrup_brix, sulphured_syrup_pol=@sulphured_syrup_pol, sulphured_syrup_ph=@sulphured_syrup_ph, sulphured_syrup_purity=@sulphured_syrup_purity " +
                " , final_molasses_brix = @final_molasses_brix, final_molasses_pol=@final_molasses_pol, final_molasses_purity=@final_molasses_purity, final_molasses_temp=@final_molasses_temp, final_molasses_tanks=@final_molasses_tanks " +
                " , nm_bagasse_pol = @nm_bagasse_pol, nm_bagasse_moisture=@nm_bagasse_moisture " +
                " , om_bagasse_pol=@om_bagasse_pol, om_bagasse_moisture =@om_bagasse_moisture " +
                ", pol_pressure_cake_sample1 = @pol_pressure_cake_sample1, pol_pressure_cake_sample2=@pol_pressure_cake_sample2, pol_pressure_cake_sample3=@pol_pressure_cake_sample3 " +
                ", pol_pressure_cake_sample4 = @pol_pressure_cake_sample4, pol_pressure_cake_sample5=@pol_pressure_cake_sample5, pol_pressure_cake_average=@pol_pressure_cake_average " +
                ", pol_pressure_cake_moisture = @pol_pressure_cake_moisture, pol_pressure_cake_composite = @pol_pressure_cake_composite " +
                ", standing_trucks = @standing_trucks, standing_trolleys=@standing_trolleys, standing_triplers=@standing_triplers, standing_cart=@standing_cart " +
                ", uncrushed_cane = @uncrushed_cane, crushed_cane=@crushed_cane, updt_dt=@updt_dt, updt_by=@updt_by " +
                " where entry_date = @entry_date and entry_time = @entry_time";

            List<SqlParameter> update_param = new List<SqlParameter>();
            update_param.Add(new SqlParameter("@entry_date", entryDate));
            update_param.Add(new SqlParameter("@entry_time", entryTime));
            update_param.Add(new SqlParameter("@nm_primary_juice_brix", nmPjBrix));
            update_param.Add(new SqlParameter("@nm_primary_juice_pol", nmPjPol));
            update_param.Add(new SqlParameter("@nm_primary_juice_purity", nmPjPurity));
            update_param.Add(new SqlParameter("@om_primary_juice_brix", omPjBrix));
            update_param.Add(new SqlParameter("@om_primary_juice_pol", omPjPol));
            update_param.Add(new SqlParameter("@om_primary_juice_purity", omPjPurity));
            update_param.Add(new SqlParameter("@nm_mixed_juice_brix", nmMjBrix));
            update_param.Add(new SqlParameter("@nm_mixed_juice_pol", nmMjPol));
            update_param.Add(new SqlParameter("@nm_mixed_juice_purity", nmMjPurity));
            update_param.Add(new SqlParameter("@om_mixed_juice_brix", omMjBrix));
            update_param.Add(new SqlParameter("@om_mixed_juice_pol", omMjPol));
            update_param.Add(new SqlParameter("@om_mixed_juice_purity", omMjPurity));
            update_param.Add(new SqlParameter("@nm_last_juice_brix", nmLjBrix));
            update_param.Add(new SqlParameter("@nm_last_juice_pol", nmLjPol));
            update_param.Add(new SqlParameter("@nm_last_juice_purity", nmLjPurity));
            update_param.Add(new SqlParameter("@om_last_juice_brix", omLjBrix));
            update_param.Add(new SqlParameter("@om_last_juice_pol", omLjPol));
            update_param.Add(new SqlParameter("@om_last_juice_purity", omLjPurity));
            update_param.Add(new SqlParameter("@oliver_juice_brix", filteredJuiceBrix));
            update_param.Add(new SqlParameter("@oliver_juice_pol", filteredJuicePol));
            update_param.Add(new SqlParameter("@oliver_juice_ph", filteredJuicePh));
            update_param.Add(new SqlParameter("@oliver_juice_purity", filteredJuicePurity));
            update_param.Add(new SqlParameter("@clear_juice_brix", clearedJuiceBrix));
            update_param.Add(new SqlParameter("@clear_juice_pol", clearedJuicePol));
            update_param.Add(new SqlParameter("@clear_juice_ph", clearedJuicePh));
            update_param.Add(new SqlParameter("@clear_juice_purity", clearedJuicePurity));
            update_param.Add(new SqlParameter("@unsulphured_syrup_brix", unSulphuredJuiceBrix));
            update_param.Add(new SqlParameter("@unsulphured_syrup_pol", unSulphuredJuicePol));
            update_param.Add(new SqlParameter("@unsulphured_syrup_ph", unSulphuredJuicePh));
            update_param.Add(new SqlParameter("@unsulphured_syrup_purity", unSulphuredJuicePurity));
            update_param.Add(new SqlParameter("@sulphured_syrup_brix", sulphuredJuiceBrix));
            update_param.Add(new SqlParameter("@sulphured_syrup_pol", sulphuredJuicePol));
            update_param.Add(new SqlParameter("@sulphured_syrup_ph", sulphuredJuicePh));
            update_param.Add(new SqlParameter("@sulphured_syrup_purity", sulphuredJuicePurity));
            update_param.Add(new SqlParameter("@final_molasses_brix", finalMolassesBrix));
            update_param.Add(new SqlParameter("@final_molasses_pol", finalMolassesPol));
            update_param.Add(new SqlParameter("@final_molasses_purity", finalMolassesPurity));
            update_param.Add(new SqlParameter("@final_molasses_temp", finalMolassesTemp));
            update_param.Add(new SqlParameter("@final_molasses_tanks", finalMolassesTanks));
            update_param.Add(new SqlParameter("@nm_bagasse_pol", bagasseNmPol));
            update_param.Add(new SqlParameter("@nm_bagasse_moisture", bagasseNmMoisture));
            update_param.Add(new SqlParameter("@om_bagasse_pol", bagasseOmPol));
            update_param.Add(new SqlParameter("@om_bagasse_moisture", bagasseOmMoisture));
            update_param.Add(new SqlParameter("@pol_pressure_cake_sample1", pressCakeSample1));
            update_param.Add(new SqlParameter("@pol_pressure_cake_sample2", pressCakeSample2));
            update_param.Add(new SqlParameter("@pol_pressure_cake_sample3", pressCakeSample3));
            update_param.Add(new SqlParameter("@pol_pressure_cake_sample4", pressCakeSample4));
            update_param.Add(new SqlParameter("@pol_pressure_cake_sample5", pressCakeSample5));
            update_param.Add(new SqlParameter("@pol_pressure_cake_average", pressCakeSampleAverage));
            update_param.Add(new SqlParameter("@pol_pressure_cake_moisture", pressCakeMoisture));
            update_param.Add(new SqlParameter("@pol_pressure_cake_composite", pressCakeComposite));
            update_param.Add(new SqlParameter("@standing_trucks", standingTrucks));
            update_param.Add(new SqlParameter("@standing_trolleys", standingTrolley));
            update_param.Add(new SqlParameter("@standing_triplers", standingTripplers));
            update_param.Add(new SqlParameter("@standing_cart", standingCart));
            update_param.Add(new SqlParameter("@uncrushed_cane", unCrushedCane));
            update_param.Add(new SqlParameter("@crushed_cane", crushedCane));
            update_param.Add(new SqlParameter("@updt_dt", DateTime.Now.ToString("yyyy-MM-dd hh:mm:ss")));
            update_param.Add(new SqlParameter("@updt_by", genFunc.userCode));
            
            
            try
            {
                updated_record_count = SqlHelper.ExecuteNonQuery(dbConn.sqlConn(), CommandType.Text, update_sql, update_param.ToArray());
            }
            catch (SqlException sqlEx)
            {
                expHelper.statusMsg = "Error while updating two hourly data.\nError message" + sqlEx.Message + "\nStack Trace" + sqlEx.StackTrace;
            }
            catch (Exception ex)
            {
                expHelper.statusMsg = "Error while updating two hourly data.\nError message" + ex.Message + "\nStack Trace" + ex.StackTrace;
            }
            return updated_record_count;
        }
        #endregion

        #region select values from table-> transactions_two_hourly
        /// <summary>
        /// Two Hourly data for selected date and time
        /// </summary>
        /// <param name="entry_date"></param>
        /// <param name="entry_time"></param>
        /// <returns></returns>
        public DataTable getTwoHourlyData(string entry_date, int entry_time)
        {
            DataTable twoHourlyDataTable = null;
            string sql = @"select entry_time, nm_primary_juice_brix ,nm_primary_juice_pol ,nm_primary_juice_purity , om_primary_juice_brix " +
                        " ,om_primary_juice_pol ,om_primary_juice_purity ,nm_mixed_juice_brix ,nm_mixed_juice_pol " +
                        " ,nm_mixed_juice_purity ,om_mixed_juice_brix ,om_mixed_juice_pol ,om_mixed_juice_purity " +
                        " ,nm_last_juice_brix ,nm_last_juice_pol ,nm_last_juice_purity ,om_last_juice_brix ,om_last_juice_pol " +
                        " ,om_last_juice_purity ,oliver_juice_brix ,oliver_juice_pol ,oliver_juice_ph " +
                        " ,oliver_juice_purity ,clear_juice_brix ,clear_juice_pol ,clear_juice_ph " +
                        " ,clear_juice_purity ,unsulphured_syrup_brix ,unsulphured_syrup_pol ,unsulphured_syrup_ph " +
                        " ,unsulphured_syrup_purity ,sulphured_syrup_brix ,sulphured_syrup_pol ,sulphured_syrup_ph " +
                        " ,sulphured_syrup_purity ,final_molasses_brix ,final_molasses_pol ,final_molasses_purity " +
                        " ,final_molasses_temp ,final_molasses_tanks ,nm_bagasse_pol ,nm_bagasse_moisture " +
                        " ,om_bagasse_pol ,om_bagasse_moisture ,pol_pressure_cake_sample1 ,pol_pressure_cake_sample2 " +
                        " ,pol_pressure_cake_sample3 ,pol_pressure_cake_sample4 ,pol_pressure_cake_sample5 ,pol_pressure_cake_average " +
                        " ,pol_pressure_cake_moisture ,pol_pressure_cake_composite ,standing_trucks ,standing_trolleys " +
                        " ,standing_triplers ,standing_cart ,uncrushed_cane ,crushed_cane " +
                        " ,unique_entry_code ,crtd_dt ,crtd_by ,updt_dt ,updt_by ,udc  " +
                        " from transactions_two_hourly " +
                        " where entry_date = @entry_date and entry_time = @entry_time ";
            List<SqlParameter> param = new List<SqlParameter>();
            param.Add(new SqlParameter("@entry_date", entry_date));
            param.Add(new SqlParameter("@entry_time", entry_time));
            try
            {
                twoHourlyDataTable = SqlHelper.ExecuteDataset(dbConn.sqlConn(), CommandType.Text, sql, param.ToArray()).Tables[0];
            }
            catch (SqlException sqlEx)
            {
                MessageBox.Show("Error occured while fetching two hourly records.\nError Message"+sqlEx.Message, "Sql Exception!", MessageBoxButtons.OK, MessageBoxIcon.Error);
                expHelper.statusMsg = "Error occured while fetching two hourly records.\nError Message" + sqlEx.Message + "\nStack Trace" + sqlEx.StackTrace;

            }
            catch (NullReferenceException nullEx)
            {
                MessageBox.Show("No data for  @entry_date and @entry_time\n" + nullEx.Message, "Null Exception", MessageBoxButtons.OK, MessageBoxIcon.Error);
                expHelper.statusMsg = "Error occured while fetching two hourly records.\nError Message" + nullEx.Message + "\nStack Trace" + nullEx.StackTrace;

            }
            catch (Exception genEx)
            {
                MessageBox.Show("Generic exception  @entry_date and @entry_time\n" + genEx.Message, "Null Exception", MessageBoxButtons.OK, MessageBoxIcon.Error);
                expHelper.statusMsg = "Generic error occured while fetching two hourly records.\nError Message" + genEx.Message + "\nStack Trace" + genEx.StackTrace;
            }
            return twoHourlyDataTable;
        }
        /// <summary>
        /// Two hourly data for selected date
        /// </summary>
        /// <param name="entry_date"></param>
        /// <param name="entry_time"></param>
        /// <returns></returns>
        public DataTable getTwoHourlyData(string entry_date)
        {
            DataTable twoHourlyDataTable = null;
            string sql = @"select entry_time, nm_primary_juice_brix ,nm_primary_juice_pol ,nm_primary_juice_purity , om_primary_juice_brix " +
                        " ,om_primary_juice_pol ,om_primary_juice_purity ,nm_mixed_juice_brix ,nm_mixed_juice_pol " +
                        " ,nm_mixed_juice_purity ,om_mixed_juice_brix ,om_mixed_juice_pol ,om_mixed_juice_purity " +
                        " ,nm_last_juice_brix ,nm_last_juice_pol ,nm_last_juice_purity ,om_last_juice_brix ,om_last_juice_pol " +
                        " ,om_last_juice_purity ,oliver_juice_brix ,oliver_juice_pol ,oliver_juice_ph " +
                        " ,oliver_juice_purity ,clear_juice_brix ,clear_juice_pol ,clear_juice_ph " +
                        " ,clear_juice_purity ,unsulphured_syrup_brix ,unsulphured_syrup_pol ,unsulphured_syrup_ph " +
                        " ,unsulphured_syrup_purity ,sulphured_syrup_brix ,sulphured_syrup_pol ,sulphured_syrup_ph " +
                        " ,sulphured_syrup_purity ,final_molasses_brix ,final_molasses_pol ,final_molasses_purity " +
                        " ,final_molasses_temp ,final_molasses_tanks ,nm_bagasse_pol ,nm_bagasse_moisture " +
                        " ,om_bagasse_pol ,om_bagasse_moisture ,pol_pressure_cake_sample1 ,pol_pressure_cake_sample2 " +
                        " ,pol_pressure_cake_sample3 ,pol_pressure_cake_sample4 ,pol_pressure_cake_sample5 ,pol_pressure_cake_average " +
                        " ,pol_pressure_cake_moisture ,pol_pressure_cake_composite ,standing_trucks ,standing_trolleys " +
                        " ,standing_triplers ,standing_cart ,uncrushed_cane ,crushed_cane " +
                        " ,unique_entry_code ,crtd_dt ,crtd_by ,updt_dt ,updt_by ,udc  " +
                        " from transactions_two_hourly " +
                        " where entry_date = @entry_date  ";
            List<SqlParameter> param = new List<SqlParameter>();
            param.Add(new SqlParameter("@entry_date", entry_date));
            
            try
            {
                twoHourlyDataTable = SqlHelper.ExecuteDataset(dbConn.sqlConn(), CommandType.Text, sql, param.ToArray()).Tables[0];
            }
            catch (SqlException sqlEx)
            {
                MessageBox.Show("Error occured while fetching two hourly records.\nError Message" + sqlEx.Message, "Sql Exception!", MessageBoxButtons.OK, MessageBoxIcon.Error);
                expHelper.statusMsg = "Error occured while fetching two hourly records.\nError Message" + sqlEx.Message + "\nStack Trace" + sqlEx.StackTrace;

            }
            catch (NullReferenceException nullEx)
            {
                MessageBox.Show("No data for  @entry_date and @entry_time\n" + nullEx.Message, "Null Exception", MessageBoxButtons.OK, MessageBoxIcon.Error);
                expHelper.statusMsg = "Error occured while fetching two hourly records.\nError Message" + nullEx.Message + "\nStack Trace" + nullEx.StackTrace;

            }
            catch (Exception genEx)
            {
                MessageBox.Show("Generic exception  @entry_date and @entry_time\n" + genEx.Message, "Null Exception", MessageBoxButtons.OK, MessageBoxIcon.Error);
                expHelper.statusMsg = "Generic error occured while fetching two hourly records.\nError Message" + genEx.Message + "\nStack Trace" + genEx.StackTrace;
            }
            return twoHourlyDataTable;
        }
        #endregion

        #region Check either entry for definded date and time is possible or not? here we will check unique_entry_code in database, if unique code already exists we will refuse entries
        public bool isHourlyTransactionEntryPossible(string entry_date, string entry_time)
        {
            bool possibility = false;
            int records;
            string sql = @"select count(1) count from transactions_two_hourly where entry_date = @entry_date and entry_time = @entry_time";
            List<SqlParameter> param = new List<SqlParameter>();
            param.Add(new SqlParameter("@entry_date", entry_date));
            param.Add(new SqlParameter("@entry_time", entry_time));
            try
            {
                records = Convert.ToInt16(SqlHelper.ExecuteScalar(dbConn.sqlConn(), CommandType.Text, sql, param.ToArray()));
                if (records == 0)
                {
                    possibility = true;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Execption - " + ex.Message + "\n For more details please check log file", "Exception", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                expHelper.statusMsg = "ERR: Entry not possible.\nException Message " + ex.Message + "\nStack Trace - " + ex.StackTrace;
            }
            return possibility;
        }


        #endregion
        
        /// No need of this functions this function have some hardcoded parameters which can lead to invalid 
        /// values
        /// 

      /*  public DataSet get_two_hourly_averages()
        {
            DataSet ds = null;
            try
            {
                List<SqlParameter> param = new List<SqlParameter>();
                param.Add(new SqlParameter("transaction_date", "2016-11-06"));
                param.Add(new SqlParameter("transaction_time", 10));
                param.Add(new SqlParameter("@entry_date",SqlDbType.Date));
                param.Add(new SqlParameter("@entry_time", SqlDbType.Int));
                param.Add(new SqlParameter("@combined_pj_brix_avg",SqlDbType.Decimal));

                param.Add(new SqlParameter("@combined_pj_pol_avg", SqlDbType.Decimal));
                param.Add(new SqlParameter("@combined_mj_brix_avg", SqlDbType.Decimal));
                param.Add(new SqlParameter("@combined_mj_pol_avg", SqlDbType.Decimal));
                param.Add(new SqlParameter("@combined_lj_brix_avg", SqlDbType.Decimal));

                param.Add(new SqlParameter("@combined_lj_pol_avg", SqlDbType.Decimal));
                param.Add(new SqlParameter("@combined_pj_purity", SqlDbType.Decimal));
                param.Add(new SqlParameter("@combined_mj_purity", SqlDbType.Decimal));
                param.Add(new SqlParameter("@combined_lj_purity", SqlDbType.Decimal));
                param.Add(new SqlParameter("@combined_bagasse_pol", SqlDbType.Decimal));
                param.Add(new SqlParameter("@combined_bagasse_moist", SqlDbType.Decimal));
                param.Add(new SqlParameter("@combined_bagasse_pol_avg", SqlDbType.Decimal));
                param.Add(new SqlParameter("@combined_bagasse_moist_avg", SqlDbType.Decimal));
                param.Add(new SqlParameter("@press_cake_avg", SqlDbType.Decimal));
                param.Add(new SqlParameter("@final_mol_brix", SqlDbType.Decimal));
                param.Add(new SqlParameter("@final_mol_pol", SqlDbType.Decimal));
                ds = SqlHelper.ExecuteDataset(dbConn.sqlConn(), CommandType.StoredProcedure, "proc_final_calculation",param.ToArray());
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            return ds;
        }*/
    }


}
