﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Windows.Forms;
using System.Data.SqlClient;
using Microsoft.ApplicationBlocks.Data;

namespace Litmus.classes
{
    
    class vehicle_master_logic
    {
        DbConnections dbConn = new DbConnections();
        classes.ExceptionHelper expHelper = new ExceptionHelper();
        public void insertVehicleDetails(int vehicleCode, string vehicleName, float averageWeight, bool isActive, string crtdBy)
        {
            string sql = @"insert into vehicle_master(v_code, v_name, v_average_weight, v_is_active, v_crtd_by) " +
                        " values(@vehicleCode, @vehicleName, @averageWeight, @isActive, @crtdBy)";
            List<SqlParameter> sqlParam = new List<SqlParameter>();
            sqlParam.Add(new SqlParameter("@vehicleCode", vehicleCode));
            sqlParam.Add(new SqlParameter("@vehicleName", vehicleName));
            sqlParam.Add(new SqlParameter("@averageWeight", averageWeight));
            sqlParam.Add(new SqlParameter("@isActive", isActive));
            sqlParam.Add(new SqlParameter("@crtdBy", crtdBy));
            int insertedRows = 0;
            try
            {
                insertedRows = SqlHelper.ExecuteNonQuery(dbConn.sqlConn(), CommandType.Text, sql, sqlParam.ToArray());
                MessageBox.Show(insertedRows + " record(s) inserted",
                    "Success",
                    MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (SqlException ex)
            {
                MessageBox.Show("Error occured while inserting Vehicle details!\nError Message - " + ex.Message + "\n For more details check error log", "Error!", MessageBoxButtons.OK, MessageBoxIcon.Error);
                expHelper.statusMsg = "ERROR: Error occured while inserting Vehicle details!\nError Message - " + ex.Message + "\n " + ex.StackTrace;
            }
        }
        public DataSet getVehicleDetails()
        {
            DataSet ds = null;
            string sql = @"select v_code, v_name, v_average_weight, v_is_active from vehicle_master";
            try
            {
                ds = SqlHelper.ExecuteDataset(dbConn.sqlConn(), CommandType.Text, sql);
            }
            catch (SqlException ex)
            {
                MessageBox.Show("Error occured while selecting all Vehicle details!\nError Message - " + ex.Message + "\n For more details check error log", "Error!", MessageBoxButtons.OK, MessageBoxIcon.Error);
                expHelper.statusMsg = "ERROR: Error occured while selecting All Vehicle details!\nError Message - " + ex.Message + "\n " + ex.StackTrace;
            }
            return ds;
        }
        public DataSet getVehicleDetails(string vehicleName)
        {
            DataSet ds = null;
            string sql = @"select v_code, v_name, v_agerage_weight, v_is_active from vehicle_master where v_name like %@vehicleName%";
            List<SqlParameter> param = new List<SqlParameter>();
            param.Add(new SqlParameter("@vehicleName", vehicleName));
            try
            {
                ds = SqlHelper.ExecuteDataset(dbConn.sqlConn(), CommandType.Text, sql,param.ToArray());
            }
            catch (SqlException ex)
            {
                MessageBox.Show("Error occured while selecting  Vehicle details!\nError Message - " + ex.Message + "\n For more details check error log", "Error!", MessageBoxButtons.OK, MessageBoxIcon.Error);
                expHelper.statusMsg = "ERROR: Error occured while selecting Vehicle details!\nError Message - " + ex.Message + "\n " + ex.StackTrace;
            }
            return ds;
        }
        public DataSet getVehicleDetails(int vehicleCode)
        {
            DataSet ds = null;
            string sql = @"select v_code, v_name, v_agerage_weight, v_is_active from vehicle_master where v_code = @vehicleCode";
            List<SqlParameter> param = new List<SqlParameter>();
            param.Add(new SqlParameter("@vehicleCode", vehicleCode));
            try
            {
                ds = SqlHelper.ExecuteDataset(dbConn.sqlConn(), CommandType.Text, sql, param.ToArray());
            }
            catch (SqlException ex)
            {
                MessageBox.Show("Error occured while selecting  Vehicle details!\nError Message - " + ex.Message + "\n For more details check error log", "Error!", MessageBoxButtons.OK, MessageBoxIcon.Error);
                expHelper.statusMsg = "ERROR: Error occured while selecting  Vehicle details!\nError Message - " + ex.Message + "\n " + ex.StackTrace;
            }
            return ds;

        }
        
        public void updateVehicleDetails(int vehicleCode, string vehicleName, float averageWeight, bool isActive)
        {
            string sql = @"update vehicle_master set v_code = @vehicleCode, v_name = @vehicleName, v_average_weight = @averageWeight " +
                        " ,v_is_active = @isActive where v_code = @vehicleCode";
            List<SqlParameter> param = new List<SqlParameter>();
            int updatedRecords = 0;
            param.Add(new SqlParameter("@vehicleCode", vehicleCode));
            param.Add(new SqlParameter("@vehicleName", vehicleName));
            param.Add(new SqlParameter("@averageWeight", averageWeight));
            param.Add(new SqlParameter("@isActive", isActive));
            try
            {
                updatedRecords = SqlHelper.ExecuteNonQuery(dbConn.sqlConn(), CommandType.Text, sql, param.ToArray());
                MessageBox.Show(updatedRecords + " vehicle record(s) updated", "Updation Success!", MessageBoxButtons.OK, MessageBoxIcon.Information); 
            }
            catch (SqlException ex)
            {
                MessageBox.Show("Error occured while updating all Vehicle details!\nError Message - " + ex.Message + "\n For more details check error log", "Error!", MessageBoxButtons.OK, MessageBoxIcon.Error);
                expHelper.statusMsg = "ERROR: Error occured while updating Vehicle details!\nError Message - " + ex.Message + "\n " + ex.StackTrace;
            }

        }
           
    }
}
