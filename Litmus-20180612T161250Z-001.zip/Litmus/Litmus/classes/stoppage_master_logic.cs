﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.SqlClient;
using Microsoft.ApplicationBlocks.Data;
using Litmus.classes;
using System.Windows.Forms;
namespace Litmus.classes
{
    class stoppage_master_logic
    {
        generalFunctions genFunc = new generalFunctions();
        ExceptionHelper expHelper = new ExceptionHelper();
        DbConnections dbConn = new DbConnections();

        #region insert Stoppage Head
        public bool insert_stoppage_head(string stoppage_head, int isActive, string description)
        {
            bool insertion_sucess = false;
            int inserted_rows = 0;
            string insert_sql = @"insert into stoppage_head(sh_name, sh_is_active, sh_crtd_by, sh_description) " +
                                   " values( @sh_name, @sh_is_active, @sh_crtd_by, @sh_description)";

            string current_user = genFunc.userCode;
            List<SqlParameter> insertParam = new List<SqlParameter>();
            insertParam.Add(new SqlParameter("@sh_name", stoppage_head));
            insertParam.Add(new SqlParameter("@sh_is_active", isActive));
            insertParam.Add(new SqlParameter("@sh_crtd_by", current_user));
            insertParam.Add(new SqlParameter("@sh_description", description));
            try
            {
                inserted_rows = SqlHelper.ExecuteNonQuery(dbConn.sqlConn(), CommandType.Text, insert_sql, insertParam.ToArray());
                if (inserted_rows == 1)
                {
                    insertion_sucess = true;
                }
                else if (inserted_rows > 1)
                {
                    MessageBox.Show("More than 1 row affected", "Caution!!", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
                else
                {
                    insertion_sucess = false;
                }

            }
            catch (SqlException ex)
            {
                MessageBox.Show("Sql exception occured while inserting 'Stoppage Head'.\nError message: " + ex.Message + "\nFor more information check error log",
                    "Sql Exception!!", MessageBoxButtons.OK, MessageBoxIcon.Error);
                expHelper.statusMsg = "Sql exception occured while inserting 'Stoppage Head'.\nError message: " + ex.Message + "\nStack Trace :" + ex.StackTrace;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Generic exception occured while inserting 'Stoppage Head'.\nError message: " + ex.Message + "\nFor more information check error log",
                    "Generic Exception!!", MessageBoxButtons.OK, MessageBoxIcon.Error);
                expHelper.statusMsg = "Generic exception occured while inserting 'Stoppage Head'.\nError message: " + ex.Message + "\nStack Trace :" + ex.StackTrace;
            }
            return insertion_sucess;
        }
        #endregion
        
        #region insert Stoppage Sub Head
        public bool insert_stoppage_Sub_head(int stoppage_head_code, string stoppage_sub_head, int isActive, string sub_head_description)
        {
            bool insertion_sucess = false;
            int inserted_rows = 0;
            string insert_sql = @"insert into stoppage_sub_head(stoppage_head_code, ss_name, ss_is_active, ss_crtd_by, ss_description) " +
                                   " values(@stoppage_head_code, @ss_name, @ss_is_active, @ss_crtd_by, @ss_description)";

            string current_user = genFunc.userCode;
            List<SqlParameter> insertParam = new List<SqlParameter>();
            insertParam.Add(new SqlParameter("@stoppage_head_code", stoppage_head_code));
            insertParam.Add(new SqlParameter("@ss_name", stoppage_sub_head));
            insertParam.Add(new SqlParameter("@ss_is_active", isActive));
            insertParam.Add(new SqlParameter("@ss_crtd_by", current_user));
            insertParam.Add(new SqlParameter("@ss_description", sub_head_description));
            try
            {
                inserted_rows = SqlHelper.ExecuteNonQuery(dbConn.sqlConn(), CommandType.Text, insert_sql, insertParam.ToArray());
                if (inserted_rows == 1)
                {
                    insertion_sucess = true;
                }
                else if (inserted_rows > 1)
                {
                    MessageBox.Show("More than 1 row affected", "Caution!!", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
                else
                {
                    insertion_sucess = false;
                }

            }
            catch (SqlException ex)
            {
                MessageBox.Show("Sql exception occured while inserting 'Stoppage Head'.\nError message: " + ex.Message + "\nFor more information check error log",
                    "Sql Exception!!", MessageBoxButtons.OK, MessageBoxIcon.Error);
                expHelper.statusMsg = "Sql exception occured while inserting 'Stoppage Head'.\nError message: " + ex.Message + "\nStack Trace :" + ex.StackTrace;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Generic exception occured while inserting 'Stoppage Head'.\nError message: " + ex.Message + "\nFor more information check error log",
                    "Generic Exception!!", MessageBoxButtons.OK, MessageBoxIcon.Error);
                expHelper.statusMsg = "Generic exception occured while inserting 'Stoppage Head'.\nError message: " + ex.Message + "\nStack Trace :" + ex.StackTrace;
            }
            return insertion_sucess;
        }
        #endregion

        #region update stoppage heads
        public bool update_stoppage_head(int sh_code, string stoppage_head, int isActive, string description)
        {
            bool updation_sucess = false;
            int updated_records = 0;
            //string insert_sql = @"insert into stoppage_head(sh_name, sh_is_active, sh_crtd_by, sh_description) " +
            //                       " values( @sh_name, @sh_is_active, @sh_crtd_by, @sh_description)";

            string updateSql = @"update stoppage_head set sh_name=@sh_name, sh_is_active = @sh_is_active " +
                                " , sh_updt_by = @sh_updt_by, sh_updt_dt = @sh_updt_dt, sh_description =@sh_description " +
                                " where sh_code = @sh_code";
                                
            string current_user = genFunc.userCode;
            List<SqlParameter> insertParam = new List<SqlParameter>();
            insertParam.Add(new SqlParameter("@sh_code", sh_code));
            insertParam.Add(new SqlParameter("@sh_name", stoppage_head));
            insertParam.Add(new SqlParameter("@sh_is_active", isActive));
            insertParam.Add(new SqlParameter("@sh_updt_by", current_user));
            insertParam.Add(new SqlParameter("@sh_updt_dt", DateTime.Now.ToString("yyyy-MM-dd")));
            insertParam.Add(new SqlParameter("@sh_description", description));
            try
            {
                updated_records = SqlHelper.ExecuteNonQuery(dbConn.sqlConn(), CommandType.Text, updateSql, insertParam.ToArray());
                if (updated_records == 1)
                {
                    updation_sucess = true;
                }
                else if (updated_records > 1)
                {
                    MessageBox.Show("More than 1 row affected", "Caution!!", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
                else
                {
                    updation_sucess = false;
                }

            }
            catch (SqlException ex)
            {
                MessageBox.Show("Sql exception occured while updating 'Stoppage Head'.\nError message: " + ex.Message + "\nFor more information check error log",
                    "Sql Exception!!", MessageBoxButtons.OK, MessageBoxIcon.Error);
                expHelper.statusMsg = "Sql exception occured while updating 'Stoppage Head'.\nError message: " + ex.Message + "\nStack Trace :" + ex.StackTrace;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Generic exception occured while updating 'Stoppage Head'.\nError message: " + ex.Message + "\nFor more information check error log",
                    "Generic Exception!!", MessageBoxButtons.OK, MessageBoxIcon.Error);
                expHelper.statusMsg = "Generic exception occured while updating 'Stoppage Head'.\nError message: " + ex.Message + "\nStack Trace :" + ex.StackTrace;
            }
            return updation_sucess;
        }
        #endregion

        #region update stoppage sub heads
        public bool update_stoppage_Sub_head(int stoppage_head_code, int ss_code, string stoppage_sub_head, int isActive, string sub_head_description)
        {
            bool update_sucess = false;
            int updated_rows = 0;
           
            
            string update_sql = @"update stoppage_sub_head set ss_name = @ss_name, ss_is_active = @ss_is_active "+
                " , ss_updt_by = @ss_updt_by, ss_description = @ss_description, ss_updt_dt = @ss_updt_dt " +
                " where stoppage_head_code = @stoppage_head_code and ss_code = @ss_code";
            
            string current_user = genFunc.userCode;
            List<SqlParameter> updateParam = new List<SqlParameter>();
            updateParam.Add(new SqlParameter("@stoppage_head_code", stoppage_head_code));
            updateParam.Add(new SqlParameter("@ss_code", ss_code));
            updateParam.Add(new SqlParameter("@ss_name", stoppage_sub_head));
            updateParam.Add(new SqlParameter("@ss_is_active", isActive));
            updateParam.Add(new SqlParameter("@ss_updt_by", current_user));
            updateParam.Add(new SqlParameter("@ss_updt_dt", DateTime.Now.ToString("yyyy-MM-dd")));
            updateParam.Add(new SqlParameter("@ss_description", sub_head_description));
            try
            {
                updated_rows = SqlHelper.ExecuteNonQuery(dbConn.sqlConn(), CommandType.Text, update_sql, updateParam.ToArray());
                if (updated_rows == 1)
                {
                    update_sucess = true;
                }
                else if (updated_rows > 1)
                {
                    MessageBox.Show("More than 1 row affected", "Caution!!", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
                else
                {
                    update_sucess = false;
                }

            }
            catch (SqlException ex)
            {
                MessageBox.Show("Sql exception occured while updating 'Stoppage Head'.\nError message: " + ex.Message + "\nFor more information check error log",
                    "Sql Exception!!", MessageBoxButtons.OK, MessageBoxIcon.Error);
                expHelper.statusMsg = "Sql exception occured while updating 'Stoppage Head'.\nError message: " + ex.Message + "\nStack Trace :" + ex.StackTrace;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Generic exception occured while updating 'Stoppage Head'.\nError message: " + ex.Message + "\nFor more information check error log",
                    "Generic Exception!!", MessageBoxButtons.OK, MessageBoxIcon.Error);
                expHelper.statusMsg = "Generic exception occured while updating 'Stoppage Head'.\nError message: " + ex.Message + "\nStack Trace :" + ex.StackTrace;
            }
            return update_sucess;
        }
        #endregion

        #region get list of existing stoppage heads
        public DataTable get_stoppage_head_list()
        {
             DataTable  dt_stoppage_head = null;
            string sqlGetStoppageList = @"select sh_code, sh_name, sh_description from stoppage_head where sh_is_active = 1 order by sh_code";
            try
            {
                dt_stoppage_head = SqlHelper.ExecuteDataset(dbConn.sqlConn(), CommandType.Text, sqlGetStoppageList).Tables[0];
            }
            catch (SqlException sqlEx)
            {
                MessageBox.Show("Sql exception occured while getting list of 'Stoppage Head'.\nError message: " + sqlEx.Message + "\nFor more information check error log",
                       "Sql Exception!!", MessageBoxButtons.OK, MessageBoxIcon.Error);
                expHelper.statusMsg = "Sql exception occured while getting list of 'Stoppage Head'.\nError message: " + sqlEx.Message + "\nStack Trace :" + sqlEx.StackTrace;
            }
            catch (NullReferenceException ex)
            {
                MessageBox.Show("No data found while getting list of 'Stoppage Head'.\nError message: " + ex.Message + "\nFor more information check error log",
                    "Null Reference Exception!!", MessageBoxButtons.OK, MessageBoxIcon.Error);
                expHelper.statusMsg = "No data found while getting list of 'Stoppage Head'.\nError message: " + ex.Message + "\nStack Trace :" + ex.StackTrace;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Generic exception occured while getting list of 'Stoppage Head'.\nError message: " + ex.Message + "\nFor more information check error log",
                "Generic Exception!!", MessageBoxButtons.OK, MessageBoxIcon.Error);
                expHelper.statusMsg = "Generic exception occured while getting list of 'Stoppage Head'.\nError message: " + ex.Message + "\nStack Trace :" + ex.StackTrace;
            }
            return dt_stoppage_head;
        }
        #endregion

        #region get list of existing stoppage sub heads
        public DataTable get_stoppage_sub_head_list(int stoppage_head_code)
        {
            DataTable dt = null;

            string selectSql = @"select ss_code, ss_name, ss_description from stoppage_sub_head where ss_is_active = 1 and stoppage_head_code = @stoppage_head_code order by ss_name";
            List<SqlParameter> param = new List<SqlParameter>();
            param.Add(new SqlParameter("@stoppage_head_code", stoppage_head_code));
            try
            {
                dt = SqlHelper.ExecuteDataset(dbConn.sqlConn(), CommandType.Text, selectSql,param.ToArray()).Tables[0];
            }
            catch (SqlException sqlEx)
            {
                MessageBox.Show("Sql exception occured while getting list of 'Stoppage Sub Head'.\nError message: " + sqlEx.Message + "\nFor more information check error log",
                       "Sql Exception!!", MessageBoxButtons.OK, MessageBoxIcon.Error);
                expHelper.statusMsg = "Sql exception occured while getting list of 'Stoppage Head'.\nError message: " + sqlEx.Message + "\nStack Trace :" + sqlEx.StackTrace;
            }
            catch (NullReferenceException ex)
            {
                MessageBox.Show("No data found while getting list of 'Stoppage Sub Head'.\nError message: " + ex.Message + "\nFor more information check error log",
                    "Null Reference Exception!!", MessageBoxButtons.OK, MessageBoxIcon.Error);
                expHelper.statusMsg = "No data found while getting list of 'Stoppage Sub Head'.\nError message: " + ex.Message + "\nStack Trace :" + ex.StackTrace;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Generic exception occured while getting list of 'Stoppage Sub Head'.\nError message: " + ex.Message + "\nFor more information check error log",
                "Generic Exception!!", MessageBoxButtons.OK, MessageBoxIcon.Error);
                expHelper.statusMsg = "Generic exception occured while getting list of 'Stoppage Sub Head'.\nError message: " + ex.Message + "\nStack Trace :" + ex.StackTrace;
            }
            
            return dt;
        }
        #endregion

        #region select all details of stoppage heads (as on click event of query button)

        public DataTable stoppage_head_details_all()
        {
            DataTable stoppageHead_Table=null;
            string sql = @"select sh_code, sh_name, sh_is_active, sh_description from stoppage_head order by sh_code";
            try
            {
                stoppageHead_Table = SqlHelper.ExecuteDataset(dbConn.sqlConn(), CommandType.Text, sql).Tables[0];
            }
            catch (SqlException sqlExp)
            {
                MessageBox.Show("Sql Exception occured while fetching 'Stoppage Head All Details'\nError Message: " + sqlExp.Message + "\nFor more details please check log file", "Sql Exception!!", MessageBoxButtons.OK, MessageBoxIcon.Error);
                expHelper.statusMsg = "Sql exception occured while fetching 'Stoppage Head All Details'.\nError message: " + sqlExp.Message + "\nStack Trace :" + sqlExp.StackTrace;
            }
            catch (NullReferenceException ex)
            {
                MessageBox.Show("No data found while fetching 'Stoppage Head All Details.\nError message: " + ex.Message + "\nFor more information check error log",
                    "Null Reference Exception!!", MessageBoxButtons.OK, MessageBoxIcon.Error);
                expHelper.statusMsg = "No data found while fetching 'Stoppage Head All Details.\nError message: " + ex.Message + "\nStack Trace :" + ex.StackTrace;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Generic exception occured while fetching 'Stoppage Head All Details.\nError message: " + ex.Message + "\nFor more information check error log",
                "Generic Exception!!", MessageBoxButtons.OK, MessageBoxIcon.Error);
                expHelper.statusMsg = "Generic exception occured while fetching 'Stoppage Head All Details.\nError message: " + ex.Message + "\nStack Trace :" + ex.StackTrace;
            }
            return stoppageHead_Table;
        }
        #endregion

        #region select all details of Stoppage Sub Head
        public DataTable stoppage_sub_head_details_all(int stoppage_head_code)
        {
            string sql = @"select ss_code, ss_name, ss_is_active, ss_description from stoppage_sub_head where stoppage_head_code = @stoppage_head_code";
            List<SqlParameter> param = new List<SqlParameter>();
            param.Add(new SqlParameter("@stoppage_head_code", stoppage_head_code));
            DataTable stoppage_sub_head_dt = null;
            try
            {
                stoppage_sub_head_dt = SqlHelper.ExecuteDataset(dbConn.sqlConn(), CommandType.Text, sql,param.ToArray()).Tables[0];
            }
            catch (SqlException sqlExp)
            {
                MessageBox.Show("Sql Exception occured while fetching 'Stoppage Sub Head All Details'\nError Message: " + sqlExp.Message + "\nFor more details please check log file", "Sql Exception!!", MessageBoxButtons.OK, MessageBoxIcon.Error);
                expHelper.statusMsg = "Sql exception occured while fetching 'Stoppage Sub Head All Details'.\nError message: " + sqlExp.Message + "\nStack Trace :" + sqlExp.StackTrace;
            }
            catch (NullReferenceException ex)
            {
                MessageBox.Show("No data found while fetching 'Stoppage Sub Head All Details.\nError message: " + ex.Message + "\nFor more information check error log",
                    "Null Reference Exception!!", MessageBoxButtons.OK, MessageBoxIcon.Error);
                expHelper.statusMsg = "No data found while fetching 'Stoppage Sub Head All Details.\nError message: " + ex.Message + "\nStack Trace :" + ex.StackTrace;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Generic exception occured while fetching 'Stoppage Sub Head All Details.\nError message: " + ex.Message + "\nFor more information check error log",
                "Generic Exception!!", MessageBoxButtons.OK, MessageBoxIcon.Error);
                expHelper.statusMsg = "Generic exception occured while fetching 'Stoppage Sub Head All Details.\nError message: " + ex.Message + "\nStack Trace :" + ex.StackTrace;
            }
            return stoppage_sub_head_dt;
        }
        #endregion
    }
}
