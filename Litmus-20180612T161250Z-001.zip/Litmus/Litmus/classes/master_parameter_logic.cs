﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using System.Data.Common;
using Microsoft.ApplicationBlocks.Data;
using System.Windows.Forms;
namespace Litmus.classes
{
    class master_parameter_logic
    {
        generalFunctions genFunc = new generalFunctions();
        DbConnections dbConn = new DbConnections();
        classes.ExceptionHelper expHelper = new ExceptionHelper();

        public static string _unitName = string.Empty, _crushing_season = string.Empty, _reportStartTime = string.Empty;
        public static string _curshing_start_date, _crushing_end_date;
        public static string _designation1 = string.Empty, _designation2 = string.Empty, _designation3 = string.Empty, _designation4 = string.Empty, _designation5 = string.Empty;
        public static string _name1 = string.Empty, _name2 = string.Empty, _name3 = string.Empty, _name4 = string.Empty, _name5 = string.Empty;
        public static double _newMillCapacity = 0, _oldMillCapacity = 0;
        public static string _entryDate, _processDate;
        public int _dayHours = 0;

        public string unitName { get { return _unitName; } set { _unitName = value; } }
        public string crushing_season { get { return _crushing_season ; } set { _crushing_season = value; } }
        public string reportStartTime { get { return _reportStartTime; } set { _reportStartTime = value; } }

        public string crushingStartDate { get { return _curshing_start_date; } set { _curshing_start_date = value; } }
        public string crushingEndDate { get { return _crushing_end_date; } set { _crushing_end_date = value; } }

        public string designation1 { get { return _designation1; } set { _designation1 = value; } }
        public string designation2 { get { return _designation2; } set { _designation2 = value; } }
        public string designation3 { get { return _designation3; } set { _designation3 = value; } }
        public string designation4 { get { return _designation4; } set { _designation4 = value; } }
        public string designation5 { get { return _designation5; } set { _designation5 = value; } }

        public string name1 { get { return _name1; } set { _name1 = value; } }
        public string name2 { get { return _name2; } set { _name2 = value; } }
        public string name3 { get { return _name3; } set { _name3 = value; } }
        public string name4 { get { return _name4; } set { _name4 = value; } }
        public string name5 { get { return _name5; } set { _name5 = value; } }

        public  double newMillCapacity { get { return _newMillCapacity; } set { _newMillCapacity = value; } }
        public  double oldMillCapacity { get { return _oldMillCapacity; } set { _oldMillCapacity = value; } }

        public string entryDate { get { return _entryDate; } set { _entryDate = value; } }
        public string processDate { get { return _processDate; } set { _processDate = value; } }

        public int dayHours { get { return _dayHours; } set { _dayHours = value; } }
        Dictionary<int, string> formData = new Dictionary<int, string>();
        private SqlDataAdapter sda = new SqlDataAdapter();

        public DataSet setParameters()
        {
            DataTable dt = null;
            string sql = @"select * from controls order by param_code";
            DataSet ds = new DataSet();
            
            try
            {
                using (SqlConnection conn = dbConn.sqlConn())
                {
                    
                    sda.SelectCommand = new SqlCommand(sql, dbConn.sqlConn());
                    SqlCommandBuilder builder = new SqlCommandBuilder(sda);
                    dbConn.sqlConn().Open();
                    sda.Fill(ds);
                    sda.UpdateCommand = builder.GetUpdateCommand();
                    dt = ds.Tables[0];
                    //dt.Rows[0][2] = "test2";
                    
                    dbConn.sqlConn().Close();
                }
                if (dt.Rows.Count > 0)
                {
                    _unitName = dt.Rows[0]["param_value"].ToString();
                    _reportStartTime = dt.Rows[1][2].ToString();
                    _curshing_start_date = dt.Rows[2][2].ToString();
                    _crushing_end_date = dt.Rows[3][2].ToString();
                    _dayHours = Convert.ToInt16(dt.Rows[4][2].ToString());
                    _entryDate = dt.Rows[5][2].ToString();
                    _processDate = dt.Rows[6][2].ToString();
                    _newMillCapacity = Convert.ToDouble(dt.Rows[7][2].ToString());
                    _oldMillCapacity = Convert.ToDouble(dt.Rows[8][2].ToString());
                    _name1 = dt.Rows[9][2].ToString();
                    _name2 = dt.Rows[10][2].ToString();
                    _name3 = dt.Rows[11][2].ToString();
                    _name4 = dt.Rows[12][2].ToString();
                    _designation1 = dt.Rows[13][2].ToString();
                    _designation2 = dt.Rows[14][2].ToString();
                    _designation3 = dt.Rows[15][2].ToString();
                    _designation4 = dt.Rows[16][2].ToString();
                }
                else
                {
                    MessageBox.Show("No master parameters defined!", "Master Parameters", MessageBoxButtons.OK, MessageBoxIcon.Hand);

                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error occured while fetching parameter list\n" + ex.Message, "Error!!", MessageBoxButtons.OK, MessageBoxIcon.Error);
                expHelper.statusMsg = "Error occured while fetching parameter list\n" + ex.Message + "\n stack trace -" + ex.StackTrace;
            }
            return ds;
        }

        public void updateDataset(DataSet ds)
        {
            DialogResult result = MessageBox.Show("Are you sure you want to change parameters?", "Sure to make changes?", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (result == DialogResult.Yes)
            {
                try
                {
                    int recodesUpdate = sda.Update(ds);
                    MessageBox.Show(" Modified parameters updated", "Updated!!", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    setParameters();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error occured while updating basic parameters\n" + ex.StackTrace, "Error, Can't update parameters", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
           
        }

        public void insertFormData(string unit_name,  string reportTime, string crushingStartDate, string crushingEndDate, string dayHours,
               string entryDate, string procecssDate, string newMillCap, string oldMillCap, string desig1, string name1, string desig2, string name2,
               string desig3, string name3, string desig4, string name4, string desig5, string name5)
        {
            formData.Add(1, unit_name);
            formData.Add(2, reportTime);
            formData.Add(3, crushingStartDate);
            formData.Add(4, crushingEndDate);
            formData.Add(5, dayHours);
            formData.Add(6, entryDate);
            formData.Add(7, procecssDate);
            formData.Add(8, newMillCap);
            formData.Add(9, oldMillCap);
            formData.Add(10, name1);
            formData.Add(11, name2);
            formData.Add(12, name3);
            formData.Add(13, name4);
            formData.Add(14, name5);
            formData.Add(15, desig1);
            formData.Add(16, desig2);
            formData.Add(17, desig3);
            formData.Add(18, desig4);
            formData.Add(19, desig5);
            foreach (var pair in formData)
            {
              insertMasterParameter(pair.Key.ToString(),pair.Value.ToString(),genFunc.userCode);
            }
        }

        private void insertMasterParameter(string param_code, string param_value, string crtd_by, string param_standard="0", string param_max_limit="0", string param_min_limit="0", 
                string param_min_alert ="0", string param_max_alert ="0", int isInformative= 0)
        {
            string sql = @"insert into controls(param_code, param_value, param_standard, param_max_limit, param_min_limit, param_max_alert, " +
                           " param_min_alert, is_informative, crtd_by) values (@param_code, @param_value, @param_std, @param_max_limit, @param_min_limit " +
                           " , @param_max_alert, @param_min_alert, @is_informative, @crtd_by)";
            List<SqlParameter> param = new List<SqlParameter>();
            param.Add(new SqlParameter("@param_code", param_code));
            param.Add(new SqlParameter("@param_value", param_value));
            param.Add(new SqlParameter("@param_std", param_standard));
            param.Add(new SqlParameter("@param_max_limit", param_max_limit));
            param.Add(new SqlParameter("@param_min_limit", param_min_limit));
            param.Add(new SqlParameter("@param_max_alert", param_max_alert));
            param.Add(new SqlParameter("@param_min_alert", param_min_alert));
            param.Add(new SqlParameter("@is_informative", isInformative));
            param.Add(new SqlParameter("@crtd_by", crtd_by));

            try
            {
                SqlHelper.ExecuteScalar(dbConn.sqlConn(), CommandType.Text, sql, param.ToArray());
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }  
    }
}
