﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.ApplicationBlocks.Data;
using System.Data;
using System.Data.SqlClient;
namespace Litmus.classes
{
    class key_sampe_logic
    {
        classes.generalFunctions genFunc = new generalFunctions();
        classes.ExceptionHelper expHelper = new ExceptionHelper();
        DbConnections dbConn = new DbConnections();
        /// <summary>
        /// Insert new record for key samples
        /// </summary>
        /// <param name="TRANSACTION DATE"> TRANSACTION DATE</param>
        /// <param name="TRANSACTION TIME"></param>
        /// <param name="PAN NO"></param>
        /// <param name="BRIX %"></param>
        /// <param name="POL %"></param>
        /// <param name="PURITY"></param>
        /// <param name="USER CODE"></param>
        public void insertKeySample(string trans_date, string trans_time, string sugar_stage, int panNo, float brix, float pol, float purity, string userCode)
        {
            try
            {
                string insertSql = @"insert into analysis_key_sample(pan_number, trans_date, trans_time, sugar_stage, brix, pol, purity, crtd_by) " +
                                    " values (@pan_no, @trans_date, @trans_time, @sugar_stage,  @brix, @pol, @purity, @userCode)";
                List<SqlParameter> param = new List<SqlParameter>();
                param.Add(new SqlParameter("@trans_date", trans_date));
                param.Add(new SqlParameter("@trans_time", trans_time));
                param.Add(new SqlParameter("@sugar_stage", sugar_stage));
                param.Add(new SqlParameter("@pan_no", panNo));
                param.Add(new SqlParameter("@brix", brix));
                param.Add(new SqlParameter("@pol", pol));
                param.Add(new SqlParameter("@purity", purity));
                param.Add(new SqlParameter("@userCode", userCode));

                int insertdRows = SqlHelper.ExecuteNonQuery(dbConn.sqlConn(), CommandType.Text, insertSql, param.ToArray());
                MessageBox.Show(insertdRows + " Records inserted!");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error occured. \nError Message: " + ex.Message + "\nFor more details check error log.", "Error!!", MessageBoxButtons.OK, MessageBoxIcon.Error);
                expHelper.statusMsg = "ERROR - While inserting record for key sample.\nError message : " + ex.Message + "\nStack Trace" + ex.StackTrace + "\nHelp link" + ex.HelpLink;
            }

        }
    }
}
