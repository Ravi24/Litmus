﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using Microsoft.ApplicationBlocks.Data;

namespace Litmus.classes
{
    class hourly_report_logic
    {
        classes.generalFunctions genFunc = new generalFunctions();
        classes.ExceptionHelper expHelper = new ExceptionHelper();
        DbConnections dbConn = new DbConnections();
        public string get_report_web_address(int report_code)
        {
            string http_addresss="http://";
            
            string sql = @"select r_web_domain_name+':'+convert(nvarchar(4),ISNULL(r_web_port,80))+'/'+r_web_page_name from report_dtl where r_code = @report_code";

            List<SqlParameter> param = new List<SqlParameter>();
            param.Add(new SqlParameter("@report_code",report_code));

            try
            {
                http_addresss += SqlHelper.ExecuteScalar(dbConn.sqlConn(), CommandType.Text, sql, param.ToArray()).ToString();
            }
            catch (SqlException ex)
            {
                expHelper.statusMsg = "ERROR: " + ex.ToString();
            }

            return http_addresss;
        }
    }
}
