﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using Microsoft.ApplicationBlocks.Data;
using System.Windows.Forms;

namespace Litmus.classes
{
    class stoppage_transaction_logic
    {
        generalFunctions genfunc = new generalFunctions();
        DbConnections dbConn = new DbConnections();
        ExceptionHelper expHelper = new ExceptionHelper();

        public int insertStoppage(string entry_date, string start_time, string end_time, int mill_code, int head_code, string head_name
            , int sub_head_code, string sub_head_name, string comment)
        {
            int insertedRecords = 0;
            string sql = @"insert into transactions_stoppage (s_date, s_start_time, s_end_time, s_mill_code, s_head_code, s_head_name " +
                " ,s_sub_head_code, s_sub_head_name, s_comment, s_crtd_by) values " +
                " (@s_date, @s_start_time, @s_end_time, @mill_code, @s_head_code, @s_head_name, @s_sub_head_code, " +
                " @s_sub_head_name, @comment, @crtd_by)";

            List<SqlParameter> insertParam = new List<SqlParameter>();
            insertParam.Add(new SqlParameter("@s_date", entry_date));
            insertParam.Add(new SqlParameter("@s_start_time", start_time));
            insertParam.Add(new SqlParameter("@s_end_time", end_time));
            insertParam.Add(new SqlParameter("@mill_code", mill_code));
            insertParam.Add(new SqlParameter("@s_head_code", head_code));
            insertParam.Add(new SqlParameter("@s_head_name", head_name));
            insertParam.Add(new SqlParameter("@s_sub_head_code", sub_head_code));
            insertParam.Add(new SqlParameter("@s_sub_head_name", sub_head_name));
            insertParam.Add(new SqlParameter("@comment", comment));
            insertParam.Add(new SqlParameter("@crtd_by", genfunc.userCode));

            try
            {
                insertedRecords = SqlHelper.ExecuteNonQuery(dbConn.sqlConn(), CommandType.Text, sql, insertParam.ToArray());
            }
            catch (SqlException sqlEx)
            {
                MessageBox.Show("Sql excepton occured while inserting stoppage data\nError Message- "+sqlEx.Message, "Failed!!", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Generic error occured while inserting stoppge data\nError Message-"+ex.Message, "Failed!", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            return insertedRecords;
        }

        /// <summary>
        /// Update stoppage Record
        /// </summary>
        /// <param name="entry_date"></param>
        /// <param name="start_time"></param>
        /// <param name="end_time"></param>
        /// <param name="mill_code"></param>
        /// <param name="head_code"></param>
        /// <param name="head_name"></param>
        /// <param name="sub_head_code"></param>
        /// <param name="sub_head_name"></param>
        /// <param name="comment"></param>
        /// <returns></returns>
        public int updateRecord(int id, string start_time, string end_time, int mill_code, int head_code, string head_name
            , int sub_head_code, string sub_head_name, string comment)
        {
            int updatedRecords = 0;
            string sql = @"update transactions_stoppage set s_start_time = @s_start_time, s_end_time = @s_end_time, " +
                " s_mill_code = @s_mill_code, s_head_code = @s_head_code, s_head_name = @s_head_name " +
                " , s_sub_head_code = @s_sub_head_code, s_sub_head_name = @s_sub_head_name, s_comment = @s_comment " +
                " where id = @id ";

            List<SqlParameter> updateParam = new List<SqlParameter>();
            updateParam.Add(new SqlParameter("@id", id));
            updateParam.Add(new SqlParameter("@s_start_time", start_time));
            updateParam.Add(new SqlParameter("@s_end_time", end_time));
            updateParam.Add(new SqlParameter("@s_mill_code", mill_code));
            updateParam.Add(new SqlParameter("@s_head_code", head_code));
            updateParam.Add(new SqlParameter("@s_head_name", head_name));
            updateParam.Add(new SqlParameter("@s_sub_head_code", sub_head_code));
            updateParam.Add(new SqlParameter("@s_sub_head_name", sub_head_name));
            updateParam.Add(new SqlParameter("@s_comment", comment));
            updateParam.Add(new SqlParameter("@updt_by", genfunc.userCode));
            updateParam.Add(new SqlParameter("@updt_dt", DateTime.Now.ToString("yyyy-MM-dd hh:mm")));


            try
            {
                updatedRecords = SqlHelper.ExecuteNonQuery(dbConn.sqlConn(), CommandType.Text, sql, updateParam.ToArray());
            }
            catch (SqlException sqlEx)
            {
                MessageBox.Show("Sql excepton occured while inserting stoppage data\nError Message- " + sqlEx.Message, "Failed!!", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Generic error occured while inserting stoppge data\nError Message-" + ex.Message, "Failed!", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            return updatedRecords;
        }
        /// <summary>
        /// get stoppage data from transactions_stoppage by its Date
        /// </summary>
        /// <param name="date"></param>
        /// <returns></returns>
        public DataTable getStoppageRecords(string date)
        {
            DataTable stoppage_dt = new DataTable();

            string selectSql = "select id, s_start_time, s_end_time, s_mill_code, s_head_name, s_sub_head_name from transactions_stoppage where s_date = @s_date";
            List<SqlParameter> param = new List<SqlParameter>();
            param.Add(new SqlParameter("@s_date", date));
            try
            {
                stoppage_dt = SqlHelper.ExecuteDataset(dbConn.sqlConn(), CommandType.Text, selectSql, param.ToArray()).Tables[0];
            }
            catch (SqlException ex)
            {
                MessageBox.Show("Error occured while selecting stoppage data\n Error message- " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            return stoppage_dt;
        }
        /// <summary>
        /// Get data from stoppage transaction by its ID
        /// </summary>
        /// <param name="stoppage_id"></param>
        /// <returns></returns>
        public DataTable getStoppageRecords(int stoppage_id)
        {
            DataTable stoppage_dt = new DataTable();

            string selectSql = "select id, s_start_time, s_end_time, s_mill_code, s_head_code, s_head_name, s_sub_head_code, s_sub_head_name, s_comment from transactions_stoppage where id = @id";
            List<SqlParameter> param = new List<SqlParameter>();
            param.Add(new SqlParameter("@id", stoppage_id));
            try
            {
                stoppage_dt = SqlHelper.ExecuteDataset(dbConn.sqlConn(), CommandType.Text, selectSql, param.ToArray()).Tables[0];
            }
            catch (SqlException ex)
            {
                MessageBox.Show("Error occured while selecting stoppage data\n Error message- " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            return stoppage_dt;
        }

    }
}
