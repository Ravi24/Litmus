﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.ApplicationBlocks.Data;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;
namespace Litmus.classes
{
    class molasses_logic
    {
        
        DbConnections dbConn = new DbConnections();
        classes.ExceptionHelper expHelper = new ExceptionHelper();
        public void insert_molasses_data(string entry_date, string entry_time, int mol_code,  float brix, float pol, float purity,string crtd_by)
        {
            string insert_sql = @"insert into analysis_molasses(mo_entry_date, mo_entry_time, mo_code, mo_brix, mo_pol, mo_purity, mo_crtd_by) " +
                                " values(@entry_date, @entry_time, @mol_code, @brix, @pol, @purity, @crtd_by)";

            try
            {
                List<SqlParameter> param = new List<SqlParameter>();
                param.Add(new SqlParameter("@entry_date", entry_date));
                param.Add(new SqlParameter("@entry_time", entry_time));
                param.Add(new SqlParameter("@mol_code", mol_code));
                param.Add(new SqlParameter("@brix", brix));
                param.Add(new SqlParameter("@pol", pol));
                param.Add(new SqlParameter("@purity", purity));
                param.Add(new SqlParameter("@crtd_by", crtd_by));
               DialogResult dialogResult = MessageBox.Show("Are you sure to save data?", "Sure to save...", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
               if (dialogResult == DialogResult.Yes)
               {
                   int inserted_rows = SqlHelper.ExecuteNonQuery(dbConn.sqlConn(), CommandType.Text, insert_sql, param.ToArray());
                   MessageBox.Show(inserted_rows + "record saved!", "Record saved...", MessageBoxButtons.OK, MessageBoxIcon.Information);
               }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Data not saved!\nError message - "+ex.Message, "Error!!", MessageBoxButtons.OK, MessageBoxIcon.Error);
                expHelper.statusMsg = "molasses entry not saved.\nError message - " + ex.Message + "\n stack trace - " + ex.StackTrace + "\n";
            }
        }
        public void insert_molasses_data(string entry_date, string entry_time,  float brix, float pol, float purity, string crtd_by,
            float melting_seed, float melting_melt, float melting_c_single_sugar, float melting_c_double_sugar, float melting_b_sugar, string melting_stage)
        {
            string sql = @"insert into analysis_melting(melt_entry_date, melt_entry_time, melt_seed, melt_melt, melt_c_single_sugar, melt_c_double_sugar, " +
                        " melt_b_sugar, melt_brix, melt_pol, melt_purity, melt_sugar_stage, melt_crtd_by) " +
                        " values(@entryDate, @entryTime, @seed, @melt, @cSingleSugar, @cDoubleSugar, @bSugar, @brix, @pol, @purity, @sugarStage, @crtdBy)";
            try
            {
                List<SqlParameter> param = new List<SqlParameter>();
                param.Add(new SqlParameter("@entryDate", entry_date));
                param.Add(new SqlParameter("@entryTime", entry_time));
                param.Add(new SqlParameter("@seed", melting_seed));
                param.Add(new SqlParameter("@melt", melting_melt));
                param.Add(new SqlParameter("@cSingleSugar", melting_c_single_sugar));
                param.Add(new SqlParameter("@cDoubleSugar", melting_c_double_sugar));
                param.Add(new SqlParameter("@bSugar", melting_b_sugar));
                param.Add(new SqlParameter("@brix", brix));
                param.Add(new SqlParameter("@pol", pol));
                param.Add(new SqlParameter("@purity", purity));
                param.Add(new SqlParameter("@sugarStage", melting_stage));
                param.Add(new SqlParameter("@crtdBy", crtd_by));
                int insertedRecords = 0;

                insertedRecords = SqlHelper.ExecuteNonQuery(dbConn.sqlConn(), CommandType.Text, sql, param.ToArray());
                MessageBox.Show(insertedRecords + "record saved!", "Record saved...", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Data not saved for Melting!\nError message - " + ex.Message, "Error!!", MessageBoxButtons.OK, MessageBoxIcon.Error);
                expHelper.statusMsg = "Melting entry not saved.\nError message - " + ex.Message + "\n stack trace - " + ex.StackTrace + "\n";
                
            }

        }
    }
}
