﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections;
using System.Windows.Forms;
using System.Data;
using System.Data.SqlClient;
using Microsoft.ApplicationBlocks.Data;

namespace Litmus.classes
{
    class DbHelper
    {
        DbConnections dbConn = new DbConnections();
       
        ExceptionHelper expHelper = new ExceptionHelper();

        #region Get list of master menu from database
        public DataTable getActiveMasterMenuList()
        {
            DataTable dt = null;
            string sql = @"select a.mm_code, UPPER(a.mm_name) mm_name from menu_master a where a.mm_isActive = 1";
            try
            {
                dt = SqlHelper.ExecuteDataset(dbConn.sqlConn(), CommandType.Text, sql).Tables[0];
                DataRow row = dt.NewRow();
                row["mm_code"] = "0";
                row["mm_name"] = "--Select--";
                dt.Rows.InsertAt(row, 0);
            }
            catch (SqlException ex)
            {
                expHelper.statusMsg = "ERR: " + ex.Message;
            }
            return dt;
        }
        public DataTable getAllMasterMenuList()
        {
            DataTable dt = null;
            string sql = @"select a.mm_code, UPPER(a.mm_name) mm_name from menu_master a";
            try
            {
                dt = SqlHelper.ExecuteDataset(dbConn.sqlConn(), CommandType.Text, sql).Tables[0];
                DataRow row = dt.NewRow();
                row["mm_code"] = "0";
                row["mm_name"] = "--Select--";
                dt.Rows.InsertAt(row, 0);
            }
            catch (SqlException ex)
            {
                expHelper.statusMsg = "ERR: " + ex.Message;
            }
            return dt;
        }
        #endregion

        #region Get list of all sub menues based on master menu to assign rights to user
        public DataSet getSubMenuList(int masterMenuCode, string userCode)
        {
            string sql = @"select UPPER(b.mr_sub_menu_name) mr_sub_menu_name , b.mr_is_active isActive , b.mr_create 'Create', b.mr_read 'Read', b.mr_update 'Update', b.mr_delete 'Delete', " +
                           " mr_unique_menu from  menu_rights b where " +
                           "  b.mr_master_menu_code = @masterMenuCode and b.mr_user_code = @userCode order by b.mr_user_code, b.mr_master_menu_code, b.mr_sub_menu_code";
            List<SqlParameter> param = new List<SqlParameter>();
            param.Add(new SqlParameter("@masterMenuCode", masterMenuCode));
            param.Add(new SqlParameter("@userCode", userCode));
           

            DataSet ds = new DataSet();
            try
            {
                ds   = SqlHelper.ExecuteDataset(dbConn.sqlConn(), CommandType.Text, sql, param.ToArray());
            }
            catch (SqlException ex)
            {
                expHelper.statusMsg = "ERR: " + ex.Message;
            }
            return ds;

        }
        #endregion


        #region get user rights (CRUD) in a string base on this string we will enable and disable user rights also check these rights before execution of any query
        public DataTable userRights(string uniqueMenuCode)
        {

            string sql = @"select mr_create, mr_read, mr_update, mr_delete " +
            " from menu_rights where mr_unique_menu = @uniqueMenu";
            DataTable dt = null;
            List<SqlParameter> param = new List<SqlParameter>();
            param.Add(new SqlParameter("@uniqueMenu", uniqueMenuCode));
            try
            {
                dt = SqlHelper.ExecuteDataset(dbConn.sqlConn(), CommandType.Text, sql, param.ToArray()).Tables[0];
            }
            catch (SqlException ex)
            {
                MessageBox.Show("Error occured while fetching data for user's menu right\n Exception Details- " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            return dt;
        }
        #endregion

        #region frm_master_menu_creation
        /// <summary>
        /// Database related work for Menu Master form
        /// </summary>
        /// <returns></returns> 
        
        public int getMaxMasterMenuId()
        {
            int masterMenuMaxId = 0;
            string sql = @"select max(mm_code) mm_code from menu_master";
            try
            {
                DataTable dt = new DataTable();
                dt = SqlHelper.ExecuteDataset(dbConn.sqlConn(), CommandType.Text, sql).Tables[0];
                masterMenuMaxId = Convert.ToInt16(dt.Rows[0]["mm_code"]);
                masterMenuMaxId = masterMenuMaxId + 1;
            }
            catch (Exception ex)
            {
                expHelper.statusMsg = "ERR: " + ex.Message;
            }
            return masterMenuMaxId;
        }

        public void insertNewMasterMenu(string menuCode, string menuname, int isActive, string createdBy)
        {
            
            string sql = @"insert into menu_master(mm_code, mm_name, mm_isActive, mm_crtd_by) " +
                          " values (@menuCode, @menuname, @isActive, @crtdBy) ";
            int inserted_records = 0;
            List<SqlParameter> param = new List<SqlParameter>();
            try
            {
                param.Add(new SqlParameter("@menuCode", menuCode));
                param.Add(new SqlParameter("@menuname", menuname));
                param.Add(new SqlParameter("@isActive", isActive));
                param.Add(new SqlParameter("@crtdBy", createdBy));

                inserted_records = SqlHelper.ExecuteNonQuery(dbConn.sqlConn(), CommandType.Text, sql, param.ToArray());
                if (inserted_records == 1)
                {
                    MessageBox.Show(inserted_records + " Added to menu master");
                    
                }
            }
            catch (SqlException ex)
            {
                expHelper.statusMsg = "ERR:" + ex.Message + " " +this.ToString() +" " + ex.LineNumber;
            }
        }

        public void updateNewMasterMenu(string menuCode, string menuname, int isActive)
        {
            string sql = @"update menu_master set mm_name = @menuname, mm_isActive = @isActive where mm_code = @menuCode";
            List<SqlParameter> param = new List<SqlParameter>();
            param.Add(new SqlParameter("@menuname", menuname));
            param.Add(new SqlParameter("@menuCode", menuCode));
            param.Add(new SqlParameter("@isActive", isActive));

            int totalUpdatedRecords = 0;
            try
            {
                totalUpdatedRecords = SqlHelper.ExecuteNonQuery(dbConn.sqlConn(), CommandType.Text, sql,param.ToArray());
                switch (totalUpdatedRecords)
                {
                    case 0:
                        MessageBox.Show("No record updated", "Message", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        break;
                    case 1:
                        MessageBox.Show("One record update");
                        break;
                    default:
                        MessageBox.Show(totalUpdatedRecords + " update, please contact administrator", "Critical Exeception", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        break;
                }
            }
            catch (SqlException ex)
            {
                expHelper.statusMsg = "ERR: " + ex.Message + "  in Line- " + ex.StackTrace + " " + this.ToString() + " " + ex.HelpLink;
                MessageBox.Show("Can not update record, " + ex.Message, "Exception!!", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        
        #endregion

        #region Form code name
        ///<summary>
        ///get menu actual form name defined in database. form name in database and form name defined in solution must be same.
        /// </summary>
        /// 
        public DataTable subMenuDetails (string menuname, string userCode)
        {
            string sql = @" select mr_form_name form_name, mr_unique_menu form_unique_code from menu_rights where mr_sub_menu_name = @menuname " +
                " and mr_user_code = @userCode and mr_is_active = 1";
            List<SqlParameter> sqlParams = new List<SqlParameter>();
            sqlParams.Add(new SqlParameter("@menuname", menuname));
            sqlParams.Add(new SqlParameter("@userCode", userCode));
            DataTable dt = null;
            
            try
            {
                dt   = SqlHelper.ExecuteDataset(dbConn.sqlConn(), CommandType.Text, sql, sqlParams.ToArray()).Tables[0];

                switch (dt.Rows.Count)
                {
                    case 0:
                        MessageBox.Show("All rights revoked recently, please re-login.\nNo form associated with this menu", "Rights revoked", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        expHelper.statusMsg = "Err: No form associated with this menu.Please define a form name first .. It seems that user did not provided a form name in database check ms_form_name column in menu_sub_master table";
                        break;
                    case 1:
                        //menuFormname = dt.Rows[0]["ms_form_name"].ToString();
                        break;
                    default:
                        MessageBox.Show("More than one form is associated with this menu!\n please define only one form with a menu","More than one form defined", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        expHelper.statusMsg = "Err: No form associated with this menu.Please define a form name first .. It seems that a menu name is repeated in  menu_sub_master table";
                        break;
                }
               
            }
            catch (SqlException ex)
            {
                MessageBox.Show("Error occured while fetching form name for selected menu\n" + ex.Message, "Error!", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                expHelper.statusMsg = "Err: Error occured while fetching form name for selected menu\n" + ex.Message;
            }
            return dt;
            
        }
        #endregion


       

        #region Get user name by its user code
        public string username(string userCode)
        {
            string sql = @"select first_name +' '+last_name user_name from user_master where user_code = @userCode";
            List<SqlParameter> param = new List<SqlParameter>();
            param.Add(new SqlParameter("@userCode", userCode));
            DataTable dt = null;
            string name = "";
            try
            {
                dt = SqlHelper.ExecuteDataset(dbConn.sqlConn(), CommandType.Text, sql, param.ToArray()).Tables[0];
                switch (dt.Rows.Count)
                {
                    case 0:
                        MessageBox.Show("No user associated with given user code", "No User Found!", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                        break;
                    case 1:
                        name = dt.Rows[0]["user_name"].ToString();
                        break;
                    default :
                        MessageBox.Show("More than one user associated with given user code.", "More than one User Found!", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                        break;
                }
            }
            catch (SqlException ex)
            {
                MessageBox.Show("Error occured ..\n" + ex.Message, "Exception!!", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            return name;
        }
        
        #endregion

        #region frm_sub_menues
            #region Create a new sub menu
                ///<summary>
                ///When creating new sub menu we will insert sub menu data in 'menu_sub_master' table.
                ///At the same time we need to insert data in 'Menu Rights' table too. 
                ///For this we have written an stored procedure in database named [menuRights_on_subMenuCreation]
                ///</summary>

        public void newSubMenuCreation(int masterMenuCode, int subMenuCode, int isActive)
        {
            // inserting data in 'menu_sub_master'



            List<SqlParameter> param = new List<SqlParameter>();
            param.Add(new SqlParameter("@commandType", "insert"));
            param.Add(new SqlParameter("@masterMenuCode", masterMenuCode));
            param.Add(new SqlParameter("@subMenuCode", subMenuCode));

            try
            {
                int affectedRows;
                affectedRows = (int)SqlHelper.ExecuteNonQuery(dbConn.sqlConn(), CommandType.StoredProcedure, "menuRights_on_subMenuCreation", param.ToArray());
                MessageBox.Show(affectedRows + " rows inserted in user rights table");
            }
            catch (SqlException ex)
            {
                MessageBox.Show("Error occured while crating user right list. \n" + ex.Message, "Error!!", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        public void insertNewSubMenu(int masterMenuCode, string subMenuCode, string subMeuname, int isActive, string createdBy, string formname)
        {
            string sql = @"insert into menu_sub_master(ms_master_menu_code, ms_code, ms_name, ms_isActive,ms_form_name, ms_crtd_by) " +
                          " values (@masterMenuCode, @menuCode, @menuname, @isActive, @formname, @crtdBy) ";
            int inserted_records = 0;
            List<SqlParameter> param = new List<SqlParameter>();
            try
            {
                param.Add(new SqlParameter("@masterMenuCode", masterMenuCode));
                param.Add(new SqlParameter("@menuCode", subMenuCode));
                param.Add(new SqlParameter("@menuname", subMeuname));
                param.Add(new SqlParameter("@isActive", isActive));
                param.Add(new SqlParameter("@crtdBy", createdBy));
                param.Add(new SqlParameter("@formname", formname));

                inserted_records = SqlHelper.ExecuteNonQuery(dbConn.sqlConn(), CommandType.Text, sql, param.ToArray());
                if (inserted_records == 1)
                {
                    newSubMenuCreation(Convert.ToInt16(masterMenuCode), Convert.ToInt16(subMenuCode), isActive);
                    MessageBox.Show(inserted_records + " Master menu item add.");

                }
            }
            catch (SqlException ex)
            {
                MessageBox.Show("Error occured while creating new sub menu\n"+ex.Message,"Error!",MessageBoxButtons.OK,MessageBoxIcon.Error);
                expHelper.statusMsg = "ERR:" + ex.Message + " " + this.ToString() + " " + ex.LineNumber;
            }
        }

        public int getMaxSubMenuCode()
        {
            ///<summary>
            /////get next id of sub menu-- will use this number in frm_sub_menu to create a new sub menu item.
            ///</summary>
            string sql = @"select max(ms_code) max from menu_sub_master";
            int nextNumber = 0;
            try
            {
                nextNumber = Convert.ToInt16(SqlHelper.ExecuteScalar(dbConn.sqlConn(), CommandType.Text, sql)) + 1;
            }
            catch (SqlException ex)
            {
                MessageBox.Show("Error occured, please check error log", "Error!", MessageBoxButtons.OK, MessageBoxIcon.Error);
                expHelper.statusMsg = "Err: error occured while trying to fetch max id of sub menu \n sql query used - " + sql + "\n exception details" + ex.Message + " exception class- " + ex.Class;
            }
            return nextNumber;
        }

            #endregion
        #endregion

        #region Form 1
        #region form1 main Form on which all menue will be placed
        /// <summary>
        /// Created Date: 25-May-2017
        /// Created By: Ravi Bhushan
        /// fetching user based menu rights from data base and will return it as data table, later we will call it in form1 which contains user based
        /// menu items. 
        /// </summary>
        /// <param name="user_code"></param>
        /// <returns></returns>
        public DataTable getUserMasterMenu()
        {
            DataTable dt = null;
            string sql = @"select mm_code, UPPER(mm_name) mm_name from menu_master where mm_isActive = 1";
            try
            {
                dt = SqlHelper.ExecuteDataset(dbConn.sqlConn(), CommandType.Text, sql).Tables[0];
            }
            catch (SqlException ex)
            {
                MessageBox.Show("Error Occured while fetching menu items. \n" + ex.LineNumber + " " + ex.Message + "\n" + ex.HelpLink);
                expHelper.statusMsg = "Err: Error Occured while fetching menu items. \n Line Number: " + ex.LineNumber + " " + ex.Message + "\n Hyper Link: " + ex.HelpLink + "\n Class name: " + ex.Class;
            }
            return dt;
        }

        public DataTable getUserSubMenu(string userCode, string masterMenuCode)
        {
            DataTable dt = null;
            string sql = @"select mr_id, mr_user_code,  mr_sub_menu_code, upper(mr_sub_menu_name) mr_sub_menu_name, mr_is_active, " +
                        " mr_create, mr_read, mr_update, mr_delete " +
                        " from menu_rights " +
                        " where mr_user_code = @userCode and mr_master_menu_code = @masterMenuCode and mr_is_active = 1 order by mr_sub_menu_code";
            List<SqlParameter> sqlParamas = new List<SqlParameter>();
            try
            {
                sqlParamas.Add(new SqlParameter("@userCode", userCode));
                sqlParamas.Add(new SqlParameter("@masterMenuCode", masterMenuCode));
                dt = SqlHelper.ExecuteDataset(dbConn.sqlConn(), CommandType.Text, sql, sqlParamas.ToArray()).Tables[0];
            }
            catch (SqlException ex)
            {
                MessageBox.Show("Error Occured while fetching menu items. \n" + ex.LineNumber + " " + ex.Message + "\n" + ex.HelpLink);
                expHelper.statusMsg = "Err: Error Occured while fetching sub-menu items. \n Line Number: " + ex.LineNumber + " " + ex.Message + "\n Hyper Link: " + ex.HelpLink + "\n Class name: " + ex.Class;
            }
            return dt;
        }
        #endregion

        public void updateMenuRights(string uniqueMenuCode, int isActive, int create, int read, int update, int delete)
        {
            string updateSql = @"update menu_rights set mr_is_active = @isActive, mr_create = @create, mr_read = @read, mr_update = @update, mr_delete = @delete " +
                                " where mr_unique_menu = @menuUniqueCode";
            List<SqlParameter> param = new List<SqlParameter>();
            param.Add(new SqlParameter("@menuUniqueCode", uniqueMenuCode));
            param.Add(new SqlParameter("@isActive", isActive));
            param.Add(new SqlParameter("@create", create));
            param.Add(new SqlParameter("@read", read));
            param.Add(new SqlParameter("@update", update));
            param.Add(new SqlParameter("@delete", delete));
            try
            {
                SqlHelper.ExecuteNonQuery(dbConn.sqlConn(), CommandType.Text, updateSql, param.ToArray());
               
                Form1 frm = new Form1();
                frm.Refresh();
            }
            catch (SqlException sqlEx)
            {
                MessageBox.Show("Sql Exception occured while changing user rights.\nError Message- "+sqlEx.Message+"\nFor more detais, check error log.", "Sql Exception", MessageBoxButtons.OK, MessageBoxIcon.Error);
                expHelper.statusMsg = "Sql Exception occured while changing user rights\nError Message- " + sqlEx.Message + "\nStack Trace- " + sqlEx.StackTrace;
            }
            catch (Exception exp)
            {
                MessageBox.Show("Generic error occured while changing user rights.\nError Message- " + exp.Message + "\nFor more detais, check error log.", "Sql Exception", MessageBoxButtons.OK, MessageBoxIcon.Error);
                expHelper.statusMsg = "Generic error occured while changing user rights\nError Message- " + exp.Message + "\nStack Trace- " + exp.StackTrace;
            }
        }
        #endregion

        #region frm_user_management

        public void insertUser(string firstname, string Lastname, string userCode, Boolean isActive, string password, string mobileNo = null, string emailAddress = null)
        {
            string sql = "insert into user_master(first_name, last_name, user_code, password, isActive, mobile_No, email_Address) " +
                         " values(@firstname, @lastname, @userCode, @password, @isActive, @mobileNo, @emailAddress)";
            int insertedRecord =0;
            List<SqlParameter> param = new List<SqlParameter>();
            param.Add(new SqlParameter("@firstname", firstname));
            param.Add(new SqlParameter("@lastname", Lastname));
            param.Add(new SqlParameter("@userCode", userCode));
            param.Add(new SqlParameter("@password", password));
            param.Add(new SqlParameter("@isActive", isActive));
            param.Add(new SqlParameter("@mobileNo", mobileNo));
            param.Add(new SqlParameter("@emailAddress", emailAddress));

            List<SqlParameter> storedProcParam = new List<SqlParameter>();
            storedProcParam.Add(new SqlParameter("@userCode",userCode));
            storedProcParam.Add(new SqlParameter("@commandType", "create"));
            try
            {
               insertedRecord = SqlHelper.ExecuteNonQuery(dbConn.sqlConn(), CommandType.Text, sql, param.ToArray());
                // executing an stored procedure to insert menu and submenu in menu_rights table for newly created user
               SqlHelper.ExecuteNonQuery(dbConn.sqlConn(), CommandType.StoredProcedure, "menuRights_on_userCreation", storedProcParam.ToArray());
               MessageBox.Show(insertedRecord + (" User Created"), "User Created!", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (SqlException ex)
            {
                MessageBox.Show("Error occured while creating user\n Error Details :" + ex.Message + " in Class- " +ex.Class,"Error!!",MessageBoxButtons.OK,MessageBoxIcon.Error);
            }
        }
        #endregion

    }
}
