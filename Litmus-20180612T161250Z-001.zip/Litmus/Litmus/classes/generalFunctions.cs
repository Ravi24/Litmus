﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Collections;
using System.Windows.Forms;

using System.Data;
using System.Data.SqlClient;
using Microsoft.ApplicationBlocks.Data;

namespace Litmus.classes
{
    class generalFunctions
    {
        ExceptionHelper exphelper = new ExceptionHelper();
        DbHelper dbHelper = new DbHelper();
        DbConnections dbConn = new DbConnections();
        private static string _userCode;
        private static string _userRight;
        private static string _userName;
        private static string _uniqueFormCode;
        private static string _uniqueFormName;
        private static string _reportDate;
        private static int  _cropDay;
        private static string _appVersion;
        private static string _appMessage;
        private static bool _appEnabled;
        
        //private static float _purity;

        public string userCode
        { 
            get { return _userCode; } 
            set { _userCode = value; }
        }

        public string userRights { 
            get { return _userRight; } 
            set { _userRight = value; } 
        }
        public static string _ledger_process_status;
        public string ledger_process_stats
        {
            get { return _ledger_process_status; }
            set { _ledger_process_status = value;}
        }
        public string userName { get { return _userName; } set { _userName = value; } }
        public string uniqueFormCode { get { return _uniqueFormCode; } set { _uniqueFormCode = value; } }
        public string uniqueFormName { get { return _uniqueFormName; } set { _uniqueFormName = value; } }
        //public float purity { get { return _purity; } set { _purity = value; } }
        public string reportDate { get { return _reportDate; } set { _reportDate = value; } }

        public int crop_day { get { return _cropDay; } set { _cropDay = value; } } 
        public  string app_version {get{return _appVersion;} set{_appVersion = value;}}
        public  string app_message { get { return _appMessage; } set { _appMessage = value; } }
        public  bool app_enabled { get { return _appEnabled; } set { _appEnabled = value; } }


        #region frm_hourly_transction validation
        public void validateTransactionTime(string transactionTime)
        {
            
        }
        #endregion

        #region Creating string for user rights (CRUD)
        public void menuRights(string uniqueMenuCode)
        {
            string rights = "";
            DataTable dt = dbHelper.userRights(uniqueMenuCode);
            if (dt.Rows.Count > 0)
            {
                if (dt.Rows[0]["mr_create"].ToString() == "True")
                {
                    rights = rights + "C";
                    
                }
                if (dt.Rows[0]["mr_read"].ToString() == "True")
                {
                    rights = rights + "R";
                }
                 if (dt.Rows[0]["mr_update"].ToString() == "True")
                {
                    rights = rights + "U";
                }
                 if (dt.Rows[0]["mr_delete"].ToString() == "True")
                {
                    rights = rights + "D";
                }
                
                //{
                  //  MessageBox.Show("No/Invalid role defined.", "Invalid role", MessageBoxButtons.OK, MessageBoxIcon.Information);
                //}

            }
            else
            {
                MessageBox.Show("User is not authorised for any role.", "No role defined", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
           
            _userRight = rights;

        }
        #endregion

        #region Text Box input constraint for String or numeric values
        public bool forceNumericValue(Control controlName)
        {
            bool inputValid = false;
            Regex reg= new Regex("^[0-9]{1,9}$");
            if (reg.IsMatch(controlName.Text) == false)
            {
                controlName.BackColor = System.Drawing.Color.Red;
                controlName.Focus();

            }
            else
            {
                controlName.BackColor = System.Drawing.Color.White;
                inputValid = true;
            }
            return inputValid;
        }
        /// <summary>
        /// Check either textbox is empty or not. if it is empty disable button/control passed in parameter
        /// </summary>
        /// <param name="TextBoxName"></param>
        /// <param name="ButtonToDisable"></param>
        public void ValidateTextBoxNotEmpty(Control TextBoxName, Control ButtonToDisable)
        {
            TextBox tempTextBox = (TextBox)TextBoxName;
            Button tempButton = (Button)ButtonToDisable;
            if (tempTextBox.Text == string.Empty)
            {
                tempButton.Enabled = false;
                tempTextBox.BackColor = System.Drawing.Color.Red;
                tempTextBox.Focus();
            }
            else
            {
                tempButton.Enabled = true;
                tempTextBox.BackColor = System.Drawing.Color.White;
            }

        }
        
        #endregion

        #region get list of parameter code and name from "PARAMETER_TYPES" table
        /// <summary>
        /// Auth: Ravi bhushan 
        /// Date: 16-06-2017
        /// pass two parameter (1) category of parameter type (2) active status(true/false). 
        /// this fuction will return parameter_types.param_code (code of parameter) and parameter_types.param_desc (description/short name) of parameter
        /// in form of a dataset.
        /// this will be useful to bind parameter_types in combo boxes.
        /// </summary>
        /// <param name="param_category"></param>
        /// <param name="is_active"></param>
        /// <returns> dataset </returns>
        /// 
        public  DataSet get_parameter_types(string parameter_category, int parameter_is_active)
        {
            DataSet ds = null;
            string sql = @"select param_code, upper(param_desc) as 'param_desc' from parameter where param_category = @param_category and is_active = @is_active";
            List<SqlParameter> param = new List<SqlParameter>();
            param.Add(new SqlParameter("@param_category", parameter_category));
            param.Add(new SqlParameter("@is_active", parameter_is_active));
            try
            {
                ds = SqlHelper.ExecuteDataset(dbConn.sqlConn(), CommandType.Text, sql, param.ToArray());
            }
            catch (Exception ex)
            {
                MessageBox.Show("Unable to fetch parameter_type details from parameter_types table.\nException message- "+ex.Message+"\for further details,please check log file", "Exception!!", MessageBoxButtons.OK, MessageBoxIcon.Error);
                exphelper.statusMsg = "ERROR - error occured while fetch parameter details from 'parameter_types' table.\n Exception message - " + ex.Message + "\nStack trace - " + ex.StackTrace;
            }
            return ds;
        }
        #endregion

        #region Disable fields of particular type in given control
        /// <summary>
        /// diable all controls of specified types in desired container e.g. you want to disable all TextBoxes in GroupBox1
        /// </summary>
        /// <param name="in_control"></param>
        /// <param name="t"></param>
        public void disableFieldsInControl(Control in_control, Type t)
        {
            foreach (Control control in in_control.Controls)
            {
                if (control.GetType() == t)
                {
                    control.Enabled = false;
                }
            }
        }
        /// <summary>
        /// To disable a control by its name in desired container.
        /// </summary>
        /// <param name="in_control"></param>
        /// <param name="t"> type of control (Button, TextBox...)</param>
        /// <param name="name_of_control"></param>
        public void disableFieldsInControl(Control in_control, Type t, string name_of_control)
        {
            
            foreach (Control control in in_control.Controls)
            {
                if (control.GetType() == t && control.Name == name_of_control)
                {
                    control.Enabled = false;
                }
            }
        }
        #endregion

        /// <summary>
        /// disable all controls exists in desired parameter and set text to "0" for all TextBoxes
        /// </summary>
        /// <param name="in_control"></param>
        public void disableFieldsInControl(Control in_control)
        {
            foreach(Control ctrl in in_control.Controls)
            {
                ctrl.Enabled = false;
                if (ctrl.GetType() == typeof(TextBox))
                {
                    ctrl.Text = "0";
                }
            }
        }
        

        #region Enable fields in given control

        public void enableFieldsInControl(Control in_control, Type c)
        {
            foreach (Control control in in_control.Controls)
            {
                if (control.GetType() == c)
                {
                    control.Enabled = true;
                }
            }
        }

        public void enableFieldsInControl( Control in_control, Type t, string name_of_control)
        {
            foreach (Control control in in_control.Controls)
            {
                if (control.GetType() == t && control.Name == name_of_control )
                {
                    control.Enabled = true;
                }
            }
        }
        public void enableFieldsInControl(Control in_control)
        {
            in_control.Enabled = true;
            foreach (Control ctrl in in_control.Controls)
            {
                ctrl.Enabled = true;
                if (ctrl.GetType() == typeof(TextBox))
                {
                    ctrl.Text = "0";
                }
            }
        }
        #endregion

        /// <summary>
        /// This method will check, text entered in given input box has valid time or not (24:00)
        /// </summary>
        /// <param name="input_box_name"></param>
        public void validate_hours_minutes(Control input_box_name)
        {
            string pattern = @"^(?:([01]?\d|2[0-3]):([0-5]?\d))$";
            Regex reg = new Regex(pattern);
            try
            {
                if (reg.IsMatch(input_box_name.Text) == true)
                {
                    input_box_name.BackColor = System.Drawing.Color.White;
                }
                else
                {
                    input_box_name.BackColor = System.Drawing.Color.Red;
                    input_box_name.Focus();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Unable to match time pattern\n."+ex.Message+" \nFor more details check log file", "Error!", MessageBoxButtons.OK, MessageBoxIcon.Error);
                exphelper.statusMsg = "ERROR: " + ex.Message + "\nStack Trace - " + ex.StackTrace;
            }
        }

        /// <summary>
        /// purity percentage can not exeed 100%. 
        /// Here I am checking value/text of textbox, if it its value is more than 100 button which is passed in parameter will be disabled and
        /// color of textbox (passed in parameter) will turn red.
        /// </summary>
        /// <param name="purity_text_box_name"></param>
        /// <param name="submit_button_name"></param>
        public void validate_purity_percentage(Control purity_text_box_name, Control submit_button_name)
        {
            TextBox tempTextBox = (TextBox)purity_text_box_name;
            Button tempButton = (Button)submit_button_name;
            float percentValue = float.Parse(tempTextBox.Text);
            if (percentValue > 100)
            {
                purity_text_box_name.Focus();
                tempTextBox.BackColor = System.Drawing.Color.Red;
                tempTextBox.Focus();
                tempButton.Enabled = false;
            }
            else
            {
                tempTextBox.BackColor = System.Drawing.Color.White;
                tempButton.Enabled = true;
            }
        }
        /// <summary>
        ///  This method will check, text entered in given input box has valid time or not (24:00)
        ///  and will disable a button (provided in parameter) to prevend accidental click on submit/save button
        /// </summary>
        /// <param name="input_box_name"></param>
        /// <param name="buttonToDisable"></param>
        public void validate_hours_minutes(Control input_box_name,Control buttonToDisable)
        {
            string pattern = @"^(?:([01]?\d|2[0-3]):([0-5]?\d))$";
            Regex reg = new Regex(pattern);
            try
            {
                if (reg.IsMatch(input_box_name.Text) == true)
                {
                    input_box_name.BackColor = System.Drawing.Color.White;
                    buttonToDisable.Enabled = true;
                }
                else
                {
                    input_box_name.BackColor = System.Drawing.Color.Red;
                    input_box_name.Focus();
                    buttonToDisable.Enabled = false;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Unable to match time pattern\n." + ex.Message + " \nFor more details check log file", "Error!", MessageBoxButtons.OK, MessageBoxIcon.Error);
                exphelper.statusMsg = "ERROR: " + ex.Message + "\nStack Trace - " + ex.StackTrace;
            }
        }

        #region Calculate Purity
        public float calculate_purity(float pol, float brix)
        {
            float purity = 0;
            if (pol == 0 || brix == 0)
            {
                purity = 0;
            }
            else
            {
                try
                {
                    purity = (pol / brix) * 100;
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                    exphelper.statusMsg = "ERROR: While calculating purity. \nException message - " + ex.Message + "\nException stack trace - " + ex.StackTrace;
                }
            }
            return purity;
        }
        #endregion

        public string parseHourMinuteFormat(string hourMinute)
        {
            int length = hourMinute.Length;
            string hourPart, minutePart;
            string actualTime;
            switch (length)
            {
                case 1:
                    actualTime = string.Concat("0", hourMinute, ":00");
                    return actualTime;
                case 2:
                    //12 => 12:00
                    hourPart = hourMinute.ToString();
                    minutePart = "00";
                    actualTime = string.Concat(hourPart, ":", minutePart);
                    return actualTime;
                    //break;
                case 3:
                    hourPart = hourMinute.Substring(0, 1);
                    minutePart = hourMinute.Substring(1, 2);
                    actualTime = string.Concat("0",hourPart, ":", minutePart);
                    return actualTime;
                    //break;
                case 4:
                    hourPart = hourMinute.Substring(0,2);
                    minutePart = hourMinute.Substring(2, 2);
                    actualTime = string.Concat(hourPart, ":", minutePart);
                    return actualTime;
                    //break;
                default:
                    actualTime = hourMinute;
                    return actualTime;
                    //break;
            }
            
        }
        /// <summary>
        /// Return Type- Dataset. \nA table in database named 'drop_down_list' holding combobox list display and values for saveral types.
        /// \nPass comboBoxType as Cooling Tower Traces, Molasses Stages etc. to get combo box options. 
        /// </summary>
        /// <param name="comboListFor"></param>
        /// <returns></returns>
        public DataSet getComboListOptions(string comboListFor)
        {
            string sql = @"select ddl_value, display_text from drop_down_list where ddl_type = @ddl_type and is_active = 1 order by ddl_value";
            List<SqlParameter> param = new List<SqlParameter>();
            param.Add(new SqlParameter("@ddl_type", comboListFor));
            DataSet ds = null;
            try
            {
                ds = SqlHelper.ExecuteDataset(dbConn.sqlConn(), CommandType.Text, sql, param.ToArray());
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error in get combolist options.\nError message:- " + ex.Message, "Error!", MessageBoxButtons.OK, MessageBoxIcon.Error);
                exphelper.statusMsg = "ERROR: could not get list of combo boxes. \nError message :-" + ex.Message + "\nStack Trace:-" + ex.StackTrace;
            }
            return ds;
        }

        public  DataSet getDatabaseServerDetails()
        {
            string sql = @"select SERVERPROPERTY('machineName') machineName, SERVERPROPERTY('InstanceName') instanceName, DB_NAME() as 'db_name'";
            DataSet ds = null;
            try
            {
                ds = SqlHelper.ExecuteDataset(dbConn.sqlConn(), CommandType.Text, sql);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error occured while trying to get server details.\nError Message" + ex.Message, "Error!", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            return ds;

        }


        /// <summary>
        /// get Crop Day for selected date
        /// </summary>
        /// <param name="date"></param>
        /// <returns></returns>
        public int getCropDay(string date)
        {
            int crop_day = 0;
            string sql = @"select DATEDIFF(dd,(select param_value from controls where param_code = 3),@current_date)";
            List<SqlParameter> param = new List<SqlParameter>();
            param.Add(new SqlParameter("@current_date", date));
            try
            {
                crop_day = (int)(SqlHelper.ExecuteScalar(dbConn.sqlConn(), CommandType.Text, sql, param.ToArray()));
                crop_day = crop_day+1;
            }
            catch (SqlException ex)
            {
                MessageBox.Show("Error while calculating crop day.\nError Message -" + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error while calculating crop day.\nError Message -" + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            return crop_day;

        }

        public void authenticate_application()
        {
            string sql = @"select a.app_version, a.app_enable, a.app_message from app_manager a";
            Console.WriteLine("Getting application version/is_active and app message. Sql = "+sql ); 
            DataTable dt_appManager = SqlHelper.ExecuteDataset(dbConn.sqlConn(), CommandType.Text, sql).Tables[0];

            _appVersion = dt_appManager.Rows[0]["app_version"].ToString();
            _appEnabled = Convert.ToBoolean(dt_appManager.Rows[0]["app_enable"]);
            _appMessage = dt_appManager.Rows[0]["app_message"].ToString();
        }

        public bool user_session_start(string user_code, string ip_address, string host_name)
        {
            DataTable dt = user_session_check(user_code);
            bool session_created = false;
            int inserted_rows = 0;
            string sql = @"insert into user_session(user_code, ip_address, host_name) " +
                            " values(@user_code, @ip_address, @host_name)";
            Console.WriteLine(" creating user session " + sql);
            List<SqlParameter> session_param = new List<SqlParameter>();
            session_param.Add(new SqlParameter("@user_code", user_code));
            session_param.Add(new SqlParameter("@ip_address", ip_address));
            session_param.Add(new SqlParameter("@host_name", host_name));

            if (dt != null && dt.Rows.Count > 0)
            {
                MessageBox.Show(userCode + "already logged in at " + dt.Rows[0]["host_name"].ToString() + "\nIP Address:- " + dt.Rows[0]["ip_address"].ToString(), "Already logged in ", MessageBoxButtons.OK, MessageBoxIcon.Hand);
            }
            else
            {
                try
                {
                    inserted_rows = SqlHelper.ExecuteNonQuery(dbConn.sqlConn(), CommandType.Text, sql, session_param.ToArray());
                }
                catch (SqlException ex)
                {
                    exphelper.statusMsg = "Sql exception occured - " + ex.Message + "\nStack Trace :- " + ex.StackTrace;
                }

                switch (inserted_rows)
                {
                    case 0:
                        session_created = false;
                        break;
                    case 1:
                        session_created = true;
                        break;
                    default:
                        exphelper.statusMsg = "More than one row were inserted in session ";
                        session_created = false;
                        break;
                }
            }
            //return session_created;
            Console.WriteLine("Returning 'True'. to start new session by force at " +this.GetType().ToString() );
            return true;
        }
        public DataTable user_session_check(string user_code)
        {
            DataTable dt = null;

            string sql = @"select us.host_name 'host_name', us.ip_address 'ip_address', us.user_code 'user_code', um.first_name 'user_name' " +
                          "  from user_session us, user_master um " +
                          " where us.user_code = um.user_code and um.user_code = @user_code";

            Console.WriteLine("Sql to get machine details " + sql);

            List<SqlParameter> param = new List<SqlParameter>();
            param.Add(new SqlParameter("@user_code",user_code));
            try
            {
                dt = SqlHelper.ExecuteDataset(dbConn.sqlConn(), CommandType.Text, sql, param.ToArray()).Tables[0];
            }
            catch (SqlException ex)
            {
                Console.WriteLine(" sql excetption " + ex);
                exphelper.statusMsg = "sql exception  " + ex.Message ;
            }
            catch (Exception ex)
            {
                Console.WriteLine(" sql excetption " + ex);
                exphelper.statusMsg = "sql exception  " + ex.Message;
            }

            return dt;
        }
        public bool user_session_end(string user_code)
        {
            bool session_end = false;
            int deleted_rows = 0;

            string delete_sql = @"delete from user_session where user_code = @user_code";
            Console.WriteLine("Clear user session sql := " + delete_sql);
            List<SqlParameter> session_param = new List<SqlParameter>();
            session_param.Add(new SqlParameter("@user_code", user_code));
            try
            {
                deleted_rows = SqlHelper.ExecuteNonQuery(dbConn.sqlConn(), CommandType.Text, delete_sql, session_param.ToArray());
                switch (deleted_rows)
                {
                    case 0:
                        session_end = false;
                        Application.Exit();
                        break;
                    case 1:
                        session_end = true;
                        Application.Exit();
                        break;
                    default:
                        exphelper.statusMsg = "More than one row deleted. ";
                        break;
                }
            }
            catch (SqlException ex)
            {
                Console.WriteLine("sql exception " + ex);
                exphelper.statusMsg = "Sql exception occured - " + ex.Message + "\nStack Trace :- " + ex.StackTrace;
            }
            catch (Exception ex)
            {
                Console.WriteLine("sql exception " + ex);
                exphelper.statusMsg = "Sql exception occured - " + ex.Message + "\nStack Trace :- " + ex.StackTrace;
            }
            return session_end;
        }

        public bool user_session_end(string user_code, bool close_app)
        {
            bool session_end = false;
            int deleted_rows = 0;

            string delete_sql = @"delete from user_session where user_code = @user_code";
            List<SqlParameter> session_param = new List<SqlParameter>();
            session_param.Add(new SqlParameter("@user_code", user_code));
            try
            {
                deleted_rows = SqlHelper.ExecuteNonQuery(dbConn.sqlConn(), CommandType.Text, delete_sql, session_param.ToArray());
                Console.WriteLine(" delete user session " + delete_sql);
                switch (deleted_rows)
                {
                    case 0:
                        session_end = false;
                        break;
                    case 1:
                        session_end = true;
                        if (close_app == true)
                        {
                            Application.Exit();
                        }
                        break;
                    default:
                        exphelper.statusMsg = "More than one row deleted. ";
                        break;
                }
            }
            catch (SqlException ex)
            {
                Console.WriteLine(" Sql exception occured " + ex);
                exphelper.statusMsg = "Sql exception occured - " + ex.Message + "\nStack Trace :- " + ex.StackTrace;
            }
            catch (Exception ex)
            {
                Console.WriteLine(" Generaic exception occured " + ex);
                exphelper.statusMsg = "Generic exception occured - " + ex.Message + "\nStack Trace :- " + ex.StackTrace;
            }
            return session_end;
        }
    }
}

