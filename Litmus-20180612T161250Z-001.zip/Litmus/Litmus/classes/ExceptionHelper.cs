﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.Windows.Forms;


namespace Litmus.classes
{
    class ExceptionHelper
    {
         private string _statusMsg;
         public string statusMsg
         {
             get { return _statusMsg; }
             set { _statusMsg = value;

                 if (_statusMsg.Substring(0, 3) == "ERR")
                 {
                     litmusLogCreation(_statusMsg);
                 }
             }
         }
         #region Log file (text) code
         public void litmusLogCreation(string newEvent)
            {
             string currentDate = DateTime.Now.ToString("dd-MM-yy");
             string currentDateTime = DateTime.Now.ToString();
             string filename = "LitmusLog_" + currentDate + ".txt";
             string folderPath = System.Environment.GetFolderPath(Environment.SpecialFolder.CommonApplicationData);
             string completePath = Path.Combine(folderPath, filename);
             

             if (!File.Exists(completePath))
             {
                 
                 FileStream fs = File.Create(completePath);
                 Byte[] content = new UTF8Encoding(true).GetBytes(currentDateTime +"- "+ newEvent + " " + Environment.NewLine);
                 fs.Write(content, 0, content.Length);
                 fs.Close();
             }
             else
             {
                 try
                 {
                     FileStream fs = File.Open(completePath, FileMode.Append, FileAccess.Write);
                     Byte[] content = new UTF8Encoding(true).GetBytes(currentDateTime + "- " + newEvent + " " + Environment.NewLine);
                     fs.Write(content, 0, content.Length);
                     fs.Close();
                 }
                 catch(Exception ex)
                 {
                     MessageBox.Show("Not able to write log. Please run program with administrative privilage\n"+ex.Message, "Error!", MessageBoxButtons.OK, MessageBoxIcon.Error);
                 }
             }
            }
         #endregion
    }
}
