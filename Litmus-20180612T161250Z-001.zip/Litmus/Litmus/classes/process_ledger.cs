﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.ApplicationBlocks.Data;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;
using Litmus.forms.master_forms;
namespace Litmus.classes
{

    class process_ledger
    {
        
        DbConnections dbConn = new DbConnections();
        classes.ExceptionHelper expHelper = new ExceptionHelper();
        classes.generalFunctions genFunc = new generalFunctions();

        Control status_message_control = null;
       
        /// <summary>
        /// <value>boolean</value>
        /// Function to check either data for the processing date exists in table ledger_data or not.
        /// if it exists it will return true else it will retrun false
        /// </summary>
        /// <param name="trans_date"></param>
        /// <returns></returns>
        /// 

        static DateTime _process_start_date, _process_end_date;

        public DateTime process_start_date
        {
            get { return _process_start_date; }
            set { _process_start_date = value; }
        }

        public DateTime process_end_date
        {
            get { return _process_end_date; }
            set { _process_end_date = value; }
        }

        public bool data_exist_for_date(string start_date, string end_date)
        {
            bool data_exist = true;
            int count = 0;
            string checkDataSql = @"select count(trans_date) from ledger_data where trans_date between @start_date and @end_date";
            
            List<SqlParameter> param = new List<SqlParameter>();
            
            

            param.Add(new SqlParameter("@start_date", start_date));
            param.Add(new SqlParameter("@end_date",end_date));
            try
            {
                count = Convert.ToInt16(SqlHelper.ExecuteScalar(dbConn.sqlConn(), CommandType.Text, checkDataSql, param.ToArray()));
                if (count > 0)
                {
                    data_exist = true;
                }
                else
                {
                    data_exist = false; 
                }
            }
            catch (SqlException ex)
            {
                MessageBox.Show("Sql Exception occured. \nError message: "+ex.Message+"\nPlease check error log for more details","Excepton occured",MessageBoxButtons.OK,MessageBoxIcon.Error);
                expHelper.statusMsg = "Sql Exception occured. \nError message: " + ex.Message + "\nStack Trace: " + ex.StackTrace;
            }
            catch (Exception exp)
            {
                MessageBox.Show("Generic Exception occured. \nError message: " + exp.Message + "\nPlease check error log for more details", "Excepton occured", MessageBoxButtons.OK, MessageBoxIcon.Error);
                expHelper.statusMsg = "Generic Exception occured. \nError message: " + exp.Message + "\nStack Trace: " + exp.StackTrace;
            }
            return data_exist;
        }

        /// <summary>
        /// After filling all entries for the day Admin will process all the data for selected date range
        /// </summary>
        /// <param name="fromDate"></param>
        public void transfer_ledgerData(string process_date)
        {
            try
            {
                List<SqlParameter> param = new List<SqlParameter>();
                param.Add(new SqlParameter("transaction_date", process_date));
                genFunc.ledger_process_stats = "Processing final data for "+process_date;
                SqlHelper.ExecuteDataset(dbConn.sqlConn(), CommandType.StoredProcedure, "proc_daily_calculation", param.ToArray());
                MessageBox.Show("Process for " + process_date + " is completed", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (SqlException ex)
            {
                MessageBox.Show("Error occured while process daily calculation data for " + process_date +"\n"+ex.Message, "Error!!", MessageBoxButtons.OK, MessageBoxIcon.Error);
                expHelper.statusMsg = "ERROR occured while process daily calculation data for " + process_date + "\n" + ex.Message + "\n" + ex.StackTrace;
            }
        }

        //public void transfer_ledgerDatas(string process_date)
        //{
        //    try
        //    {
        //        List<SqlParameter> param = new List<SqlParameter>();
        //        param.Add(new SqlParameter("transaction_date", process_date));
        //        genFunc.ledger_process_stats = "Processing final data for " + process_date;
        //        SqlHelper.ExecuteDataset(dbConn.sqlConn(), CommandType.StoredProcedure, "proc_daily_calculation", param.ToArray());
        //        MessageBox.Show("Process for " + process_date + " is completed", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
        //    }
        //    catch (SqlException ex)
        //    {
        //        MessageBox.Show("Error occured while process daily calculation data for " + process_date + "\n" + ex.Message, "Error!!", MessageBoxButtons.OK, MessageBoxIcon.Error);
        //        expHelper.statusMsg = "ERROR occured while process daily calculation data for " + process_date + "\n" + ex.Message + "\n" + ex.StackTrace;
        //    }
        //}

        private void pocess_ledger_several_dates()
        {
            int return_value;
            string current_date;
            DataTable ledger_dt = null;
            try
            {
                while (Convert.ToDateTime(process_start_date) <= Convert.ToDateTime(process_end_date))
                {
                    if(data_exist_for_date(process_start_date.ToString("dd-MMM-yyyy"),process_end_date.ToString("dd-MMM-yyyy")) == true)
                    {
                        if (status_message_control.InvokeRequired)
                        {
                            MethodInvoker assignMethodToControl = new MethodInvoker(pocess_ledger_several_dates);
                            status_message_control.Invoke(assignMethodToControl);
                        }
                        else
                        {
                            current_date = process_start_date.ToString("dd-MMM-yyyy");

                            
                            status_message_control.Text = "Deleting data for " + current_date.ToString();

                            delete_data_for_date(process_start_date.ToString("dd-MMM-yyyy"));

                           
                            status_message_control.Text = "Data deleted for " + current_date.ToString();


                            List<SqlParameter> param = new List<SqlParameter>();
                            param.Add(new SqlParameter("transaction_date", current_date));
                            param.Add(new SqlParameter("return", SqlDbType.Int));

                            param[1].Direction = ParameterDirection.ReturnValue;


                           
                            status_message_control.Text = "Processing final data for " + current_date;
                            SqlHelper.ExecuteDataset(dbConn.sqlConn(), CommandType.StoredProcedure, "proc_daily_calculation", param.ToArray());

                            status_message_control.Text = "Processing done for " + current_date;
                            //MessageBox.Show("Process for " + process_start_date + " is completed", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);

                            ledger_dt = ledger_data_in_message_box(current_date);

                            if (ledger_dt != null && ledger_dt.Rows.Count > 0)
                            {
                                status_message_control.Text = status_message_control.Text +" -- Recovery - " + ledger_dt.Rows[0]["estimated_sugar_percent_cane"].ToString() + " Estimated Molasses(%) = " + ledger_dt.Rows[0]["estimated_molasses_percent_cane"].ToString();
                            }
                            return_value = (int)param[1].Value;
                            if (return_value != 0)
                            {
                                MessageBox.Show("Failed to process " + current_date + "\nReturn Code " + return_value.ToString(), "Error!!", MessageBoxButtons.OK, MessageBoxIcon.Error);
                            }
                        }
                    }
                    else
                    {
                        if (status_message_control.InvokeRequired)
                        {
                            MethodInvoker assignMethodToControl = new MethodInvoker(pocess_ledger_several_dates);
                            status_message_control.Invoke(assignMethodToControl);
                        }
                        else
                        {
                            current_date = process_start_date.ToString("dd-MMM-yyyy");

                            genFunc.ledger_process_stats = "Deleting data for " + current_date.ToString();
                            status_message_control.Text = "Deleting data for " + current_date.ToString();

                            delete_data_for_date(process_start_date.ToString("dd-MMM-yyyy"));

                            genFunc.ledger_process_stats = "Data deleted for " + current_date.ToString();
                            status_message_control.Text = "Data deleted for " + current_date.ToString();


                            List<SqlParameter> param = new List<SqlParameter>();
                            param.Add(new SqlParameter("transaction_date", current_date));
                            param.Add(new SqlParameter("return", SqlDbType.Int));

                            param[1].Direction = ParameterDirection.ReturnValue;


                            genFunc.ledger_process_stats = "Processing final data for " + current_date;
                            status_message_control.Text = "Processing final data for " + current_date;
                            SqlHelper.ExecuteDataset(dbConn.sqlConn(), CommandType.StoredProcedure, "proc_daily_calculation", param.ToArray());

                            status_message_control.Text = "Processing done for " + current_date;
                            //MessageBox.Show("Process for " + process_start_date + " is completed", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);

                            ledger_dt = ledger_data_in_message_box(current_date);

                            if (ledger_dt != null && ledger_dt.Rows.Count > 0)
                            {
                                status_message_control.Text = status_message_control.Text + " -- Recovery - " + ledger_dt.Rows[0]["estimated_sugar_percent_cane"].ToString() + " Estimated Molasses(%) = " + ledger_dt.Rows[0]["estimated_molasses_percent_cane"].ToString();
                                //MessageBox.Show("Estimated Recover(%) = " + ledger_dt.Rows[0]["estimated_sugar_percent_cane"].ToString() + "\nEstimated Molasses(%) = " + ledger_dt.Rows[0]["estimated_molasses_percent_cane"].ToString(), "Estimated Sugar & Molasses", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            }
                            return_value = (int)param[1].Value;
                            if (return_value != 0)
                            {
                                MessageBox.Show("Failed to process " + current_date + "\nReturn Code " + return_value.ToString(), "Error!!", MessageBoxButtons.OK, MessageBoxIcon.Error);
                            }
                        }
                    }
                    

                    process_start_date = process_start_date.AddDays(1);
                }

                if (ledger_dt != null && ledger_dt.Rows.Count > 0)
                {
                    MessageBox.Show("Estimated Recover(%) = " + ledger_dt.Rows[0]["estimated_sugar_percent_cane"].ToString() + "\nEstimated Molasses(%) = " + ledger_dt.Rows[0]["estimated_molasses_percent_cane"].ToString(), "Estimated Sugar & Molasses", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
            catch (SqlException ex)
            {
                MessageBox.Show("Error occured while process daily calculation data for " + process_start_date + "\n" + ex.Message, "Error!!", MessageBoxButtons.OK, MessageBoxIcon.Error);
                expHelper.statusMsg = "ERROR occured while process daily calculation data for " + process_start_date + "\n" + ex.Message + "\n" + ex.StackTrace;
            }
        }
       
        public async void transfer_ledger_data_multiple_dates (string from_date, string to_date, Control status_control)
        {
            process_start_date = Convert.ToDateTime(from_date);
            process_end_date = Convert.ToDateTime(to_date);

            status_message_control = status_control;
            
            
                try
                {
                    Task task = new Task(pocess_ledger_several_dates);
                    task.Start();
                    await task;
                    MessageBox.Show("Process Complete - porcess_ledger.cs", "Process_ledger.cs", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.ToString());
                }

            
            //MessageBox.Show("Process for " + from_date + " is completed", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        public int delete_data_for_date(string trans_date)
        {
            string sql = @"delete from ledger_data where trans_date = @trans_date";
            List<SqlParameter> param = new List<SqlParameter>();
            int deleted_rows = 0;
            param.Add(new SqlParameter("@trans_date", trans_date));
            try
            {
                genFunc.ledger_process_stats = "Deleting final data for " + trans_date;
                deleted_rows = SqlHelper.ExecuteNonQuery(dbConn.sqlConn(), CommandType.Text, sql, param.ToArray());
            }
            catch (SqlException ex)
            {
                MessageBox.Show("Error while deleting data for date: " + trans_date + "\nError message: " + ex.Message + "\nFor more details check error log", "Exception!!", MessageBoxButtons.OK, MessageBoxIcon.Error);
                expHelper.statusMsg = "Error while deleting data for date: " + trans_date + "\nError message: " + ex.Message + "\nStack Trace: " + ex.StackTrace;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Generic Error while deleting data for date: " + trans_date + "\nError message: " + ex.Message + "\nFor more details check error log", "Exception!!", MessageBoxButtons.OK, MessageBoxIcon.Error);
                expHelper.statusMsg = "Generic Error while deleting data for date: " + trans_date + "\nError message: " + ex.Message + "\nStack Trace: " + ex.StackTrace;
            }
            return deleted_rows;
        }

        public DataTable ledger_data_in_message_box(string process_date)
        {
            DataTable ledger_dt = null;
            string sql = @"select estimated_sugar_percent_cane, estimated_molasses_percent_cane from ledger_data where trans_date = @trans_date";
            List<SqlParameter> param = new List<SqlParameter>();
            param.Add(new SqlParameter("@trans_date", process_date));
            try
            {
                ledger_dt = SqlHelper.ExecuteDataset(dbConn.sqlConn(), CommandType.Text, sql, param.ToArray()).Tables[0];
            }
            catch (SqlException ex)
            {
                MessageBox.Show("Error while deleting data for date: " + process_date + "\nError message: " + ex.Message + "\nFor more details check error log", "Exception!!", MessageBoxButtons.OK, MessageBoxIcon.Error);
                expHelper.statusMsg = "Error while deleting data for date: " + process_date + "\nError message: " + ex.Message + "\nStack Trace: " + ex.StackTrace;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Generic Error while deleting data for date: " + process_date + "\nError message: " + ex.Message + "\nFor more details check error log", "Exception!!", MessageBoxButtons.OK, MessageBoxIcon.Error);
                expHelper.statusMsg = "Generic Error while deleting data for date: " + process_date + "\nError message: " + ex.Message + "\nStack Trace: " + ex.StackTrace;
            }
            return ledger_dt;
        }
    }
}
