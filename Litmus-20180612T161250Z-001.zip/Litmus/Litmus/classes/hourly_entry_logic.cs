﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.Sql;
using System.Data.SqlClient;
using Microsoft.ApplicationBlocks.Data;
using System.Windows.Forms;
namespace Litmus.classes
{
    class hourly_entry_logic
    {
       
        classes.DbHelper dbHelper = new DbHelper();
        DbConnections dbConn = new DbConnections();
        classes.master_parameter_logic masterParameters = new master_parameter_logic();
        classes.ExceptionHelper expHelper = new ExceptionHelper();
        classes.generalFunctions genFunc = new generalFunctions();

        public static int _entryTime;
        public static float _cart_avg_weight=0, _trippler_avg_weight=0, _trolley_avg_weight=0, _truck_avg_weight=0;
        public int entryTime { get { return _entryTime; } set { _entryTime = value; } }
        public float cart_avg_weight { get { return _cart_avg_weight; } set { _cart_avg_weight = value; } }
        public float trippler_avg_weight { get { return _trippler_avg_weight; } set { _trippler_avg_weight = value; } }
        public float trolley_avg_weight { get { return _trolley_avg_weight; } set { _trolley_avg_weight = value; } }
        public float truck_avg_weight { get { return _truck_avg_weight; } set { _truck_avg_weight = value; } }



        #region composing entry time for hourly transactions
        public void CurrentEntryTime(string entryDate)
        {
            string sql = @"select entry_time from transactions_hourly where id = (select max(id) from transactions_hourly) and entry_date = @date";
            List<SqlParameter> param = new List<SqlParameter>();
            param.Add(new SqlParameter("@date", entryDate));
            DataSet ds = new DataSet();
            try
            {
                
                ds = SqlHelper.ExecuteDataset(dbConn.sqlConn(), CommandType.Text, sql, param.ToArray());
                if (ds.Tables[0].Rows.Count > 0)
                {
                    if (ds.Tables[0].Rows.Count > 0 & Convert.ToInt16(ds.Tables[0].Rows[0]["entry_time"]) < 24)
                    {
                        entryTime = (Convert.ToInt16(ds.Tables[0].Rows[0]["entry_time"]) + 1);
                    }
                    else
                    {
                        entryTime = 1;
                    }

                }
                else
                {
                    entryTime = Convert.ToInt16(masterParameters.reportStartTime)+1;
                }

            }
            catch (Exception ex)
            {
                MessageBox.Show("Execption - " + ex.Message + "\n For more details please check log file", "Exception", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                expHelper.statusMsg = "ERR: could not get entry time for hourly transactions.\nException Message " + ex.Message + "\nStack Trace - " + ex.StackTrace;
            }

        }
        #endregion

        

        #region Check either entry for definded date and time is possible or not? here we will check unique_entry_code in database, if unique code already exists we will refuse entries 
        public bool isHourlyTransactionEntryPossible(string entry_date, string entry_time)
        {
            bool possibility = false;
            int records;
            string sql = @"select count(1) count from transactions_hourly where entry_date = @entry_date and entry_time = @entry_time";
            List<SqlParameter> param = new List<SqlParameter>();
            param.Add(new SqlParameter("@entry_date", entry_date));
            param.Add(new SqlParameter("@entry_time", entry_time));
            try
            {
                records = Convert.ToInt16(SqlHelper.ExecuteScalar(dbConn.sqlConn(), CommandType.Text, sql, param.ToArray()));
                if (records == 0)
                {
                    possibility = true;
                }
            }
            catch(SqlException ex)
            {
                MessageBox.Show("Execption - " + ex.Message + "\n For more details please check log file", "Exception", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                expHelper.statusMsg = "ERR: Entry for hourly transactions.\nException Message " + ex.Message + "\nStack Trace - " + ex.StackTrace;
            }
            return possibility;
        }
        #endregion


        #region Insert new entries in database for hourly transactions 

        public void insertHourlyRecord(string entryDate, string recordEntryTime, float newMillJuice, float oldMillJuice, float juiceTotal, float newMillWater,
                                        float oldMillWater, float waterTotal, float sugarBagsL31, float sugarBagsL30, float sugarBagsLTotal, float sugarBagsM31,
                                        float sugarBagsM30, float sugarBagsMTotal, float sugarBagsS31, float sugarBageS30, float sugarBagsSTotal, float sugarBiss,
                                        float sugarBagsTotal,
                                        string coolingTrace, float coolingPol, float coolingPh,
                                        string crtd_by, int standing_truck, int standing_trippler, int standing_trolley, int standing_cart, float un_crushed_cane, float crushed_cane)
        {
            string sql = @"insert into transactions_hourly(entry_Date, entry_time, new_mill_juice, old_mill_juice, juice_total, new_mill_water, old_mill_water, water_total, " +
                        " sugar_bags_L31,  sugar_bags_L30, sugar_bags_L_total, sugar_bags_M31, sugar_bags_M30, sugar_bags_M_total, sugar_bags_S31, 	sugar_bags_S30, sugar_bags_S_total," +
                        " sugar_Biss, sugar_bags_total, cooling_trace,cooling_pol, cooling_ph, " +
                        " crtd_by, standing_truck, standing_trippler, standing_trolley, standing_cart, un_crushed_cane, crushed_cane)" +
                        " values (@entry_Date, @entry_time, @newMillJuice, @oldMillJuice, @juiceTotal, @newMillWater, @oldMillWater, @waterTotal, @sugarBagsL31,  @sugarBagsL30, " +
                        " @sugarBagsLTotal, @sugarBagsM31, @sugarBagsM30, @sugarBagsMTotal, @sugarBagsS31, @sugarBagsS30, @sugarBagsSTotal, @sugarBiss, @sugarBagsTotal, " +
                        " @coolingTrace, @coolingPol, @coolingPh, " +
                        " @crtd_by, @standing_truck, @standing_trippler, @standing_trolley, @standing_cart, @un_crushed_cane, @crushed_cane)";

            List<SqlParameter> param = new List<SqlParameter>();
            param.Add(new SqlParameter("@entry_date", entryDate));
            param.Add(new SqlParameter("@entry_time", entryTime));
            param.Add(new SqlParameter("@newMillJuice", newMillJuice));
            param.Add(new SqlParameter("@oldMillJuice", oldMillJuice));
            param.Add(new SqlParameter("@juiceTotal", juiceTotal));
            param.Add(new SqlParameter("@newMillWater", newMillWater));
            param.Add(new SqlParameter("@oldMillWater", oldMillWater));
            param.Add(new SqlParameter("@waterTotal", waterTotal));

            param.Add(new SqlParameter("@sugarBagsL31", sugarBagsL31));
            param.Add(new SqlParameter("@sugarBagsL30", sugarBagsL30));
            param.Add(new SqlParameter("@sugarBagsLTotal", sugarBagsLTotal));

            param.Add(new SqlParameter("@sugarBagsM31", sugarBagsM31));
            param.Add(new SqlParameter("@sugarBagsM30", sugarBagsM30));
            param.Add(new SqlParameter("@sugarBagsMTotal", sugarBagsMTotal));

            param.Add(new SqlParameter("@sugarBagsS31", sugarBagsS31));
            param.Add(new SqlParameter("@sugarBagsS30", sugarBageS30));
            param.Add(new SqlParameter("@sugarBagsSTotal", sugarBagsSTotal));

            param.Add(new SqlParameter("@sugarBiss", sugarBiss));

            param.Add(new SqlParameter("@sugarBagsTotal", sugarBagsTotal));

            param.Add(new SqlParameter("@coolingTrace", coolingTrace));
            param.Add(new SqlParameter("@coolingPol", coolingPol));
            param.Add(new SqlParameter("@coolingPh", coolingPh));


            param.Add(new SqlParameter("@crtd_by", crtd_by));
            
            param.Add(new SqlParameter("@standing_truck", standing_truck));
            param.Add(new SqlParameter("@standing_trippler", standing_trippler));
            param.Add(new SqlParameter("@standing_trolley", standing_trolley));
            param.Add(new SqlParameter("@standing_cart", standing_cart));
            param.Add(new SqlParameter("@un_crushed_cane", un_crushed_cane));
            param.Add(new SqlParameter("@crushed_cane", crushed_cane));


            try
            {
                int insertedRecord = SqlHelper.ExecuteNonQuery(dbConn.sqlConn(), CommandType.Text, sql, param.ToArray());


            }
            catch (Exception ex)
            {
                expHelper.statusMsg = "ERR: Error Message - " + ex.Message + "\nStack Trace" + ex.StackTrace + "\n-----------------------------------------";
                MessageBox.Show(ex.Message);
                Console.Write("Error when inserting hourly data \n"+ex.Message);
            }
        }
        
        #endregion

        #region update existing records in transactions_hourly table
        public void updateHourlyRecord(string entry_date, string entry_time, float new_mill_juice, float old_mill_juice, float juice_total
            , float new_mill_water, float old_mill_water, float water_total, float sugar_bags_L31, float sugar_bags_L30
            , float sugar_bags_L_total, float sugar_bags_M31, float sugar_bags_M30, float sugar_bags_M_total
            , float sugar_bags_S31, float sugar_bags_S30, float sugar_bags_S_total, float sugar_Biss, float sugar_bags_total
            , string cooling_trace, float cooling_pol, float cooling_ph, int standing_truck, int standing_trippler, int standing_trolley, 
            int standing_cart, float un_crushed_cane, float crushed_cane)
        {
            int updatedRecordsCount = 0;
            string updateSql = @"update transactions_hourly set new_mill_juice = @new_mill_juice, old_mill_juice = @old_mill_juice " +
                " ,juice_total = @juice_total, new_mill_water = @new_mill_water, old_mill_water = @old_mill_water " +
                " , water_total = @water_total, sugar_bags_L31 = @sugar_bags_L31, sugar_bags_L30 =@sugar_bags_L30 " +
                " , sugar_bags_L_total = @sugar_bags_L_total, sugar_bags_M31 = @sugar_bags_M31, sugar_bags_M30 = @sugar_bags_M30 " +
                " , sugar_bags_M_total = @sugar_bags_M_total, sugar_bags_S31 = @sugar_bags_S31, sugar_bags_S30 = @sugar_bags_S30 " +
                " , sugar_bags_S_total = @sugar_bags_S_total, sugar_Biss = @sugar_Biss, sugar_bags_total = @sugar_bags_total " +
                " , cooling_trace = @cooling_trace, cooling_pol = @cooling_pol, cooling_ph = @cooling_ph " +
                " , updt_dt = @updt_dt, updt_by = @updt_by, standing_truck=  @standing_truck, standing_trippler = @standing_trippler, " + 
                " standing_trolley = @standing_trolley, standing_cart =  @standing_cart, un_crushed_cane= @un_crushed_cane, crushed_cane= @crushed_cane " +
                "  where entry_date = @entry_date and entry_time = @entry_time ";

            List<SqlParameter> updateParam = new List<SqlParameter>();
            updateParam.Add(new SqlParameter("@entry_date", entry_date));
            updateParam.Add(new SqlParameter("@entry_time", entry_time));
            updateParam.Add(new SqlParameter("@new_mill_juice", new_mill_juice));
            updateParam.Add(new SqlParameter("@old_mill_juice", old_mill_juice));
            updateParam.Add(new SqlParameter("@juice_total", juice_total));
            updateParam.Add(new SqlParameter("@new_mill_water", new_mill_water));
            updateParam.Add(new SqlParameter("@old_mill_water", old_mill_water));
            updateParam.Add(new SqlParameter("@water_total", water_total));
            updateParam.Add(new SqlParameter("@sugar_bags_L31", sugar_bags_L31));
            updateParam.Add(new SqlParameter("@sugar_bags_L30", sugar_bags_L30));
            updateParam.Add(new SqlParameter("@sugar_bags_L_total", sugar_bags_L_total));
            updateParam.Add(new SqlParameter("@sugar_bags_M31", sugar_bags_M31));
            updateParam.Add(new SqlParameter("@sugar_bags_M30", sugar_bags_M30));
            updateParam.Add(new SqlParameter("@sugar_bags_M_total", sugar_bags_M_total));
            updateParam.Add(new SqlParameter("@sugar_bags_S30", sugar_bags_S30));
            updateParam.Add(new SqlParameter("@sugar_bags_S31", sugar_bags_S31));
            updateParam.Add(new SqlParameter("@sugar_bags_S_total", sugar_bags_S_total));
            updateParam.Add(new SqlParameter("@sugar_Biss", sugar_Biss));
            updateParam.Add(new SqlParameter("@sugar_bags_total", sugar_bags_total));
            updateParam.Add(new SqlParameter("@cooling_trace", cooling_trace));
            updateParam.Add(new SqlParameter("@cooling_pol", cooling_pol));
            updateParam.Add(new SqlParameter("@cooling_ph", cooling_ph));
            updateParam.Add(new SqlParameter("@updt_dt", DateTime.Now.ToString("yyyy-MM-dd")));
            updateParam.Add(new SqlParameter("@updt_by", genFunc.userCode));
            updateParam.Add(new SqlParameter("@standing_truck", standing_truck));
            updateParam.Add(new SqlParameter("@standing_trippler", standing_trippler));
            updateParam.Add(new SqlParameter("@standing_trolley", standing_trolley));
            updateParam.Add(new SqlParameter("@standing_cart", standing_cart));
            updateParam.Add(new SqlParameter("@un_crushed_cane", un_crushed_cane));
            updateParam.Add(new SqlParameter("@crushed_cane", crushed_cane));

            updatedRecordsCount = SqlHelper.ExecuteNonQuery(dbConn.sqlConn(), CommandType.Text, updateSql, updateParam.ToArray());

            if (updatedRecordsCount == 1)
            {
                MessageBox.Show(updatedRecordsCount + " record(s) modified!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else if (updatedRecordsCount > 1)
            {
                MessageBox.Show(updatedRecordsCount + " record(s) modified!\nMore than one record modified, kindly contact to administrater before proceeding.", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Hand);
            }
            else
            {
                MessageBox.Show(updatedRecordsCount + " record(s) modified!", "Failed", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
            }
        }
        #endregion
        #region get data of selected data and time in update mode
        /// <summary>
        /// Return - Data Table 
        /// Get all data of hourly data of given date
        /// </summary>
        /// <param name="entryDate"></param>
        /// <returns></returns>
        public DataTable getHourlyData(string entryDate)
        {
            DataTable hourlyDatatable = null;
            string sql = @"select entry_time, new_mill_juice, old_mill_juice, juice_total, new_mill_water,old_mill_water, water_total " +
                            " , sugar_bags_l31, sugar_bags_L30, sugar_bags_L_total " +
                            "  , sugar_bags_m31, sugar_bags_m30, sugar_bags_m_total " +
                            " , sugar_bags_s31, sugar_bags_s30, sugar_bags_s_total " +
                            " , sugar_Biss, sugar_bags_total " +
                            " , cooling_trace, cooling_pol, cooling_ph, standing_truck, standing_trippler, standing_trolley, standing_cart, un_crushed_cane, crushed_cane " +
                            "  from transactions_hourly " +
                            "  where entry_Date = @entryDate ";
            Console.Write("Hourly data sql - " + sql);
            List<SqlParameter> param = new List<SqlParameter>();
            param.Add(new SqlParameter("@entryDate", entryDate));
            try
            {
                hourlyDatatable = SqlHelper.ExecuteDataset(dbConn.sqlConn(), CommandType.Text, sql, param.ToArray()).Tables[0];
            }
            catch (SqlException ex)
            {
                MessageBox.Show("Sql exception occured while trying to get hourly data for selected date and time.\nError Message: " + ex.Message + "\nFor mor details, check error log", "Sql Exception", MessageBoxButtons.OK, MessageBoxIcon.Error);
                expHelper.statusMsg = "Sql exception occured while trying to get hourly data for selected date and time.\nError Message: " + ex.Message +"\nStack Trace: "+ex.StackTrace;
            }
            catch (NullReferenceException nullExp)
            {
                MessageBox.Show("Null Reference Exception occured while trying to get hourly data for selected date and time.\nError Message: " + nullExp.Message + "\nFor mor details, check error log", "Null Reference Exception", MessageBoxButtons.OK, MessageBoxIcon.Error);
                expHelper.statusMsg = "Null Reference Exception while trying to get hourly data for selected date and time.\nError Message: " + nullExp.Message + "\nStack Trace: " + nullExp.StackTrace;
            }
            catch (Exception genExp)
            {
                MessageBox.Show("Generic Exception occured while trying to get hourly data for selected date and time.\nError Message: " + genExp.Message + "\nFor mor details, check error log", "Generic Exception", MessageBoxButtons.OK, MessageBoxIcon.Error);
                expHelper.statusMsg = "Generic Exception occured while trying to get hourly data for selected date and time.\nError Message: " + genExp.Message + "\nStack Trace: " + genExp.StackTrace;
            }

            return hourlyDatatable;
        }
        /// <summary>
        /// Return type - Data table 
        /// Get hourly data of given data and time
        /// </summary>
        /// <param name="entryDate"></param>
        /// <param name="entryTime"></param>
        /// <returns></returns>
        public DataTable getHourlyData(string entryDate, int entryTime)
        {
            DataTable hourlyDatatable = null;
            string sql = @"select new_mill_juice, old_mill_juice, juice_total, new_mill_water,old_mill_water, water_total " +
                            " , sugar_bags_l31, sugar_bags_L30, sugar_bags_L_total " +
                            "  , sugar_bags_m31, sugar_bags_m30, sugar_bags_m_total " +
                            " , sugar_bags_s31, sugar_bags_s30, sugar_bags_s_total " +
                            " , sugar_Biss, sugar_bags_total " +
                            " , cooling_trace, cooling_pol, cooling_ph, standing_truck, standing_trippler, standing_trolley, standing_cart, un_crushed_cane, crushed_cane " +
                            "  from transactions_hourly " +
                            "  where entry_Date = @entryDate and entry_time = @entryTime ";
            List<SqlParameter> param = new List<SqlParameter>();
            param.Add(new SqlParameter("@entryDate", entryDate));
            param.Add(new SqlParameter("@entryTime", entryTime));
            try
            {
                hourlyDatatable = SqlHelper.ExecuteDataset(dbConn.sqlConn(), CommandType.Text, sql, param.ToArray()).Tables[0];
            }
            catch (SqlException ex)
            {
                MessageBox.Show("Sql exception occured while trying to get hourly data for selected date and time.\nError Message: " + ex.Message + "\nFor mor details, check error log", "Sql Exception", MessageBoxButtons.OK, MessageBoxIcon.Error);
                expHelper.statusMsg = "Sql exception occured while trying to get hourly data for selected date and time.\nError Message: " + ex.Message + "\nStack Trace: " + ex.StackTrace;
            }
            catch (NullReferenceException nullExp)
            {
                MessageBox.Show("Null Reference Exception occured while trying to get hourly data for selected date and time.\nError Message: " + nullExp.Message + "\nFor mor details, check error log", "Null Reference Exception", MessageBoxButtons.OK, MessageBoxIcon.Error);
                expHelper.statusMsg = "Null Reference Exception while trying to get hourly data for selected date and time.\nError Message: " + nullExp.Message + "\nStack Trace: " + nullExp.StackTrace;
            }
            catch (Exception genExp)
            {
                MessageBox.Show("Generic Exception occured while trying to get hourly data for selected date and time.\nError Message: " + genExp.Message + "\nFor mor details, check error log", "Generic Exception", MessageBoxButtons.OK, MessageBoxIcon.Error);
                expHelper.statusMsg = "Generic Exception occured while trying to get hourly data for selected date and time.\nError Message: " + genExp.Message + "\nStack Trace: " + genExp.StackTrace;
            }

            return hourlyDatatable;
        }

        #endregion

        #region Get Average weight from vehicle master
        // get average weight of vehile when object of class is created
        public hourly_entry_logic()
        {
            DataTable dt = null;
            string sql = @"select v_code, v_name, v_average_weight from vehicle_master where v_is_active = 1";
            try
            {
                dt = SqlHelper.ExecuteDataset(dbConn.sqlConn(), CommandType.Text, sql).Tables[0];
                int vehicleCode = 0;
                if (dt != null && dt.Rows.Count > 0)
                {
                    
                    foreach (DataRow dr in dt.Rows)
                    {
                        vehicleCode = Convert.ToInt16(dr["v_code"].ToString());
                        switch (vehicleCode)
                        {
                            case 1: // truck
                                truck_avg_weight = float.Parse(dr["v_average_weight"].ToString());
                                Console.WriteLine("truck avg weight = " + truck_avg_weight);
                                break;
                            case 2: // trippler
                                trippler_avg_weight = float.Parse(dr["v_average_weight"].ToString());
                                Console.WriteLine("trippler_avg_weight avg weight = " + trippler_avg_weight);
                                break;
                            case 3: //trolley
                                trolley_avg_weight = float.Parse(dr["v_average_weight"].ToString());
                                Console.WriteLine("trolley_avg_weight avg weight = " + trolley_avg_weight);
                                break;
                            case 4: //cart
                                cart_avg_weight = float.Parse(dr["v_average_weight"].ToString());
                                Console.WriteLine("cart_avg_weight avg weight = " + cart_avg_weight);
                                break;
                        }
                    }
                }
            }
            catch (SqlException ex)
            {
                expHelper.statusMsg = "Error: occured while fetching vehicle average weight.\nError message: " + ex.Message;
                Console.WriteLine(ex.Message);
                throw;
            }
            catch (Exception ex)
            {
                expHelper.statusMsg = "Error: occured while fetching vehicle average weight.\nError message: " + ex.Message;
                Console.WriteLine(ex.Message);
                throw;
            }
        }

        #endregion
    }
}
