﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.SqlClient;
using System.Reflection;
using Litmus.classes;
using System.Windows.Forms;
namespace Litmus
{
    
    class DbConnections
    {
        private string serverName = Properties.Settings.Default.serverName;
        private string userName = Properties.Settings.Default.userName;
        private string passwrod = Properties.Settings.Default.password;
        private string initialDatabase = Properties.Settings.Default.initialCatalog;
        //private string sqlConnString = @"Data Source=Bitcodes\sqlexpress;Initial Catalog=Litmus;Integrated Security=True";
        //private string sqlConnString = 
        
        private string _statusMsg;
        ExceptionHelper exceptionHelper = new ExceptionHelper();

        public string statusMsg
        {
            get { return _statusMsg; }
            set { _statusMsg = value; }
        }

        public SqlConnection sqlConn()
        {
            SqlConnection sqlConn = null;
            try
            {
                string sqlConnString = @"Data Source = " + serverName + ";Initial Catalog = " + initialDatabase + "; USER ID = " + userName + "; password = " + passwrod;
                try
                {
                    sqlConn = new SqlConnection(sqlConnString);
                    if (sqlConn.State != System.Data.ConnectionState.Open)
                    {
                        sqlConn.Open();
                        if (sqlConn.State != System.Data.ConnectionState.Open)
                        {
                            MessageBox.Show("Exiting application!\nCould not connect to database, please check connection settings", "Invalid Database", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                            sqlConn = null;
                        }
                        else
                        {
                            sqlConn.Close();
                        }
                    }
                }
                catch (Exception ex)
                {
                    exceptionHelper.statusMsg = "ERR:" + ex.Message + "\nStack Trace" + ex.StackTrace;
                }
                

               
            }
            catch (SqlException ex)
            {
                string sqlConnString = @"Data Source = " + serverName + ";Initial Catalog = " + initialDatabase + "; USER ID = " + userName + "; password = " + passwrod;
                exceptionHelper.statusMsg = "ERR:" + ex.Message + "\nStack Trace" + ex.StackTrace;
                
            }
            return sqlConn;
        }
        
    }
}
