﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Windows.Forms;
using System.Data.SqlClient;
using Microsoft.ApplicationBlocks.Data;
using Litmus.classes;
namespace Litmus.classes.reports
{
    class dailyReports_logic
    {
        DbConnections dbConn = new DbConnections();
        ExceptionHelper expHelper = new ExceptionHelper();

        public DataTable get_available_reports()
        {
            DataTable reports_datatable = null;
            string sql = @"select r_code, r_name from report_dtl where r_is_active = 1 and r_report_type = 39 order by r_name";

            try
            {
                reports_datatable = SqlHelper.ExecuteDataset(dbConn.sqlConn(), CommandType.Text, sql).Tables[0];
            }
            catch (SqlException sqlExp)
            {
                MessageBox.Show("Sql exception occured while fetching 'Daily Reports Name'.\n Error Message: " + sqlExp.Message, "Sql Exception", MessageBoxButtons.OK, MessageBoxIcon.Error);
                expHelper.statusMsg = " Sql exception occured while fetching 'Daily Reports Name'.\n Error Message" + sqlExp.Message + "\n Stack Trace" + sqlExp.StackTrace + "\n Inner Exception:" + sqlExp.InnerException;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Generic exception occured while fetching 'Daily Reports Name'.\n Error Message: " + ex.Message, "Sql Exception", MessageBoxButtons.OK, MessageBoxIcon.Error);
                expHelper.statusMsg = " Generic exception occured while fetching 'Daily Reports Name'.\n Error Message" + ex.Message + "\n Stack Trace" + ex.StackTrace + "\n Inner Exception:" + ex.InnerException;
            }

            return reports_datatable;
        }

        public DataTable get_form_rg_six_data(string transDate)
        {
            DataTable get_form_rg_six_dataTable = null;
            string sql = @"select net_mixed_juice_qtl 'net_mixed_juice',  " +
                            " gross_mixed_juice_percent_cane, dirt_correction_perccent_cane, net_mixed_juice_percent_cane, water_percent_cane " +
                            " , total_sugar_bagged, total_sugar_bagged, final_molasses_sent_out, estimated_sugar_percent_cane, estimated_molasses_percent_cane " +
                            " , total_bagasse_percent_cane, press_cake_percent_cane " +
                            " , pol_in_cane_percent, fiber_percent_cane " +
                            " , combined_pj_pol_avg, combined_pj_brix_avg, combined_pj_purity " +
                            " , combined_mj_pol, combined_mj_brix, combined_mj_purity " +
                            " , combined_lj_pol_avg, combined_lj_brix_avg, combined_lj_purity " +
                            " , clear_juice_pol, clear_juice_brix, clear_juice_purity " +
                            " , oliver_pol, oliver_brix,  oliver_purity " +
                            " , un_sulphered_pol, un_sulphered_brix, un_sulphered_purity " +
                            " , sulphered_pol, sulphered_brix, sulphered_purity " +
                            "  , a_mass_pol,a_mass_brix, a_mass_purity " +
	                        "  , a1_mass_pol, a1_mass_brix, a1_mass_purity " +
	                        "  , b_mass_pol, b_mass_brix, b_mass_purity  " +
	                        "  , c1_mass_pol, c1_mass_brix, c1_mass_purity " +
                            "  , c_mass_pol, c_mass_brix, c_mass_purity " +
                            " from ledger_data  " +
                            " where trans_date = @transDate";
            List<SqlParameter> param = new List<SqlParameter>();
            try
            {
                param.Add(new SqlParameter("@transDate", transDate));
            }
            catch (ArgumentNullException ex)
            {
                MessageBox.Show("Date not provided.\nError Message"+ex.Message, "Invalid date", MessageBoxButtons.OK, MessageBoxIcon.Hand);
            }
            try
            {

                get_form_rg_six_dataTable = SqlHelper.ExecuteDataset(dbConn.sqlConn(), CommandType.Text, sql, param.ToArray()).Tables[0];
            }
            catch (SqlException sqlEx)
            {
                MessageBox.Show("Error occured while fetchind data for report.\nError Message" + sqlEx.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Hand);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Generic error occured while fetchind data for report.\nError Message" + ex.Message, "Generic Error", MessageBoxButtons.OK, MessageBoxIcon.Hand);
            }
            return get_form_rg_six_dataTable; 
        }
    }
}
