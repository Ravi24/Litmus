﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using Microsoft.ApplicationBlocks.Data;
using System.Windows.Forms;
using Litmus.classes;

namespace Litmus.classes.reports.hourly_report
{
    class repo_hourly_sugar_bags_logic
    {
        DbConnections dbConn = new DbConnections();
        ExceptionHelper expHelper = new ExceptionHelper();
        generalFunctions genFunc = new generalFunctions();

        

        DataSet ds = new DataSet();
        string sql_day_summary = "";
        string sql_shift_summary = "";
        /// <summary>
        /// retrun sql query
        /// 
        /// </summary>
        /// <param name="report_code"></param>
        /// <param name="param_date"></param>
        /// <returns></returns>
        private string sql_string(int report_code, string param_date)
        {
            string sql = "";
            
            switch (report_code)
            {
                case 1: // sugar bags report
                    sql = @"select t1.sugar_bags_l31, t1.sugar_bags_L30, t1.sugar_bags_L_total,sum(t2.sugar_bags_L_total) 'L_sum' " +
                           " , t1.sugar_bags_M31, t1.sugar_bags_M30, t1.sugar_bags_M_total, sum(t2.sugar_bags_M_total) 'm_sum' " +
                           "  , t1.sugar_bags_s31, t1.sugar_bags_s30, t1.sugar_bags_s_total, sum(t2.sugar_bags_s_total) 's_sum' " +
                           "  , t1.sugar_Biss, t1.sugar_biss, sum(t2.sugar_biss) 'biss_sum' " +
                           ", (t1.sugar_bags_L_total+t1.sugar_bags_M_total+t1.sugar_bags_s_total+t1.sugar_Biss) 'totals' " +
                        " from transactions_hourly t1 " +
                        " inner join transactions_hourly t2 " +
                        " on t1.entry_Date = t2.entry_Date " +
                        " and t1.id >= t2.id " +
                        " and t1.entry_Date = @param_date " +
                        " group by t1.id,t1.entry_time, t1.sugar_bags_l31, t1.sugar_bags_L30, t1.sugar_bags_L_total " +
                        " , t1.sugar_bags_M31, t1.sugar_bags_M30, t1.sugar_bags_M_total " +
                        " , t1.sugar_bags_s31, t1.sugar_bags_s30, t1.sugar_bags_S_total " +
                        " , t1.sugar_Biss " +
                        " order by t1.id";
                    
                    break;
                case 2: // hourly juice & water report sql
                    break;
                case 3:
                    sql = @"select nm_primary_juice_brix, nm_primary_juice_pol, nm_primary_juice_purity " +
                            " , om_primary_juice_brix, om_primary_juice_pol, om_primary_juice_purity " +
                            " , nm_mixed_juice_brix, nm_mixed_juice_pol, nm_mixed_juice_purity " +
                            " , om_mixed_juice_brix, om_mixed_juice_pol, om_mixed_juice_purity " +
                            " , nm_last_juice_brix, nm_last_juice_pol, nm_last_juice_purity " +
                            " , om_last_juice_brix, om_last_juice_pol, om_last_juice_purity " +
                            " from transactions_two_hourly where entry_date = @param_date";

                    sql_day_summary = @"select nm_pj_brix_avg, nm_pj_pol_avg " +
                                   " , case when nm_pj_brix_avg > 0 then round(((nm_pj_pol_avg)/nm_pj_brix_avg)*100,2) else 0 end 'nm_pj_purity' " +
                                   " , om_pj_brix_avg, om_pj_pol_avg " +
                                   " , case when om_pj_brix_avg > 0 then round(((om_pj_pol_avg)/om_pj_brix_avg)*100,2)  else 0 end 'om_pj_purity' " +
                                   " ,  nm_mj_brix_avg, nm_mj_pol_avg " +
                                   " , case when nm_mj_brix_avg > 0 then round(((nm_mj_pol_avg)/nm_mj_brix_avg)*100,2) else 0 end 'nm_mj_purity' " +
                                   " , om_mj_brix_avg, om_mj_pol_avg " +
                                   " , case when om_mj_brix_avg > 0 then  round(((om_mj_pol_avg)/om_mj_brix_avg)*100,2) else 0 end  'om_mj_purity' " +
                                   " , nm_lj_brix_avg, nm_lj_pol_avg " +
                                   " , case when nm_lj_brix_avg > 0 then round(((nm_lj_pol_avg)/nm_lj_brix_avg)*100,0) else 0 end 'nm_lj_purity' " +
                                   " , om_lj_brix_avg, om_lj_pol_avg " +
                                   " , case when om_lj_brix_avg > 0 then round(((om_lj_pol_avg)/om_lj_brix_avg)*100,0) else 0 end 'om_lj_purity' " +
                                   "  from func_tow_hourly_transaction_summary(@param_date)  ";

                    sql_shift_summary = @"select nm_pj_brix_avg, nm_pj_pol_avg " +
                                   " , case when nm_pj_brix_avg > 0 then round(((nm_pj_pol_avg)/nm_pj_brix_avg)*100,2) else 0 end 'nm_pj_purity' " +
                                   " , om_pj_brix_avg, om_pj_pol_avg " +
                                   " , case when om_pj_brix_avg > 0 then round(((om_pj_pol_avg)/om_pj_brix_avg)*100,2)  else 0 end 'om_pj_purity' " +
                                   " ,  nm_mj_brix_avg, nm_mj_pol_avg " +
                                   " , case when nm_mj_brix_avg > 0 then round(((nm_mj_pol_avg)/nm_mj_brix_avg)*100,2) else 0 end 'nm_mj_purity' " +
                                   " , om_mj_brix_avg, om_mj_pol_avg " +
                                   " , case when om_mj_brix_avg > 0 then  round(((om_mj_pol_avg)/om_mj_brix_avg)*100,2) else 0 end  'om_mj_purity' " +
                                   " , nm_lj_brix_avg, nm_lj_pol_avg " +
                                   " , case when nm_lj_brix_avg > 0 then round(((nm_lj_pol_avg)/nm_lj_brix_avg)*100,0) else 0 end 'nm_lj_purity' " +
                                   " , om_lj_brix_avg, om_lj_pol_avg " +
                                   " , case when om_lj_brix_avg > 0 then round(((om_lj_pol_avg)/om_lj_brix_avg)*100,0) else 0 end 'om_lj_purity' " +
                                   "  from func_tow_hourly_transaction_summary_for_hours(@param_date, @shift_first_entry, @shift_last_entry)  ";
                    break;
                case 4:
                    
                    
                    break;
                    
                default:
                    MessageBox.Show("Unable to define request string for the report","Error",MessageBoxButtons.OK,MessageBoxIcon.Hand);
                    break;
            }
           
            return sql;
        }

        public DataSet report_dataset(int report_code,string param_date)
        { 
            string sql = sql_string(report_code, param_date);
           
            List<SqlParameter> sqlPram = new List<SqlParameter>();
            sqlPram.Add(new SqlParameter("@param_date", param_date));
            DataTable dt_day_summary = new DataTable();
            DataTable dt_data = new DataTable();
            DataTable dt_shift_summary = new DataTable();
            try
            {
                switch (report_code)
                {
                    case 1:
                        dt_data = SqlHelper.ExecuteDataset(dbConn.sqlConn(), CommandType.Text, sql, sqlPram.ToArray()).Tables[0];
                        dt_data.TableName = "table_data";
                        ds.Tables.Add(dt_data.Copy());
                        break;
                    case 2:
                        dt_data = SqlHelper.ExecuteDataset(dbConn.sqlConn(), CommandType.Text, sql, sqlPram.ToArray()).Tables[0];
                        dt_data.TableName = "table_data";
                        break;

                    case 3:
                        dt_data = SqlHelper.ExecuteDataset(dbConn.sqlConn(), CommandType.Text, sql, sqlPram.ToArray()).Tables[0];
                        dt_data.TableName = "table_data";
                        dt_day_summary = SqlHelper.ExecuteDataset(dbConn.sqlConn(), CommandType.Text, sql_day_summary, sqlPram.ToArray()).Tables[0];
                        dt_day_summary.TableName = "table_day_summary";
                        ds.Tables.Add(dt_data.Copy());
                        ds.Tables.Add(dt_day_summary.Copy());
                        break;

                    case 4:
                        List<SqlParameter> param = new List<SqlParameter>();
                        param.Add(new SqlParameter("entry_date",param_date));
                        dt_data = SqlHelper.ExecuteDataset(dbConn.sqlConn(), CommandType.StoredProcedure, "proc_repo_two_hourly_bagasse_view", param.ToArray()).Tables[0];
                        dt_data.TableName = "table_data";
                        ds.Tables.Add(dt_data.Copy());
                        break;
                }
                
            }
            catch (SqlException ex)
            {
                MessageBox.Show(ex.Message + "\nFor more details check error log.", "Sql exception", MessageBoxButtons.OK, MessageBoxIcon.Error);
                expHelper.statusMsg = "Error occured while fetching data for hourly report.\nError message " + ex.Message + "\nStack trace- " + ex.StackTrace;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message + "\nFor more details check error log.", "Generic exception", MessageBoxButtons.OK, MessageBoxIcon.Error);
                expHelper.statusMsg = "Error occured while fetching data for hourly report.\nError message " + ex.Message + "\nStack trace- " + ex.StackTrace;
            }
            return ds;
        }

        public DataSet shift_sumary_dataset(string date, int start_hour, int end_hour)
        {
            DataSet shift_summary_dataset = null;
            List<SqlParameter> param = new List<SqlParameter>();
            param.Add(new SqlParameter("@param_date", date));
            param.Add(new SqlParameter("@shift_first_entry", start_hour));
            param.Add(new SqlParameter("@shift_last_entry", end_hour));
            try
            {
                shift_summary_dataset = SqlHelper.ExecuteDataset(dbConn.sqlConn(), CommandType.Text, sql_shift_summary, param.ToArray());
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            return shift_summary_dataset;
        }
    }
}
