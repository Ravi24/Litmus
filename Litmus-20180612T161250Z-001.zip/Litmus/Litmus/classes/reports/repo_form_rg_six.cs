﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.Data;
using iTextSharp;
using iTextSharp.text;
using iTextSharp.text.pdf;
using System.Windows.Forms;


using Litmus.classes;

namespace Litmus.classes.reports
{
    class repo_form_rg_six
    {
        generalFunctions genFunc = new generalFunctions();
        master_parameter_logic masterParam = new master_parameter_logic();
        dailyReports_logic dailyReportLogic = new dailyReports_logic();
        ExceptionHelper expHelper = new ExceptionHelper();

        public void generate_report(string reportDate, string saving_location)
        {
          
            try
            {
                DataTable dt = new DataTable();
                dt = dailyReportLogic.get_form_rg_six_data(reportDate);
                FileStream fs = new FileStream(saving_location, FileMode.Create);
                Document document = new Document(PageSize.A4, 10, 10, 10, 10);

                PdfWriter writer = PdfWriter.GetInstance(document, fs);
                Font HeaderFont = new Font(Font.FontFamily.TIMES_ROMAN, 8f, Font.BOLD, BaseColor.BLUE);
                Font bodyHeader = new Font(Font.FontFamily.HELVETICA, 8f, Font.BOLD, BaseColor.BLACK);
                Font bodyContent = new Font(Font.FontFamily.COURIER, 7f, Font.NORMAL, BaseColor.BLACK);

                document.AddAuthor(genFunc.userName);
                document.AddCreator(masterParam.unitName);
                document.AddCreationDate();

                document.Open();


                PdfPTable table = new PdfPTable(5);
                table.TotalWidth = 500f;
                table.LockedWidth = true;
                float[] widths = new float[] { 40f, 170f, 60f, 60f, 170f };
                table.SetWidths(widths);


                #region Pdf Header Section
                PdfPCell HeaderCell = new PdfPCell(new Paragraph("Center Excise Series No. 44" + Environment.NewLine +
                                                                    "Form R.G.6(G)" + Environment.NewLine +
                                                                    "Ragister of Daily Manufacturing (Rule 83)" + Environment.NewLine +
                                                                    "(For Central Sugar Factories)"
                                                                    , HeaderFont));
                HeaderCell.Border = 0;
                HeaderCell.Colspan = 5;
                HeaderCell.HorizontalAlignment = Element.ALIGN_CENTER;
                table.AddCell(HeaderCell);

                PdfPCell headerLineTwoCellOne = new PdfPCell(new Phrase("Date :" + reportDate, HeaderFont));
                headerLineTwoCellOne.Colspan = 2;
                headerLineTwoCellOne.Border = 0;

                PdfPCell headerLineTwoCellTwo = new PdfPCell(new Phrase("Crop Day - " + ((Convert.ToDateTime(reportDate) - Convert.ToDateTime(masterParam.crushingStartDate))).TotalDays.ToString(), HeaderFont));
                headerLineTwoCellTwo.Colspan = 1;
                headerLineTwoCellTwo.Border = 0;
                headerLineTwoCellTwo.HorizontalAlignment = Element.ALIGN_CENTER;

                PdfPCell headerLineTwoCellThree = new PdfPCell(new Phrase("", HeaderFont));
                headerLineTwoCellThree.Colspan = 2;
                headerLineTwoCellThree.Border = 0;

                PdfPCell headerLineFour = new PdfPCell(new Phrase("Name of Factory:" + masterParam.unitName, HeaderFont));
                headerLineFour.Border = 0;
                headerLineFour.Colspan = 5;

                PdfPCell headerLineFive = new PdfPCell(new Phrase("Clerification Used: Double Sulphitation Seohara", HeaderFont));
                headerLineFive.Border = 0;
                headerLineFive.Colspan = 5;

                table.AddCell(headerLineTwoCellOne);
                table.AddCell(headerLineTwoCellTwo);
                table.AddCell(headerLineTwoCellThree);
                table.AddCell(headerLineFour);
                table.AddCell(headerLineFive);

                #endregion

                #region Pdf Body Section
                PdfPCell bodyHeaderCellOne = new PdfPCell(new Phrase("Serial No.", bodyHeader));
                PdfPCell bodyHeaderCellTwo = new PdfPCell(new Phrase("Particulars", bodyHeader));
                PdfPCell bodyHeaderCellThree = new PdfPCell(new Phrase("On Date", bodyHeader));
                PdfPCell bodyHeaderCellFour = new PdfPCell(new Phrase("To Date", bodyHeader));
                PdfPCell bodyHeaderCellFive = new PdfPCell(new Phrase("Total for the month or for the period as" +
                                                                        "the case may be to entered at the end" +
                                                                        "of the month and at end of the period."
                                                                        , bodyHeader));
                bodyHeaderCellOne.HorizontalAlignment = Element.ALIGN_CENTER;
                bodyHeaderCellOne.VerticalAlignment = Element.ALIGN_CENTER;
                bodyHeaderCellTwo.HorizontalAlignment = Element.ALIGN_CENTER;
                bodyHeaderCellTwo.VerticalAlignment = Element.ALIGN_CENTER;
                bodyHeaderCellThree.HorizontalAlignment = Element.ALIGN_CENTER;
                bodyHeaderCellThree.VerticalAlignment = Element.ALIGN_CENTER;
                bodyHeaderCellFour.HorizontalAlignment = Element.ALIGN_CENTER;
                bodyHeaderCellFour.VerticalAlignment = Element.ALIGN_CENTER;
                bodyHeaderCellFive.HorizontalAlignment = Element.ALIGN_CENTER;
                bodyHeaderCellFive.VerticalAlignment = Element.ALIGN_CENTER;

                table.AddCell(bodyHeaderCellOne);
                table.AddCell(bodyHeaderCellTwo);
                table.AddCell(bodyHeaderCellThree);
                table.AddCell(bodyHeaderCellFour);
                table.AddCell(bodyHeaderCellFive);


                PdfPCell[] bodyLineOne = new PdfPCell[]{ new PdfPCell(new Phrase("1",bodyContent)),
                new PdfPCell(new Phrase("2",bodyContent)),
                new PdfPCell(new Phrase("3",bodyContent)),
                new PdfPCell(new Phrase("4",bodyContent)),
                new PdfPCell(new Phrase("5",bodyContent))
                
                };
                foreach (PdfPCell cell in bodyLineOne)
                {
                    cell.HorizontalAlignment = Element.ALIGN_CENTER;
                    table.AddCell(cell);
                }
                // header of serial number 1
                PdfPCell serial_cane_crushing_data = new PdfPCell(new Phrase("1", bodyContent));
                serial_cane_crushing_data.Rowspan = 2;
                serial_cane_crushing_data.HorizontalAlignment = Element.ALIGN_CENTER;
                serial_cane_crushing_data.VerticalAlignment = Element.ALIGN_MIDDLE;
                PdfPCell cane_crushing_head = new PdfPCell(new Phrase("Cane Crushing:-", bodyContent));
                cane_crushing_head.Colspan = 4;
                cane_crushing_head.HorizontalAlignment = Element.ALIGN_LEFT;
                cane_crushing_head.BackgroundColor = BaseColor.LIGHT_GRAY;
                table.AddCell(serial_cane_crushing_data);
                table.AddCell(cane_crushing_head);
                // line-3
                PdfPCell[] bodyLineThree = new PdfPCell[]{
              

                  new PdfPCell(new Phrase("Number of hours actually crushing"+Environment.NewLine+
                                          "Number of hours lost"+Environment.NewLine+
                                          "Total cane milled (Qtls.)"+Environment.NewLine+
                                          "Total mixed juice obtained (Qtls.)",bodyContent)),

                  new PdfPCell(new Phrase("data1"+Environment.NewLine+
                                          "data2"+Environment.NewLine+
                                          "data2"+Environment.NewLine+
                                          "data2",bodyContent)),

                 new PdfPCell(new Phrase("data1"+Environment.NewLine+
                                          "data2"+Environment.NewLine+
                                          "data2"+Environment.NewLine+
                                          "data2",bodyContent)),

                new PdfPCell(new Phrase("",bodyContent))
                };

                foreach (PdfPCell cell in bodyLineThree)
                {
                    cell.HorizontalAlignment = Element.ALIGN_LEFT;
                    table.AddCell(cell);
                }
                // header of serial number 2
                PdfPCell serial_Juice_and_water = new PdfPCell(new Phrase("2", bodyContent));
                serial_Juice_and_water.Rowspan = 2;
                serial_Juice_and_water.HorizontalAlignment = Element.ALIGN_CENTER;
                serial_Juice_and_water.VerticalAlignment = Element.ALIGN_MIDDLE;
                PdfPCell header_juice_and_water = new PdfPCell(new Phrase("Juice & Water:-", bodyContent));
                header_juice_and_water.Colspan = 4;
                header_juice_and_water.HorizontalAlignment = Element.ALIGN_LEFT;
                header_juice_and_water.BackgroundColor = BaseColor.LIGHT_GRAY;
                table.AddCell(serial_Juice_and_water);
                table.AddCell(header_juice_and_water);
                // line-5
                PdfPCell[] bodyLineFive = new PdfPCell[]{
              
                  new PdfPCell(new Phrase("Average Gross Mixed Juice Percent Cane"+Environment.NewLine+
                                          "Dirt Correction % Mixed Juice"+Environment.NewLine+
                                          "Average Net Mixed Juice % Cane"+Environment.NewLine+
                                          "Average Added Water % Cane",bodyContent)),

                  new PdfPCell(new Phrase(dt.Rows[0]["gross_mixed_juice_percent_cane"].ToString()+Environment.NewLine+
                                          dt.Rows[0]["dirt_correction_perccent_cane"].ToString()+Environment.NewLine+
                                          dt.Rows[0]["net_mixed_juice_percent_cane"].ToString()+Environment.NewLine+
                                          dt.Rows[0]["water_percent_cane"].ToString(),bodyContent)),

                 new PdfPCell(new Phrase("data1"+Environment.NewLine+
                                          "data2"+Environment.NewLine+
                                          "data2"+Environment.NewLine+
                                          "data2",bodyContent)),

                new PdfPCell(new Phrase("",bodyContent))
                };

                foreach (PdfPCell cell in bodyLineFive)
                {
                    cell.HorizontalAlignment = Element.ALIGN_LEFT;
                    table.AddCell(cell);
                }


                // Sugar heading

                PdfPCell serial_sugar = new PdfPCell(new Phrase("3", bodyContent));
                serial_sugar.Rowspan = 2;
                serial_sugar.HorizontalAlignment = Element.ALIGN_CENTER;
                serial_sugar.VerticalAlignment = Element.ALIGN_MIDDLE;
                PdfPCell header_sugar = new PdfPCell(new Phrase("Sugar:-", bodyContent));
                header_sugar.Colspan = 4;
                header_sugar.HorizontalAlignment = Element.ALIGN_LEFT;
                header_sugar.BackgroundColor = BaseColor.LIGHT_GRAY;
                table.AddCell(serial_sugar);
                table.AddCell(header_sugar);
                // line-7 -- Sugar Data
                PdfPCell[] bodyLineSeven = new PdfPCell[]{
              
                  new PdfPCell(new Phrase("Total Sugar Bagged (Nos.)"+Environment.NewLine+
                                          "Quantity of Sugar (Qtls.)",bodyContent)),

                  new PdfPCell(new Phrase(dt.Rows[0]["total_sugar_bagged"].ToString()+Environment.NewLine+
                                          dt.Rows[0]["total_sugar_bagged"].ToString(),bodyContent)),

                 new PdfPCell(new Phrase("data1"+Environment.NewLine+
                                          "data2",bodyContent)),

                new PdfPCell(new Phrase("",bodyContent))
                };

                foreach (PdfPCell cell in bodyLineSeven)
                {
                    cell.HorizontalAlignment = Element.ALIGN_LEFT;
                    table.AddCell(cell);
                }
                // Molasses heading

                PdfPCell serial_molasses = new PdfPCell(new Phrase("4", bodyContent));
                serial_molasses.Rowspan = 2;
                serial_molasses.HorizontalAlignment = Element.ALIGN_CENTER;
                serial_molasses.VerticalAlignment = Element.ALIGN_MIDDLE;
                PdfPCell header_molasses = new PdfPCell(new Phrase("Molasses:-", bodyContent));
                header_molasses.Colspan = 4;
                header_molasses.HorizontalAlignment = Element.ALIGN_LEFT;
                header_molasses.BackgroundColor = BaseColor.LIGHT_GRAY;
                table.AddCell(serial_molasses);
                table.AddCell(header_molasses);

                // line-9 -- Molasses Data
                PdfPCell[] bodyLineNine = new PdfPCell[]{
              
                  new PdfPCell(new Phrase("Total Molasses Sent Out (Qtls.)",bodyContent)),

                  new PdfPCell(new Phrase(dt.Rows[0]["final_molasses_sent_out"].ToString(),bodyContent)),

                 new PdfPCell(new Phrase("data1",bodyContent)),

                new PdfPCell(new Phrase("",bodyContent))
                };

                foreach (PdfPCell cell in bodyLineNine)
                {
                    cell.HorizontalAlignment = Element.ALIGN_LEFT;
                    table.AddCell(cell);
                }

                //  Estimated sugar & molasses Point-5

                PdfPCell serial_five = new PdfPCell(new Phrase("5", bodyContent));
                serial_five.Rowspan = 1;
                serial_five.HorizontalAlignment = Element.ALIGN_CENTER;
                serial_five.VerticalAlignment = Element.ALIGN_MIDDLE;
                table.AddCell(serial_five);
                PdfPCell[] bodyLineTen = new PdfPCell[]{
              
                  new PdfPCell(new Phrase("Estimated Recovery of Sugar % Cane)"+Environment.NewLine+
                                          "Estimated Recovery of Molasses % Cane",bodyContent)),

                  new PdfPCell(new Phrase(dt.Rows[0]["estimated_sugar_percent_cane"].ToString()+Environment.NewLine+
                                          dt.Rows[0]["estimated_molasses_percent_cane"].ToString(),bodyContent)),

                 new PdfPCell(new Phrase("data1",bodyContent)),

                new PdfPCell(new Phrase("",bodyContent))
                };

                foreach (PdfPCell cell in bodyLineTen)
                {
                    cell.HorizontalAlignment = Element.ALIGN_LEFT;
                    table.AddCell(cell);
                }
                // Bagasse & Fiber percent point 6 
                PdfPCell serial_six = new PdfPCell(new Phrase("6", bodyContent));
                serial_six.Rowspan = 1;
                serial_six.HorizontalAlignment = Element.ALIGN_CENTER;
                serial_six.VerticalAlignment = Element.ALIGN_MIDDLE;
                table.AddCell(serial_six);

                PdfPCell[] bodyLineEleven = new PdfPCell[]{
              
                  new PdfPCell(new Phrase("Bagasse % Cane)"+Environment.NewLine+
                                          "Press Cake % Cane",bodyContent)),

                  new PdfPCell(new Phrase(dt.Rows[0]["total_bagasse_percent_cane"].ToString()+Environment.NewLine+
                                          dt.Rows[0]["press_cake_percent_cane"].ToString(),bodyContent)),

                 new PdfPCell(new Phrase("data1",bodyContent)),

                new PdfPCell(new Phrase("",bodyContent))
                };

                foreach (PdfPCell cell in bodyLineEleven)
                {
                    cell.HorizontalAlignment = Element.ALIGN_LEFT;
                    table.AddCell(cell);
                }


                // -- Analysis heading
                #region Point 7
                PdfPCell serial_analysis = new PdfPCell(new Phrase("7", bodyContent));
                serial_analysis.Rowspan = 14;
                serial_analysis.HorizontalAlignment = Element.ALIGN_CENTER;
                serial_analysis.VerticalAlignment = Element.ALIGN_MIDDLE;
                PdfPCell header_analysis = new PdfPCell(new Phrase("Analysis:-", bodyContent));
                header_analysis.Colspan = 4;
                header_analysis.HorizontalAlignment = Element.ALIGN_LEFT;
                header_analysis.BackgroundColor = BaseColor.LIGHT_GRAY;
                table.AddCell(serial_analysis);
                table.AddCell(header_analysis);

                // Analysis Data Cane
                PdfPCell[] bodyLineAnalysisDataCane = new PdfPCell[]{

                  new PdfPCell(new Phrase("Cane                     Sugar % Cane"+Environment.NewLine+
                                          "                         Fiber % Cane",bodyContent)),

                  new PdfPCell(new Phrase(dt.Rows[0]["pol_in_cane_percent"].ToString()+Environment.NewLine+
                                          dt.Rows[0]["fiber_percent_cane"].ToString(),bodyContent)),

                 new PdfPCell(new Phrase("data1",bodyContent)),

                new PdfPCell(new Phrase("",bodyContent))
                };

                foreach (PdfPCell cell in bodyLineAnalysisDataCane)
                {
                    cell.HorizontalAlignment = Element.ALIGN_LEFT;
                    table.AddCell(cell);
                }
                // Analysis Data - Primary Juice
                PdfPCell[] bodyLineAnalysisDataPrimaryJuice = new PdfPCell[]{
              

                  new PdfPCell(new Phrase("Primary Juice            Sugar % Cane"+Environment.NewLine+
                                          "                         Fiber % Cane"+Environment.NewLine+
                                          "                         Purity",bodyContent)),

                  new PdfPCell(new Phrase(dt.Rows[0]["combined_pj_pol_avg"].ToString()+Environment.NewLine+
                                          dt.Rows[0]["combined_pj_brix_avg"].ToString()+Environment.NewLine+
                                          dt.Rows[0]["combined_pj_purity"].ToString(),bodyContent)),

                 new PdfPCell(new Phrase("data1",bodyContent)),

                new PdfPCell(new Phrase("",bodyContent))
                };

                foreach (PdfPCell cell in bodyLineAnalysisDataPrimaryJuice)
                {
                    cell.HorizontalAlignment = Element.ALIGN_LEFT;
                    table.AddCell(cell);
                }

                // Analysis Data - Mixed Juice
                PdfPCell[] bodyLineAnalysisDataMixedJuice = new PdfPCell[]{
              

                 new PdfPCell(new Phrase( "Mixed Juice              Sugar % Cane"+Environment.NewLine+
                                          "                         Fiber % Cane"+Environment.NewLine+
                                          "                         Purity",bodyContent)),

                  new PdfPCell(new Phrase(dt.Rows[0]["combined_mj_pol"].ToString()+Environment.NewLine+
                                          dt.Rows[0]["combined_mj_brix"].ToString()+Environment.NewLine+
                                          dt.Rows[0]["combined_mj_purity"].ToString(),bodyContent)),

                 new PdfPCell(new Phrase("data1",bodyContent)),

                new PdfPCell(new Phrase("",bodyContent))
                };

                foreach (PdfPCell cell in bodyLineAnalysisDataMixedJuice)
                {
                    cell.HorizontalAlignment = Element.ALIGN_LEFT;
                    table.AddCell(cell);
                }

                // Analysis Data - Last Juice
                PdfPCell[] bodyLineAnalysisDataLastJuice = new PdfPCell[]{
              

                 new PdfPCell(new Phrase( "Last Juice               Sugar % Cane"+Environment.NewLine+
                                          "                         Fiber % Cane"+Environment.NewLine+
                                          "                         Purity",bodyContent)),

                  new PdfPCell(new Phrase(dt.Rows[0]["combined_lj_pol_avg"].ToString()+Environment.NewLine+
                                          dt.Rows[0]["combined_lj_brix_avg"].ToString()+Environment.NewLine+
                                          dt.Rows[0]["combined_lj_purity"].ToString(),bodyContent)),

                 new PdfPCell(new Phrase("data1",bodyContent)),

                new PdfPCell(new Phrase("",bodyContent))
                };

                foreach (PdfPCell cell in bodyLineAnalysisDataLastJuice)
                {
                    cell.HorizontalAlignment = Element.ALIGN_LEFT;
                    table.AddCell(cell);
                }

                // Analysis Data - Clear/Clerified Juice
                PdfPCell[] bodyLineAnalysisDataClearJuice = new PdfPCell[]{
              

                    new PdfPCell(new Phrase( "Clear Juice              Sugar % Cane"+Environment.NewLine+
                                            "                         Fiber % Cane"+Environment.NewLine+
                                            "                         Purity",bodyContent)),

                    new PdfPCell(new Phrase(dt.Rows[0]["clear_juice_pol"].ToString()+Environment.NewLine+
                                            dt.Rows[0]["clear_juice_brix"].ToString()+Environment.NewLine+
                                            dt.Rows[0]["clear_juice_purity"].ToString(),bodyContent)),

                    new PdfPCell(new Phrase("data1",bodyContent)),

                new PdfPCell(new Phrase("",bodyContent))
                };

                foreach (PdfPCell cell in bodyLineAnalysisDataClearJuice)
                {
                    cell.HorizontalAlignment = Element.ALIGN_LEFT;
                    table.AddCell(cell);
                }

                // Analysis Data - VAc. Filter/Oliver Juice
                PdfPCell[] bodyLineAnalysisDataOliverJuice = new PdfPCell[]{
              

                 new PdfPCell(new Phrase( "Oliver Juice             Sugar % Cane"+Environment.NewLine+
                                          "                         Fiber % Cane"+Environment.NewLine+
                                          "                         Purity",bodyContent)),

                  new PdfPCell(new Phrase(dt.Rows[0]["oliver_pol"].ToString()+Environment.NewLine+
                                          dt.Rows[0]["oliver_brix"].ToString()+Environment.NewLine+
                                          dt.Rows[0]["oliver_purity"].ToString(),bodyContent)),

                 new PdfPCell(new Phrase("data1",bodyContent)),

                new PdfPCell(new Phrase("",bodyContent))
                };

                foreach (PdfPCell cell in bodyLineAnalysisDataOliverJuice)
                {
                    cell.HorizontalAlignment = Element.ALIGN_LEFT;
                    table.AddCell(cell);
                }


                // Analysis Data - Un-Sulphered Syrup
                PdfPCell[] bodyLineAnalysisDataUnSulpheredJuice = new PdfPCell[]{
              

                 new PdfPCell(new Phrase( "Un-Sulphered Syrup       Sugar % Cane"+Environment.NewLine+
                                          "                         Fiber % Cane"+Environment.NewLine+
                                          "                         Purity",bodyContent)),

                  new PdfPCell(new Phrase(dt.Rows[0]["un_sulphered_pol"].ToString()+Environment.NewLine+
                                          dt.Rows[0]["un_sulphered_brix"].ToString()+Environment.NewLine+
                                          dt.Rows[0]["un_sulphered_purity"].ToString(),bodyContent)),

                 new PdfPCell(new Phrase("data1",bodyContent)),

                new PdfPCell(new Phrase("",bodyContent))
                };

                foreach (PdfPCell cell in bodyLineAnalysisDataUnSulpheredJuice)
                {
                    cell.HorizontalAlignment = Element.ALIGN_LEFT;
                    table.AddCell(cell);
                }

                // Analysis Data - Sulphered Syrup
                PdfPCell[] bodyLineAnalysisDataSulpheredJuice = new PdfPCell[]{
              

                 new PdfPCell(new Phrase( "Sulphered Syrup          Sugar % Cane"+Environment.NewLine+
                                          "                         Fiber % Cane"+Environment.NewLine+
                                          "                         Purity",bodyContent)),

                  new PdfPCell(new Phrase(dt.Rows[0]["sulphered_pol"].ToString()+Environment.NewLine+
                                          dt.Rows[0]["sulphered_brix"].ToString()+Environment.NewLine+
                                          dt.Rows[0]["sulphered_purity"].ToString(),bodyContent)),

                 new PdfPCell(new Phrase("data1",bodyContent)),

                new PdfPCell(new Phrase("",bodyContent))
                };

                foreach (PdfPCell cell in bodyLineAnalysisDataSulpheredJuice)
                {
                    cell.HorizontalAlignment = Element.ALIGN_LEFT;
                    table.AddCell(cell);
                }

                // Analysis Data - Massecuite-A Syrup
                PdfPCell[] bodyLineAnalysisDataMassecuite = new PdfPCell[]{
             

                 new PdfPCell(new Phrase( "Massecuite               Sugar % Cane"+Environment.NewLine+
                                          "                         Fiber % Cane"+Environment.NewLine+
                                          "                         Purity",bodyContent)),

                  new PdfPCell(new Phrase(dt.Rows[0]["a_mass_pol"].ToString()+Environment.NewLine+
                                          dt.Rows[0]["a_mass_brix"].ToString()+Environment.NewLine+
                                          dt.Rows[0]["a_mass_purity"].ToString(),bodyContent)),

                 new PdfPCell(new Phrase("data1",bodyContent)),

                new PdfPCell(new Phrase("",bodyContent))
                };

                foreach (PdfPCell cell in bodyLineAnalysisDataMassecuite)
                {
                    cell.HorizontalAlignment = Element.ALIGN_LEFT;
                    table.AddCell(cell);
                }

                // Analysis Data - Massecuite-A1 Syrup
                PdfPCell[] bodyLineAnalysisDataMassecuiteA1 = new PdfPCell[]{
             

                 new PdfPCell(new Phrase( "Massecuite A1            Sugar % Cane"+Environment.NewLine+
                                          "                         Fiber % Cane"+Environment.NewLine+
                                          "                         Purity",bodyContent)),

                  new PdfPCell(new Phrase(dt.Rows[0]["a1_mass_pol"].ToString()+Environment.NewLine+
                                          dt.Rows[0]["a1_mass_brix"].ToString()+Environment.NewLine+
                                          dt.Rows[0]["a1_mass_purity"].ToString(),bodyContent)),

                 new PdfPCell(new Phrase("data1",bodyContent)),

                new PdfPCell(new Phrase("",bodyContent))
                };

                foreach (PdfPCell cell in bodyLineAnalysisDataMassecuiteA1)
                {
                    cell.HorizontalAlignment = Element.ALIGN_LEFT;
                    table.AddCell(cell);
                }

                // Analysis Data - Massecuite-B Syrup
                PdfPCell[] bodyLineAnalysisDataMassecuiteB = new PdfPCell[]{
             

                 new PdfPCell(new Phrase( "Massecuite B             Sugar % Cane"+Environment.NewLine+
                                          "                         Fiber % Cane"+Environment.NewLine+
                                          "                         Purity",bodyContent)),

                  new PdfPCell(new Phrase(dt.Rows[0]["b_mass_pol"].ToString()+Environment.NewLine+
                                          dt.Rows[0]["b_mass_brix"].ToString()+Environment.NewLine+
                                          dt.Rows[0]["b_mass_purity"].ToString(),bodyContent)),

                 new PdfPCell(new Phrase("data1",bodyContent)),

                new PdfPCell(new Phrase("",bodyContent))
                };

                foreach (PdfPCell cell in bodyLineAnalysisDataMassecuiteB)
                {
                    cell.HorizontalAlignment = Element.ALIGN_LEFT;
                    table.AddCell(cell);
                }

                // Analysis Data - Massecuite-c1 Syrup
                PdfPCell[] bodyLineAnalysisDataMassecuiteC1 = new PdfPCell[]{
             

                 new PdfPCell(new Phrase( "Massecuite C1            Sugar % Cane"+Environment.NewLine+
                                          "                         Fiber % Cane"+Environment.NewLine+
                                          "                         Purity",bodyContent)),

                  new PdfPCell(new Phrase(dt.Rows[0]["c1_mass_pol"].ToString()+Environment.NewLine+
                                          dt.Rows[0]["c1_mass_brix"].ToString()+Environment.NewLine+
                                          dt.Rows[0]["c1_mass_purity"].ToString(),bodyContent)),

                 new PdfPCell(new Phrase("data1",bodyContent)),

                new PdfPCell(new Phrase("",bodyContent))
                };

                foreach (PdfPCell cell in bodyLineAnalysisDataMassecuiteC1)
                {
                    cell.HorizontalAlignment = Element.ALIGN_LEFT;
                    table.AddCell(cell);
                }

                // Analysis Data - Massecuite-c Syrup
                PdfPCell[] bodyLineAnalysisDataMassecuiteC = new PdfPCell[]{
             

                 new PdfPCell(new Phrase( "Massecuite C             Sugar % Cane"+Environment.NewLine+
                                          "                         Fiber % Cane"+Environment.NewLine+
                                          "                         Purity",bodyContent)),

                  new PdfPCell(new Phrase(dt.Rows[0]["c_mass_pol"].ToString()+Environment.NewLine+
                                          dt.Rows[0]["c_mass_brix"].ToString()+Environment.NewLine+
                                          dt.Rows[0]["c_mass_purity"].ToString(),bodyContent)),

                 new PdfPCell(new Phrase("data1",bodyContent)),

                new PdfPCell(new Phrase("",bodyContent))
                };

                foreach (PdfPCell cell in bodyLineAnalysisDataMassecuiteC)
                {
                    cell.HorizontalAlignment = Element.ALIGN_LEFT;
                    table.AddCell(cell);
                }
                #endregion





                #endregion
                document.Add(table);
                document.Close();
                fs.Close();
            }
            catch (IOException ex)
            {
                MessageBox.Show("IOException occured while processing report.\nException Message: " + ex.Message + "\nFor more details kindly check log.", "IOException", MessageBoxButtons.OK, MessageBoxIcon.Error);
                expHelper.statusMsg = Environment.NewLine + "IOException occured while processing report.\nException Message: " + ex.Message + "\nStack Trace: " + ex.StackTrace + Environment.NewLine;
            }
            catch (Exception exp)
            {
                MessageBox.Show("Generic Exception occured while processing report.\nException Message: " + exp.Message + "\nFor more details kindly check log.", "Generic Exception", MessageBoxButtons.OK, MessageBoxIcon.Error);
                expHelper.statusMsg = Environment.NewLine + "Generic Exception occured while processing report.\nException Message: " + exp.Message + "\nStack Trace: " + exp.StackTrace + Environment.NewLine;
            }
        
           
        }
    }
}
