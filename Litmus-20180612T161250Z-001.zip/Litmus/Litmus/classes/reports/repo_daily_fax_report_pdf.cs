﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Data;
using Microsoft.ApplicationBlocks.Data;
using iTextSharp.text;
using iTextSharp.text.pdf;

namespace Litmus.classes.reports
{
    class repo_daily_fax_report_pdf
    {

        private void generate_data_for_fax_report(string report_data)
        {

        }
    }
}
