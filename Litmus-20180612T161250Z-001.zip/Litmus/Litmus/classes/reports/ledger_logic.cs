﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using Microsoft.ApplicationBlocks.Data;
using System.Windows.Forms;
namespace Litmus.classes.reports
{
    class ledger_logic
    {
        DbConnections dbConn = new DbConnections();
        classes.ExceptionHelper expHelper = new ExceptionHelper();
        public DataTable get_ledgerData(string startDate, string endDate)
        {
            DataTable dt_first_page = null;
           

            List<SqlParameter> param = new List<SqlParameter>();
            param.Add(new SqlParameter("from_date", startDate));
            param.Add(new SqlParameter("to_date", endDate));
            try
            {
                dt_first_page = SqlHelper.ExecuteDataset(dbConn.sqlConn(), CommandType.StoredProcedure, "proc_rv_repo_ledger_one", param.ToArray()).Tables[0];
               
            }
            catch (SqlException ex)
            {
                expHelper.statusMsg = "Error:" + ex.Message;
            }
            return dt_first_page;
        }
        public DataTable get_ledger_second_page(string startDate, string endDate)
        {
            
            DataTable dt_second_page = null;

            List<SqlParameter> param = new List<SqlParameter>();
            param.Add(new SqlParameter("from_date", startDate));
            param.Add(new SqlParameter("to_date", endDate));
            try
            {

                dt_second_page = SqlHelper.ExecuteDataset(dbConn.sqlConn(), CommandType.StoredProcedure, "proc_rv_repo_ledger_two", param.ToArray()).Tables[0];
            }
            catch (SqlException ex)
            {
                expHelper.statusMsg = "Error:" + ex.Message;
            }
            catch (Exception ex)
            {
                expHelper.statusMsg = "Error:" + ex.Message;
            }
            return dt_second_page;
        }
        public DataTable get_ledger_third_page(string startDate, string endDate)
        {

            DataTable dt_third_page = null;

            List<SqlParameter> param = new List<SqlParameter>();
            param.Add(new SqlParameter("from_date", startDate));
            param.Add(new SqlParameter("to_date", endDate));
            try
            {
                dt_third_page = SqlHelper.ExecuteDataset(dbConn.sqlConn(), CommandType.StoredProcedure, "proc_rv_repo_ledger_three", param.ToArray()).Tables[0];
            }
            catch (SqlException ex)
            {
                expHelper.statusMsg = "Error:" + ex.Message;
            }
            catch (Exception ex)
            {
                expHelper.statusMsg = "Error:" + ex.Message;
            }
            return dt_third_page;
        }
        public DataTable get_ledger_fourth_page(string startDate, string endDate)
        {

            DataTable dt_fourt_page = null;

            List<SqlParameter> param = new List<SqlParameter>();
            param.Add(new SqlParameter("from_date", startDate));
            param.Add(new SqlParameter("to_date", endDate));
            try
            {

                dt_fourt_page = SqlHelper.ExecuteDataset(dbConn.sqlConn(), CommandType.StoredProcedure, "proc_repo_ledger_four", param.ToArray()).Tables[0];
            }
            catch (SqlException ex)
            {
                expHelper.statusMsg = "Error:" + ex.Message;
            }
            catch (Exception ex)
            {
                expHelper.statusMsg = "Error:" + ex.Message;
            }
            return dt_fourt_page;
        }

        public DataTable get_ledger_fifth_page(string startDate, string endDate)
        {

            DataTable dt_fifth_page = null;

            List<SqlParameter> param = new List<SqlParameter>();
            param.Add(new SqlParameter("from_date", startDate));
            param.Add(new SqlParameter("to_date", endDate));
            try
            {

                dt_fifth_page = SqlHelper.ExecuteDataset(dbConn.sqlConn(), CommandType.StoredProcedure, "proc_repo_ledger_five", param.ToArray()).Tables[0];
            }
            catch (SqlException ex)
            {
                expHelper.statusMsg = "Error:" + ex.Message;
            }
            catch (Exception ex)
            {
                expHelper.statusMsg = "Error:" + ex.Message;
            }
            return dt_fifth_page;
        }

        public DataTable get_ledger_sixth_page(string startDate, string endDate)
        {

            DataTable dt_sixth_page = null;

            List<SqlParameter> param = new List<SqlParameter>();
            param.Add(new SqlParameter("from_date", startDate));
            param.Add(new SqlParameter("to_date", endDate));
            try
            {

                dt_sixth_page = SqlHelper.ExecuteDataset(dbConn.sqlConn(), CommandType.StoredProcedure, "proc_rv_repo_ledger_six", param.ToArray()).Tables[0];
            }
            catch (SqlException ex)
            {
                expHelper.statusMsg = "Error:" + ex.Message;
            }
            catch (Exception ex)
            {
                expHelper.statusMsg = "Error:" + ex.Message;
            }
            return dt_sixth_page;
        }
        public DataTable get_ledger_seventh_page(string startDate, string endDate)
        {

            DataTable dt_seventh_page = null;

            List<SqlParameter> param = new List<SqlParameter>();
            param.Add(new SqlParameter("from_date", startDate));
            param.Add(new SqlParameter("to_date", endDate));
            try
            {

                dt_seventh_page = SqlHelper.ExecuteDataset(dbConn.sqlConn(), CommandType.StoredProcedure, "proc_rv_repo_ledger_seven", param.ToArray()).Tables[0];
            }
            catch (SqlException ex)
            {
                expHelper.statusMsg = "Error:" + ex.Message;
            }
            catch (Exception ex)
            {
                expHelper.statusMsg = "Error:" + ex.Message;
            }
            return dt_seventh_page;
        }
        // page eight
        public DataTable get_ledger_eight_page(string startDate, string endDate)
        {

            DataTable dt_eight_page = null;

            List<SqlParameter> param = new List<SqlParameter>();
            param.Add(new SqlParameter("from_date", startDate));
            param.Add(new SqlParameter("to_date", endDate));
            try
            {

                dt_eight_page = SqlHelper.ExecuteDataset(dbConn.sqlConn(), CommandType.StoredProcedure, "proc_rv_repo_ledger_eight", param.ToArray()).Tables[0];
            }
            catch (SqlException ex)
            {
                expHelper.statusMsg = "Error:" + ex.Message;
            }
            catch (Exception ex)
            {
                expHelper.statusMsg = "Error:" + ex.Message;
            }
            return dt_eight_page;
        }

        // page NINE
        public DataTable get_ledger_nine_page(string startDate, string endDate)
        {

            DataTable dt_nine_page = null;

            List<SqlParameter> param = new List<SqlParameter>();
            param.Add(new SqlParameter("from_date", startDate));
            param.Add(new SqlParameter("to_date", endDate));
            try
            {

                dt_nine_page = SqlHelper.ExecuteDataset(dbConn.sqlConn(), CommandType.StoredProcedure, "proc_rv_repo_ledger_nine", param.ToArray()).Tables[0];
            }
            catch (SqlException ex)
            {
                expHelper.statusMsg = "Error:" + ex.Message;
            }
            catch (Exception ex)
            {
                expHelper.statusMsg = "Error:" + ex.Message;
            }
            return dt_nine_page;
        }

        // page TEN
        public DataTable get_ledger_ten_page(string startDate, string endDate)
        {

            DataTable dt_nine_page = null;

            List<SqlParameter> param = new List<SqlParameter>();
            param.Add(new SqlParameter("from_date", startDate));
            param.Add(new SqlParameter("to_date", endDate));
            try
            {

                dt_nine_page = SqlHelper.ExecuteDataset(dbConn.sqlConn(), CommandType.StoredProcedure, "proc_rv_repo_ledger_ten", param.ToArray()).Tables[0];
            }
            catch (SqlException ex)
            {
                expHelper.statusMsg = "Error:" + ex.Message;
            }
            catch (Exception ex)
            {
                expHelper.statusMsg = "Error:" + ex.Message;
            }
            return dt_nine_page;
        }
        // page Elevn
        public DataTable get_ledger_eleven_page(string startDate, string endDate)
        {

            DataTable dt_nine_page = null;

            List<SqlParameter> param = new List<SqlParameter>();
            param.Add(new SqlParameter("from_date", startDate));
            param.Add(new SqlParameter("to_date", endDate));
            try
            {

                dt_nine_page = SqlHelper.ExecuteDataset(dbConn.sqlConn(), CommandType.StoredProcedure, "proc_rv_repo_ledger_eleven", param.ToArray()).Tables[0];
            }
            catch (SqlException ex)
            {
                expHelper.statusMsg = "Error:" + ex.Message;
            }
            catch (Exception ex)
            {
                expHelper.statusMsg = "Error:" + ex.Message;
            }
            return dt_nine_page;
        }
        // page Twelve
        public DataTable get_ledger_twelve_page(string startDate, string endDate)
        {

            DataTable dt_nine_page = null;

            List<SqlParameter> param = new List<SqlParameter>();
            param.Add(new SqlParameter("from_date", startDate));
            param.Add(new SqlParameter("to_date", endDate));
            try
            {

                dt_nine_page = SqlHelper.ExecuteDataset(dbConn.sqlConn(), CommandType.StoredProcedure, "proc_rv_repo_ledger_twelve", param.ToArray()).Tables[0];
            }
            catch (SqlException ex)
            {
                expHelper.statusMsg = "Error:" + ex.Message;
            }
            catch (Exception ex)
            {
                expHelper.statusMsg = "Error:" + ex.Message;
            }
            return dt_nine_page;
        }
        // page Thirteen
        public DataTable get_ledger_thirteen_page(string startDate, string endDate)
        {

            DataTable dt_thirteeen_page = null;

            List<SqlParameter> param = new List<SqlParameter>();
            param.Add(new SqlParameter("from_date", startDate));
            param.Add(new SqlParameter("to_date", endDate));
            try
            {

                dt_thirteeen_page = SqlHelper.ExecuteDataset(dbConn.sqlConn(), CommandType.StoredProcedure, "proc_rv_repo_ledger_thirteen", param.ToArray()).Tables[0];
            }
            catch (SqlException ex)
            {
                expHelper.statusMsg = "Error:" + ex.Message;
            }
            catch (Exception ex)
            {
                expHelper.statusMsg = "Error:" + ex.Message;
            }
            return dt_thirteeen_page;
        }
    }
}
