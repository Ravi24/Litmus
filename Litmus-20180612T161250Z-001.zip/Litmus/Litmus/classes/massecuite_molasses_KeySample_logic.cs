﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using Microsoft.ApplicationBlocks.Data;

namespace Litmus.classes
{
    class massecuite_molasses_KeySample_logic
    {
        classes.generalFunctions genFunc = new generalFunctions();
        DbConnections dbConn = new DbConnections();
        classes.ExceptionHelper expHelper = new ExceptionHelper();
        public int insertMassecuiteRecord(int massecuite_type, string trans_date, string trans_time,  float hydro_liter, int pan_no, string start_time, string drop_time, 
                                            int cryst_no,float brix, float pol,float purity)
        {
            int insertedRecords = 0;
            string sql = @"insert into analysis_massecuite(m_param_type_code, m_trans_date, m_trans_time, m_hl, m_pan_no, m_start_time, " +
                        " m_drop_time, m_crystal_no, m_brix, m_pol, m_purity, crtd_by ) " + 
                        "values (@m_param_type_code, @m_tarns_date, @m_trans_time, @m_hl, @m_pan_no, @m_start_time, " +
                        " @m_drop_time, @m_crystal_no, @m_brix, @m_pol, @m_purity, @crtd_by)";

            List<SqlParameter> param = new List<SqlParameter>();
            param.Add(new SqlParameter("@m_param_type_code", massecuite_type));
            param.Add(new SqlParameter("@m_tarns_date", trans_date));
            param.Add(new SqlParameter("@m_trans_time", trans_time));
            param.Add(new SqlParameter("@m_hl", hydro_liter));
            param.Add(new SqlParameter("@m_pan_no", pan_no));
            param.Add(new SqlParameter("@m_start_time", start_time));
            param.Add(new SqlParameter("@m_drop_time", drop_time));
            param.Add(new SqlParameter("@m_crystal_no", cryst_no));
            param.Add(new SqlParameter("@m_brix", brix));
            param.Add(new SqlParameter("@m_pol", pol));
            param.Add(new SqlParameter("@m_purity", purity));
            param.Add(new SqlParameter("@crtd_by", genFunc.userCode ));

            try
            {
                insertedRecords = SqlHelper.ExecuteNonQuery(dbConn.sqlConn(), CommandType.Text, sql, param.ToArray());
                MessageBox.Show(insertedRecords + " record(s) inserted!", "Success!", MessageBoxButtons.OK, MessageBoxIcon.Information);

            }
            catch (Exception ex)
            {
                expHelper.statusMsg = "ERROR: "+ex.Message +"\n Stack Trace - "+ ex.StackTrace;
                MessageBox.Show("Error occured while saving records.\nError message - " + ex.Message, "Error!!", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            return insertedRecords;
        }
    }
}
