﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data;
using System.Data.SqlClient;
using Microsoft.ApplicationBlocks.Data;
using System.ComponentModel;


namespace Litmus.classes
{///<summary>
 /// This analysis data will be filled by Lab head only. This is a 24 hourly data i.e. data for one field will be filled only once in a day, however 
 /// update will be available for user.
 /// --- User dont want to get bounded to fill all fields at a time i.e. if he gets details for few parameters, he will fill them and save data,
 /// later when he gets other parameters for the same day; he will just open the form containing previously entered parameters detals
 /// and will fill recently received parameters, however if he want to update previously filled/saved parameters he can update them
 /// </summary>
    class day_analysis_logic
    {
        //classes.generalFunctions genfun = new generalFunctions();
        classes.ExceptionHelper expHandle = new ExceptionHelper();
        
        DbConnections dbConn = new DbConnections();
      /// <summary>
      /// Return Type Boolean\n
      /// Here we are cheking either entry for the selected date exists or not? If it exists True will be returned and we will show existing data
      /// and on save button click event we will
      /// fire an UPDATE command, if it does not exists False will be returned and on save button click event we will fire an Insert Command
      /// </summary>
      /// <param name="transaction_date">Transaction Date (String)</param>
      /// <returns></returns>
        public bool entryExistsForTheDay(string transaction_date)
        {
            bool entryExists = false;
            int count = 0;
            string sql = @"select count(1) from transactions_daily where trans_date = @transaction_date";
            List<SqlParameter> param = new List<SqlParameter>();
            try
            {
                param.Add(new SqlParameter("transaction_date", transaction_date));
                count = Convert.ToInt16(SqlHelper.ExecuteScalar(dbConn.sqlConn(), CommandType.Text, sql, param.ToArray()));
                if (count > 0)
                {
                    entryExists = true;
                }
            }
            catch (SqlException ex)
            {
                MessageBox.Show("Exception: " + ex.Message + "\nFor more details please check log file");
                    expHandle.statusMsg = "ERROR while trying to count number of records in transactions_day table for the day!\nException Message" + ex.Message +
                                         "\nStack Trace = " + ex.StackTrace;
            }
            finally
            {
                
            }
            return entryExists;
        }
        public float totalSugarBagsforTheDay(string entryDate)
        {
            float totalSugarBags = 0;
            string sql = @"select isnull(sum(sugar_bags_total),0) from transactions_hourly where entry_Date = @entryDate";
            List<SqlParameter> param = new List<SqlParameter>();
            try
            {
                param.Add(new SqlParameter("@entryDate", entryDate));
                totalSugarBags = float.Parse(SqlHelper.ExecuteScalar(dbConn.sqlConn(), CommandType.Text, sql, param.ToArray()).ToString());
            }
            catch (SqlException ex)
            {
                MessageBox.Show("Could not get total number of bags produced on " + entryDate + "!\n Error Message :- " + ex.Message + "\nFor more details check error log", "Error Occured", MessageBoxButtons.OK, MessageBoxIcon.Error);
                expHandle.statusMsg = "Could not get total number of bags produced on " + entryDate + "!\n Error Message :- " + ex.Message + "\nStack Trace - " + ex.StackTrace;
            }
            return totalSugarBags;
        }
        
        /// <summary>
        /// 
        /// Here trying to get transaction details for the selected date.
        /// </summary>
        /// <param name="transactionDate"></param>
        /// <returns></returns>
        public DataTable getDailyAnalysisDataForTheDay(string transactionDate)
        {
            DataTable dt = null;
            string sql = @"select * from transactions_daily where trans_date = @transactionDate";
            List<SqlParameter> param = new List<SqlParameter>();
            param.Add(new SqlParameter("transactionDate", transactionDate));
            try
            {
                dt = SqlHelper.ExecuteDataset(dbConn.sqlConn(), CommandType.Text, sql, param.ToArray()).Tables[0];
            }
            catch (SqlException ex)
            {
                MessageBox.Show("Exception occured while trying to get Daily Analysis Data for " + transactionDate + "!\n Check error log for more details", "Exception", MessageBoxButtons.OK, MessageBoxIcon.Error);
               
                    expHandle.statusMsg = "ERROR occured while trying to get Daily Analysis Data for " + transactionDate + "\nStack Trace - " + ex.StackTrace;
            }
            
            return dt;
        }
        public int insertDailyAnalysis(string trans_date, string trans_time, float early, float general, float rejected, float gate, float centre, float cane_crushed,
            float total_juice, float sp_gravity, float total_water, float press_cake, float molasses_sent_out, float biss_sugar, float biss_molasses,
            float scrap_sugar, float scrap_molasses, float moist_sugar, float moist_molasses, float raw_sugar, float raw_molasses, float other_sugar, float other_molasses,
            float unknow_losses, float dirt_correction,
            float store_sulpher, float store_phosphoric, float store_lime, float viscosity_reducer, float biocide, float color_reducer, float magnafloe,
            float lub_oil, float lub_grease, float boiler_chemical,
            float icumsa_l31, float icumsa_l30, float icumsa_m31, float icumsa_m30, float icumsa_s31, float icumsa_s30, float foreign_matter_l31, float foreign_matter_l30, float
            foreign_matter_m31, float foreign_matter_m30, float foreign_matter_s31, float foreign_matter_s30, float retention_l31, float retention_l30, float retention_m31, 
            float retention_m30, float retention_s31, float retention_s30, 
            float etp_ph, float etp_tss, float etp_cod, float etp_bod, float etp_water_flow,
            float calcium_mixed_juice, float calcium_clear_juice, float phosphate_mixed_juice, float phosphate_clear_juice, 
            float total_operation_tubewell, float exhaust_condensate_recovery, float no_of_80t_c_massecuite_pan,
            float ph_injection_inlet, float ph_injection_outlet, float average_vaccume_pan, float average_vaccume_evap, float Exhaust_steam_press_lp, 
            float Exhaust_steam_press_hp, float boiler_steam_press_lp, float boiler_steam_press_hp, float ph_boiler_feed_water, float boiler_water, float bagasse_baed, float power_from_uppcb, float
            power_export_uppcb, float filter_water, float pan_water, float cf_water, float bagasse_sold, float bagasse_stock, float nm_p_index, float nm_pry_ext, float om_p_index, float om_pry_ext, float
            trs_percentage, float rs_percentage, float temp_max, float temp_min, float humidity, float rain_fall, float iu_primary_juice, float iu_mixed_juice, float
            iu_clear_juice, float ph_primary_juice, float ph_mixed_juice, float live_steam_generation, float live_steam_consumption, float power_turbines, float bleeding_in_process, 
            float bleeding_acf, float ata_cogen, float d_sulpher_heating, float drain_pipe_loss, float exhaust_steam_generation, float exhaust_steam_consumption, float steam_per_ton_of_cane,
            float steam_per_qtl_of_sugar,
            float turbine_25, float turbine_3_new, float turbine_3_old, float turbine_1, float
            dg_set, float power_import_cogen, float total_power, float power_per_ton_of_cane, float power_per_qtl_of_sugar, string crtd_by, float steam_per_cane, float cane_farm)
        {
            int insertedRows = 0;
            string sql = @"insert into transactions_daily(trans_date, trans_time, cane_early, cane_general, cane_rejected, cane_gate, cane_centre, cane_crushed, total_juice, sp_gravity, total_water, " +
                           " press_cake, molasses_sent_out, biss_sugar, biss_molasses, scrap_sugar, scrap_molasses, moist_sugar, moist_molasses, " +
                           " raw_sugar, raw_molasses, other_sugar, other_molasses, unknown_losses, dirt_correction, store_sulpher, store_phosphoric, " +
                           " store_lime, store_viscosity_reducer, store_biocide, store_color_reducer, store_megnafloe, store_lub_oil, store_lub_grease, store_boiler_chemical, " +
                           " icumsa_l31, icumsa_l30, icumsa_m31, icumsa_m30, icumsa_s31, icumsa_s30, foreign_matter_l31, foreign_matter_l30, " +
                           " foreign_matter_m31, foreign_matter_m30, foreign_matter_s31, foreign_matter_s30, retention_l31, retention_l30, retention_m31, retention_m30, " +
                           " retention_s31, retention_s30, etp_ph, etp_tss, etp_cod, etp_bod, etp_water_flow, calcium_mixed_juice, " +
                           " calcium_clear_juice, phosphate_mixed_juice, phosphate_clear_juice,total_operating_tube_well, exhaust_condensate_recovery,T_c_massecuite_pan, " + 
                           " ph_injection_inlet, ph_injection_outlet, average_vaccume_pan, average_vaccume_evap, " +
                           " Exhaust_steam_press_lp, Exhaust_steam_press_hp, boiler_steam_press_lp, boiler_steam_press_hp, ph_boiler_feed_water, boiler_water, bagasse_baed, power_from_uppcb, " +
                           " power_export_uppcb, filter_water, pan_water, cf_water, bagasse_sold, bagasse_stock, nm_p_index, nm_pry_ext,  om_p_index, om_pry_ext, " +
                           " trs_percentage, rs_percentage, temp_max, temp_min, humidity, rain_fall, iu_primary_juice, iu_mixed_juice, " +
                           " iu_clear_juice, ph_primary_juice, ph_mixed_juice, live_steam_generation, live_steam_consumption, power_turbines, bleeding_in_process, bleeding_acf, " +
                           " ata3_cogen, d_sulpher_heating, drain_pipe_loss, exhaust_steam_generation, exhaust_steam_consumption, steam_per_ton_cane, steam_per_qtl_sugar, " + 
                           " turbine_25_mw, turbine_three_mw_new, turbine_three_mw_old, turbine_1_mw, " +
                           " dg_set, power_import_cogen, total_power, power_per_ton_cane, power_per_qtl_sugar, crtd_by, steam_percent_cane, cane_farm) values " +

                           " (  @trans_date,@trans_time,@early,@general,@rejected, @gate, @centre, @cane_crushed, @total_juice,@sp_gravity,@total_water," +
                            "   @press_cake,@molasses_sent_out,@biss_sugar,@biss_molasses,@scrap_sugar, @scrap_molasses, @moist_sugar, @moist_molasses, "+
                            "   @raw_sugar, @raw_molasses, @other_sugar, @other_molasses, @unknown_losses, @dirt_correction,@store_sulpher,@store_phosphoric," +
                            "  @store_lime,@viscosity_reducer,@biocide,@color_reducer,@magnafloe,@lub_oil,@lub_grease,@boiler_chemical," +
                            "  @icumsa_l31,@icumsa_l30,@icumsa_m31,@icumsa_m30,@icumsa_s31,@icumsa_s30,@foreign_matter_l31,@foreign_matter_l30," +
                            "  @foreign_matter_m31,@foreign_matter_m30,@foreign_matter_s31,@foreign_matter_s30,@retention_l31,@retention_l30,@retention_m31,@retention_m30," +
                            "  @retention_s31,@retention_s30, @etp_ph, @etp_tss, @etp_cod, @etp_bod, @etp_waterflow, @calcium_mixed_juice," +
                            "  @calcium_clear_juice,@phosphate_mixed_juice,@phosphate_clear_juice,@total_operating_tubewell,@exhaust_condensate_recovery, @t_c_massecuite_pan, " + 
                            " @ph_injection_inlet,@ph_injection_outlet," +
                            "  @average_vaccume_pan,@average_vaccume_evap," +
                            "  @Exhaust_steam_press_lp,@Exhaust_steam_press_hp,@boiler_steam_press_lp,@boiler_steam_press_hp,@ph_boiler_feed_water, @boiler_water, @bagasse_baed,@power_from_uppcb," +
                            "  @power_export_uppcb,@filter_water,@pan_water,@cf_water,@bagasse_sold,@bagasse_stock,@nm_p_index,@nm_pry_ext,@om_p_index,@om_pry_ext," +
                            "  @trs_percentage,@rs_percentage,@temp_max,@temp_min,@humidity,@rain_fall,@iu_primary_juice,@iu_mixed_juice," +
                            "  @iu_clear_juice,@ph_primary_juice,@ph_mixed_juice,@live_steam_generation,@live_steam_consumption,@power_turbines,@bleeding_in_process,@bleeding_acf," +
                            "  @ata_cogen,@d_sulpher_heating, @drain_pipe_loss,@exhaust_steam_generation,@exhaust_steam_consumption,@steam_per_ton_cane, @steam_per_qtl_sugar, " + 
                            " @turbine_25mw,@turbine_three_mw_new, @turbine_three_mw_old,@turbine_1_mw," +
                            "  @dg_set,@power_import_cogen,@total_power,@power_per_ton_cane, @power_per_qtl_sugar, @crtd_by, @steam_per_cane, @cane_farm)";
            List<SqlParameter> param = new List<SqlParameter>();
            try
            {
                param.Add(new SqlParameter("@trans_date", trans_date)); param.Add(new SqlParameter("@trans_time", trans_time));
                param.Add(new SqlParameter("@early", early)); param.Add(new SqlParameter("@general", general));
                param.Add(new SqlParameter("@rejected", rejected));
                param.Add(new SqlParameter("@gate", gate)); param.Add(new SqlParameter("@centre", centre)); param.Add(new SqlParameter("@cane_crushed", cane_crushed));
                param.Add(new SqlParameter("@total_juice", total_juice));
                param.Add(new SqlParameter("@sp_gravity", sp_gravity)); param.Add(new SqlParameter("@total_water", total_water));
                param.Add(new SqlParameter("@press_cake", press_cake)); param.Add(new SqlParameter("@molasses_sent_out", molasses_sent_out));
                param.Add(new SqlParameter("@biss_sugar", biss_sugar)); param.Add(new SqlParameter("@biss_molasses", biss_molasses));
                param.Add(new SqlParameter("@scrap_sugar", scrap_sugar));
                param.Add(new SqlParameter("@scrap_molasses", scrap_molasses));
                param.Add(new SqlParameter("@moist_sugar", moist_sugar));
                param.Add(new SqlParameter("@moist_molasses", moist_molasses));
                param.Add(new SqlParameter("@raw_sugar", raw_sugar));
                param.Add(new SqlParameter("@raw_molasses", raw_molasses));
                param.Add(new SqlParameter("@other_sugar", other_sugar));
                param.Add(new SqlParameter("@other_molasses", other_molasses));
                param.Add(new SqlParameter("@unknown_losses", unknow_losses));
                param.Add(new SqlParameter("@dirt_correction", dirt_correction)); param.Add(new SqlParameter("@store_sulpher", store_sulpher));
                param.Add(new SqlParameter("@store_phosphoric", store_phosphoric)); param.Add(new SqlParameter("@store_lime", store_lime));
                param.Add(new SqlParameter("@viscoSity_reducer", viscosity_reducer)); param.Add(new SqlParameter("@biocide", biocide));
                param.Add(new SqlParameter("@color_reducer", color_reducer)); param.Add(new SqlParameter("@magnafloe", magnafloe));
                param.Add(new SqlParameter("@lub_oil", lub_oil)); param.Add(new SqlParameter("@lub_grease", lub_grease));
                param.Add(new SqlParameter("@boiler_chemical", boiler_chemical)); 
                param.Add(new SqlParameter("@icumsa_l31", icumsa_l31)); param.Add(new SqlParameter("@icumsa_l30", icumsa_l30));
                param.Add(new SqlParameter("@icumsa_m31", icumsa_m31)); param.Add(new SqlParameter("@icumsa_m30", icumsa_m30));
                param.Add(new SqlParameter("@icumsa_s31", icumsa_s31)); param.Add(new SqlParameter("@icumsa_s30", icumsa_s30));
                param.Add(new SqlParameter("@foreign_matter_l31", foreign_matter_l31)); param.Add(new SqlParameter("@foreign_matter_l30", foreign_matter_l30));
                param.Add(new SqlParameter("@foreign_matter_m31", foreign_matter_m31)); param.Add(new SqlParameter("@foreign_matter_m30", foreign_matter_m30));
                param.Add(new SqlParameter("@foreign_matter_s31", foreign_matter_s31)); param.Add(new SqlParameter("@foreign_matter_s30", foreign_matter_s30));
                param.Add(new SqlParameter("@retention_l31", retention_l31)); param.Add(new SqlParameter("@retention_l30", retention_l30));
                param.Add(new SqlParameter("@retention_m31", retention_m31)); param.Add(new SqlParameter("@retention_m30", retention_m30));
                param.Add(new SqlParameter("@retention_s31", retention_s31)); param.Add(new SqlParameter("@retention_s30", retention_s30));
                param.Add(new SqlParameter("@etp_ph", etp_ph)); param.Add(new SqlParameter("@etp_tss", etp_tss)); param.Add(new SqlParameter("@etp_cod", etp_cod));
                param.Add(new SqlParameter("@etp_bod", etp_bod)); param.Add(new SqlParameter("@etp_waterflow", etp_water_flow));
                param.Add(new SqlParameter("@calcium_mixed_juice", calcium_mixed_juice));
                param.Add(new SqlParameter("@calcium_clear_juice", calcium_clear_juice)); param.Add(new SqlParameter("@phosphate_mixed_juice", phosphate_mixed_juice));
                param.Add(new SqlParameter("@phosphate_clear_juice", phosphate_clear_juice));
                param.Add(new SqlParameter("@total_operating_tubewell", total_operation_tubewell));
                param.Add(new SqlParameter("@exhaust_condensate_recovery", exhaust_condensate_recovery));
                param.Add(new SqlParameter("@t_c_massecuite_pan", no_of_80t_c_massecuite_pan));
                param.Add(new SqlParameter("@ph_injection_inlet", ph_injection_inlet)); param.Add(new SqlParameter("@ph_injection_outlet", ph_injection_outlet));
                param.Add(new SqlParameter("@average_vaccume_pan", average_vaccume_pan)); param.Add(new SqlParameter("@average_vaccume_evap", average_vaccume_evap));
                param.Add(new SqlParameter("@Exhaust_steam_press_lp", Exhaust_steam_press_lp)); param.Add(new SqlParameter("@Exhaust_steam_press_hp", Exhaust_steam_press_hp));
                param.Add(new SqlParameter("@boiler_steam_press_lp", boiler_steam_press_lp)); param.Add(new SqlParameter("@boiler_steam_press_hp", boiler_steam_press_hp));
                param.Add(new SqlParameter("@ph_boiler_feed_water", ph_boiler_feed_water));
                param.Add(new SqlParameter("@boiler_water", boiler_water));
                param.Add(new SqlParameter("@bagasse_baed", bagasse_baed)); param.Add(new SqlParameter("@power_from_uppcb", power_from_uppcb));
                param.Add(new SqlParameter("@power_export_uppcb", power_export_uppcb)); param.Add(new SqlParameter("@filter_water", filter_water));
                param.Add(new SqlParameter("@pan_water", pan_water)); param.Add(new SqlParameter("@cf_water", cf_water));
                param.Add(new SqlParameter("@bagasse_sold", bagasse_sold)); param.Add(new SqlParameter("@bagasse_stock", bagasse_stock));
                param.Add(new SqlParameter("@nm_p_index", nm_p_index)); param.Add(new SqlParameter("@nm_pry_ext", nm_pry_ext));
                param.Add(new SqlParameter("@om_p_index", om_p_index)); param.Add(new SqlParameter("@om_pry_ext", om_pry_ext));
                param.Add(new SqlParameter("@trs_percentage", trs_percentage)); param.Add(new SqlParameter("@rs_percentage", rs_percentage));
                param.Add(new SqlParameter("@temp_max", temp_max)); param.Add(new SqlParameter("@temp_min", temp_min));
                param.Add(new SqlParameter("@humidity", humidity)); param.Add(new SqlParameter("@rain_fall", rain_fall));
                param.Add(new SqlParameter("@iu_primary_juice", iu_primary_juice)); param.Add(new SqlParameter("@iu_mixed_juice", iu_mixed_juice));
                param.Add(new SqlParameter("@iu_clear_juice", iu_clear_juice)); param.Add(new SqlParameter("@ph_primary_juice", ph_primary_juice));
                param.Add(new SqlParameter("@ph_mixed_juice", ph_mixed_juice)); param.Add(new SqlParameter("@live_steam_generation", live_steam_generation));
                param.Add(new SqlParameter("@live_steam_consumption", live_steam_consumption)); param.Add(new SqlParameter("@power_turbines", power_turbines));
                param.Add(new SqlParameter("@bleeding_in_process", bleeding_in_process)); param.Add(new SqlParameter("@bleeding_acf", bleeding_acf));
                param.Add(new SqlParameter("@ata_cogen", ata_cogen));
                param.Add(new SqlParameter("@d_sulpher_heating", d_sulpher_heating));
                param.Add(new SqlParameter("@drain_pipe_loss", drain_pipe_loss));
                param.Add(new SqlParameter("@exhaust_steam_generation", exhaust_steam_generation)); param.Add(new SqlParameter("@exhaust_steam_consumption", exhaust_steam_consumption));
                param.Add(new SqlParameter("@steam_per_ton_cane", steam_per_ton_of_cane));
                param.Add(new SqlParameter("@steam_per_qtl_sugar", steam_per_qtl_of_sugar));
                param.Add(new SqlParameter("@turbine_25mw", turbine_25));
                param.Add(new SqlParameter("@turbine_three_mw_new", turbine_3_new)); param.Add(new SqlParameter("@turbine_three_mw_old", turbine_3_old));
                param.Add(new SqlParameter("@turbine_1_mw", turbine_1));
                param.Add(new SqlParameter("@dg_set", dg_set)); param.Add(new SqlParameter("@power_import_cogen", power_import_cogen));
                param.Add(new SqlParameter("@total_power", total_power));
                param.Add(new SqlParameter("@power_per_ton_cane", power_per_ton_of_cane));
                param.Add(new SqlParameter("@power_per_qtl_sugar", power_per_qtl_of_sugar));
                param.Add(new SqlParameter("@crtd_by", crtd_by));
                param.Add(new SqlParameter("@steam_per_cane", steam_per_cane));
                param.Add(new SqlParameter("@cane_farm", cane_farm));

                insertedRows = SqlHelper.ExecuteNonQuery(dbConn.sqlConn(), CommandType.Text, sql, param.ToArray());
                if (insertedRows == 1)
                {
                    MessageBox.Show(insertedRows + " record(s) saved!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                else if (insertedRows > 1)
                {
                    MessageBox.Show(insertedRows + " record(s) saved!\nMore than one record saved, kindly contact to administrater before proceeding.", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                }
                else
                {
                    MessageBox.Show(insertedRows + " record(s) saved!", "Failed", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                }
            }
            catch (SqlException ex)
            {
                MessageBox.Show("Exception occured while insert record in transactions_daily table!\n Error Message-"+ex.Message+"\nCheck error log for more details", "Exception", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    expHandle.statusMsg = "ERROR occured while updating record in transactions_daily table !\n Error Message-"+ex.Message+"\nStack Trace - " + ex.StackTrace;
            }

            return insertedRows;
        }

        public int updateDailyAnalysis(string trans_date, string trans_time, float early, float general, float rejected, float gate, float centre, float cane_crushed,
            float total_juice, float sp_gravity, float total_water, float press_cake, float molasses_sent_out, float biss_sugar, float biss_molasses,
            float scrap_sugar, float scrap_molasses, float moist_sugar, float moist_molasses, float raw_sugar, float raw_molasses, float other_sugar, float other_molasses,
            float unknow_losses, float dirt_correction,
            float store_sulpher, float store_phosphoric, float store_lime, float viscosity_reducer, float biocide, float color_reducer, float magnafloe,
            float lub_oil, float lub_grease, float boiler_chemical,
            float icumsa_l31, float icumsa_l30, float icumsa_m31, float icumsa_m30, float icumsa_s31, float icumsa_s30, float foreign_matter_l31, float foreign_matter_l30, float
            foreign_matter_m31, float foreign_matter_m30, float foreign_matter_s31, float foreign_matter_s30, float retention_l31, float retention_l30, float retention_m31,
            float retention_m30, float retention_s31, float retention_s30,
            float etp_ph, float etp_tss, float etp_cod, float etp_bod, float etp_water_flow,
            float calcium_mixed_juice, float calcium_clear_juice, float phosphate_mixed_juice, float phosphate_clear_juice,
            float total_operation_tubewell, float exhaust_condensate_recovery, float no_of_80t_c_massecuite_pan,
            float ph_injection_inlet, float ph_injection_outlet, float average_vaccume_pan, float average_vaccume_evap, float Exhaust_steam_press_lp,
            float Exhaust_steam_press_hp, float boiler_steam_press_lp, float boiler_steam_press_hp, float ph_boiler_feed_water, float boiler_water, float bagasse_baed, float power_from_uppcb, float
            power_export_uppcb, float filter_water, float pan_water, float cf_water, float bagasse_sold, float bagasse_stock, float nm_p_index, float nm_pry_ext, float om_p_index, float om_pry_ext,
            float trs_percentage, float rs_percentage, float temp_max, float temp_min, float humidity, float rain_fall, float iu_primary_juice, float iu_mixed_juice, float
            iu_clear_juice, float ph_primary_juice, float ph_mixed_juice, float live_steam_generation, float live_steam_consumption, float power_turbines, float bleeding_in_process,
            float bleeding_acf, float ata_cogen, float d_sulpher_heating, float drain_pipe_loss, float exhaust_steam_generation, float exhaust_steam_consumption, float steam_per_ton_of_cane,
            float steam_per_qtl_of_sugar,
            float turbine_25, float turbine_3_new, float turbine_3_old, float turbine_1, float
            dg_set, float power_import_cogen, float total_power, float power_per_ton_of_cane, float power_per_qtl_of_sugar, string updt_dt, string updt_by, float steam_per_cane, float cane_farm)
        {

           
            int updatedRecords = 0;
            
            string sql = @"update transactions_daily set  trans_time = @trans_time, cane_early = @cane_early, cane_general = @cane_general, cane_rejected = @cane_rejected " +
                " ,cane_centre = @cane_centre, cane_gate = @cane_gate, cane_crushed = @cane_crushed, total_juice = @total_juice, sp_gravity = @sp_gravity, total_water = @total_water " +
                ", press_cake = @press_cake, molasses_sent_out = @molasses_sent_out, biss_sugar = @biss_sugar, biss_molasses = @biss_molasses, scrap_sugar = @scrap_sugar, scrap_molasses = @scrap_molasses" +
                ", moist_sugar = @moist_sugar, moist_molasses = @moist_molasses, raw_sugar = @raw_sugar, raw_molasses = @raw_molasses, other_sugar = @other_sugar,other_molasses = @other_molasses, store_sulpher = @store_sulpher " +
                ", store_phosphoric = @store_phosphoric, store_lime = @store_lime, store_viscosity_reducer = @store_viscosity_reducer, store_biocide= @store_biocide "+
                ", store_color_reducer = @store_color_reducer, store_megnafloe = @store_magnafloe, store_lub_oil = @store_lub_oil " +
                ", store_lub_grease = @store_lub_grease, store_boiler_chemical = @store_boiler_chemical " +
                ", icumsa_l31 = @icumsa_l31, icumsa_l30 = @icumsa_l30, icumsa_m31 = @icumsa_m31, icumsa_m30 = @icumsa_m30, icumsa_s31 = @icumsa_s31 , icumsa_s30 = @icumsa_s30 " +
                ", foreign_matter_l31 = @foreign_matter_l31, foreign_matter_l30 = @foreign_matter_l30, foreign_matter_m31 = @foreign_matter_m31, foreign_matter_m30 = @foreign_matter_m30, foreign_matter_s31 = @foreign_matter_s31, foreign_matter_s30 = @foreign_matter_s30 " +
                ", retention_l31 = @retention_l31, retention_l30 = @retention_l30, retention_m31 = @retention_m31, retention_m30 = @retention_m30, retention_s31 = @retention_s31, retention_s30 = @retention_s30 " +
                ", etp_ph = @etp_ph, etp_tss = @etp_tss, etp_cod = @etp_cod, etp_bod = @etp_bod, etp_water_flow = @etp_waterflow, calcium_mixed_juice = @calcium_mixed_juice " +
                ", calcium_clear_juice = @calcium_clear_juice, phosphate_mixed_juice = @phosphate_mixed_juice, phosphate_clear_juice = @phosphate_clear_juice, unknown_losses = @unknown_losses " +
                ", dirt_correction = @dirt_correction, total_operating_tube_well = @total_operating_tubewell, exhaust_condensate_recovery = @exhaust_condensate_recovery, T_c_massecuite_pan = @T_c_massecuite_pan " +
                ", ph_injection_inlet= @ph_injection_inlet, ph_injection_outlet =@ph_injection_outlet, average_vaccume_pan =@average_vaccume_pan, average_vaccume_evap = @average_vaccume_evap " +
                ", Exhaust_steam_press_lp = @Exhaust_steam_press_lp, Exhaust_steam_press_hp=@Exhaust_steam_press_hp, boiler_steam_press_lp=@boiler_steam_press_lp, boiler_steam_press_hp=@boiler_steam_press_hp " +
                ", ph_boiler_feed_water=@ph_boiler_feed_water, boiler_water = @boiler_water, bagasse_baed=@bagasse_baed, power_from_uppcb=@power_from_uppcb, power_export_uppcb=@power_export_uppcb, filter_water=@filter_water " +
                ", pan_water=@pan_water, cf_water=@cf_water, bagasse_sold=@bagasse_sold, bagasse_stock=@bagasse_stock, nm_p_index=@nm_p_index, nm_pry_ext=@nm_pry_ext , om_p_index=@om_p_index, om_pry_ext=@om_pry_ext " +
                ", trs_percentage = @trs_percentage, rs_percentage=@rs_percentage, temp_max = @temp_max, temp_min=@temp_min, humidity=@humidity, rain_fall=@rain_fall, iu_primary_juice =@iu_primary_juice " +
                ", iu_mixed_juice =@iu_mixed_juice, iu_clear_juice=@iu_clear_juice, ph_primary_juice=@ph_primary_juice, ph_mixed_juice=@ph_mixed_juice, live_steam_generation =@live_steam_generation " +
                ", live_steam_consumption = @live_steam_consumption , bleeding_in_process=@bleeding_in_process, bleeding_acf =@bleeding_acf, ata3_cogen =@ata3_cogen " +
                ", d_sulpher_heating=@d_sulpher_heating, drain_pipe_loss=@drain_pipe_loss, exhaust_steam_generation=@exhaust_steam_generation, exhaust_steam_consumption=@exhaust_steam_consumption " +
                ", steam_per_ton_cane = @steam_per_ton_cane, steam_per_qtl_sugar=@steam_per_qtl_sugar, turbine_25_mw=@turbine_25_mw, turbine_three_mw_new=@turbine_three_mw_new " +
                ", turbine_three_mw_old=@turbine_three_mw_old, turbine_1_mw=@turbine_1_mw,dg_set=@dg_set,power_import_cogen=@power_import_cogen, total_power = @total_power " +
                ", power_per_ton_cane=@power_per_ton_cane,power_per_qtl_sugar=@power_per_qtl_sugar, updt_dt=@updt_dt, updt_by=@updt_by, steam_percent_cane = @steam_per_cane, cane_farm = @cane_farm" +
                " where trans_date = @trans_date" ; 
            List<SqlParameter> param = new List<SqlParameter>();
            try
            {
                param.Add(new SqlParameter("@trans_date", trans_date));
                param.Add(new SqlParameter("@trans_time", trans_time));
                param.Add(new SqlParameter("@cane_early", early)); param.Add(new SqlParameter("@cane_general", general));
                param.Add(new SqlParameter("@cane_rejected", rejected));
                param.Add(new SqlParameter("@cane_gate", gate)); param.Add(new SqlParameter("@cane_centre", centre)); param.Add(new SqlParameter("@cane_crushed", cane_crushed));
                param.Add(new SqlParameter("@total_juice", total_juice));
                param.Add(new SqlParameter("@sp_gravity", sp_gravity)); param.Add(new SqlParameter("@total_water", total_water));
                param.Add(new SqlParameter("@press_cake", press_cake)); param.Add(new SqlParameter("@molasses_sent_out", molasses_sent_out));
                param.Add(new SqlParameter("@biss_sugar", biss_sugar)); param.Add(new SqlParameter("@biss_molasses", biss_molasses));
                param.Add(new SqlParameter("@scrap_sugar", scrap_sugar));
                param.Add(new SqlParameter("@scrap_molasses", scrap_molasses));
                param.Add(new SqlParameter("@moist_sugar", moist_sugar));
                param.Add(new SqlParameter("@moist_molasses", moist_molasses));
                param.Add(new SqlParameter("@raw_sugar", raw_sugar));
                param.Add(new SqlParameter("@raw_molasses", raw_molasses));
                param.Add(new SqlParameter("@other_sugar", other_sugar));
                param.Add(new SqlParameter("@other_molasses", other_molasses));
                param.Add(new SqlParameter("@unknown_losses", unknow_losses));
                param.Add(new SqlParameter("@dirt_correction", dirt_correction)); param.Add(new SqlParameter("@store_sulpher", store_sulpher));
                param.Add(new SqlParameter("@store_phosphoric", store_phosphoric)); param.Add(new SqlParameter("@store_lime", store_lime));
                param.Add(new SqlParameter("@store_viscosity_reducer", viscosity_reducer)); param.Add(new SqlParameter("@store_biocide", biocide));
                param.Add(new SqlParameter("@store_color_reducer", color_reducer)); param.Add(new SqlParameter("@store_magnafloe", magnafloe));
                param.Add(new SqlParameter("@store_lub_oil", lub_oil)); param.Add(new SqlParameter("@store_lub_grease", lub_grease));
                param.Add(new SqlParameter("@store_boiler_chemical", boiler_chemical));
                param.Add(new SqlParameter("@icumsa_l31", icumsa_l31)); param.Add(new SqlParameter("@icumsa_l30", icumsa_l30));
                param.Add(new SqlParameter("@icumsa_m31", icumsa_m31)); param.Add(new SqlParameter("@icumsa_m30", icumsa_m30));
                param.Add(new SqlParameter("@icumsa_s31", icumsa_s31)); param.Add(new SqlParameter("@icumsa_s30", icumsa_s30));
                param.Add(new SqlParameter("@foreign_matter_l31", foreign_matter_l31)); param.Add(new SqlParameter("@foreign_matter_l30", foreign_matter_l30));
                param.Add(new SqlParameter("@foreign_matter_m31", foreign_matter_m31)); param.Add(new SqlParameter("@foreign_matter_m30", foreign_matter_m30));
                param.Add(new SqlParameter("@foreign_matter_s31", foreign_matter_s31)); param.Add(new SqlParameter("@foreign_matter_s30", foreign_matter_s30));
                param.Add(new SqlParameter("@retention_l31", retention_l31)); param.Add(new SqlParameter("@retention_l30", retention_l30));
                param.Add(new SqlParameter("@retention_m31", retention_m31)); param.Add(new SqlParameter("@retention_m30", retention_m30));
                param.Add(new SqlParameter("@retention_s31", retention_s31)); param.Add(new SqlParameter("@retention_s30", retention_s30));
                param.Add(new SqlParameter("@etp_ph", etp_ph)); param.Add(new SqlParameter("@etp_tss", etp_tss)); param.Add(new SqlParameter("@etp_cod", etp_cod));
                param.Add(new SqlParameter("@etp_bod", etp_bod)); param.Add(new SqlParameter("@etp_waterflow", etp_water_flow));
                param.Add(new SqlParameter("@calcium_mixed_juice", calcium_mixed_juice));
                param.Add(new SqlParameter("@calcium_clear_juice", calcium_clear_juice)); param.Add(new SqlParameter("@phosphate_mixed_juice", phosphate_mixed_juice));
                param.Add(new SqlParameter("@phosphate_clear_juice", phosphate_clear_juice));
                param.Add(new SqlParameter("@total_operating_tubewell", total_operation_tubewell));
                param.Add(new SqlParameter("@exhaust_condensate_recovery", exhaust_condensate_recovery));
                param.Add(new SqlParameter("@t_c_massecuite_pan", no_of_80t_c_massecuite_pan));
                param.Add(new SqlParameter("@ph_injection_inlet", ph_injection_inlet)); param.Add(new SqlParameter("@ph_injection_outlet", ph_injection_outlet));
                param.Add(new SqlParameter("@average_vaccume_pan", average_vaccume_pan)); param.Add(new SqlParameter("@average_vaccume_evap", average_vaccume_evap));
                param.Add(new SqlParameter("@Exhaust_steam_press_lp", Exhaust_steam_press_lp)); param.Add(new SqlParameter("@Exhaust_steam_press_hp", Exhaust_steam_press_hp));
                param.Add(new SqlParameter("@boiler_steam_press_lp", boiler_steam_press_lp)); param.Add(new SqlParameter("@boiler_steam_press_hp", boiler_steam_press_hp));
                param.Add(new SqlParameter("@ph_boiler_feed_water", ph_boiler_feed_water));
                param.Add(new SqlParameter("@boiler_water", boiler_water));
                param.Add(new SqlParameter("@bagasse_baed", bagasse_baed)); param.Add(new SqlParameter("@power_from_uppcb", power_from_uppcb));
                param.Add(new SqlParameter("@power_export_uppcb", power_export_uppcb)); param.Add(new SqlParameter("@filter_water", filter_water));
                param.Add(new SqlParameter("@pan_water", pan_water)); param.Add(new SqlParameter("@cf_water", cf_water));
                param.Add(new SqlParameter("@bagasse_sold", bagasse_sold)); param.Add(new SqlParameter("@bagasse_stock", bagasse_stock));
                param.Add(new SqlParameter("@nm_p_index", nm_p_index)); param.Add(new SqlParameter("@nm_pry_ext", nm_pry_ext));
                param.Add(new SqlParameter("@om_p_index", om_p_index)); param.Add(new SqlParameter("@om_pry_ext", om_pry_ext));
                param.Add(new SqlParameter("@trs_percentage", trs_percentage)); param.Add(new SqlParameter("@rs_percentage", rs_percentage));
                param.Add(new SqlParameter("@temp_max", temp_max)); param.Add(new SqlParameter("@temp_min", temp_min));
                param.Add(new SqlParameter("@humidity", humidity)); param.Add(new SqlParameter("@rain_fall", rain_fall));
                param.Add(new SqlParameter("@iu_primary_juice", iu_primary_juice)); param.Add(new SqlParameter("@iu_mixed_juice", iu_mixed_juice));
                param.Add(new SqlParameter("@iu_clear_juice", iu_clear_juice)); param.Add(new SqlParameter("@ph_primary_juice", ph_primary_juice));
                param.Add(new SqlParameter("@ph_mixed_juice", ph_mixed_juice)); param.Add(new SqlParameter("@live_steam_generation", live_steam_generation));
                param.Add(new SqlParameter("@live_steam_consumption", live_steam_consumption)); param.Add(new SqlParameter("@power_turbines", power_turbines));
                param.Add(new SqlParameter("@bleeding_in_process", bleeding_in_process)); param.Add(new SqlParameter("@bleeding_acf", bleeding_acf));
                param.Add(new SqlParameter("@ata3_cogen", ata_cogen));
                param.Add(new SqlParameter("@d_sulpher_heating", d_sulpher_heating));
                param.Add(new SqlParameter("@drain_pipe_loss", drain_pipe_loss));
                param.Add(new SqlParameter("@exhaust_steam_generation", exhaust_steam_generation)); param.Add(new SqlParameter("@exhaust_steam_consumption", exhaust_steam_consumption));
                param.Add(new SqlParameter("@steam_per_ton_cane", steam_per_ton_of_cane));
                param.Add(new SqlParameter("@steam_per_qtl_sugar", steam_per_qtl_of_sugar));
                param.Add(new SqlParameter("@turbine_25_mw", turbine_25));
                param.Add(new SqlParameter("@turbine_three_mw_new", turbine_3_new)); param.Add(new SqlParameter("@turbine_three_mw_old", turbine_3_old));
                param.Add(new SqlParameter("@turbine_1_mw", turbine_1));
                param.Add(new SqlParameter("@dg_set", dg_set)); param.Add(new SqlParameter("@power_import_cogen", power_import_cogen));
                param.Add(new SqlParameter("@total_power", total_power));
                param.Add(new SqlParameter("@power_per_ton_cane", power_per_ton_of_cane));
                param.Add(new SqlParameter("@power_per_qtl_sugar", power_per_qtl_of_sugar));
                param.Add(new SqlParameter("@updt_by", updt_by));
                param.Add(new SqlParameter("@updt_dt", updt_dt));
                param.Add(new SqlParameter("@steam_per_cane", steam_per_cane));
                param.Add(new SqlParameter("@cane_farm", cane_farm));
                updatedRecords = SqlHelper.ExecuteNonQuery(dbConn.sqlConn(), CommandType.Text, sql, param.ToArray());

                if (updatedRecords == 1)
                {
                    MessageBox.Show(updatedRecords + " record(s) modified!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                else if (updatedRecords > 1)
                {
                    MessageBox.Show(updatedRecords + " record(s) modified!\nMore than one record modified, kindly contact to administrater before proceeding.", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                }
                else
                {
                    MessageBox.Show(updatedRecords + " record(s) modified!", "Failed", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                }
            }
            catch (SqlException ex)
            {
                MessageBox.Show("Exception occured while updating record in transactions_daily table !\nError Message"+ex.Message +"\nCheck error log for more details", "Exception", MessageBoxButtons.OK, MessageBoxIcon.Error);
                expHandle.statusMsg = "ERROR occured while updating record in transactions_daily table !\nError Message "+ex.Message+"\nStack Trace - " + ex.StackTrace;
                
            }
            return updatedRecords;
        }

    }
}
