﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Data;
using Microsoft.ApplicationBlocks.Data;
using System.Windows.Forms;
namespace Litmus.classes
{
    class melting_logic
    {
        DbConnections dbConn = new DbConnections();
        classes.ExceptionHelper expHelper = new ExceptionHelper();

        public void insertMeltingData(string trans_date, string trans_time, int melting_code, float brix, float pol, float purity, string crtdBy)
        {
            string @sql = "insert into analysis_melting(trans_date, trans_time, m_code, brix, pol, purity, crtd_by) " +
                        " values (@trans_date, @trans_time, @m_code, @brix, @pol, @purity, @crtd_by)";
            List<SqlParameter> param = new List<SqlParameter>();
            param.Add(new SqlParameter("@trans_date", trans_date));
            param.Add(new SqlParameter("@trans_time", trans_time));
            param.Add(new SqlParameter("@m_code", melting_code));
            param.Add(new SqlParameter("@brix", brix));
            param.Add(new SqlParameter("@pol", pol));
            param.Add(new SqlParameter("@purity", purity));
            param.Add(new SqlParameter("@crtd_by", crtdBy));
            try
            {
                int insertedRecords = SqlHelper.ExecuteNonQuery(dbConn.sqlConn(), CommandType.Text, sql, param.ToArray());
                MessageBox.Show(insertedRecords + " records saved!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (SqlException ex)
            {
                MessageBox.Show("Error occured while inserting records for melting data.\nError Message- "+ex.Message+"\nFor more details please check error file", "Error!", MessageBoxButtons.OK, MessageBoxIcon.Error);
                expHelper.statusMsg = "ERR:occured while inserting records for melting data.\nError Message- " + ex.Message + "\nStack Trace" + ex.StackTrace;
            }
        }
    }
}
