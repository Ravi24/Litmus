﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Litmus.forms.transactional_forms
{
    public partial class frm_meltings : Form
    {
        classes.generalFunctions genFunc = new classes.generalFunctions();
        classes.melting_logic meltingLogic = new classes.melting_logic();
        classes.ExceptionHelper expHelper=  new classes.ExceptionHelper();
        classes.master_parameter_logic masterParam = new classes.master_parameter_logic();
        int meltingCode;
        float brix, pol, purity;
        string trans_date, trans_time;

        public frm_meltings()
        {
            InitializeComponent();
            // convert to time format and check validity on text box time lost focus

            disableAllFields();
            txtBSugarTransTime.LostFocus += new EventHandler(convertToTime);
            txtCSingleSugarTransTime.LostFocus += new EventHandler(convertToTime);
            txtCDoubleTransTime.LostFocus += new EventHandler(convertToTime);
            txtMeltTransTime.LostFocus += new EventHandler(convertToTime);
            txtDrySeedTransTime.LostFocus += new EventHandler(convertToTime);
            txtDustCollectorTransTime.LostFocus += new EventHandler(convertToTime);

            txtBSugarPurity.GotFocus += new EventHandler(setAllInputToVariables);
            txtCSinglePurity.GotFocus += new EventHandler(setAllInputToVariables);
            txtCDoublePurity.GotFocus += new EventHandler(setAllInputToVariables);
            txtMeltPurity.GotFocus += new EventHandler(setAllInputToVariables);
            txtDrySeedPurity.GotFocus += new EventHandler(setAllInputToVariables);
            txtDustCollectorPurity.GotFocus += new EventHandler(setAllInputToVariables);


            btnSave.GotFocus += new EventHandler(setAllInputToVariables);
            setDefaultEntryDate();
        }

        private void setDefaultEntryDate()
        {
            foreach (Control tabCtrl in tabMeltings.Controls)
            {
                foreach (Control childTab in tabCtrl.Controls)
                {

                    if (childTab.GetType() == typeof(DateTimePicker))
                        {
                            childTab.Text = masterParam.entryDate;
                        }
                    }
            }
        }

        private void resetAllFields()
        {
            foreach (Control tabCtrl in tabMeltings.Controls)
            {
                foreach (Control childTab in tabCtrl.Controls)
                {
                    if (childTab.GetType() == typeof(TextBox))
                    {
                        childTab.Text = "";
                    }
                }
                disableAllFields();
                btnNewRecord.Enabled = true;
            }
        }

       //disable all input fields

        private void disableAllFields()
        {
            genFunc.disableFieldsInControl(tabMeltings);
        }
        private void convertToTime(object sender, EventArgs e)
        {
            TextBox tempText = (TextBox)sender;
            tempText.Text = genFunc.parseHourMinuteFormat(tempText.Text);
            genFunc.validate_hours_minutes((TextBox)sender, btnSave);

        }

        /// <summary>
        /// melting codes are defined in table named parameter with param_category = 22
        /// in this method we are assigning values when Save button is focused.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void setAllInputToVariables(object sender, EventArgs e)
        {
            int tabIndax = tabMeltings.SelectedIndex;;
            switch (tabIndax)
            {
                case 0:
                    meltingCode = 32;
                    trans_date = txtBSugarTransDate.Text;
                    trans_time = txtBSugarTransTime.Text;
                    brix = float.Parse(txtBSugarBrix.Text);
                    pol = float.Parse(txtBSugarPol.Text);

                    purity = genFunc.calculate_purity(pol, brix);
                    txtBSugarPurity.Text = purity.ToString();
                    genFunc.validate_purity_percentage(txtBSugarPurity, btnSave);
                    break;
                case 1:
                    meltingCode = 33;
                    trans_date = txtCSugarTransDate.Text;
                    trans_time = txtCSingleSugarTransTime.Text;
                    brix = float.Parse(txtCSingleBrix.Text);
                    pol = float.Parse(txtCSinglePol.Text);
                    purity = genFunc.calculate_purity(pol, brix);
                    txtCSinglePurity.Text = purity.ToString();
                    genFunc.validate_purity_percentage(txtCSinglePurity, btnSave);
                    break;
                case 2:
                    // double sugar
                    meltingCode = 34;
                    trans_date = txtCDoubleTransDate.Text;
                    trans_time = txtCDoubleTransTime.Text;
                    brix = float.Parse(txtCDoubleBrix.Text);
                    pol = float.Parse(txtCDoublePol.Text);
                    purity = genFunc.calculate_purity(pol, brix);
                    txtCDoublePurity.Text = purity.ToString();
                    genFunc.validate_purity_percentage(txtCDoublePurity, btnSave);
                    break;
                case 3:
                    meltingCode = 35;
                    trans_date = txtMeltTransDate.Text;
                    trans_time = txtMeltTransTime.Text;
                    brix = float.Parse(txtMeltBrix.Text);
                    pol = float.Parse(txtMeltPol.Text);
                    purity = genFunc.calculate_purity(pol, brix);
                    txtMeltPurity.Text = purity.ToString();
                    genFunc.validate_purity_percentage(txtMeltPurity, btnSave);
                    break;
                case 4:
                    meltingCode = 36;
                    trans_date = txtDrySeedTransDate.Text;
                    trans_time = txtDrySeedTransTime.Text;
                    brix = float.Parse(txtDrySeedBrix.Text);
                    pol = float.Parse(txtDrySeedPol.Text);
                    purity = genFunc.calculate_purity(pol, brix);
                    txtDrySeedPurity.Text = purity.ToString();
                    genFunc.validate_purity_percentage(txtDrySeedPurity, btnSave);
                    break;
                case 5:
                    meltingCode = 37;
                    trans_date = txtDustCollectorTransDate.Text;
                    trans_time = txtDustCollectorTransTime.Text;
                    brix = float.Parse(txtDustCollectorBrix.Text);
                    pol = float.Parse(txtDustCollectorPol.Text);
                    purity = float.Parse(txtDustCollectorPurity.Text);
                    purity = genFunc.calculate_purity(pol, brix);
                    txtDustCollectorPurity.Text = purity.ToString();
                    genFunc.validate_purity_percentage(txtDustCollectorPurity, btnSave);
                    break;
                default:
                    MessageBox.Show("Melting code not found in 'Meltings'", "Error: Melt code not found", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    break;
            }
        }

        private void btnNewRecord_Click(object sender, EventArgs e)
        {
            genFunc.enableFieldsInControl(tabMeltings);
            btnNewRecord.Enabled = false;
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            string crtdBy = genFunc.userCode;
            DialogResult dialogResult = MessageBox.Show("Are you sure you want to save records?", "Sure to save?", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (dialogResult == System.Windows.Forms.DialogResult.Yes)
            {
                try
                {
                    meltingLogic.insertMeltingData(trans_date, trans_time, meltingCode, brix, pol, purity, crtdBy);
                    resetAllFields();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error occured while inserting records for melting data.\nError Message- " + ex.Message + "\nFor more details please check error file", "Error!", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    expHelper.statusMsg = "ERR:occured while inserting records for melting data.\nError Message- " + ex.Message + "\nStack Trace" + ex.StackTrace;
                }
                genFunc.disableFieldsInControl(tabMeltings);
                btnSave.Enabled = false;
                btnNewRecord.Enabled = true;
            }
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            resetAllFields();
            disableAllFields();
        }
       
        
    }
}
