﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Collections;
using Microsoft.ApplicationBlocks.Data;
using System.Reflection;
using Litmus.classes;
using Litmus.forms;
using System.Diagnostics;
using System.Net;

namespace Litmus 
{
    public partial class Login : Form
    {
        Litmus.DbConnections dbConn = new DbConnections();
        ExceptionHelper exceptionHelper = new ExceptionHelper();
        generalFunctions genFunc = new generalFunctions();

        private void Login_Load(object sender, EventArgs e)
        {
           txtPassword.KeyDown += new KeyEventHandler(key_enter_press_event);
           
           
        }
        private void key_enter_press_event(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                login_logic();
            }
        }
        public Login()
        {
            InitializeComponent();
        }
        private void btnExit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
            genFunc.authenticate_application();
            Assembly assembly = Assembly.GetExecutingAssembly();
            
            FileVersionInfo fileVersionInfo = FileVersionInfo.GetVersionInfo(assembly.Location);
            Console.Write("Application version := " + fileVersionInfo);
            if (fileVersionInfo.ProductVersion != genFunc.app_version)
            {
                Console.WriteLine("Application version mismatched");
                MessageBox.Show("It seems you are running older version of application. Get updated application", "Update your application", MessageBoxButtons.OK, MessageBoxIcon.Hand);
            }
           
            else
            {
                
                login_logic();
            }
        }

        private void login_logic()
        {
            string user_code = txtUsername.Text.Trim();
            string password = txtPassword.Text.Trim();
            int countUser = 0;
            bool user_session_start = false;
            DataTable dt = null;
            string query = @"select first_name, last_name, user_code, is_admin from user_master where user_code = @user_code and password = @password and isActive = 1";
            Console.WriteLine(" get user details sql = " + query); ;
            List<SqlParameter> param = new List<SqlParameter>();
            param.Add(new SqlParameter("@user_code", user_code));
            param.Add(new SqlParameter("@password", password));
            try
            {
                dt = SqlHelper.ExecuteDataset(dbConn.sqlConn(), CommandType.Text, query, param.ToArray()).Tables[0];
                
                foreach (DataRow row in dt.Rows)
                {
                    foreach (var item in row.ItemArray)
                    {
                        Console.WriteLine(item);
                        exceptionHelper.statusMsg = "ERROR: USER TABLE DATA" + item;
                    }
                }
                countUser = dt.Rows.Count;
                Console.WriteLine("User Count " + countUser);
                switch (countUser)
                {
                    case 0:
                        MessageBox.Show("No user exists with these details", "Invalid Credentials!", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                        exceptionHelper.statusMsg = "ERR: More than one user found for user code = " + user_code + "";
                        break;
                    case 1:

                        genFunc.userCode = dt.Rows[0]["user_code"].ToString();
                        genFunc.userName = dt.Rows[0]["first_name"].ToString();
                        Console.WriteLine("Is application enabled := "+genFunc.app_enabled.ToString());
                        if (genFunc.app_enabled == true)
                        {
                             
                            //this.Hide();
                            this.hideForm();
                            string hostName = Dns.GetHostName();
                            string ipAddress = Dns.GetHostByName(hostName).AddressList[0].ToString();
                            user_session_start = genFunc.user_session_start(user_code,ipAddress,hostName);
                            if (user_session_start == true )
                            {
                                Form1 mainForm = new Form1();
                                mainForm.Show();
                            }
                            else
                            {
                                MessageBox.Show("Unable to create user session!", "Failed", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                                Application.Exit();
                            }
                        }
                        else if( genFunc.app_enabled == false && Convert.ToBoolean(dt.Rows[0]["is_admin"]) == true)
                        {
                            Console.WriteLine("Appllication is disabled from database end. User is logged in as an administrator");
                            //MessageBox.Show(genFunc.app_message+"\nAdmin is making some important changes in application.\nKindly avoid to save any data!", "Do not make any changees", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                            this.hideForm();
                            Form1 mainForm = new Form1();
                            mainForm.Show();
                        }
                        else
                        {
                            Console.WriteLine("Application is disable by administrator. User does not belongs to admin group");
                            MessageBox.Show(genFunc.app_message, "Application is disabled by administrator", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                            Application.Exit();
                        }
                        

                        break;
                    default:
                        MessageBox.Show("More than one user found with same credential", "User Exception!", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        exceptionHelper.statusMsg = "ERR: More than one user found for user code = " + user_code + "";
                        break;
                }
            }
            catch (SqlException ex)
            {
                MessageBox.Show("Invalid credentials!\n" + ex.Message, "Un-authorized access!", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                exceptionHelper.statusMsg = "ERR:" + ex.Message;
                Application.Exit();
            }
        }

        private void linkConfigureDatabase_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            Litmus.forms.master_forms.frm_db_configuration form = new forms.master_forms.frm_db_configuration();
            form.ShowDialog();
        }

        
    }
}
