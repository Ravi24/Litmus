﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Reflection;
using System.Diagnostics;
using System.Net;


namespace Litmus
{
    public partial class Form1 : Form
    {
        classes.generalFunctions genFunction = new classes.generalFunctions();
        classes.DbHelper dbHelper = new classes.DbHelper();
        classes.ExceptionHelper expHelper = new classes.ExceptionHelper();
        classes.master_parameter_logic masterParam = new classes.master_parameter_logic();

        Login frms = new Login();
        private int screenWidth, screenHeight;

        protected override void OnFormClosing(FormClosingEventArgs e)
        {
            base.OnFormClosing(e);
            if (e.CloseReason == CloseReason.UserClosing)
            {
                genFunction.user_session_end(genFunction.userCode);
                Application.Exit();
            }
        }

        public Form1()
        {
            InitializeComponent();
            masterParam.setParameters(); // initializing all default paramertes
            screenWidth = Screen.PrimaryScreen.Bounds.Width;
            screenHeight = Screen.PrimaryScreen.Bounds.Height;
            this.Width = screenWidth;
            this.Height = screenHeight-25;
            Assembly assembly = Assembly.GetExecutingAssembly();
            FileVersionInfo fileVersionInfo = FileVersionInfo.GetVersionInfo(assembly.Location);
            LblUserName2.Text = genFunction.userCode;
            txtAppVersion.Text = fileVersionInfo.ProductVersion;
            bindMenuItems();
            serverDetailsInFormTitle();
        }
        private void serverDetailsInFormTitle()
        {
            DataSet ds = genFunction.getDatabaseServerDetails();
            this.Text += " Connected To- " + ds.Tables[0].Rows[0]["machineName"].ToString() + "\\" + ds.Tables[0].Rows[0]["instanceName"].ToString() + "@" + ds.Tables[0].Rows[0]["db_name"].ToString();
        }

        public void bindMenuItems()
        {
            DataTable dt = dbHelper.getUserMasterMenu();
            MenuStrip menuStripLeft = new MenuStrip();
            menuStripLeft.Dock = DockStyle.Left;
            
            foreach (DataRow dr in dt.Rows)
            {
                ToolStripMenuItem menuItem = new ToolStripMenuItem(dr["mm_name"].ToString());
                menuItem.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
                bindSubMenu(menuItem,dr["mm_code"].ToString());
                menuItem.TextAlign = ContentAlignment.MiddleLeft;
                menuStripLeft.Items.Add(menuItem);
            }
            
            panel1.Controls.Add(menuStripLeft);
            panel1.Height = screenHeight; 
        }
        public void bindSubMenu(ToolStripMenuItem mnu,string menuCode)
        {
            DataTable dt = null;
            dt = dbHelper.getUserSubMenu(genFunction.userCode,menuCode);
            foreach (DataRow dr in dt.Rows)
            {
                ToolStripMenuItem subMenuItem = new ToolStripMenuItem(dr["mr_sub_menu_name"].ToString(),null,new EventHandler(subMenuClicked));
                subMenuItem.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
                mnu.DropDownItems.Add(subMenuItem);
            }
        }

        private void subMenuClicked(object sender, EventArgs e)
        {
            DataTable dt = dbHelper.subMenuDetails(sender.ToString(),genFunction.userCode);

            if (dt.Rows.Count > 0)
            {
                string selectedFormname = dt.Rows[0]["form_name"].ToString();
                string selectedFormUnqueCode = dt.Rows[0]["form_unique_code"].ToString();
                try
                {
                    string name = "Litmus." + selectedFormname;
                    var type = Type.GetType(name);
                    
                    // here changing user menu rights for the form which is about to open
                    genFunction.uniqueFormName = selectedFormname;
                    genFunction.uniqueFormCode = selectedFormUnqueCode;
                    genFunction.menuRights(selectedFormUnqueCode);
                    Form frm = Activator.CreateInstance(type) as Form;
                    
                    if (genFunction.userRights.Contains("R"))
                    {
                        frm.Show();
                        frm.ShowInTaskbar = true;
                    }
                    else MessageBox.Show("User is not permitted to open this form", "Read permission not assightned", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Form name " + selectedFormname + " does not exist.\n" + ex.Message, "Form not found", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    expHelper.statusMsg = "ERR: Form name " + selectedFormname + " does not exists\n" + ex.Message+"\nStack Trace: "+ex.StackTrace+"\n--------------------------";
                }
            }
            else
            {
                MessageBox.Show("This menu option is no more available for you", "Menu not availale", MessageBoxButtons.OK, MessageBoxIcon.Hand);
            }
        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
           
           int formcount = Application.OpenForms.Count;
           if (formcount > 2)
           {
               MessageBox.Show("Please close all forms before exit", "Close forms", MessageBoxButtons.OK, MessageBoxIcon.Stop);
           }
           else
           {
               DialogResult dialogResult = MessageBox.Show("Are you sure to exit?\n Save your all data before exit", "Sure to exit...", MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2);
               if (dialogResult == DialogResult.Yes)
               {
                   genFunction.user_session_end(genFunction.userCode);
                  
               }
           }
        }

        private void switchuserToolStripMenuItem_Click(object sender, EventArgs e)
        {
           
            Application.Restart();
            genFunction.user_session_end(genFunction.userCode);
            Environment.Exit(0);
        }


        //Application Setting form
        private void preferencesToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

    }
}
